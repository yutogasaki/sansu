import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import type { Problem } from "../../domain/types";
import { ExploreProblemPanel } from "./ExploreProblemPanel";

const arbitraryProblem: Problem = {
    id: "rapid-trail-arbitrary-problem",
    subject: "math",
    categoryId: "mul_arbitrary_family",
    questionText: "7 × 8",
    inputType: "number",
    correctAnswer: "56",
    isReview: false,
};

const visualSupportProblem: Problem = {
    ...arbitraryProblem,
    id: "rapid-trail-visual-support-problem",
    categoryId: "add_1d_1",
    questionText: "みかん 1こ と みかん 4こ あわせて いくつ？",
    correctAnswer: "5",
    questionVisual: {
        kind: "addition-items",
        groups: [
            { emoji: "🍊", label: "みかん", count: 1 },
            { emoji: "🍊", label: "みかん", count: 4 },
        ],
    },
};

const renderPanel = (completedSteps: number, feedback: "idle" | "correct" | "incorrect") => (
    renderToStaticMarkup(
        <ExploreProblemPanel
            problem={arbitraryProblem}
            answer={feedback === "idle" ? "" : "56"}
            prompt="こたえを しずくへ とどけよう"
            feedback={feedback}
            attemptCount={feedback === "incorrect" ? 1 : 0}
            combo={2}
            targetKind="flower"
            incorrectEnergyCost={1}
            completedSteps={completedSteps}
            inputDisabled={feedback !== "idle"}
            onAnswerChange={() => undefined}
            onSubmit={() => undefined}
        />,
    )
);

const renderMakimodonPanel = (
    completedSteps: number,
    feedback: "idle" | "correct" | "incorrect",
) => renderToStaticMarkup(
    <ExploreProblemPanel
        problem={arbitraryProblem}
        answer={feedback === "idle" ? "" : "56"}
        prompt="まきものの はしっこを みよう"
        feedback={feedback}
        attemptCount={feedback === "incorrect" ? 1 : 0}
        combo={2}
        targetKind="flower"
        incorrectEnergyCost={1}
        presentation="makimodon"
        completedSteps={completedSteps}
        inputDisabled={feedback !== "idle"}
        onAnswerChange={() => undefined}
        onSubmit={() => undefined}
    />,
);

const renderRootPullPanel = (
    completedSteps: number,
    feedback: "idle" | "correct" | "incorrect",
    version: "v1" | "v2" = "v1",
    payoffVariant: "dirt-hat" | "leaf-hat" = "dirt-hat",
) => renderToStaticMarkup(
    <ExploreProblemPanel
        problem={arbitraryProblem}
        answer={feedback === "idle" ? "" : "56"}
        prompt="はっぱを いっしょに ひっぱろう"
        feedback={feedback}
        attemptCount={feedback === "incorrect" ? 1 : 0}
        combo={2}
        targetKind="flower"
        incorrectEnergyCost={1}
        presentation="root-pull"
        completedSteps={completedSteps}
        rootPullAssetSet={version}
        rootPullPayoffVariant={payoffVariant}
        inputDisabled={feedback !== "idle"}
        onAnswerChange={() => undefined}
        onSubmit={() => undefined}
    />,
);

const renderSnapRootPanel = (
    completedSteps: number,
    feedback: "idle" | "correct" | "incorrect",
) => renderToStaticMarkup(
    <ExploreProblemPanel
        problem={arbitraryProblem}
        answer={feedback === "idle" ? "" : "56"}
        prompt="いっぽん葉を ひっぱろう"
        feedback={feedback}
        attemptCount={feedback === "incorrect" ? 1 : 0}
        combo={2}
        targetKind="flower"
        incorrectEnergyCost={1}
        presentation="snap-root"
        completedSteps={completedSteps}
        inputDisabled={feedback !== "idle"}
        onAnswerChange={() => undefined}
        onSubmit={() => undefined}
    />,
);

describe("ExploreProblemPanel rapid-trail art", () => {
    it("uses authored same-camera painted flower art", () => {
        const markup = renderPanel(3, "idle");

        expect(markup).toContain('data-camera-key="firefly-flower-side-v5"');
        expect(markup).toContain('data-visual-candidate-id="firefly-stumble-bloom-painted-v5"');
        expect(markup).toContain('data-visual-mode="world-painted"');
        expect(markup).toContain('data-stage="waiting"');
        expect(markup).not.toContain("scene-run-pop-v1.webp");
    });

    it("keeps arbitrary problem identity while showing the next physical clue", () => {
        const markup = renderPanel(4, "correct");

        expect(markup).toContain('data-question-text="7 × 8"');
        expect(markup).toContain('data-skill-id="mul_arbitrary_family"');
        expect(markup).toContain('data-stage="warm-bud"');
        expect(markup).toContain("でこぼこで 葉帽子が ぐらり。つぎ！");
    });

    it("does not advance the flower art after a wrong answer", () => {
        const markup = renderPanel(4, "incorrect");

        expect(markup).toContain('data-stage="dew-trail"');
        expect(markup).toContain("しずくは そのまま。もういちど");
        expect(markup).toContain('role="alert"');
    });

    it("shows the Q7 body payoff and keeps that settled plate for Q8", () => {
        const q7Correct = renderPanel(6, "correct");
        const q8Ready = renderPanel(7, "idle");

        expect(q7Correct).toContain('data-stage="light-path"');
        expect(q7Correct).toContain('data-light-path="complete"');
        expect(q7Correct).toContain("四つのしずくが、花のまんなかへ ぽちゃん！");
        expect(q8Ready).toContain('data-stage="light-path"');
        expect(q8Ready).toContain("ずれた葉帽子で、花の四滴を みよう");
        expect(q8Ready).toContain(">1</button>");
        expect(q8Ready).toContain(">2</button>");
        expect(q8Ready).toContain(">3</button>");
    });

    it("activates the compact mobile shelf only while visual support is shown", () => {
        const renderVisualSupport = (feedback: "idle" | "correct") => renderToStaticMarkup(
            <ExploreProblemPanel
                problem={visualSupportProblem}
                answer={feedback === "correct" ? "5" : ""}
                prompt="しずくを かぞえよう"
                feedback={feedback}
                attemptCount={0}
                combo={0}
                targetKind="flower"
                incorrectEnergyCost={1}
                completedSteps={3}
                inputDisabled={feedback === "correct"}
                onAnswerChange={() => undefined}
                onSubmit={() => undefined}
            />,
        );
        const ready = renderVisualSupport("idle");
        const correct = renderVisualSupport("correct");

        expect(ready).toContain(
            'class="explore-immersive-answer-shelf has-visual-support"',
        );
        expect(ready).toContain('class="explore-immersive-message is-ready"');
        expect(ready).toContain('aria-label="この問題の 数のヒント"');
        expect(ready).toContain('data-prompt-density="compact"');
        expect(correct).toContain('class="explore-immersive-answer-shelf"');
        expect(correct).not.toContain("has-visual-support");
        expect(correct).not.toContain("explore-immersive-message is-ready");
    });
});

describe("ExploreProblemPanel Makimodon cold open", () => {
    it("starts unnamed with the rolled-body cause while preserving the math problem", () => {
        const markup = renderMakimodonPanel(0, "idle");

        expect(markup).toContain('data-camera-key="makimodon-side-v1"');
        expect(markup).toContain('data-stage="rolled"');
        expect(markup).toContain('data-question-text="7 × 8"');
        expect(markup).toContain('data-skill-id="mul_arbitrary_family"');
        expect(markup).toContain("この まきまき、いきもの？");
        expect(markup).not.toContain("マキモドン");
    });

    it("does not advance its physical stage after a wrong answer", () => {
        const markup = renderMakimodonPanel(1, "incorrect");

        expect(markup).toContain('data-stage="trip"');
        expect(markup).toContain("まきまきは そのまま。もういちど");
        expect(markup).toContain('role="alert"');
    });

    it("shows the rewind-and-seat payoff on the third correct answer", () => {
        const markup = renderMakimodonPanel(2, "correct");

        expect(markup).toContain('data-stage="payoff"');
        expect(markup).toContain('data-band-reach="rewound-seat"');
        expect(markup).toContain("ぜんぶ まきもどった！");
        expect(markup).toContain("あいぼうが せなかへ どん。");
    });
});

describe("ExploreProblemPanel Root Pull opening", () => {
    it("starts on the authored ready plate without changing the math problem", () => {
        const markup = renderRootPullPanel(0, "idle");

        expect(markup).toContain('data-camera-key="opening-root-pull-side-v1"');
        expect(markup).toContain('data-stage="ready"');
        expect(markup).toContain("/assets/explore/opening-root-pull-v1/ready.webp");
        expect(markup).toContain('data-question-text="7 × 8"');
        expect(markup).toContain('data-skill-id="mul_arbitrary_family"');
        expect(markup).toContain("こたえて、ぐいっ！");
        expect(markup).not.toContain("この まきまき、いきもの？");
    });

    it("keeps the first committed pull visible after a wrong answer", () => {
        const markup = renderRootPullPanel(1, "incorrect");

        expect(markup).toContain('data-stage="small-pull"');
        expect(markup).toContain("/assets/explore/opening-root-pull-v1/pull-one.webp");
        expect(markup).toContain("まだ ぬけない。もういちど！");
        expect(markup).toContain('role="alert"');
    });

    it("shows the comic release on the third correct answer", () => {
        const markup = renderRootPullPanel(2, "correct");

        expect(markup).toContain('data-stage="comic-release"');
        expect(markup).toContain("/assets/explore/opening-root-pull-v1/payoff.webp");
        expect(markup).toContain('data-actor-state="safe-seated"');
        expect(markup).toContain('data-subject-state="free"');
        expect(markup).toContain("スポン！ しりもちも だいせいこう");
    });

    it("shows the v2 leaf-visor beat without removing the numeric keypad", () => {
        const markup = renderRootPullPanel(0, "correct", "v2", "leaf-hat");

        expect(markup).toContain('data-asset-set="v2"');
        expect(markup).toContain("/assets/explore/opening-root-pull-v2/pull-one.webp");
        expect(markup).toContain("ぺろん！ はっぱで まえが みえない");
        expect(markup).toContain(">1</button>");
        expect(markup).toContain(">2</button>");
        expect(markup).toContain(">3</button>");
    });

    it("shows the selected v2 payoff variant on the third correct answer", () => {
        const markup = renderRootPullPanel(2, "correct", "v2", "leaf-hat");

        expect(markup).toContain('data-payoff-variant="leaf-hat"');
        expect(markup).toContain("/assets/explore/opening-root-pull-v2/payoff-leaf-hat.webp");
        expect(markup).toContain("スポン！ はっぱぼうし だいせいこう");
    });
});

describe("ExploreProblemPanel Snap Root opening", () => {
    it("uses the painted dig-pop sequence and keeps the numeric keypad", () => {
        const markup = renderSnapRootPanel(0, "idle");

        expect(markup).toContain('data-opening-art="snap-root"');
        expect(markup).toContain('data-delivery-id="snap-root-v1"');
        expect(markup).toContain('data-visual-candidate-id="dig-pop-carry-bloom-v3"');
        expect(markup).toContain('data-camera-key="opening-snap-root-side-v2"');
        expect(markup).toContain('data-asset-variant="shared-landscape"');
        expect(markup).toContain('data-stage="ready"');
        expect(markup).toContain('data-actor-state="ready"');
        expect(markup).toContain('data-subject-state="planted"');
        expect(markup).toContain('data-action-state="ready"');
        expect(markup).toContain('data-contact-state="none"');
        expect(markup).toContain('data-subject-contact="none"');
        expect(markup).toContain('data-lift-contact="none"');
        expect(markup).toContain("/assets/explore/opening-snap-root-carry-bloom-v3/scene-ready.webp");
        expect(markup).not.toContain("scene-ready-tablet.webp");
        expect(markup).toContain(">1</button>");
        expect(markup).toContain(">2</button>");
        expect(markup).toContain(">3</button>");
    });

    it("holds its body stage on an incorrect answer", () => {
        const markup = renderSnapRootPanel(1, "incorrect");

        expect(markup).toContain('data-stage="dig-one"');
        expect(markup).toContain('data-actor-state="digging"');
        expect(markup).toContain('data-subject-state="rising"');
        expect(markup).toContain('data-action-state="dig-one"');
        expect(markup).toContain("/assets/explore/opening-snap-root-carry-bloom-v3/scene-dig-one.webp");
        expect(markup).toContain("だいじょうぶ。もういちど！");
        expect(markup).toContain('role="alert"');
    });

    it("shows one canonical safe full-body pop payoff", () => {
        const markup = renderSnapRootPanel(2, "correct");

        expect(markup).toContain('data-stage="popped"');
        expect(markup).toContain('data-actor-state="safe-seated"');
        expect(markup).toContain('data-subject-state="free-standing"');
        expect(markup).toContain('data-action-state="pop"');
        expect(markup).toContain('data-contact-state="none"');
        expect(markup).toContain("/assets/explore/opening-snap-root-carry-bloom-v3/scene-popped.webp");
        expect(markup).toContain("できた！ つちぼうし！");
        expect(markup).not.toContain("data-payoff-variant");
        expect(markup).not.toContain("data-watering-state");
        expect(markup).not.toContain("watering-ready.svg");
        expect(markup).not.toContain("actor-water-sheet.svg");
        expect(markup).not.toContain("編み根");
        expect(markup).not.toContain("着地");
    });
});
