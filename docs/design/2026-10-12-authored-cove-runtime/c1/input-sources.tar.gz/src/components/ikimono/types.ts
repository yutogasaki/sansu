export type IkimonoStage =
    | 'egg'       // 生まれる前
    | 'hatching'  // 生まれそう
    | 'small'     // 生体（小）
    | 'medium'    // 生体（中）
    | 'adult'     // 生体（成体）
    | 'fading'    // さよなら（フェードアウト中）
    | 'gone';     // 完全に去った → 次のライフサイクルへ

export interface IkimonoState {
    profileId: string;
    birthDate: string;   // ISO timestamp
    generation: number;  // ライフサイクル回数（1, 2, 3...）
    name?: string;       // 孵化時につけた名前
    species: number;     // 生き物の種類（0〜9）
}

export interface IkimonoGalleryEntry {
    profileId: string;
    generation: number;
    name: string;
    birthDate: string;      // ISO timestamp
    departedDate: string;   // ISO timestamp（gone になった日）
    species: number;        // 生き物の種類（0〜9）
}

/** 生き物の種類の数 */
export const SPECIES_COUNT = 10;
