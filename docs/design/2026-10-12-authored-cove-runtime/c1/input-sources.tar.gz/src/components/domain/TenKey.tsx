import React from "react";
import { Button } from "../ui/Button";
import { Icons } from "../icons";
import { cn } from "../../utils/cn";
import { acknowledgeAnswerConfirmation, useAnswerConfirmationDemonstrated } from './answerConfirmGuidance';
import './TenKey.css';

interface TenKeyProps {
    onInput: (val: number | string) => void;
    onDelete: () => void;
    onEnter: () => void;
    onClear: () => void;
    showDecimal?: boolean;
    nextFieldLabel?: string;
    nextFieldDisabled?: boolean;
    onCursorMove?: (direction: "left" | "right") => void;
    compact?: boolean;
    layout?: 'standard' | 'compact-three';
    disabled?: boolean;
    enterDisabled?: boolean;
    className?: string;
    minRowHeight?: number;
    enterLabel?: string;
    confirmationMode?: 'automatic' | 'manual';
    writtenInput?: boolean;
}

export const TenKey: React.FC<TenKeyProps> = ({
    onInput,
    onDelete,
    onEnter,
    onClear,
    showDecimal = false,
    nextFieldLabel,
    nextFieldDisabled = false,
    onCursorMove,
    compact = false,
    layout = 'standard',
    disabled = false,
    enterDisabled = false,
    className,
    minRowHeight,
    enterLabel = 'こたえる',
    confirmationMode,
    writtenInput = false,
}) => {
    const confirmationDemonstrated = useAnswerConfirmationDemonstrated();
    const confirmReady = confirmationMode === 'manual' && !disabled && !enterDisabled;
    const baseBtnClass = cn(
        "h-full w-full border border-white/75 bg-white/72 font-bold text-slate-700 shadow-[0_14px_24px_-20px_rgba(15,23,42,0.32)] transition-all active:scale-95 hover:bg-white/84",
        compact ? "text-lg rounded-xl mobile:text-sm" : "text-2xl rounded-2xl land:text-xl mobile:text-base"
    );
    const actionBtnClass = cn(
        "h-full w-full border border-white/75 bg-white/58 font-bold text-slate-500 shadow-[inset_0_1px_0_rgba(255,255,255,0.28)] transition-all active:scale-95 hover:bg-white/74",
        compact ? "text-base rounded-xl" : "text-xl rounded-2xl"
    );
    const iconClass = compact ? "w-5 h-5 mobile:w-4 mobile:h-4" : "w-6 h-6 mobile:w-5 mobile:h-5";
    const enterIconClass = compact ? "w-8 h-8 mobile:w-6 mobile:h-6 drop-shadow-md" : "w-10 h-10 mobile:w-8 mobile:h-8 drop-shadow-md";

    const showCursor = Boolean(onCursorMove) && !writtenInput;
    const extraKeys = Number(showDecimal) + (showCursor ? 2 : 0);
    const needsConfirmation = confirmationMode !== 'automatic';
    const sharedConfirmationRow = layout === 'compact-three' && extraKeys > 0;
    const auxiliaryKeys = extraKeys + Number(needsConfirmation);
    const enterButton = <Button
                disabled={disabled || enterDisabled}
                aria-label={enterLabel ?? 'こたえる'}
                data-keypad-submit
                data-confirmation-mode={confirmationMode}
                data-confirmation-state={confirmationMode ? confirmReady ? 'ready' : 'idle' : undefined}
                data-confirmation-cue={confirmReady && !confirmationDemonstrated ? 'intro' : undefined}
                onClick={() => {
                    if (confirmationMode === 'manual') acknowledgeAnswerConfirmation();
                    onEnter();
                }}
                className={cn(
                    "answer-confirm-key",
                    "flex h-full w-full flex-col items-center justify-center border border-cyan-200/80 bg-[linear-gradient(135deg,#2BBAA0,#5DC4D2)] text-white shadow-[0_18px_34px_-22px_rgba(34,197,214,0.62)] transition-all active:scale-95 hover:brightness-[1.03] mobile:text-base",
                    compact ? "rounded-xl" : "rounded-2xl"
                )}
                variant="ghost"
            >
                <Icons.Check className={enterIconClass} strokeWidth={3} />
                {!sharedConfirmationRow && <span className={cn("text-[10px] leading-none", enterLabel === 'こたえる' && "whitespace-nowrap")}>{enterLabel ?? 'こたえる'}</span>}
            </Button>;
    if (layout === 'compact-three') {
        return <div role="group" aria-label="すうじ キーパッド" aria-disabled={disabled}
            data-keypad-layout="compact-three"
            className={cn('ten-key-compact-three', className)}
            style={{ gridTemplateRows: `repeat(4, minmax(${Math.max(44, minRowHeight ?? 44)}px, 1fr))` }}>
            {[7, 8, 9, 4, 5, 6, 1, 2, 3].map(value => <Button key={value}
                disabled={disabled} aria-label={String(value)} onClick={() => onInput(value)} className={baseBtnClass} variant="ghost">{value}</Button>)}
            <Button disabled={disabled} aria-label="ひとつ もどす" onClick={onDelete} className={actionBtnClass} variant="ghost">
                <Icons.Backspace className={iconClass} />
            </Button>
            <Button disabled={disabled} aria-label="0" onClick={() => onInput(0)} className={baseBtnClass} variant="ghost">0</Button>
            <Button disabled={disabled} aria-label="こたえを けす" onClick={onClear} className={actionBtnClass} variant="ghost">C</Button>
            {auxiliaryKeys > 0 && <div className={cn("ten-key-extra-controls", needsConfirmation && "ten-key-confirm-control")}
                style={{ gridTemplateColumns: `repeat(${auxiliaryKeys}, minmax(44px, 1fr))` }}>
                {showCursor && <Button disabled={disabled} aria-label="カーソルを ひだりへ" onClick={() => onCursorMove?.('left')} className={actionBtnClass} variant="ghost">
                    <Icons.ArrowLeft className={iconClass} />
                </Button>}
                {showDecimal && <Button disabled={disabled} aria-label="しょうすうてん" onClick={() => onInput('.')} className={baseBtnClass} variant="ghost">.</Button>}
                {showCursor && <Button disabled={disabled || nextFieldDisabled} aria-label={nextFieldLabel ?? 'カーソルを みぎへ'} onClick={() => onCursorMove?.('right')} className={actionBtnClass} variant="ghost">
                    {nextFieldLabel ? <span>つぎ</span> : <Icons.ArrowRight className={iconClass} />}
                </Button>}
                {needsConfirmation && enterButton}
            </div>}
        </div>;
    }

    return (
        <div
            role="group"
            aria-label="すうじ キーパッド"
            aria-disabled={disabled}
            className={cn(
                "h-full w-full min-h-0 grid grid-cols-4 rounded-[28px] border border-white/70 bg-[linear-gradient(180deg,rgba(255,255,255,0.4),rgba(255,255,255,0.18))] p-3 shadow-[inset_0_1px_0_rgba(255,255,255,0.28)] mobile:p-2",
                compact ? "gap-2 mobile:gap-1.5" : "gap-3 mobile:gap-2",
                className,
            )}
            style={{ gridTemplateRows: `repeat(4, minmax(${minRowHeight ?? (compact ? 38 : 44)}px, 1fr))` }}
        >
            {/* Row 1 */}
            <Button disabled={disabled} aria-label="7" onClick={() => onInput(7)} className={baseBtnClass} variant="ghost">7</Button>
            <Button disabled={disabled} aria-label="8" onClick={() => onInput(8)} className={baseBtnClass} variant="ghost">8</Button>
            <Button disabled={disabled} aria-label="9" onClick={() => onInput(9)} className={baseBtnClass} variant="ghost">9</Button>
            <Button
                disabled={disabled}
                aria-label="こたえを けす"
                onClick={onClear}
                className={cn(baseBtnClass, "border-rose-100/90 bg-rose-50/78 text-rose-500 hover:bg-rose-50 mobile:text-sm")}
                variant="ghost"
            >
                C
            </Button>

            {/* Row 2 */}
            <Button disabled={disabled} aria-label="4" onClick={() => onInput(4)} className={baseBtnClass} variant="ghost">4</Button>
            <Button disabled={disabled} aria-label="5" onClick={() => onInput(5)} className={baseBtnClass} variant="ghost">5</Button>
            <Button disabled={disabled} aria-label="6" onClick={() => onInput(6)} className={baseBtnClass} variant="ghost">6</Button>
            <Button
                disabled={disabled}
                aria-label="ひとつ もどす"
                onClick={onDelete}
                className={cn(actionBtnClass, "text-lg font-medium mobile:text-sm")}
                variant="ghost"
            >
                <Icons.Backspace className={iconClass} />
            </Button>

            {/* Row 3 */}
            <Button disabled={disabled} aria-label="1" onClick={() => onInput(1)} className={baseBtnClass} variant="ghost">1</Button>
            <Button disabled={disabled} aria-label="2" onClick={() => onInput(2)} className={baseBtnClass} variant="ghost">2</Button>
            <Button disabled={disabled} aria-label="3" onClick={() => onInput(3)} className={baseBtnClass} variant="ghost">3</Button>
            {showDecimal ? (
                <Button disabled={disabled} aria-label="しょうすうてん" onClick={() => onInput(".")} className={baseBtnClass} variant="ghost">.</Button>
            ) : (
                <div /> /* Empty cell for alignment */
            )}

            {/* Row 4 */}
            {onCursorMove && !writtenInput ? (
                <>
                    <Button
                        disabled={disabled}
                        aria-label="カーソルを ひだりへ"
                        onClick={() => onCursorMove("left")}
                        className={actionBtnClass}
                        variant="ghost"
                    >
                        <Icons.ArrowLeft className={iconClass} />
                    </Button>
                    <Button disabled={disabled} aria-label="0" onClick={() => onInput(0)} className={baseBtnClass} variant="ghost">0</Button>
                    <Button
                        disabled={disabled || nextFieldDisabled}
                        aria-label={nextFieldLabel ?? "カーソルを みぎへ"}
                        onClick={() => onCursorMove("right")}
                        className={actionBtnClass}
                        variant="ghost"
                    >
                        {nextFieldLabel ? <span className="text-sm">つぎ</span> : <Icons.ArrowRight className={iconClass} />}
                    </Button>
                </>
            ) : (
                <>
                    <div /> {/* Empty cell for alignment */}
                    <Button disabled={disabled} aria-label="0" onClick={() => onInput(0)} className={baseBtnClass} variant="ghost">0</Button>
                    <div /> {/* Empty cell for alignment */}
                </>
            )}

            {/* Enter Key */}
            {writtenInput && confirmationMode === 'automatic' ? <div aria-hidden="true" data-written-auto-confirm /> : enterButton}
        </div>
    );
};
