import React from "react";
import { Problem, ProblemVisualBalanceItem, ProblemVisualCategoryBucket, ProblemVisualGroup, ProblemVisualItem, ProblemVisualLengthBar, ProblemVisualNumberCard, ProblemVisualNumberLine, ProblemVisualPairItem, ProblemVisualPositionScene, ProblemVisualReferenceChoice, ProblemVisualSequenceSlot, ProblemVisualValueGroup } from "../../domain/types";
import { cn } from "../../utils/cn";
import { MathRenderer } from "./MathRenderer";
import { FractionStrips } from './FractionStrips';
import { isMathFoundation } from '../../domain/math/foundationConfig';

type PromptProblem = Pick<Problem, "questionText" | "questionVisual" | "categoryId">;

interface MathProblemPromptProps {
    problem?: PromptProblem | null;
    className?: string;
    renderItem?: (item: ProblemVisualItem) => React.ReactNode;
}

// An illustration can change material, never the reserved item's identity or geometry.
const ItemIllustrationContext = React.createContext<MathProblemPromptProps["renderItem"]>(undefined);
const FoundationCaptionContext = React.createContext(false);
const ItemIllustration = ({ item }: { item?: ProblemVisualItem }) => {
    const renderItem = React.useContext(ItemIllustrationContext);
    return item ? <>{renderItem ? renderItem(item) : item.emoji}</> : null;
};

const ItemVisualCard: React.FC<{
    group: ProblemVisualGroup;
}> = ({ group }) => {
    const crossedOutCount = group.crossedOutCount || 0;

    return (
        <div data-visual-surface="group" data-visual-group={group.label} data-visual-symbol={group.emoji} data-visual-count={group.count} className="min-w-[124px] rounded-[24px] border border-white/80 bg-white/72 px-4 py-3 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div className="mb-2 text-sm font-black tracking-[0.08em] text-slate-500">
                {group.label}
            </div>
            <div className="grid grid-cols-5 justify-items-center gap-2" style={{ '--visual-group-columns': Math.max(1, Math.min(5, group.count)) } as React.CSSProperties}>
                {Array.from({ length: group.count }, (_, index) => {
                    const isCrossedOut = index >= group.count - crossedOutCount;

                    return (
                        <span key={`${group.emoji}-${index}`} data-count-item={index} data-crossed-out={isCrossedOut} className="relative text-[clamp(20px,3.6vw,28px)] leading-none">
                            <span className={cn(isCrossedOut && "opacity-25 grayscale")}>
                                <ItemIllustration item={group} />
                            </span>
                            {isCrossedOut && (
                                <span className="absolute inset-x-0 top-1/2 h-[3px] -translate-y-1/2 -rotate-12 rounded-full bg-rose-400/90" />
                            )}
                        </span>
                    );
                })}
            </div>
        </div>
    );
};

const SingleItemsCard: React.FC<{
    group: ProblemVisualGroup;
    columns?: number;
    frameSize?: number;
    style?: "grid" | "frame";
}> = ({ group, columns = 5, frameSize, style = "grid" }) => {
    const slotCount = style === "frame" ? Math.max(frameSize || group.count, group.count) : group.count;

    return (
        <div data-visual-surface="count-frame" data-visual-group={group.label} data-visual-symbol={group.emoji} data-visual-count={group.count} className="rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div
                className="grid justify-items-center gap-2"
                style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}
            >
                {Array.from({ length: slotCount }, (_, index) => {
                    const isFilled = index < group.count;

                    return (
                        <span
                            key={`${group.emoji}-${index}`}
                            data-count-slot={isFilled ? "filled" : "empty"}
                            className={cn(
                                "flex h-10 w-10 items-center justify-center rounded-xl text-[clamp(20px,3.6vw,28px)] leading-none",
                                isFilled
                                    ? "border border-white/80 bg-white/90 text-slate-700"
                                    : "border border-dashed border-slate-200 bg-white/40 text-transparent"
                            )}
                        >
                            {isFilled ? <ItemIllustration item={group} /> : <span aria-hidden="true">{group.emoji}</span>}
                        </span>
                    );
                })}
            </div>
        </div>
    );
};

const NumberCardVisual: React.FC<{
    card: ProblemVisualNumberCard;
}> = ({ card }) => (
    <div data-visual-surface="number-card" className="flex w-full max-w-[340px] flex-col items-center gap-4 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        <div className="flex h-24 w-24 items-center justify-center rounded-[28px] border border-cyan-100 bg-cyan-50/90 text-[clamp(42px,7vw,60px)] font-black text-cyan-700 shadow-[0_16px_28px_-22px_rgba(8,145,178,0.4)]">
            {card.value}
        </div>
        <SingleItemsCard
            group={card.supportGroup}
            columns={card.columns}
            frameSize={card.frameSize}
            style="frame"
        />
    </div>
);

const ReferenceChoiceGridCard: React.FC<{
    grid: ProblemVisualReferenceChoice;
}> = ({ grid }) => (
    <div data-visual-surface="reference-grid" className="flex w-full max-w-[360px] flex-col items-center gap-4 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        <div className="flex flex-col items-center gap-1">
            <div className="flex h-16 w-16 items-center justify-center rounded-[20px] border border-cyan-100 bg-cyan-50/90 text-[clamp(28px,4vw,38px)] shadow-[0_12px_22px_-18px_rgba(8,145,178,0.36)]">
                <ItemIllustration item={grid.reference} />
            </div>
            <span className="text-xs font-black tracking-[0.08em] text-slate-500">おてほん</span>
        </div>
        <div
            className="grid w-full justify-items-center gap-3"
            style={{ gridTemplateColumns: `repeat(${grid.columns || grid.choices.length}, minmax(0, 1fr))` }}
        >
            {grid.choices.map((item, index) => (
                <div
                    key={`${item.emoji}-${index}`}
                    className="flex h-16 w-16 items-center justify-center rounded-[20px] border border-white/80 bg-white/90 text-[clamp(26px,4vw,38px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]"
                >
                    <ItemIllustration item={item} />
                </div>
            ))}
        </div>
    </div>
);

const BaseTenValueCard: React.FC<{
    group: ProblemVisualValueGroup;
}> = ({ group }) => {
    const tens = Math.floor(group.value / 10);
    const ones = group.value % 10;

    return (
        <div data-visual-surface="base10" data-base10-value={group.value} className="min-w-[152px] rounded-[24px] border border-white/80 bg-white/72 px-4 py-3 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div className="mb-3 text-center text-sm font-black tracking-[0.08em] text-slate-500">
                {group.label}
            </div>
            <div className="mb-3 flex min-h-12 flex-wrap justify-center gap-2">
                {Array.from({ length: tens }, (_, index) => (
                    <span
                        key={`ten-${group.value}-${index}`} data-base10-unit="ten"
                        className="h-12 w-3 rounded-full bg-cyan-300 shadow-[inset_0_-6px_10px_rgba(8,145,178,0.18)]"
                    />
                ))}
            </div>
            <div className="flex min-h-6 flex-wrap justify-center gap-2">
                {Array.from({ length: ones }, (_, index) => (
                    <span
                        key={`one-${group.value}-${index}`} data-base10-unit="one"
                        className="h-4 w-4 rounded-full bg-amber-300 shadow-[inset_0_-3px_6px_rgba(217,119,6,0.22)]"
                    />
                ))}
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-[11px] font-black text-slate-500">
                <span className="rounded-full bg-cyan-50 px-2 py-1 text-cyan-700">10が {tens}ほん</span>
                <span className="rounded-full bg-amber-50 px-2 py-1 text-amber-700">1が {ones}こ</span>
            </div>
        </div>
    );
};

const BaseTenGuideCard: React.FC = () => (
    <div data-visual-surface="guide" className="w-full max-w-[460px] rounded-[20px] border border-cyan-100/90 bg-cyan-50/88 px-4 py-3 text-center shadow-[0_16px_28px_-22px_rgba(8,145,178,0.38)]">
        <p className="text-sm font-black leading-6 tracking-[0.04em] text-cyan-800">
            ながい ぼう 1ほん は 10、まる 1こ は 1
        </p>
    </div>
);

const PromptCaption: React.FC<{
    text: string;
}> = ({ text }) => React.useContext(FoundationCaptionContext) ? null : (
    <p data-visual-caption className="text-sm font-black tracking-[0.08em] text-slate-500">
        {text}
    </p>
);

const PromptQuestionCard: React.FC<{
    text: string;
}> = ({ text }) => (
    <div data-visual-surface="question" className="w-full max-w-[420px] rounded-[20px] border border-cyan-100/90 bg-cyan-50/88 px-4 py-3 text-center shadow-[0_16px_28px_-22px_rgba(8,145,178,0.38)]">
        <p className="text-sm font-black leading-6 tracking-[0.04em] text-cyan-800">
            {text}
        </p>
    </div>
);

const NumberSequenceCard: React.FC<{
    slots: ProblemVisualSequenceSlot[];
}> = ({ slots }) => (
    <div data-visual-surface="sequence" className="flex flex-wrap items-center justify-center gap-2 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        {slots.map((slot, index) => (
            <React.Fragment key={`slot-${index}`}>
                <div data-visual-value={slot.value ?? undefined} data-visual-hidden={slot.value === null} className={cn(
                    "flex h-14 min-w-14 items-center justify-center rounded-full px-4 text-[clamp(24px,4vw,34px)] font-black",
                    slot.value === null
                        ? "border-2 border-dashed border-cyan-300 bg-cyan-50/80 text-cyan-700"
                        : "border border-white/80 bg-white/90 text-slate-700"
                )}>
                    {slot.value ?? "?"}
                </div>
                {index < slots.length - 1 && (
                    <span className="text-lg font-black text-slate-300">→</span>
                )}
            </React.Fragment>
        ))}
    </div>
);

const NumberLineCard: React.FC<{
    line: ProblemVisualNumberLine;
}> = ({ line }) => {
    const values = Array.from({ length: line.max - line.min + 1 }, (_, index) => line.min + index);
    const hasStep = typeof line.step === "number" && line.step !== 0;
    const direction = hasStep && line.step! > 0 ? "right" : "left";

    return (
        <div data-visual-surface="number-line" className="flex w-full max-w-[520px] flex-col items-center gap-3 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div className="relative flex w-full items-center justify-between gap-2 px-2">
                <div className="absolute left-6 right-6 top-1/2 h-1 -translate-y-1/2 rounded-full bg-slate-200" />
                {values.map((value) => {
                    const isHidden = line.hiddenValues?.includes(value) || (value === line.end && line.hiddenTarget);
                    const isStart = hasStep && value === line.start;
                    const isEnd = hasStep && value === line.end;
                    const isHighlighted = line.highlightValues?.includes(value);

                    return (
                        <div key={value} className="relative z-10 flex flex-col items-center gap-2">
                            <div className={cn(
                                "h-3 w-3 rounded-full",
                                isStart
                                    ? "bg-cyan-500"
                                    : isHidden || isEnd
                                        ? "bg-amber-400"
                                        : isHighlighted
                                            ? "bg-violet-400"
                                            : "bg-slate-300"
                            )} />
                            <div data-visual-value={value} data-visual-hidden={Boolean(isHidden)} className={cn(
                                "flex h-10 min-w-10 items-center justify-center rounded-full px-2 text-sm font-black",
                                isStart
                                    ? "border border-cyan-200 bg-cyan-50 text-cyan-700"
                                    : isHidden || isEnd
                                        ? "border-2 border-dashed border-amber-300 bg-amber-50 text-amber-700"
                                        : isHighlighted
                                            ? "border border-violet-200 bg-violet-50 text-violet-700"
                                        : "border border-white/80 bg-white/90 text-slate-600"
                            )}>
                                {isHidden ? "?" : value}
                            </div>
                        </div>
                    );
                })}
            </div>
            {hasStep && (
                <div className="flex items-center gap-2 rounded-full bg-white/80 px-3 py-1 text-sm font-black text-slate-500">
                    <span>{direction === "right" ? "→" : "←"}</span>
                    <span>{Math.abs(line.step || 0)}</span>
                </div>
            )}
        </div>
    );
};

const LENGTH_TONE_STYLES: Record<ProblemVisualLengthBar["tone"], { rail: string; fill: string }> = {
    rose: {
        rail: "bg-rose-100",
        fill: "bg-rose-400",
    },
    sky: {
        rail: "bg-sky-100",
        fill: "bg-sky-400",
    },
    amber: {
        rail: "bg-amber-100",
        fill: "bg-amber-400",
    },
    emerald: {
        rail: "bg-emerald-100",
        fill: "bg-emerald-400",
    },
};

const CATEGORY_TONE_STYLES: Record<ProblemVisualCategoryBucket["tone"], { card: string; chip: string }> = {
    rose: {
        card: "bg-rose-50/80 border-rose-100",
        chip: "bg-rose-400",
    },
    sky: {
        card: "bg-sky-50/80 border-sky-100",
        chip: "bg-sky-400",
    },
    amber: {
        card: "bg-amber-50/80 border-amber-100",
        chip: "bg-amber-400",
    },
    emerald: {
        card: "bg-emerald-50/80 border-emerald-100",
        chip: "bg-emerald-400",
    },
};

const OrdinalRowCard: React.FC<{
    items: ProblemVisualItem[];
    showPlaceholder?: boolean;
}> = ({ items, showPlaceholder = false }) => (
    <div data-visual-surface="ordinal" className="flex flex-wrap items-center justify-center gap-2 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        {items.map((item, index) => (
            <React.Fragment key={`${item.emoji}-${index}`}>
                <div className="flex h-16 w-16 items-center justify-center rounded-[20px] border border-white/80 bg-white/90 text-[clamp(26px,4vw,38px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]">
                    <ItemIllustration item={item} />
                </div>
                {index < items.length - 1 && (
                    <span className="text-lg font-black text-slate-300">→</span>
                )}
            </React.Fragment>
        ))}
        {showPlaceholder && (
            <>
                {items.length > 0 && (
                    <span className="text-lg font-black text-slate-300">→</span>
                )}
                <div className="flex h-16 w-16 items-center justify-center rounded-[20px] border-2 border-dashed border-cyan-300 bg-cyan-50/80 text-[clamp(26px,4vw,38px)] font-black text-cyan-700">
                    ?
                </div>
            </>
        )}
    </div>
);

const LengthCompareCard: React.FC<{
    bars: ProblemVisualLengthBar[];
    direction?: "horizontal" | "vertical";
}> = ({ bars, direction = "horizontal" }) => {
    if (direction === "vertical") {
        return (
            <div data-visual-surface="length" className="flex w-full max-w-[420px] items-end justify-center gap-4 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
                {bars.map((bar, index) => {
                    const tone = LENGTH_TONE_STYLES[bar.tone];

                    return (
                        <div key={`${bar.emoji}-${index}`} className="flex min-w-[110px] flex-col items-center gap-3">
                            <div className="flex h-36 items-end rounded-[22px] border border-white/70 bg-white/70 px-4 py-3">
                                <div
                                    className={cn("w-10 rounded-t-[18px] shadow-[inset_0_-4px_8px_rgba(255,255,255,0.24)]", tone.fill)}
                                    style={{ height: `${Math.max(42, bar.length * 14)}px` }}
                                />
                            </div>
                            <span className="flex h-12 w-12 items-center justify-center rounded-full border border-white/80 bg-white/90 text-[clamp(24px,4vw,32px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]">
                                <ItemIllustration item={bar} />
                            </span>
                        </div>
                    );
                })}
            </div>
        );
    }

    return (
        <div data-visual-surface="length" className="flex w-full max-w-[460px] flex-col gap-3 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            {bars.map((bar, index) => {
                const tone = LENGTH_TONE_STYLES[bar.tone];

                return (
                    <div key={`${bar.emoji}-${index}`} className="flex items-center gap-3">
                        <span className="flex h-12 w-12 items-center justify-center rounded-full border border-white/80 bg-white/90 text-[clamp(24px,4vw,32px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]">
                            <ItemIllustration item={bar} />
                        </span>
                        <div className={cn("flex h-6 flex-1 items-center rounded-full px-1", tone.rail)}>
                            <div
                                className={cn("h-4 rounded-full shadow-[inset_0_-2px_4px_rgba(255,255,255,0.24)]", tone.fill)}
                                style={{ width: `${Math.max(28, bar.length * 18)}px` }}
                            />
                        </div>
                    </div>
                );
            })}
        </div>
    );
};

const BalanceCompareCard: React.FC<{
    items: ProblemVisualBalanceItem[];
}> = ({ items }) => {
    const [left, right] = items;
    const tilt = left && right ? Math.max(-10, Math.min(10, (right.weight - left.weight) * 3.5)) : 0;

    return (
        <div data-visual-surface="balance" className="flex w-full max-w-[420px] flex-col items-center gap-3 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div className="relative flex h-36 w-full items-end justify-center">
                <div className="absolute bottom-3 h-20 w-3 rounded-full bg-slate-300" />
                <div
                    className="absolute bottom-[92px] flex w-[240px] items-center justify-between"
                    style={{ transform: `rotate(${tilt}deg)` }}
                >
                    <div className="h-1 w-full rounded-full bg-slate-400" />
                    <div className="absolute left-0 top-1/2 flex -translate-y-1/2 -translate-x-1/2 flex-col items-center gap-2">
                        <div className="h-8 w-[82px] rounded-[16px] border border-slate-200 bg-white/90 shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]" />
                        <span className="text-[clamp(24px,4vw,34px)] leading-none"><ItemIllustration item={left} /></span>
                    </div>
                    <div className="absolute right-0 top-1/2 flex -translate-y-1/2 translate-x-1/2 flex-col items-center gap-2">
                        <div className="h-8 w-[82px] rounded-[16px] border border-slate-200 bg-white/90 shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]" />
                        <span className="text-[clamp(24px,4vw,34px)] leading-none"><ItemIllustration item={right} /></span>
                    </div>
                </div>
                <div className="absolute bottom-0 h-4 w-40 rounded-full bg-slate-200/90" />
            </div>
        </div>
    );
};

const PositionSceneCard: React.FC<{
    scene: ProblemVisualPositionScene["scene"];
    target: ProblemVisualItem;
    reference: ProblemVisualItem;
    relation: ProblemVisualPositionScene["relation"];
}> = ({ scene, target, reference, relation }) => {
    if (scene === "front-back") {
        const targetFront = relation === "まえ";

        return (
            <div data-visual-surface="position" className="flex w-full max-w-[320px] justify-center rounded-[24px] border border-white/80 bg-white/72 px-4 py-5 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
                <div className="relative h-40 w-48">
                    <div
                        className={cn(
                            "absolute left-1/2 flex h-20 w-20 -translate-x-1/2 items-center justify-center rounded-full border border-white/70 bg-white/85 text-[48px] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]",
                            targetFront ? "top-5 opacity-55" : "top-10 z-20"
                        )}
                    >
                        <ItemIllustration item={reference} />
                    </div>
                    <div
                        className={cn(
                            "absolute left-1/2 flex h-20 w-20 -translate-x-1/2 items-center justify-center rounded-full border border-white/70 bg-cyan-50/85 text-[46px] shadow-[0_12px_22px_-18px_rgba(8,145,178,0.36)]",
                            targetFront ? "top-14 z-20" : "top-4 opacity-60"
                        )}
                    >
                        <ItemIllustration item={target} />
                    </div>
                </div>
            </div>
        );
    }

    const targetInside = relation === "なか";

    return (
        <div data-visual-surface="position" className="flex w-full max-w-[320px] justify-center rounded-[24px] border border-white/80 bg-white/72 px-4 py-5 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
            <div className="relative h-40 w-48">
                <div className="absolute left-1/2 top-6 flex h-24 w-24 -translate-x-1/2 items-center justify-center rounded-[28px] border-2 border-dashed border-amber-300 bg-amber-50/90 text-[50px] shadow-[0_12px_22px_-18px_rgba(217,119,6,0.22)]">
                    <ItemIllustration item={reference} />
                </div>
                <div
                    className={cn(
                        "absolute flex h-16 w-16 items-center justify-center rounded-full border border-white/80 bg-white/90 text-[38px] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]",
                        targetInside
                            ? "left-1/2 top-10 -translate-x-1/2"
                            : "right-2 top-20"
                    )}
                >
                    <ItemIllustration item={target} />
                </div>
            </div>
        </div>
    );
};

const CategorySortCard: React.FC<{
    target: ProblemVisualItem;
    buckets: ProblemVisualCategoryBucket[];
}> = ({ target, buckets }) => (
    <div data-visual-surface="categories" className="flex w-full max-w-[520px] flex-col items-center gap-4 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        <div className="flex flex-col items-center gap-1">
            <div className="flex h-16 w-16 items-center justify-center rounded-full border border-white/80 bg-white/90 text-[clamp(28px,4vw,38px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]">
                <ItemIllustration item={target} />
            </div>
            <span className="text-xs font-black tracking-[0.08em] text-slate-500">どこに はいる？</span>
        </div>
        <div className="flex w-full flex-wrap items-stretch justify-center gap-3">
            {buckets.map((bucket, index) => {
                const tone = CATEGORY_TONE_STYLES[bucket.tone];

                return (
                    <div
                        key={`${bucket.label}-${index}`}
                        className={cn("flex min-w-[150px] flex-1 flex-col gap-3 rounded-[22px] border px-4 py-3", tone.card)}
                    >
                        <div className="flex items-center justify-center gap-2">
                            <span className={cn("h-3 w-3 rounded-full", tone.chip)} />
                            <span className="text-sm font-black text-slate-700">{bucket.label}</span>
                        </div>
                        <div className="flex flex-wrap justify-center gap-2">
                            {bucket.items.map((item, itemIndex) => (
                                <span
                                    key={`${bucket.label}-${item.emoji}-${itemIndex}`}
                                    className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/80 bg-white/80 text-[clamp(20px,3vw,28px)]"
                                >
                                    <ItemIllustration item={item} />
                                </span>
                            ))}
                        </div>
                    </div>
                );
            })}
        </div>
    </div>
);

const ItemGridCard: React.FC<{
    items: ProblemVisualItem[];
    columns?: number;
}> = ({ items, columns = Math.min(Math.max(items.length, 1), 4) }) => (
    <div data-visual-surface="item-grid" className="rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]">
        <div
            className="grid justify-items-center gap-3"
            style={{ gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` }}
        >
            {items.map((item, index) => (
                <div
                    key={`${item.emoji}-${index}`}
                    className="flex h-16 w-16 items-center justify-center rounded-[20px] border border-white/80 bg-white/90 text-[clamp(26px,4vw,38px)] shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]"
                >
                    <ItemIllustration item={item} />
                </div>
            ))}
        </div>
    </div>
);

const ItemPairCard: React.FC<{
    items: ProblemVisualPairItem[];
    orientation?: "row" | "column";
}> = ({ items, orientation = "row" }) => (
    <div data-visual-surface="item-pair" className={cn(
        "flex w-full items-center justify-center gap-4 rounded-[24px] border border-white/80 bg-white/72 px-4 py-4 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.28)]",
        orientation === "column" ? "max-w-[220px] flex-col" : "max-w-[420px] flex-wrap"
    )}>
        {items.map((item, index) => (
            <div
                key={`${item.emoji}-${index}`}
                className="flex min-w-[120px] flex-col items-center gap-2 rounded-[22px] border border-white/80 bg-white/90 px-4 py-4 shadow-[0_10px_18px_-16px_rgba(15,23,42,0.24)]"
            >
                <span
                    className="leading-none"
                    style={{ fontSize: `${Math.round((item.scale || 1) * 38)}px` }}
                >
                    <ItemIllustration item={item} />
                </span>
                <span className="text-xs font-black tracking-[0.08em] text-slate-500">{item.label}</span>
            </div>
        ))}
    </div>
);

const MathProblemPromptContent: React.FC<MathProblemPromptProps> = ({ problem, className }) => {
    const visual = problem?.questionVisual;
    if (problem && isMathFoundation(problem.categoryId) && visual?.kind === 'sharing-items') return (
        <div className={cn('grid w-full grid-cols-2 gap-2', className)}>
            {[visual.source, visual.recipients].map((group, index) => <div key={index} className="rounded-lg border border-slate-200 bg-white p-1">
                <div className="mb-1 text-xs font-bold text-slate-600">{group.label}</div>
                <div className="grid grid-cols-4 justify-items-center gap-1">
                    {Array.from({ length: group.count }, (_, item) => <span key={item} data-count-item={item} className="text-lg leading-none"><ItemIllustration item={group} /></span>)}
                </div>
            </div>)}
        </div>
    );
    if (problem && isMathFoundation(problem.categoryId) && visual?.kind === 'item-order') return (
        <div className={cn('grid w-full gap-2', className)} style={{ gridTemplateColumns: `repeat(${visual.groups.length}, minmax(0, 1fr))` }}>
            {visual.groups.map((group, index) => (
                <div key={index} data-visual-surface="group" data-visual-count={group.count} className="min-w-0 rounded-lg border border-slate-200 bg-white p-1">
                    <div className="mb-1 text-xs font-bold leading-tight text-slate-600">{group.label}</div>
                    <div className="grid justify-items-center gap-1" style={{ gridTemplateColumns: `repeat(${Math.min(2, group.count)}, minmax(0, 1fr))` }}>
                        {Array.from({ length: group.count }, (_, item) => <span key={item} data-count-item={item} className="text-lg leading-none"><ItemIllustration item={group} /></span>)}
                    </div>
                </div>
            ))}
        </div>
    );
    if (visual?.kind === 'fraction-strips') return (
        <div className={cn('w-full space-y-4', className)}>
            <FractionStrips visual={visual} />
            <PromptCaption text={visual.prompt || problem?.questionText || ''} />
        </div>
    );
    const showSpatialQuestionCard = problem?.categoryId === "spatial_words"
        && (visual?.kind === "item-pair" || visual?.kind === "position-scene");
    const showComparisonQuestionCard = (problem?.categoryId === "compare_1d" || problem?.categoryId === "compare_2d")
        && (visual?.kind === "number-line" || visual?.kind === "comparison-base10");
    const showBaseTenOperationQuestionCard = !!problem?.categoryId
        && ["add_2d1d_nc_bridge", "add_2d1d_c_bridge", "sub_2d1d_nc_bridge", "sub_2d1d_c_bridge"].includes(problem.categoryId)
        && visual?.kind === "operation-base10";
    const showOperationNumberLineQuestionCard = !!problem?.categoryId
        && ["add_2d1d_mental_nc", "add_2d1d_make10", "sub_2d1d_diff", "sub_2d1d_back_add"].includes(problem.categoryId)
        && visual?.kind === "number-line";

    if (visual?.kind === "number-card") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <NumberCardVisual card={visual.card} />
                <PromptCaption text={visual.prompt || "よみかたは どれ？"} />
            </div>
        );
    }

    if (visual?.kind === "reference-choice-grid") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <ReferenceChoiceGridCard grid={visual.grid} />
                <PromptCaption text={visual.prompt || "おなじ ものは？"} />
            </div>
        );
    }

    if (visual?.kind === "single-items") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <SingleItemsCard
                    group={visual.group}
                    columns={visual.columns}
                    frameSize={visual.frameSize}
                    style={visual.style}
                />
                <PromptCaption text={visual.prompt || "いくつ ある？"} />
            </div>
        );
    }

    if (visual?.kind === "addition-items") {
        const [left, right] = visual.groups;

        if (left && right) {
            return (
                <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                    <div className="flex w-full flex-wrap items-center justify-center gap-3">
                        <ItemVisualCard group={left} />
                        <span data-visual-operator="+" className="text-[clamp(34px,6vw,50px)] font-black text-cyan-700">+</span>
                        <ItemVisualCard group={right} />
                    </div>
                    <PromptCaption text={visual.prompt || "あわせて いくつ？"} />
                </div>
            );
        }
    }

    if (visual?.kind === "subtraction-items") {
        const originalGroup = {
            ...visual.group,
            crossedOutCount: undefined,
        };
        const takenAwayCount = visual.takenAwayCount ?? visual.group.crossedOutCount ?? 0;
        const takenAwayGroup = takenAwayCount > 0
            ? {
                emoji: visual.group.emoji,
                label: visual.group.label,
                count: takenAwayCount,
            }
            : null;

        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <div className="flex w-full flex-wrap items-center justify-center gap-3">
                    <ItemVisualCard group={originalGroup} />
                    {takenAwayGroup ? (
                        <>
                            <div data-visual-surface="action" className="flex flex-col items-center gap-1 rounded-[24px] border border-white/70 bg-white/52 px-4 py-3 text-rose-500 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.2)]">
                                <span data-visual-operator="−" className="text-[clamp(28px,5vw,40px)] font-black">−</span>
                                <span className="text-xs font-black tracking-[0.08em] text-slate-500">{visual.actionLabel || "なくなる"}</span>
                            </div>
                            <ItemVisualCard group={takenAwayGroup} />
                        </>
                    ) : null}
                </div>
                <PromptCaption text={visual.prompt || "のこりは いくつ？"} />
            </div>
        );
    }

    if (visual?.kind === "sharing-items") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <div className="flex w-full flex-wrap items-center justify-center gap-3">
                    <ItemVisualCard group={visual.source} />
                    <div data-visual-surface="action" className="flex flex-col items-center gap-1 rounded-[24px] border border-white/70 bg-white/52 px-4 py-3 text-cyan-700 shadow-[0_16px_30px_-22px_rgba(15,23,42,0.2)]">
                        <span data-visual-operator="→" className="text-[clamp(28px,5vw,40px)] font-black">→</span>
                        <span className="text-xs font-black tracking-[0.08em] text-slate-500">{visual.actionLabel || "おなじに わける"}</span>
                    </div>
                    <ItemVisualCard group={visual.recipients} />
                </div>
                <PromptCaption text={visual.prompt || "1にんぶんは いくつ？"} />
            </div>
        );
    }

    if (visual?.kind === "comparison-items") {
        const [left, right] = visual.groups;

        if (left && right) {
            return (
                <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                    <div className="flex w-full flex-wrap items-center justify-center gap-3">
                        <ItemVisualCard group={left} />
                        <span className="text-[clamp(34px,6vw,50px)] font-black text-slate-400">□</span>
                        <ItemVisualCard group={right} />
                    </div>
                    <PromptCaption text={visual.prompt || "どちらが おおい？"} />
                </div>
            );
        }
    }

    if (visual?.kind === "comparison-base10") {
        const [left, right] = visual.groups;
        const showBaseTenGuide = problem?.categoryId === "compare_2d";

        if (left && right) {
            return (
                <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                    {showComparisonQuestionCard && problem?.questionText ? (
                        <PromptQuestionCard text={problem.questionText} />
                    ) : null}
                    {showBaseTenGuide && <BaseTenGuideCard />}
                    <div data-visual-group-row="base10" className="flex w-full flex-wrap items-center justify-center gap-3">
                        <BaseTenValueCard group={left} />
                        <span className="text-[clamp(34px,6vw,50px)] font-black text-slate-400">□</span>
                        <BaseTenValueCard group={right} />
                    </div>
                    <PromptCaption text={visual.prompt || "どちらが おおい？"} />
                </div>
            );
        }
    }

    if (visual?.kind === "operation-base10") {
        const [left, right] = visual.groups;

        if (left && right) {
            return (
                <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                    {showBaseTenOperationQuestionCard && problem?.questionText ? (
                        <PromptQuestionCard text={problem.questionText} />
                    ) : null}
                    <BaseTenGuideCard />
                    <div data-visual-group-row="base10" className="flex w-full flex-wrap items-center justify-center gap-3">
                        <BaseTenValueCard group={left} />
                        <span data-visual-operator={visual.operator} className="text-[clamp(34px,6vw,50px)] font-black text-cyan-700">{visual.operator}</span>
                        <BaseTenValueCard group={right} />
                    </div>
                    <PromptCaption text={visual.prompt || "10の まとまりで かんがえよう"} />
                </div>
            );
        }
    }

    if (visual?.kind === "number-sequence") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <NumberSequenceCard slots={visual.slots} />
                <PromptCaption text={visual.prompt || "つぎの かずは？"} />
            </div>
        );
    }

    if (visual?.kind === "number-line") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                {(showComparisonQuestionCard || showOperationNumberLineQuestionCard) && problem?.questionText ? (
                    <PromptQuestionCard text={problem.questionText} />
                ) : null}
                <NumberLineCard line={visual.line} />
                <PromptCaption text={visual.prompt || "どこまで すすむ？"} />
            </div>
        );
    }

    if (visual?.kind === "item-order") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <div className="flex w-full flex-wrap items-center justify-center gap-3">
                    {visual.groups.map((group, index) => (
                        <ItemVisualCard key={`${group.emoji}-${group.count}-${index}`} group={group} />
                    ))}
                </div>
                <PromptCaption text={visual.prompt || "いちばん ちいさい かずは？"} />
            </div>
        );
    }

    if (visual?.kind === "ordinal-row") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <OrdinalRowCard items={visual.items} showPlaceholder={visual.showPlaceholder} />
                <PromptCaption text={visual.prompt || "なんばんめ？"} />
            </div>
        );
    }

    if (visual?.kind === "length-compare") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <LengthCompareCard bars={visual.bars} direction={visual.direction} />
                <PromptCaption text={visual.prompt || "ながい のは どっち？"} />
            </div>
        );
    }

    if (visual?.kind === "category-sort") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <CategorySortCard target={visual.target} buckets={visual.buckets} />
                <PromptCaption text={visual.prompt || "どちらの なかま？"} />
            </div>
        );
    }

    if (visual?.kind === "item-grid") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <ItemGridCard items={visual.items} columns={visual.columns} />
                <PromptCaption text={visual.prompt || "えらぼう"} />
            </div>
        );
    }

    if (visual?.kind === "balance-compare") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                <BalanceCompareCard items={visual.items} />
                <PromptCaption text={visual.prompt || "おもい のは どっち？"} />
            </div>
        );
    }

    if (visual?.kind === "position-scene") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                {showSpatialQuestionCard && problem?.questionText ? (
                    <PromptQuestionCard text={problem.questionText} />
                ) : null}
                <PositionSceneCard
                    scene={visual.scene}
                    target={visual.target}
                    reference={visual.reference}
                    relation={visual.relation}
                />
                {!showSpatialQuestionCard && (
                    <PromptCaption text={visual.prompt || "どこ？"} />
                )}
            </div>
        );
    }

    if (visual?.kind === "item-pair") {
        return (
            <div className={cn("flex w-full flex-col items-center gap-4 text-center", className)}>
                {showSpatialQuestionCard && problem?.questionText ? (
                    <PromptQuestionCard text={problem.questionText} />
                ) : null}
                <ItemPairCard items={visual.items} orientation={visual.orientation} />
                {!showSpatialQuestionCard && (
                    <PromptCaption text={visual.prompt || "おなじ？"} />
                )}
            </div>
        );
    }

    return (
        <MathRenderer
            text={problem?.questionText || ""}
            isFraction={problem?.categoryId?.startsWith("frac_")}
            className={className}
        />
    );
};


export const MathProblemPrompt: React.FC<MathProblemPromptProps> = ({ renderItem, ...props }) => {
    const foundation = Boolean(props.problem?.questionVisual && isMathFoundation(props.problem.categoryId));
    return (
        <ItemIllustrationContext.Provider value={renderItem}>
            <FoundationCaptionContext.Provider value={foundation}>
                {foundation ? <div className="w-full space-y-2" data-math-foundation>
                    <p data-visual-caption className="text-sm font-bold leading-snug text-slate-600">{props.problem?.questionText}</p>
                    <MathProblemPromptContent {...props} />
                </div> : <MathProblemPromptContent {...props} />}
            </FoundationCaptionContext.Provider>
        </ItemIllustrationContext.Provider>
    );
};
