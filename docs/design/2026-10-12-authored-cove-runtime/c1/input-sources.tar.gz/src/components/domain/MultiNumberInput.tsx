import { NumberFieldsLayout } from './NumberFieldsLayout';
import React from "react";
import { AnswerCells } from "./AnswerCells";

interface FieldConfig {
    label: string;
    length: number; // max digits (deprecated for width, used for logic if needed)
}

interface MultiNumberInputProps {
    fields: FieldConfig[];
    values: string[]; // ['12', '3'] corresponding to fields
    activeIndex: number;
    onFocus: (index: number) => void;
    readOnly?: boolean;
    answerShape?: string[];
    replaceIndex?: number;
}

export const MultiNumberInput: React.FC<MultiNumberInputProps> = ({
    fields,
    values,
    activeIndex,
    onFocus,
    answerShape,
    replaceIndex,
    readOnly = false
}) => {
    return (
        <NumberFieldsLayout fields={fields} className="flex items-center justify-center gap-4 py-2 land:py-4">
            {fields.map((field, idx) => {
                const val = values[idx] || "";
                // Base width of 4rem (approx 64px) + 1rem per character (approx 16px)
                // This simulates "auto-expand" while keeping a minimum size
                const widthStyle = { minWidth: "4rem", width: `${Math.max(2, answerShape?.[idx].length ?? val.length) * 1.5 + 2}rem` };

                return (
                    <div key={idx} className="flex flex-col items-center gap-2">
                        {/* Label */}
                        <span data-number-label className="text-sm font-bold text-slate-500">{field.label}</span>

                        {/* Input Box - Auto expanding width */}
                        <button
                            type="button"
                            aria-label={field.label}
                            aria-pressed={activeIndex === idx}
                            data-replace-selected={replaceIndex === idx}
                            disabled={readOnly}
                            onClick={() => !readOnly && onFocus(idx)}
                            style={widthStyle}
                            className={`
                                relative box-content flex h-[var(--tenkey-key,44px)] min-h-[44px] items-center justify-center rounded-[18px]
                                border px-3 text-4xl font-mono shadow-[0_16px_28px_-22px_rgba(15,23,42,0.3)] transition-all ipadland:h-16
                                ${activeIndex === idx
                                    ? "cursor-pointer border-cyan-200 bg-cyan-50/82 text-slate-800 ring-2 ring-cyan-200/60 -translate-y-0.5"
                                    : "cursor-pointer border-white/80 bg-white/62 text-slate-500 hover:bg-white/78"
                                }
                            `}
                        >
                            {answerShape ? <AnswerCells shape={answerShape[idx]} value={val} active={activeIndex === idx && !readOnly} /> : val}
                            {/* Cursor Blinker */}
                            {!answerShape && activeIndex === idx && !readOnly && (
                                <span className="absolute right-2 top-1/2 h-[60%] w-0.5 -translate-y-1/2 animate-pulse rounded-full bg-cyan-500" />
                            )}
                        </button>
                    </div>
                );
            })}
        </NumberFieldsLayout>
    );
};
