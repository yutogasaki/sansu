import { IslandPanelHeading } from './IslandPanelHeading';
import { IslandToyIcon } from './IslandToyIcon';
import { IslandHouseOverview } from './IslandHouseOverview';
import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { ArrowRight, Award, Camera, Check, Gift, House, PackageOpen, Star, Trophy } from 'lucide-react';
import { getIslandLearningKeepsakes, isIslandLearningKeepsakeAvailable, ISLAND_LEARNING_KEEPSAKES,
    type IslandLearningKeepsakeAction, type IslandLearningKeepsakeId } from '../../domain/island/learningKeepsakes';
import type { IslandRecord } from '../../domain/island/types';
import type { IslandHouseSection } from '../../domain/island/navigation';
import type { useIslandLearningKeepsakes } from './useIslandLearningKeepsakes';
import './IslandLearningKeepsakes.css';
import './IslandPanel.css';

export type { IslandHouseSection } from '../../domain/island/navigation';
export interface IslandLearningKeepsakesProps {
    active?: boolean;
    walkingAvailable?: boolean;
    challenge?: ReactNode;
    /** Redecorating the room with learned words (growing island only). */
    decor?: ReactNode;
    section?: IslandHouseSection;
    onSectionChange?: (section: IslandHouseSection) => void;
    island: IslandRecord;
    controls: ReturnType<typeof useIslandLearningKeepsakes>;
    disabled: boolean;
    comparisonDisabled?: boolean;
    onClose: () => void;
    onLearn: () => void;
    onPhoto?: () => void;
    onSelect?: (id: IslandLearningKeepsakeId) => void;
    onShowRoom?: () => void;
    onPhotos?: () => void;
    onAlbum?: () => void;
    onShared?: () => void;
    onRewards?: () => void;
    onGrowingGuide?: () => void;
}
const subjectName = (subject: string) => subject === 'math' ? 'さんすう' : subject === 'vocab' ? 'えいご' : 'まなんだ こと';
const awardName = (id: IslandLearningKeepsakeId) => ISLAND_LEARNING_KEEPSAKES.find(item => item.id === id)!.name;
function displayAction(keepsakeId: IslandLearningKeepsakeId, displayed: boolean): IslandLearningKeepsakeAction {
    return { type: 'display', keepsakeId, displayed };
}

/** The page supplies the actual house. Reading an award never places one;
 * only the explicit display controls save the person's display selection. */
export function IslandLearningKeepsakes({ island, controls, disabled, onClose, onLearn, onPhoto, onSelect, onShowRoom, comparisonDisabled = disabled,
    onPhotos, onAlbum, onShared, onRewards, onGrowingGuide, section, onSectionChange, challenge, decor, walkingAvailable = true, active = true }: IslandLearningKeepsakesProps) {
    const [localSection, setLocalSection] = useState<IslandHouseSection>('home');
    const currentSection = section ?? localSection;
    const panelRef = useRef<HTMLElement>(null);
    const headingRef = useRef<HTMLHeadingElement>(null);
    const detailRef = useRef<HTMLHeadingElement>(null);
    const previousSection = useRef(currentSection);
    const [selectionEntry, setSelectionEntry] = useState(0);
    useLayoutEffect(() => {
        const previous = previousSection.current;
        previousSection.current = currentSection;
        if (previous === currentSection) return;
        const frame = requestAnimationFrame(() => {
            const target = currentSection === 'home'
                ? panelRef.current?.querySelector<HTMLElement>('[data-house-menu-trigger]')
                : headingRef.current;
            target?.focus({ preventScroll: true });
            target?.scrollIntoView({ block: 'nearest', behavior: 'instant' });
        });
        return () => cancelAnimationFrame(frame);
    }, [currentSection]);
    useLayoutEffect(() => {
        if (!selectionEntry) return;
        detailRef.current?.focus({ preventScroll: true });
        detailRef.current?.scrollIntoView({ block: 'start', behavior: 'instant' });
    }, [selectionEntry]);
    const changeSection = (next: IslandHouseSection) => {
        if (section === undefined) setLocalSection(next);
        onSectionChange?.(next);
    };
    const state = getIslandLearningKeepsakes(island);
    const selected = ISLAND_LEARNING_KEEPSAKES.find(item => item.id === controls.selectedId)!;
    const earned = ISLAND_LEARNING_KEEPSAKES.filter(item => isIslandLearningKeepsakeAvailable(island, item.id));
    const future = ISLAND_LEARNING_KEEPSAKES.filter(item => !isIslandLearningKeepsakeAvailable(island, item.id));
    const available = isIslandLearningKeepsakeAvailable(island, selected.id), displayed = state.displayed.includes(selected.id);
    const busy = disabled || Boolean(controls.pending), summary = controls.summary;
    const remaining = Math.max(0, selected.requiredCompletedSets - island.completedSets);
    const SelectedIcon = selected.slot === 'certificate' ? Award : Trophy;
    const choices = (items: readonly typeof ISLAND_LEARNING_KEEPSAKES[number][]) => items.map(item => {
        const available = isIslandLearningKeepsakeAvailable(island, item.id), onShelf = state.displayed.includes(item.id);
        const status = !available ? 'これから' : onShelf ? 'かざっている' : 'しまっている';
        const Icon = item.slot === 'certificate' ? Award : Trophy;
        return <button key={item.id} className="island-secondary island-keepsake-choice" disabled={busy}
            aria-pressed={selected.id === item.id} data-keepsake-choice={item.id} data-keepsake-state={!available ? 'locked' : onShelf ? 'displayed' : 'stored'}
            onClick={() => { controls.select(item.id); if (onShelf) onSelect?.(item.id); else onShowRoom?.(); setSelectionEntry(value => value + 1); }}>
            <Icon size={24} aria-hidden="true" /><strong>{item.name}</strong>
            <small>{onShelf && <Check size={14} aria-hidden="true" />}{status}</small>
        </button>;
    });
    return <section ref={panelRef} className="island-sheet island-panel island-learning-keepsakes" aria-label="いえ"
        data-testid="island-learning-keepsakes" data-keepsake-section={currentSection} data-keepsake-selected={selected.id}>
        <IslandPanelHeading titleRef={headingRef} title={<><IslandToyIcon kind="house" size={30} />{currentSection === 'keepsakes' ? 'まなびの きねん' : currentSection === 'notices' ? 'おしらせ' : 'いえの なか'}</>}
            onExit={currentSection === 'home' ? onClose : () => changeSection('home')} disabled={comparisonDisabled}
            exitLabel={currentSection === 'home' ? 'しまへ' : 'もどる'} exitAriaLabel={currentSection === 'home' ? 'しまへ もどる' : 'いえの なかへ もどる'}
            houseAction={currentSection === 'home' ? 'close' : 'home'} />
        {(controls.error || controls.pending) && <div className="island-keepsake-recovery">
            {controls.error && <div className="island-error" role="alert"><p>{controls.error}</p>
                {controls.retry && <button className="island-secondary" data-keepsake-action="retry" disabled={disabled} onClick={() => { void controls.retry!(); }}>たなの きろくを たしかめる</button>}</div>}
            {controls.pending && <p role="status">{controls.pending.type === 'display-earned' ? 'もっているものを ぜんぶ かざる'
                : `${awardName(controls.pending.keepsakeId)}を ${controls.pending.displayed ? 'かざる' : 'しまう'}`} きろくを {controls.error ? 'もういちど たしかめられるよ。' : 'たしかめているよ。'}</p>}
        </div>}
        {currentSection === 'home' && <IslandHouseOverview active={active} disabled={disabled} comparisonDisabled={comparisonDisabled}
            walkingAvailable={walkingAvailable} onAlbum={onAlbum} onPhotos={onPhotos} onGrowingGuide={onGrowingGuide}>{choose => <>
            <nav className="island-house-destinations" aria-label="いえの なかで みるもの">
                {onGrowingGuide && <button className="island-secondary" data-keepsake-action="growing-guide" disabled={disabled} onClick={() => choose(onGrowingGuide)}>
                    <IslandToyIcon kind="book" /><strong>しまの あそびかた</strong><small>ためすことと、できたこと</small></button>}
                {onShared && <button className="island-secondary" data-keepsake-action="shared" disabled={disabled} onClick={() => choose(onShared)}>
                    <IslandToyIcon kind="display" /><strong>かざりと きおく</strong><small>だいじな たからもの</small></button>}
                <button className="island-secondary" data-keepsake-action="open-keepsakes" disabled={disabled} onClick={() => choose(() => changeSection('keepsakes'))}>
                    <IslandToyIcon kind="keepsake" /><strong>まなびの きねん</strong><small>{state.displayed.length > 0 ? `${state.displayed.length}こ かざっているよ` : earned.length > 0 ? 'きねんを かざろう' : 'まなびの あゆみ'}</small></button>
                <button className="island-secondary" data-keepsake-action="notices" disabled={disabled} onClick={() => choose(() => changeSection('notices'))}>
                    <IslandToyIcon kind="gift" /><strong>おしらせ</strong><small>{island.pendingRewards.length > 0 ? `おくりもの ${island.pendingRewards.length}こ` : 'けいじばんを みる'}</small></button>
            </nav>
            {decor && <div className="island-house-living">{decor}</div>}
            {challenge}
            <footer className="island-panel-footer">
                {onPhoto && <button className="island-secondary" disabled={disabled} onClick={() => choose(onPhoto)}><Camera size={18} aria-hidden="true" />しゃしんに のこす</button>}
                <button className="island-secondary" data-keepsake-action="learn" disabled={disabled} onClick={() => choose(onLearn)}>まなぶ<ArrowRight size={18} aria-hidden="true" /></button>
            </footer>
        </>}</IslandHouseOverview>}
        {currentSection === 'notices' && <article className="island-house-notices" aria-label="いえの おしらせ">
            <h3>おしらせ</h3>
            {island.pendingRewards.length > 0 ? <><p>おくりものが {island.pendingRewards.length}こ あるよ。</p>
                {onRewards && <button className="island-primary" data-keepsake-action="rewards" disabled={disabled} onClick={onRewards}>
                    <Gift size={18} aria-hidden="true" />おくりものを みる<ArrowRight size={17} aria-hidden="true" /></button>}</>
                : <p>いまは あたらしい おしらせは ないよ</p>}
        </article>}
        {currentSection === 'keepsakes' && <>
        <article className="island-keepsake-detail" aria-label="えらんだ きねんの きろく">
            <div className="island-keepsake-selected"><SelectedIcon size={36} aria-hidden="true" /><div>
                <p className="island-keepsake-eyebrow">{selected.slot === 'certificate' ? 'しょうじょう' : 'トロフィー'}</p><h3 ref={detailRef} tabIndex={-1}>{selected.name}</h3>
                <p role="status">{available ? displayed ? 'いま かざっているよ' : 'もっているよ・かざってみよう' : 'これからの きねん'}</p>
            </div></div>
            <p className="island-keepsake-milestone">{available ? `${selected.requiredCompletedSets}かいの まなびの くぎりを おえた きねんだよ。`
                : `あと ${remaining}かい、まなびの くぎりを おえると かざれるよ。`}</p>
            <div className="island-panel-actions island-keepsake-actions">
                {available ? <button className="island-primary" data-keepsake-action={displayed ? 'store' : 'display'} disabled={busy}
                    onClick={() => { void controls.act(displayAction(selected.id, !displayed)); }}>
                    {displayed ? <PackageOpen size={18} aria-hidden="true" /> : <Star size={18} aria-hidden="true" />}
                    {displayed ? 'しまう' : 'いえに かざる'}</button>
                    : <button className="island-primary" data-keepsake-action="learn" disabled={disabled} onClick={onLearn}>まなぶ<ArrowRight size={18} aria-hidden="true" /></button>}
                {onShowRoom && <button className="island-secondary" data-keepsake-action="room" disabled={disabled} onClick={() => { onShowRoom(); changeSection('home'); }}>
                    <House size={18} aria-hidden="true" />いえを みわたす</button>}
            </div>
        </article>
        {earned.length > 0 && <><div className="island-keepsake-collection-heading"><h3>もっている きねん</h3><p>{state.displayed.length}こ かざっているよ・{earned.length}こ もっているよ</p></div>
            <div className="island-keepsake-choices island-panel-choices" role="group" aria-label="もっている きねんを えらぶ">{choices(earned)}</div></>}
        {earned.length > 1 && <button className="island-secondary island-keepsake-display-all" data-keepsake-action="display-earned"
            disabled={busy || earned.length === state.displayed.length} onClick={() => { void controls.act({ type: 'display-earned' }); }}>
            <Trophy size={18} aria-hidden="true" />もっているものを ぜんぶ かざる</button>}
        <details className="island-keepsake-history" data-keepsake-history><summary>まなびの きろくを みる</summary>
            <p className="island-keepsake-count">まなびの くぎりを <strong>{island.completedSets}かい</strong> おえたよ。</p>
            {available && summary?.completedAt !== undefined && <p data-keepsake-earned-date>
                {new Date(summary.completedAt).toLocaleDateString('ja-JP', { year: 'numeric', month: 'long', day: 'numeric' })}の きねん</p>}
            {available && summary && summary.recordScope !== 'count-only' && <div>
                <h4>たしかめられた まなびの きろく</h4>
                <p>{summary.verifiedCompletedSets}かいの くぎり{summary.problemCount !== undefined ? `・${summary.problemCount}もん` : ''}</p>
                {summary.subjects.length > 0 && <ul>{summary.subjects.map(entry => <li key={entry.subject}>{subjectName(entry.subject)}：{entry.problemCount}もん</li>)}</ul>}
                {summary.examples.length > 0 && <ul>{summary.examples.map((entry, index) => <li key={`${entry.subject}:${index}`}>{entry.questionText}</li>)}</ul>}
                {summary.recordScope === 'partial' && <p>のこっている きろくの ぶんを みているよ。</p>}
            </div>}
            {controls.reading && <p role="status">まなんだ きろくを ひらいているよ…</p>}
            {controls.readError && <div className="island-error" role="alert"><p>{controls.readError}</p>
                <button className="island-secondary" onClick={controls.retryRead} disabled={disabled}>きろくを ひらきなおす</button></div>}
        </details>
        {future.length > 0 && <details className="island-keepsake-future" data-keepsake-future><summary>これからの きねん（{future.length}こ）</summary>
            <div className="island-keepsake-choices island-panel-choices" role="group" aria-label="これからの きねんを えらぶ">{choices(future)}</div>
        </details>}
        <p className="island-keepsake-note">むりょうで かざったり しまったり できるよ。たなに かざるものは、けしきの きろくとは べつに のこるよ。</p>
        </>}
        {currentSection !== 'home' && <footer className="island-panel-footer">
            {onPhoto && <button className="island-secondary" disabled={disabled} onClick={onPhoto}><Camera size={18} aria-hidden="true" />しゃしんに のこす</button>}
            {(currentSection !== 'keepsakes' || available) && <button className="island-secondary" data-keepsake-action="learn" disabled={disabled} onClick={onLearn}>まなぶ<ArrowRight size={18} aria-hidden="true" /></button>}
        </footer>}
    </section>;
}
