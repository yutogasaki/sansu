import { IslandSessionStage } from './IslandSessionStage';
import { islandSessionHouseStage } from './islandSessionHouseStage';
import { islandSessionPlacementStage } from './islandSessionPlacementStage';
import { islandSessionSharedStage } from './islandSessionSharedStage';
import { islandSessionPhotoStage } from './islandSessionPhotoStage';
import { islandSessionWorkshopStage } from './islandSessionWorkshopStage';
import { islandSessionPlayStage } from './islandSessionPlayStage';
import { IslandSessionPhotos } from './IslandSessionPhotos';
import { IslandSessionWorkshop } from './IslandSessionWorkshop';
import { useIslandSessionPlacement } from './useIslandSessionPlacement';
import { lazy, Suspense } from 'react';
import { useIslandSessionState } from './useIslandSessionState';
import { useIslandSessionLearning } from './useIslandSessionLearning';
import { Spinner } from '../../components/ui/Spinner';
import { GrowingLoading } from './growing/GrowingLoading';
import type { GrowingGuideRequest } from './growing/GrowingGuideEntry';
import { useGrowingRoom } from './growing/useGrowingRoom';
import { lifeDb } from '../../domain/islandLife/repository';
import { savedHeroStyle } from '../../domain/islandLife/savedHeroStyle';
import { IslandProfileSwitcher } from './IslandProfileSwitcher';
import { IslandHelp, IslandTutorial, TUTORIAL_TOPICS } from './tutorial/IslandTutorial';
import { useIslandTutorial } from './tutorial/useIslandTutorial';
import type { TutorialId } from '../../domain/island/tutorialState';
import { useLearningSessionLease } from '../../hooks/useLearningSessionLease';
import { ChallengePanel } from '../../components/challenge/ChallengePanel';
import { useEffect, useEffectEvent, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useLocation, useNavigate } from 'react-router-dom';
import { Camera, Gift, Leaf, Settings2, X } from 'lucide-react';
import { useIslandNavigation } from './useIslandNavigation';
import type { IslandScreen } from '../../domain/island/navigation';
import { db } from '../../db';
import { updateProfileAtomically } from '../../domain/user/repository';
import type { UserProfile } from '../../domain/types';
import { claimIslandReward, startIslandPlan } from '../../domain/island/repository';

import { useIslandLearningObservation } from './useIslandLearningObservation';
import { isFirstIslandPlan } from '../../domain/island/learningSession';
import { setIslandNextSubject } from '../../domain/island/subjectPreference';
import { isValidIslandPlacement } from '../../domain/island/catalog';
import { ISLAND_DELIVERY_ID, ISLAND_VISUAL_CANDIDATE, ISLAND_LEARNING_CANDIDATE, islandEnabled } from '../../domain/island/feature';
import type { IslandBasicItemKind, IslandHabitatId } from '../../domain/island/types';
import { selectIslandGrowthTarget } from '../../domain/island/growthRepository';
import { reachPwaUpdateCheckpoint } from '../../pwa';
import { setSoundEnabled } from '../../utils/audio';

import { IslandInventory, IslandPlacement, IslandPlacementActions, IslandPlay, IslandRewards } from './IslandItems';
import { useIslandActions } from './useIslandActions';
import { useIslandDiscoveries } from './useIslandDiscoveries';
import { IslandDistricts, IslandGrowthChoices, type IslandDistrict } from './IslandGrowth';

import { isIslandHabitatUnlocked } from '../../domain/island/growth';
import { IslandMilestoneNotice } from './IslandMilestone';
import { useIslandMilestoneNotice } from './useIslandMilestoneNotice';
import { IslandLearningPanel } from './IslandLearningPanel';
import { useEnglishListening } from '../../hooks/useEnglishListening';
import { EnglishListening, EnglishListeningEntry } from '../../components/domain/EnglishListening';
import { IslandSoundControl } from './IslandSoundControl';

import { getIslandCosmetics } from '../../domain/island/customization';
import type { IslandAppearanceSlotId } from '../../domain/island/appearance';
import { IslandCustomizationPreviewNotice } from './IslandCustomizationPreviewNotice';
import { IslandSessionHouse } from './IslandSessionHouse';
import { IslandToyIcon } from './IslandToyIcon';
import { useIslandLearningKeepsakes } from './useIslandLearningKeepsakes';
import type { IslandLearningKeepsakeId } from '../../domain/island/learningKeepsakes';
import { islandHomeDistrict } from './islandDistrictView';
import { useIslandRewardGoal } from './useIslandRewardGoal';
import { useIslandCustomization } from './useIslandCustomization';
import { IslandStarReceipt } from './IslandStarReceipt';

import { islandDiscoveryGuide } from './islandDiscoveryHints';
import { islandGrowthPreview } from './islandGrowthPreview';
import { getIslandExperience, ISLAND_RESIDENT_IDS, ISLAND_RESIDENT_PROFILES, type IslandResidentId } from '../../domain/island/experience';
import { getOwnedIslandFurniture, isIslandOptionalFurnitureKind, type IslandOptionalFurnitureKind } from '../../domain/island/furniture';

import { useIslandFurniture } from './useIslandFurniture';
import { islandFurnitureTrial } from './islandFurnitureTrial';
import { furniturePlacementKey } from './islandFurniturePlacement';

import { useIslandExperience } from './useIslandExperience';

import { useIslandExpression } from './useIslandExpression';
import { getIslandExpression, type IslandExpressionEquipAction, type IslandExpressionItemId, type IslandExpressionRequirement } from '../../domain/island/expression';
import { useIslandAmbience } from './useIslandAmbience';
import { useIslandPhotos } from './useIslandPhotos';
import type { IslandDisplayPreview } from './IslandSharedMemories';
import { findSharedDisplayPosition } from './islandSharedPlacement';

import { useIslandSharedMemories } from './useIslandSharedMemories';
import { isValidSharedDisplayPlacement, resolveSharedTarget, SHARED_DISPLAY_IDS, sharedDisplayKey,
    type SharedDisplayId, type SharedTarget, type SharedTargetRef } from '../../domain/island/sharedMemories';
import type { IslandSharedSceneRequest, IslandStageState } from './three/types';
import type { IslandWorkshopView } from './IslandWorkshop';
import { useIslandWorkshop } from './useIslandWorkshop';
import { useIslandWorkshopAudio } from './useIslandWorkshopAudio';
import type { WorkshopSceneRequest } from './three/workshopScene';
import '../../components/domain/LearningAnswerForm.css';
import './Island.css';
import './IslandDisplayLayout.css';
import './IslandWideWorkspace.css';
import './IslandImmersiveLayout.css';
import './IslandHouseOverview.css';

type Screen = IslandScreen;
const GrowingIsland = lazy(() => import('./growing/GrowingIsland'));
// A deliberately gated art transfer inside the app. Standard builds exclude its model.
const NativeIslandArt = (import.meta.env.DEV || import.meta.env.VITE_ISLAND_ART_STUDY === 'true')
    ? lazy(() => import('./growing/native/NativeIslandArt')) : undefined;
const GrowingHouseGuide = lazy(() => import('./growing/GrowingHouseGuide'));
const IslandAlbum = lazy(() => import('./IslandAlbum').then(module => ({ default: module.IslandAlbum })));
const IslandCustomization = lazy(() => import('./IslandCustomization').then(module => ({ default: module.IslandCustomization })));
const IslandDiscoveryGuide = lazy(() => import('./IslandDiscoveryGuide').then(module => ({ default: module.IslandDiscoveryGuide })));
const IslandFurniture = lazy(() => import('./IslandFurniture').then(module => ({ default: module.IslandFurniture })));
const IslandExperiencePanel = lazy(() => import('./IslandExperiencePanel').then(module => ({ default: module.IslandExperiencePanel })));
const IslandExpression = lazy(() => import('./IslandExpression').then(module => ({ default: module.IslandExpression })));
const IslandSharedMemories = lazy(() => import('./IslandSharedMemories').then(module => ({ default: module.IslandSharedMemories })));

export function IslandSession({ profile }: { profile: UserProfile }) {
    const [nativeArt, setNativeArt] = useState(() => Boolean(NativeIslandArt) && new URLSearchParams(window.location.search).get('islandArt') === 'native05');
    const [growingProfileSwitchBlocked, setGrowingProfileSwitchBlocked] = useState(false);
    const navigate = useNavigate();
    const location = useLocation();
    const navigation = useIslandNavigation();
    const hasShell = Boolean(navigation);
    const active = navigation?.active ?? true;
    const { opening, nextPlanError, setNextPlanError, setSnapshot, island, plan, setPlan,
        localScreen, setLocalScreen, loadError, clearEntry } = useIslandSessionState(profile, hasShell);
    const [challengeStartIntent, setChallengeStartIntent] = useState(false);
    const challengeSummary = useLiveQuery(() => db.challengeSummaries.get(profile.id), [profile.id]);
    const [houseGuideAt, setHouseGuideAt] = useState<string>();
    const [growingGuideRequest, setGrowingGuideRequest] = useState<GrowingGuideRequest>();
    // An old reservation's gift is part of the same focused session. Changing
    // the route here would incorrectly allow a deferred PWA reload mid-receipt.
    const learningScreen = plan?.status === 'completed' && isFirstIslandPlan(plan) && !plan.growthTarget ? 'reward' : 'learning';
    const screen = navigation ? navigation.learning ? learningScreen : navigation.view : localScreen;
    // The growing island keeps its own save; the current island's record is left untouched.
    const [roomWord, setRoomWord] = useState<{ text: string; japanese?: string; at: number }>();
    useEffect(() => { if (!roomWord) return; const id = window.setTimeout(() => setRoomWord(undefined), 2600); return () => clearTimeout(id); }, [roomWord]);
    const growingRoom = useGrowingRoom(profile.id, profile.vocabWords, screen === 'keepsakes', profile.mathSkills);
    const savedLife = useLiveQuery(() => lifeDb.worlds.get(profile.id), [profile.id]);
    const learningHeroStyle = useMemo(() => savedHeroStyle(savedLife), [savedLife]);
    const setScreen = navigation?.setView ?? setLocalScreen;
    const listening = useEnglishListening(profile.id, active && screen === 'learning' && profile.subjectMode !== 'math', profile.vocabLevels ?? [], plan?.slots[plan.cursor]?.problem);
    const learningLease = useLearningSessionLease(profile.id, active && screen === 'learning');
    useEffect(() => { if (screen === 'challenge') setChallengeStartIntent(false); }, [screen]);
    const [workshopView, setWorkshopView] = useState<IslandWorkshopView>({ mode: 'observe', selectedSpecimenId: 'driftwood', selectedPartId: 'straight', selectedToolId: 'brush' });
    const [workshopRequest, setWorkshopRequest] = useState<WorkshopSceneRequest>();
    const [sharedSelection, setSharedSelection] = useState<SharedDisplayId>();
    const [sharedPreview, setSharedPreview] = useState<IslandDisplayPreview>();
    const [sharedRequest, setSharedRequest] = useState<IslandSharedSceneRequest>();
    const [sharedFeedback, setSharedFeedback] = useState<string>();
    const [workReplay, setWorkReplay] = useState<{ ref: SharedTargetRef; target: Extract<SharedTarget, { kind: 'work' }> }>();
    const [showCurrentDraft, setShowCurrentDraft] = useState(false);
    const [growthPreviewHabitat, setGrowthPreviewHabitat] = useState<IslandHabitatId>();
    const [growthViewHabitat, setGrowthViewHabitat] = useState<IslandHabitatId>('garden');
    const [guideLocation, setGuideLocation] = useState<{ habitat: IslandHabitatId; discoveryId?: string }>({ habitat: 'garden' });
    const [returnToGuide, setReturnToGuide] = useState(false);
    const [photoTargetId, setPhotoTargetId] = useState('island');
    const [photoOrigin, setPhotoOrigin] = useState<Screen>('home');
    const [portraitResident, setPortraitResident] = useState<'otter' | 'rabbit' | 'fox'>();
    const [keepsakeFocus, setKeepsakeFocus] = useState<IslandLearningKeepsakeId>();
    const [localHouseSection, setLocalHouseSection] = useState<'home' | 'keepsakes' | 'notices'>('home');
    const houseSection = navigation?.houseSection ?? localHouseSection;
    const setHouseSection = navigation?.setHouseSection ?? setLocalHouseSection;
    useLayoutEffect(() => { setLocalHouseSection('home'); setKeepsakeFocus(undefined); }, [navigation?.houseEntry]);
    useLayoutEffect(() => { if (houseSection !== 'keepsakes') setKeepsakeFocus(undefined); }, [houseSection]);
    const [returnToHouse, setReturnToHouse] = useState(false);
    const focusHouseAlbumOnReturn = useRef(false);
    const [expressionResident, setExpressionResident] = useState<IslandResidentId>();
    const [expressionEntryItem, setExpressionEntryItem] = useState<IslandExpressionItemId>('raincoat');
    const [expressionFlagFocus, setExpressionFlagFocus] = useState(false);
    const [expressionWalk, setExpressionWalk] = useState<IslandStageState['expressionWalkRequest']>();
    const [preparingLearning, setPreparingLearning] = useState(false);
    const [experienceEntryTab, setExperienceEntryTab] = useState<'island' | 'layouts'>('island');
    const [playRequest, setPlayRequest] = useState<IslandStageState['playRequest']>();
    const [playResident, setPlayResident] = useState<IslandResidentId>();
    useEffect(() => { if (screen !== 'play') setPlayResident(undefined); }, [screen]);
    const [furnitureKind, setFurnitureKind] = useState<IslandOptionalFurnitureKind>('telescope');
    const [furnitureResident, setFurnitureResident] = useState<IslandResidentId>('otter');
    const [furniturePartner, setFurniturePartner] = useState<IslandResidentId>('rabbit');
    const [cosmeticFocus, setCosmeticFocus] = useState<IslandAppearanceSlotId | 'all'>('all');
    const [chosenDistrict, setDistrict] = useState<IslandDistrict>();
    const district = islandHomeDistrict(island, chosenDistrict);
    const [albumComparison, setAlbumComparison] = useState<IslandHabitatId | 'all'>('garden');
    const [playMessage, setPlayMessage] = useState<string>();
    const { busy, busyKind, error, run } = useIslandActions();
    const { preview, setPreview, placementSuggestionId, setPlacementSuggestionId,
        furniturePlacementSearch, setFurniturePlacementSearch, furniturePlacementResult, setFurniturePlacementResult,
        returnToFurniture, setReturnToFurniture, select, appearance, place } = useIslandSessionPlacement({
        profileId: profile.id, island, screen, setScreen, busy, active, opening, hasShell, navigation, run,
        setSnapshot, setDistrict, setPlayRequest, setPlayMessage, returnToGuide, returnToHouse,
        onPlaced: () => { setReturnToHouse(false); setHouseSection('home'); setKeepsakeFocus(undefined); },
    });
    const milestoneNotice = useIslandMilestoneNotice(profile.id, active && screen === 'learning' && !preparingLearning,
        Boolean(error || loadError || nextPlanError));
    const comparisonDisabled = busy && busyKind !== 'discovery';
    const [tutorialStageReady, setTutorialStageReady] = useState(false);
    const tutorial = useIslandTutorial({ profileId: profile.id, eligible: false, screen, active,
        allowed: !opening && !busy && !preparingLearning && !error && !loadError && !nextPlanError
            && (tutorialStageReady || screen === 'inventory') && !(screen === 'play' && playMessage),
        grown: Boolean(island?.completedSets), canView: true });
    const customization = useIslandCustomization(island, active && screen === 'customization', run, setSnapshot);
    const furniture = useIslandFurniture(island, active && screen === 'furniture', run, setSnapshot);
    const experience = useIslandExperience(island, active && screen === 'experience', run, setSnapshot);
    const expression = useIslandExpression(island, active && screen === 'expression', run, setSnapshot);
    const keepsakes = useIslandLearningKeepsakes(island, active && screen === 'keepsakes' && !preparingLearning, run,
        updated => setSnapshot(previous => previous?.profileId === updated.profileId && previous.revision > updated.revision ? previous : updated));
    const rewardGoal = useIslandRewardGoal(island, active && !preparingLearning && ['home', 'customization', 'furniture', 'expression'].includes(screen) ? screen : undefined,
        run, updated => setSnapshot(previous => previous?.profileId === updated.profileId && previous.revision > updated.revision ? previous : updated));
    const photos = useIslandPhotos(profile.id, active && (screen === 'camera' || screen === 'photos' || screen === 'expression'), run);
    const sharedActions = useIslandSharedMemories(island, active && (screen === 'shared' || screen === 'workshop' && Boolean(workReplay)
        || screen === 'camera' && photoOrigin === 'shared'), run, (updated, action) => {
        setSnapshot(updated);
        if (action?.type === 'place-display') setSharedPreview(previous => previous && previous.displayId === action.displayId
            && previous.expectedDisplayKey === action.expectedDisplayKey && JSON.stringify(previous.ref) === JSON.stringify(action.target)
            && previous.position.x === action.position.x && previous.position.z === action.position.z && previous.rotation === action.rotation ? undefined : previous);
        if (action?.type === 'start-from-work' && workReplay && JSON.stringify(workReplay.ref) === JSON.stringify(action.target)) {
            setWorkReplay(undefined); setShowCurrentDraft(false); setWorkshopRequest(undefined);
        }
    });
    const workshopActions = useIslandWorkshop(island, screen === 'workshop', busy, run, setSnapshot);
    const workshopAudio = useIslandWorkshopAudio(active && profile.soundEnabled && screen === 'workshop');
    const experienceState = getIslandExperience(island ?? {});
    const experienceScene = screen === 'experience' ? experience.previewIsland ?? island : island;
    const expressionScene = screen === 'expression' ? expression.previewState?.selection ?? getIslandExpression(island ?? {}).selection
        : getIslandExpression(experienceScene ?? {}).selection;
    const sceneAmbience = expressionScene.soundscape ?? getIslandExperience(experienceScene ?? {}).ambience;
    const ambience = useIslandAmbience(sceneAmbience, profile.soundEnabled,
        active && !preparingLearning && ['home', 'play', 'experience', 'expression', 'showcase'].includes(screen),
        screen === 'expression' && expression.previewAction?.type === 'equip-soundscape');
    const discoveries = useIslandDiscoveries({ profileId: profile.id, island, enabled: active && ['home', 'play', 'showcase'].includes(screen), busy, run, onSaved: setSnapshot });
    const observation = useIslandLearningObservation();
    const { answer, slot, complex, latestMilestone, setLatestMilestone, starReceipt, setStarReceipt,
        pulse, reaction, setReaction, learningFeedback, setLearningFeedback } = useIslandSessionLearning({
        profile, island, plan, setPlan, setSnapshot, setNextPlanError, screen, setScreen, navigation,
        run, milestoneNotice, listening, observation,
    });
    useEffect(() => { setSoundEnabled(profile.soundEnabled); }, [profile.soundEnabled]);
    const begin = async () => {
        if (screen === 'challenge' || screen === 'learning' && learningLease !== 'ready') return;
        if (navigation && !navigation.learning) { navigation.startLearning(); return; }
        setPreparingLearning(true);
        // The shell keeps the ordinary page's selection and previews for close.
        if (!navigation) {
        expression.reset(); setExpressionWalk(undefined); setExpressionResident(undefined);
        setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined);
        furniture.reset(); setPlayRequest(undefined);
        photos.cancel();
        setSharedRequest({ id: crypto.randomUUID(), command: { type: 'stop' } });
        }
        ambience.stop();
        workshopAudio.stop();
        if (screen === 'workshop') setWorkshopRequest({ id: crypto.randomUUID(), command: { type: 'stop' } });
        const reserved = await run(() => startIslandPlan(profile.id));
        setPreparingLearning(false);
        if (!reserved || reachPwaUpdateCheckpoint('island-learning', { protectNextSession: true })) return;
        clearEntry(); setNextPlanError(false);
        if (!navigation) {
        customization.reset();
        experience.reset();
        setWorkshopRequest(undefined);
        setSharedPreview(undefined); setWorkReplay(undefined); setShowCurrentDraft(false);
        setGrowthPreviewHabitat(undefined); setReturnToGuide(false);
        setStarReceipt(undefined);
        if (screen !== 'learning') setLatestMilestone(undefined);
        setReturnToHouse(false);
        setPreview(undefined); setReaction(undefined);
        }
        setPlan(reserved); setScreen('learning');
    };
    const home = () => {
        if ((busy && !(['album', 'guide'].includes(screen) && busyKind === 'discovery'))
            || reachPwaUpdateCheckpoint('island-home', { protectNextSession: true })) return;
        if (returnToHouse && screen === 'album') focusHouseAlbumOnReturn.current = true;
        const destination = returnToHouse && ['album', 'photos', 'shared', 'reward'].includes(screen) ? 'keepsakes' : 'home';
        photos.cancel(); clearEntry(); setNextPlanError(false);
        expression.reset(); setExpressionWalk(undefined); setExpressionResident(undefined);
        furniture.reset(); setPlayRequest(undefined); setReturnToFurniture(false);
        setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined);
        setSharedRequest({ id: crypto.randomUUID(), command: { type: 'stop' } });
        setSharedPreview(undefined); setWorkReplay(undefined); setShowCurrentDraft(false);
        workshopAudio.stop();
        discoveries.revisit();
        customization.reset();
        experience.reset();
        setWorkshopRequest(undefined);
        setGrowthPreviewHabitat(undefined); setReturnToGuide(false);
        setStarReceipt(undefined);
        setReturnToHouse(false); setLocalHouseSection('home');
        if (!navigation) setKeepsakeFocus(undefined);
        setPreview(undefined); setLearningFeedback(undefined); setReaction(undefined);
        if (navigation) navigation.back(); else setScreen(destination);
    };
    useLayoutEffect(() => {
        if (!focusHouseAlbumOnReturn.current || screen !== 'keepsakes' || houseSection !== 'home') return;
        focusHouseAlbumOnReturn.current = false;
        const frame = requestAnimationFrame(() => {
            const target = document.querySelector<HTMLElement>('.island-page [data-keepsake-action="album"]:not(:disabled)')
                ?? document.querySelector<HTMLElement>('.island-page [data-house-menu-trigger]');
            target?.focus({ preventScroll: true });
        });
        return () => cancelAnimationFrame(frame);
    }, [screen, houseSection]);
    const learningStarted = useRef(false);
    const beginRequestedLearning = useEffectEvent(() => { void begin(); });
    const exitMismatchedLearning = useEffectEvent(() => navigation?.back());
    useEffect(() => {
        if (!navigation?.learning) { learningStarted.current = false; return; }
        if (navigation.targetProfile && navigation.targetProfile !== profile.id) { exitMismatchedLearning(); return; }
        if (busy || opening || loadError || learningStarted.current || learningLease !== 'ready') return;
        learningStarted.current = true;
        beginRequestedLearning();
    }, [navigation?.learning, navigation?.targetProfile, busy, opening, loadError, profile.id, learningLease]);
    const reportBlocked = navigation?.setBlocked;
    const reportLearningBlocked = navigation?.setLearningBlocked;
    useLayoutEffect(() => {
        reportBlocked?.(active && (busy && busyKind !== 'discovery' || preparingLearning || opening));
        reportLearningBlocked?.(busy || preparingLearning || opening || screen === 'challenge');
        return () => { reportBlocked?.(false); reportLearningBlocked?.(false); };
    }, [reportBlocked, reportLearningBlocked, active, busy, busyKind, preparingLearning, opening, screen]);
    const enterHouse = () => {
        if (comparisonDisabled) return;
        setReturnToHouse(false);
        setLocalHouseSection('home');
        setKeepsakeFocus(undefined); setPreview(undefined); setReaction(undefined); setPlayRequest(undefined); setScreen('keepsakes');
    };
    const openCustomization = () => {
        if (busy) return;
        setCosmeticFocus('all');
        customization.open(); setPreview(undefined); setReaction(undefined); setPlayRequest(undefined);
        setScreen('customization');
    };
    const openFurniture = () => {
        if (busy) return;
        customization.reset(); experience.reset(); furniture.reset();
        setPreview(undefined); setPlayRequest(undefined); setReaction(undefined); setPlayMessage(undefined);
        setReturnToFurniture(false); setScreen('furniture');
    };
    const receiveFurniture = async (retry = false) => {
        const kind = retry ? furniture.pendingKind : furnitureKind;
        if (!kind || busy) return;
        setPlayRequest(undefined);
        const updated = retry ? await furniture.retry?.() : await furniture.purchase(kind);
        if (!updated) return;
        const item = getOwnedIslandFurniture(updated, kind);
        if (item) select(item, updated);
    };
    const openGuide = () => {
        if (comparisonDisabled) return;
        setPreview(undefined); setReaction(undefined); setPlayRequest(undefined); setScreen('guide');
    };
    const openExperience = () => {
        if (busy) return;
        expression.reset(); setExpressionWalk(undefined); setExpressionResident(undefined);
        experience.reset(); photos.cancel(); setPreview(undefined); setReaction(undefined); setPlayRequest(undefined); setExperienceEntryTab('island'); setScreen('experience');
    };
    const openExpression = () => {
        if (busy) return;
        setExpressionEntryItem('raincoat');
        customization.reset(); experience.reset(); expression.reset(); photos.cancel();
        setExpressionWalk(undefined); setExpressionResident(undefined); setExpressionFlagFocus(false);
        setPreview(undefined); setReaction(undefined); setPlayRequest(undefined); setScreen('expression');
    };
    const previewExpression = (action: IslandExpressionEquipAction | undefined) => {
        expression.preview(action);
        setExpressionWalk(action?.type === 'equip-trail' && action.itemId ? { id: crypto.randomUUID(), residentId: action.residentId } : undefined);
    };
    const visitExpression = (requirement: IslandExpressionRequirement) => {
        if (busy) return;
        expression.reset(); setExpressionWalk(undefined); setExpressionResident(undefined);
        if (requirement === 'bell') {
            if (!island || island.completedSets < 1) { void begin(); return; }
            openWorkshop(); setWorkshopView(view => ({ ...view, mode: 'build', selectedPartId: 'bell', residentId: undefined }));
        } else {
            setGuideLocation({ habitat: requirement === 'ribbon-butterfly' ? 'garden' : 'grove', discoveryId: requirement }); openGuide();
        }
    };
    const openWorkshop = () => {
        if (busy || !island || island.completedSets < 1) return;
        setWorkReplay(undefined); setShowCurrentDraft(false);
        ambience.stop(); setWorkshopRequest(undefined); setPreview(undefined); setReaction(undefined); setPlayRequest(undefined); setScreen('workshop');
    };
    const sharedCommand = (command: IslandSharedSceneRequest['command']) => {
        setSharedFeedback(undefined); setSharedRequest({ id: crypto.randomUUID(), command });
    };
    const openShared = (ref?: SharedTargetRef, selected?: SharedDisplayId) => {
        if (busy || !island || island.completedSets < 1) return;
        photos.cancel(); workshopAudio.stop(); setWorkshopRequest(undefined); setPlayRequest(undefined); setReaction(undefined);
        setSharedFeedback(undefined); setSharedPreview(undefined); setSharedSelection(selected); setWorkReplay(undefined); setShowCurrentDraft(false);
        sharedCommand({ type: 'stop' }); setDistrict('all'); setScreen('shared');
        if (ref) {
            try {
                const target = resolveSharedTarget(island, ref);
                const displayId = SHARED_DISPLAY_IDS.find(id => island.sharedMemories?.displays[id]?.target.targetKey === target.targetKey);
                if (displayId) { setSharedSelection(displayId); return; }
                const id = SHARED_DISPLAY_IDS.find(id => !island.sharedMemories?.displays[id]) ?? 'display-1';
                const current = island.sharedMemories?.displays[id];
                const position = current?.position ?? findSharedDisplayPosition(island, id, target) ?? { x: 0, z: 1 };
                setSharedSelection(id); setSharedPreview({ displayId: id, target, ref, position, rotation: current?.rotation ?? 0,
                    valid: isValidSharedDisplayPlacement(island, id, target, position), expectedDisplayKey: sharedDisplayKey(current) });
            } catch { setSharedFeedback('この ものを もういちど えらんでね。'); }
        }
    };
    const revisitShared = (ref: SharedTargetRef, target: SharedTarget) => {
        if (busy) return;
        sharedCommand({ type: 'stop' }); setSharedPreview(undefined); workshopAudio.stop(); setWorkshopRequest(undefined);
        setShowCurrentDraft(false);
        if (target.kind === 'work') { setWorkReplay({ ref, target }); setWorkshopView(view => ({ ...view, mode: 'build', residentId: undefined })); }
        else { setWorkReplay(undefined); setWorkshopView(view => ({ ...view, mode: 'observe', selectedSpecimenId: target.specimenId, residentId: undefined })); }
        setScreen('workshop');
    };
    const photograph = () => {
        if (busy) return;
        photos.cancel(); setPhotoOrigin(screen);
        setPhotoTargetId(screen === 'shared' && sharedSelection && island?.sharedMemories?.displays[sharedSelection] ? `display-${sharedSelection}`
            : screen === 'workshop' ? 'inlet' : screen === 'keepsakes' ? 'keepsakes' : ['play', 'showcase'].includes(screen) ? 'current'
            : screen === 'experience' && portraitResident ? `resident-${portraitResident}` : 'island');
        setScreen('camera');
    };
    const openPhotos = () => {
        if (busy) return;
        if (screen === 'keepsakes' || screen === 'camera' && photoOrigin === 'keepsakes') setReturnToHouse(true);
        photos.cancel(); setWorkshopRequest(undefined); setPlayRequest(undefined); setReaction(undefined);
        if (navigation) navigation.openPhotoGallery(); else setScreen('photos');
    };
    const tryDiscovery = (itemId: string, discoveryId: string) => {
        if (busy || !island) return;
        const entry = islandDiscoveryGuide(island, discoveryId);
        if (entry) setGuideLocation({ habitat: entry.entry.habitatId, discoveryId });
        setReturnToGuide(true); setPreview(undefined); setPlayMessage(undefined); setDistrict('all');
        setScreen('play'); setPlayRequest({ id: crypto.randomUUID(), itemId, discoveryId });
    };
    const play = (itemId: string) => {
        if (busy || screen !== 'play') return;
        setPlayMessage(undefined);
        setPlayRequest({ id: crypto.randomUUID(), itemId, residentId: playResident });
    };
    const chooseGrowth = async (habitatId: IslandHabitatId) => {
        if (!island) return;
        const updated = await run(() => selectIslandGrowthTarget(profile.id, island.revision, habitatId));
        if (!updated) return;
        setSnapshot(updated); setGrowthPreviewHabitat(undefined); setScreen('home');
        return updated;
    };
    const claim = async (rewardId: string, kind: IslandBasicItemKind) => {
        if (!island) return;
        const updated = await run(() => claimIslandReward(profile.id, island.revision, rewardId, kind));
        if (!updated) return;
        setSnapshot(updated);
        const item = updated.items.find(candidate => candidate.id === `${rewardId}:item`);
        if (item) select(item, updated);
    };
    const tryTutorial = (id: TutorialId) => {
        const topic = TUTORIAL_TOPICS.find(topic => topic.id === id)!;
        const target = id === 'view' ? 'play' : topic.screen;
        if (id === 'view' || id === 'play') { setPlayRequest(undefined); setPlayMessage(undefined); setPreview(undefined); }
        tutorial.start(id, target);
        if (id === 'photo') photograph();
        else if (id === 'customization') openCustomization();
        else if (id === 'growth') {
            setGrowthViewHabitat(plan?.growthTarget ?? island?.growth?.focus ?? 'garden'); setScreen('growth');
        } else setScreen(target);
    };
    const learning = screen === 'learning';
    if (loadError) return <IslandLoadingError />;
    if (opening || !island) return <GrowingLoading step="page" />;
    const valid = Boolean(preview?.position && isValidIslandPlacement(island, preview.id, preview.position, preview.rotation));
    const growthLook = screen === 'growth' && growthPreviewHabitat ? islandGrowthPreview(island, growthPreviewHabitat) : undefined;
    const stageIsland = growthLook?.island ?? (screen === 'experience' ? experience.previewIsland : undefined) ?? island;
    const furnitureTrial = screen === 'furniture' && !busy && !furniture.pendingKind ? islandFurnitureTrial(island, furnitureKind) : undefined;
    const furniturePlacementChoice = screen === 'placement' && preview && isIslandOptionalFurnitureKind(preview.kind) && !busy
        ? { residentId: furnitureResident, ...(preview.kind === 'tea-table' ? { partnerId: furniturePartner } : {}) } : undefined;
    const placementAvailability = preview && furniturePlacementChoice && furniturePlacementResult?.key === furniturePlacementKey(preview, furniturePlacementChoice)
        ? furniturePlacementResult : undefined;
    const photoResidents = ISLAND_RESIDENT_IDS.filter(id => id !== 'fox' || island.completedSets >= 4 && isIslandHabitatUnlocked(island, 'waterside'));
    const photoResident = photoResidents.find(id => photoTargetId === `resident-${id}`);
    const cameraInlet = screen === 'camera' && photoTargetId === 'inlet';
    const photoDisplayId = SHARED_DISPLAY_IDS.find(id => photoTargetId === `display-${id}` && island.sharedMemories?.displays[id]);
    const keepsakeRoomActive = !preparingLearning && (screen === 'keepsakes' || screen === 'camera' && photoTargetId === 'keepsakes');
    const savePlacement = () => { setFurniturePlacementSearch(undefined); void place(); };
    const cancelPlacement = navigation ? home : returnToFurniture ? () => {
        setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined); setPreview(undefined); setScreen('furniture');
    } : home;
    const houseOverview = screen === 'keepsakes' && houseSection === 'home';
    const soundControl = <IslandSoundControl key={screen} enabled={profile.soundEnabled} disabled={busy} onChange={enabled => run(async () => {
        const updated = await updateProfileAtomically(profile.id, current => ({ ...current, soundEnabled: enabled }));
        if (!updated) throw new Error('Profile unavailable');
        return updated;
    }).then(updated => Boolean(updated))} />;
    const homeUtilities = <>
        <span className="growing-pocket-profile">{profile.name}</span>
        <IslandProfileSwitcher activeId={profile.id} disabled={busy || preparingLearning || opening || growingProfileSwitchBlocked || Boolean(navigation?.blocked || navigation?.learningBlocked)} />
        {soundControl}
        {milestoneNotice.milestone && <IslandMilestoneNotice milestone={milestoneNotice.milestone} island={island} />}
    </>;
    return <main className="island-page" data-tutorial-topic={tutorial.current?.id} data-layout-version="display-v1" data-game-id="mystic-island-v1" data-mode={screen} data-life-home={screen === 'home' ? 'true' : undefined} data-home-layout={screen === 'home' ? 'world-first-v2' : undefined} data-complex={Boolean(learning && complex)}
        data-house-layout={houseOverview ? 'world-first-v1' : undefined} data-house-candidate={houseOverview ? 'house-world-first-v1' : undefined}
        data-visual-candidate-id={ISLAND_VISUAL_CANDIDATE} data-delivery-id={ISLAND_DELIVERY_ID}
        data-learning-candidate={ISLAND_LEARNING_CANDIDATE}
        data-island-feature-enabled={String(islandEnabled())}
        data-island-revision={island.revision} data-discovery-count={island.growth?.discoveries.length ?? 0}
        data-build-revision={__BUILD_REVISION__} data-build-version={__APP_VERSION__} data-busy={busy}>
        {!['home', 'showcase', 'placement'].includes(screen) && <header className="island-header"><div className="island-brand" data-learning-milestone={learning ? Boolean(milestoneNotice.milestone) : undefined}>
            {houseOverview ? <IslandToyIcon kind="house" size={25} /> : <Leaf size={20} />}<div>{houseOverview || screen === 'home'
                ? <h1 title={houseOverview ? `${profile.name}の いえ` : island.experience?.islandName}>{profile.name}の {houseOverview ? 'いえ' : 'しま'}</h1>
                : <><p>{profile.name}の</p><h1 title={island.experience?.islandName}>{island.experience?.islandName ?? 'ふしぎな しま'}</h1></>}</div>
            {milestoneNotice.milestone && <IslandMilestoneNotice milestone={milestoneNotice.milestone} island={island} />}</div>
            <div className="island-header-actions">{soundControl}
            {learning ? <div className="island-learning-return">
                {island.pendingRewards.length > 0 && <span className="island-learning-gifts" aria-label={`おくりもの ${island.pendingRewards.length}こ`}><Gift size={15} aria-hidden="true" />{island.pendingRewards.length}</span>}
                <button className="island-text-button island-learning-pause" disabled={busy || preparingLearning} onClick={() => {
                    if (navigation) navigation.back(); else home();
                }}><X size={20} />とじる</button></div>
                : navigation ? null : <button className="island-icon-button" aria-label="せってい" disabled={busy} onClick={() => navigate('/settings')}><Settings2 size={20} /></button>}</div>
        </header>}
        {(error || loadError) && <div className="island-error" role="alert"><p>{error}</p><button className="island-text-button" onClick={() => window.location.reload()}>よみなおす</button></div>}
        {roomWord && screen === 'keepsakes' && <p className="room-word" role="status" key={roomWord.at}><strong>{roomWord.text}</strong>{roomWord.japanese && <span>{roomWord.japanese}</span>}</p>}
        {screen === 'placement' && preview && <IslandPlacementActions valid={valid} disabled={busy} onSave={savePlacement} onCancel={cancelPlacement} />}
        {active && screen === 'home' && <Suspense fallback={<GrowingLoading step="screen" />}>
            {nativeArt && NativeIslandArt ? <NativeIslandArt onClose={() => setNativeArt(false)} /> : <GrowingIsland onProfileSwitchBlockedChange={setGrowingProfileSwitchBlocked} key={profile.id} profileId={profile.id} profileName={profile.name} active={active} sound={Boolean(profile.soundEnabled)} onHome={enterHouse} onLearn={() => void begin()}
                menuUtilities={homeUtilities} guideRequest={growingGuideRequest} onGuideRequestConsumed={() => setGrowingGuideRequest(undefined)} />
            }
        </Suspense>}
        {/* Learning hides the world. Do not create a legacy WebGL world
            behind the questions just to destroy it when returning home. */}
        {active && screen !== 'home' && !learning && !['help', 'album', 'photos', 'inventory', 'challenge'].includes(screen) && <IslandSessionStage screen={screen}
            house={islandSessionHouseStage({ screen, setScreen, island, busy, keepsakeRoomActive, houseOverview,
                challengeSummary, keepsakeFocus, growingRoom, soundEnabled: Boolean(profile.soundEnabled), keepsakes,
                enterHouse, begin, setReturnToHouse, setAlbumComparison, setKeepsakeFocus, setHouseSection, setRoomWord })}
            placement={islandSessionPlacementStage({ screen, island, busy, furnitureTrial, furnitureKind,
                furnitureResident, furniturePartner, furniturePlacementChoice, playRequest, valid,
                controls: { preview, setPreview, placementSuggestionId, setPlacementSuggestionId, furniturePlacementSearch,
                    setFurniturePlacementSearch, setFurniturePlacementResult }, setDistrict })}
            shared={islandSessionSharedStage({ screen, island, stageIsland, busy, learning, photoOrigin, photoDisplayId,
                sharedSelection, sharedPreview, sharedRequest, sharedActions, sharedCommand, setSharedPreview,
                setSharedSelection, setSharedFeedback, openShared })}
            photo={islandSessionPhotoStage({ screen, portraitResident, photoResident, photos })}
            workshop={islandSessionWorkshopStage({ screen, island, busy, cameraInlet, workshopView, workshopRequest,
                workReplay, showCurrentDraft, workshopActions, workshopAudio, setWorkshopView })}
            play={islandSessionPlayStage({ screen, island, busy, learning, playRequest, photoTargetId, tutorial,
                setPlayMessage, setWorkshopRequest, setSharedRequest, play, select })}
                common={{
                    onTutorialReady: setTutorialStageReady,
                    onCameraPractice: () => tutorial.practice('view'),
                    compactCameraControls: screen === 'play',
                    items: stageIsland.items,
                    completedSets: island.completedSets,
                    pulse: pulse,
                    learning: learning,
                    cosmeticFocus: screen === 'customization' ? cosmeticFocus : undefined,
                    experience: stageIsland.experience,
                    expressionSelection: screen === 'expression' ? expressionScene : getIslandExpression(stageIsland).selection,
                    expressionCaptionKey: screen === 'expression' ? `${expressionResident ?? 'world'}:${expression.previewAction?.type === 'equip-trail' ? expressionWalk?.id ?? '' : ''}` : undefined,
                    expressionResidentId: screen === 'expression' && !preparingLearning ? expressionResident : undefined,
                    expressionFlagFocus: screen === 'expression' && !preparingLearning && expressionFlagFocus,
                    expressionWalkRequest: screen === 'expression' && !preparingLearning && expression.previewAction?.type === 'equip-trail' ? expressionWalk : undefined,
                    cosmetics: screen === 'customization' ? customization.preview ?? getIslandCosmetics(island) : getIslandCosmetics(stageIsland),
                    milestoneNotice: screen === 'furniture' && furnitureTrial ? <aside className="island-growth-preview-notice" role="status"><strong>どうぐの おためし</strong>いまの しまは そのまま。</aside>
                : screen === 'customization' ? <IslandCustomizationPreviewNotice saved={getIslandCosmetics(island)} preview={customization.preview ?? getIslandCosmetics(island)} />
                : <>{growthLook && <aside className="island-growth-preview-notice" role="status"><strong>つぎに 育つ すがた・おためし</strong>{growthLook.description}</aside>}
                    {screen === 'experience' && experience.previewIsland && <aside className="island-growth-preview-notice" role="status"><strong>けしきの おためし</strong>いまの しまは そのまま。</aside>}
                    {screen === 'expression' && expression.previewAction && <aside className="island-growth-preview-notice" role="status"><strong>むりょうの おためし</strong>いまの しまは そのまま。</aside>}
                    {(learning || screen === 'reward') && starReceipt && <IslandStarReceipt key={starReceipt.id} receiptId={starReceipt.id} stars={starReceipt.stars} />}</>,
                    growth: stageIsland.growth,
                    growthTarget: plan?.status === 'active' ? plan.growthTarget : undefined,
                    comparisonHabitat: screen === 'growth' ? growthViewHabitat : undefined,
                    districtFocus: learning || screen === 'shared' || screen === 'customization' || screen === 'expression' || screen === 'furniture' || screen === 'camera' && photoTargetId !== 'current' ? 'all' : district,
                    readOnly: keepsakeRoomActive || ['growth', 'inventory', 'reward', 'customization', 'guide', 'experience', 'expression'].includes(screen),
                    onDiscovery: ['home', 'play', 'showcase'].includes(screen) ? discoveries.capture : undefined,
                    reaction: reaction,
                    learningProgress: (learning || screen === 'reward') && plan
                ? { sectionId: plan.id, completed: plan.cursor, total: plan.slots.length } : undefined,
                }} />}
        {tutorial.current && !customization.error && <IslandTutorial id={tutorial.current.id} onShown={tutorial.shown} onClose={tutorial.dismiss}
            text={tutorial.current.id === 'growth' && screen === 'home' ? '学んだぶん、しまが 育ったよ。育った すがたを みてみよう。' : undefined}
            action={tutorial.current.id === 'growth' && screen === 'home' ? 'みにいく' : undefined}
            onAction={() => { tutorial.practice('growth'); setAlbumComparison(latestMilestone?.habitats[0] ?? island.growth?.focus ?? 'garden'); setScreen('album'); }} />}
        {screen === 'placement' && <IslandDistricts island={island} value={district} disabled={busy} onChange={setDistrict} />}
        <Suspense fallback={<Spinner message="じゅんびしているよ…" />}>{learning && learningLease !== 'ready' ? <section className="island-sheet" role="status">{learningLease === 'loading' ? <Spinner destination="learning" message="まなぶ じゅんびを しているよ…" /> : 'ほかの がめんの まなびを とじてから、もういちど ひらこう。'}</section>
            : learning && nextPlanError ? <section className="island-sheet island-learning-retry">
            <p role="status">{plan?.status === 'completed' ? 'ここまで といたぶんは のこっているよ。' : 'まだ もんだいを ひらけなかったよ。'}</p>
            <button className="island-primary" disabled={busy} onClick={() => void begin()}>つづきの もんだいを ひらく</button>
        </section>
            : learning ? null
            : screen === 'help' ? <IslandHelp island={island} disabled={busy} onClose={home} onTry={tryTutorial} />
            : screen === 'challenge' ? active && <ChallengePanel key={profile.id} profileId={profile.id} initialStart={challengeStartIntent}
                onClose={() => { setChallengeStartIntent(false); if (navigation) navigation.back(); else setScreen('keepsakes'); }} />
            : screen === 'reward' ? <IslandRewards island={island} intro={island.completedSets === 1 && Boolean(plan && isFirstIslandPlan(plan))} disabled={busy} onChoose={(id, kind) => void claim(id, kind)} onContinue={() => void begin()} onClose={home} />
            : screen === 'play' ? <IslandPlay items={island.items} disabled={busy} selectedId={playRequest?.itemId} message={playMessage}
                residentName={playResident ? getIslandExperience(island).residents[playResident].name : undefined}
                districts={<IslandDistricts island={island} value={district} disabled={busy} onChange={setDistrict} />}
                onSelect={play} onMove={select} onInventory={() => setScreen('inventory')} onContinue={() => void begin()} onClose={home} onGuide={openGuide} onPhoto={photograph} />
            : screen === 'inventory' ? <IslandInventory items={island.items} disabled={busy} onSelect={select} onClose={home} onFurniture={openFurniture} />
                : screen === 'furniture' ? <IslandFurniture island={island} kind={furnitureKind} trial={furnitureTrial} disabled={busy}
                    rewardGoal={rewardGoal}
                    pending={Boolean(furniture.pendingKind)} error={furniture.error} feedback={playMessage}
                    residents={photoResidents.map(id => ({ id, name: experienceState.residents[id].name }))}
                    residentId={furnitureResident} partnerId={furniturePartner}
                    onSelect={kind => { setPlayRequest(undefined); setPlayMessage(undefined); setFurnitureKind(kind); }}
                    onResident={id => { setPlayRequest(undefined); setPlayMessage(undefined); setFurnitureResident(id);
                        if (id === furniturePartner) setFurniturePartner(photoResidents.find(candidate => candidate !== id)!); }}
                    onPartner={id => { setPlayRequest(undefined); setPlayMessage(undefined); setFurniturePartner(id); }}
                    onTry={() => { const target = getOwnedIslandFurniture(island, furnitureKind) ?? furnitureTrial;
                        if (!target?.position || busy) return;
                        setPlayMessage(undefined); setPlayRequest({ id: crypto.randomUUID(), itemId: target.id,
                            residentId: furnitureResident, ...(furnitureKind === 'tea-table' ? { partnerId: furniturePartner } : {}) }); }}
                    onPurchase={() => { void receiveFurniture(); }} onRetry={furniture.retry ? () => { void receiveFurniture(true); } : undefined}
                    onPlace={select} onInventory={() => { setPlayRequest(undefined); setScreen('inventory'); }} onClose={home} onLearn={() => void begin()} />
                : screen === 'camera' || screen === 'photos' ? <IslandSessionPhotos screen={screen} island={island} profileId={profile.id}
                    photos={photos} photoOrigin={photoOrigin} photoTargetId={photoTargetId} workshopView={workshopView}
                    workReplay={workReplay} showCurrentDraft={showCurrentDraft} keepsakeRoomActive={keepsakeRoomActive} disabled={busy}
                    onTarget={id => { photos.cancel(); setPhotoTargetId(id); }} onGallery={openPhotos}
                    onCamera={photograph} onCameraClose={() => { photos.cancel(); if (navigation) navigation.back(); else setScreen(photoOrigin); }}
                    onGalleryClose={home} onLearn={() => void begin()} />
                : screen === 'shared' ? <IslandSharedMemories island={island} selectedId={sharedSelection} preview={sharedPreview} disabled={busy}
                    onSelect={setSharedSelection} onPreview={setSharedPreview} onAction={sharedActions.act} onCommand={sharedCommand}
                    error={sharedActions.error} onRetry={sharedActions.retry} feedback={sharedFeedback}
                    onRevisit={revisitShared} onPhoto={photograph} onClose={home} onLearn={() => void begin()} />
                : screen === 'workshop' ? <IslandSessionWorkshop island={island} profileId={profile.id} busy={busy}
                    workshopView={workshopView} setWorkshopView={setWorkshopView} setWorkshopRequest={setWorkshopRequest}
                    workReplay={workReplay} setWorkReplay={setWorkReplay} showCurrentDraft={showCurrentDraft} setShowCurrentDraft={setShowCurrentDraft}
                    sharedSelection={sharedSelection} sharedActions={sharedActions} workshopActions={workshopActions} workshopAudio={workshopAudio}
                    openShared={openShared} onPhoto={photograph} onClose={home} onLearn={() => void begin()} />
                : screen === 'keepsakes' ? <IslandSessionHouse island={island} controls={keepsakes} disabled={busy} comparisonDisabled={comparisonDisabled}
                    active={active} profileId={profile.id} room={growingRoom}
                    onChallengeResult={() => { setChallengeStartIntent(false); setScreen('challenge'); }}
                    onChallengeStart={() => { setChallengeStartIntent(true); setScreen('challenge'); }}
                    section={houseSection} onSectionChange={section => { setHouseSection(section); setKeepsakeFocus(undefined); }}
                    onSelect={setKeepsakeFocus} onShowRoom={() => setKeepsakeFocus(undefined)}
                    onClose={home} onLearn={() => void begin()} onPhoto={photograph} onPhotos={openPhotos}
                    onGrowingGuide={() => setHouseGuideAt(location.key)}
                    onAlbum={() => { setReturnToHouse(true); setAlbumComparison('garden'); setScreen('album'); }}
                    onShared={island.completedSets >= 1 ? () => { setReturnToHouse(true); openShared(); } : undefined}
                    onRewards={() => { setReturnToHouse(true); setScreen('reward'); }} />
                : screen === 'expression' ? <IslandExpression island={island} disabled={busy} pending={Boolean(expression.pending)}
                    initialItemId={expressionEntryItem} rewardGoal={rewardGoal}
                    previewAction={expression.previewAction} previewSelection={expressionScene} photo={photos.snapshot?.photos[0]} error={expression.error} onAction={expression.action}
                    onPreview={previewExpression} onFocusResident={setExpressionResident} onFocusFlag={setExpressionFlagFocus} onVisit={visitExpression}
                    soundEnabled={profile.soundEnabled} soundStatus={ambience.status}
                    onRetry={expression.retry ? () => { void expression.retry?.(); } : undefined} onListen={() => { void ambience.start(); }}
                    onClose={navigation ? home : openExperience} onLearn={() => void begin()}
                    onSaveScene={() => { openExperience(); setExperienceEntryTab('layouts'); }} />
                : screen === 'experience' ? <IslandExperiencePanel island={island} disabled={busy} onAction={experience.act} error={experience.error}
                    onExpression={openExpression}
                    initialTab={experienceEntryTab}
                    onRetry={experience.retry ? () => { void experience.retry?.(); } : undefined}
                    onFocusResident={setPortraitResident}
                    previewLayoutId={experience.previewLayoutId} onPreview={experience.preview} onPhoto={photograph}
                    onView={() => { experience.reset(); setScreen('showcase'); }} onClose={home}
                    ambienceStatus={ambience.status} onStartAmbience={() => { void ambience.start(); }}
                    onVisitFavorite={residentId => {
                        const favorite = island.items.find(item => item.kind === ISLAND_RESIDENT_PROFILES[residentId].favoriteItemKind && item.position);
                        if (!favorite) { setGuideLocation({ habitat: residentId === 'otter' ? 'waterside' : residentId === 'rabbit' ? 'garden' : 'village' }); openGuide(); return; }
                        experience.reset(); setPreview(undefined); setPlayMessage(undefined); setScreen('play');
                        setPlayRequest({ id: crypto.randomUUID(), itemId: favorite.id });
                    }} />
                : screen === 'showcase' ? <section className="island-showcase-controls" aria-label="しまの けんがく">
                    <h1>{experienceState.islandName}</h1><div><button className="island-secondary" onClick={photograph}><Camera size={18} />しゃしんに のこす</button>
                        <button className="island-secondary" onClick={() => navigation ? navigation.back() : setScreen('experience')}><X size={18} />とじる</button></div>
                    <IslandDistricts island={island} value={district} disabled={false} onChange={setDistrict} />
                </section>
                : screen === 'customization' ? <IslandCustomization island={island} selectedId={customization.selectedId}
                    rewardGoal={rewardGoal}
                    preview={customization.preview ?? getIslandCosmetics(island)} celebration={customization.celebration} disabled={busy}
                    selectedSlot={customization.selectedSlot} selectionReady={customization.selectionReady} restore={customization.restore}
                    error={customization.error} onRetry={customization.retry ? () => { void customization.retry?.(); } : undefined}
                    onSelect={(id, slot) => { customization.select(id, slot); tutorial.practice('customization'); }} onBrowse={customization.browse} onRestore={customization.selectRestore} onUndoPart={customization.undoPart}
                    onResetPreview={customization.reset} onSaveScene={() => { openExperience(); setExperienceEntryTab('layouts'); }}
                    onFurniture={openFurniture} onFocus={setCosmeticFocus}
                    onAction={action => void customization.act(action)} onClose={home} />
                : screen === 'growth' ? <IslandGrowthChoices island={island} plan={plan} disabled={busy} onSelect={id => void chooseGrowth(id)} onClose={home}
                    previewHabitat={growthPreviewHabitat} onPreview={habitat => { if (habitat) setGrowthViewHabitat(habitat); setGrowthPreviewHabitat(habitat); }} />
                : screen === 'guide' ? <IslandDiscoveryGuide island={island} disabled={busy} closeDisabled={comparisonDisabled} initialHabitat={guideLocation.habitat} initialDiscoveryId={guideLocation.discoveryId}
                    onClose={home} onTry={tryDiscovery} onPlace={(itemId, discoveryId) => {
                        const item = island.items.find(candidate => candidate.id === itemId);
                        const entry = islandDiscoveryGuide(island, discoveryId);
                        if (item && entry) { setGuideLocation({ habitat: entry.entry.habitatId, discoveryId }); setReturnToGuide(true); select(item); }
                    }} onGrow={habitat => {
                        const look = islandGrowthPreview(island, habitat);
                        setGrowthViewHabitat(look ? habitat : 'garden'); setGrowthPreviewHabitat(look ? habitat : undefined); setScreen('growth');
                    }} />
                : screen === 'album' ? <Suspense fallback={<Spinner destination="records" message="アルバムを ひらいているよ…" />}><IslandAlbum island={island} initialComparison={albumComparison} disabled={busy} closeDisabled={comparisonDisabled} onClose={home}
                    onPhotos={openPhotos}
                    onShared={() => openShared()}
                    onWorkshop={id => { openWorkshop(); setWorkshopView(view => ({ ...view, mode: id ? 'observe' : 'build', selectedSpecimenId: id ?? view.selectedSpecimenId })); }}
                    onPlace={id => { const item = island.items.find(candidate => candidate.id === id); if (item) select(item); }}
                    onTry={tryDiscovery} /></Suspense>
                : screen === 'placement' && preview ? <IslandPlacement hideActions item={preview} valid={valid} disabled={busy} availability={placementAvailability}
                    onFindUsable={furniturePlacementChoice ? () => { setPlacementSuggestionId(undefined); setFurniturePlacementSearch(crypto.randomUUID()); } : undefined}
                    onArrangeSurroundings={furniturePlacementChoice ? () => {
                        setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined); setPlacementSuggestionId(undefined);
                        setPreview(undefined); setPlayRequest(undefined); setReturnToFurniture(false); setReturnToGuide(false); setScreen('inventory');
                    } : undefined}
                    onPoint={point => { setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined); setPlacementSuggestionId(undefined); setPreview({ ...preview, position: point }); }}
                    onRotate={() => { setFurniturePlacementSearch(undefined); setFurniturePlacementResult(undefined); setPlacementSuggestionId(undefined); setPreview({ ...preview, rotation: preview.rotation + Math.PI / 2 }); }}
                    onSave={savePlacement} onStore={() => { setFurniturePlacementSearch(undefined); void place(true); }}
                    onCancel={cancelPlacement} onAppearance={level => void appearance(level)} /> : null}</Suspense>
        {learning && preparingLearning && learningLease === 'ready' && !nextPlanError && <Spinner overlay destination="learning" message="まなぶ じゅんびを しているよ…" />}
        {plan && slot && <IslandLearningPanel profile={profile} plan={plan} active={active && learning && learningLease === 'ready' && !nextPlanError}
            heroStyle={learningHeroStyle}
            hintPending={busyKind === 'learning-hint' && active && learning && !preparingLearning}
            soundEnabled={profile.soundEnabled} intro={isFirstIslandPlan(plan)} observation={active && learning && !listening.isOpen ? observation : undefined}
            busy={busy || preparingLearning || !active || !learning || listening.isOpen} feedback={learningFeedback} party={island.learningParty} englishAutoRead={profile.englishAutoRead && !listening.isOpen} onAction={action => void answer(action)}
            listeningEntry={listening.sentence ? <EnglishListeningEntry disabled={busy || preparingLearning || listening.isOpen} onOpen={listening.open} /> : undefined}
            subjectChoice={profile.subjectMode === 'mix' ? {
                selected: island.nextSubjectChoice?.afterPlanId === plan.id && island.nextSubjectChoice.subject === plan.subject,
                onChange: selected => { void run(() => setIslandNextSubject(profile.id, island.revision, plan.id, selected))
                    .then(updated => { if (updated) setSnapshot(updated); }); },
            } : undefined} />}
        {active && screen === 'keepsakes' && houseSection === 'home' && houseGuideAt === location.key
            && <Suspense fallback={null}><GrowingHouseGuide key={profile.id} profileId={profile.id} onClose={() => {
                setHouseGuideAt(undefined);
                window.requestAnimationFrame(() => document.querySelector<HTMLButtonElement>('[data-house-guide-book]')?.focus({ preventScroll: true }));
            }}
                onLearn={() => { setHouseGuideAt(undefined); void begin(); }}
                onIslandAction={action => {
                    setHouseGuideAt(undefined); setGrowingGuideRequest({ id: crypto.randomUUID(), action }); setScreen('home');
                }} /></Suspense>}
        {listening.isOpen && listening.sentence && <EnglishListening sentence={listening.sentence} easy={profile.uiTextMode === 'easy'} onClose={listening.close} />}
    </main>;
}

export function IslandLoadingError() {
    return <div className="island-loading" role="alert">
        しまを ひらけなかったよ。
        <button className="island-primary" onClick={() => window.location.reload()}>もういちど ひらく</button>
    </div>;
}
