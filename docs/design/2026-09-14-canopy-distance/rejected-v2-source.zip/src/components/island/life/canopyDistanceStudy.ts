import * as T from 'three';
import { canopyClearanceStudy } from './canopyClearanceStudy';

export type DistanceStudy = 'cove' | 'archipelago' | 'mist';
const requested = import.meta.env.VITE_CANOPY_DISTANCE_STUDY;
export const canopyDistanceStudy: DistanceStudy | undefined = canopyClearanceStudy === 'vault'
    && (requested === 'cove' || requested === 'archipelago' || requested === 'mist') ? requested : undefined;
export const canopyDistanceCandidate = canopyDistanceStudy ? `canopy-distance-${canopyDistanceStudy}-study-v2` : undefined;

/** Decorative remote silhouettes only: no cells, routes, actors or interaction metadata. */
export function makeCanopyDistanceStudy(root: T.Group, water: T.ShaderMaterial, variant: DistanceStudy) {
    const group = new T.Group(); group.name = 'life-distant-islets'; root.add(group);
    const haze = new T.Color(variant === 'mist' ? '#c0d4cd' : '#a6c9c2');
    const materials: T.Material[] = [];
    const paint = (color: string, fade: number) => {
        const material = new T.MeshBasicMaterial({ color: new T.Color(color).lerp(haze, fade) });
        materials.push(material); return material;
    };
    const islet = (x: number, z: number, size: number, fade: number) => {
        const island = new T.Group(); island.position.set(x, -.46, z); group.add(island);
        // Asymmetric low rock shoulders, a long quiet shoreline, no tiled/platform edge.
        const rock = new T.SphereGeometry(1, 28, 16), p = rock.getAttribute('position');
        for (let i = 0; i < p.count; i++) {
            const a = p.getX(i), b = p.getY(i), c = p.getZ(i);
            const shoulder = 1 + .10 * Math.sin(a * 4 + c * 3) + .06 * Math.sin(c * 7 - a);
            p.setXYZ(i, a * size * shoulder, Math.max(-.12, (b + .15) * .55 * size), c * size * .48 * shoulder);
        }
        rock.computeVertexNormals();
        const base = new T.Mesh(rock, paint('#789888', fade)); island.add(base);
        for (const [dx, height, spread, lean] of [[-.55, 1.1, .6, -.2], [-.05, 1.5, .8, .2], [.55, .9, .55, -.12]]) {
            const foliage = new T.SphereGeometry(1, 16, 10), q = foliage.getAttribute('position');
            for (let i = 0; i < q.count; i++) {
                const a=q.getX(i), b=q.getY(i), c=q.getZ(i), bend=(b+1)*.5;
                q.setXYZ(i, (a*spread+lean*bend*bend)*size, (b*.28+height)*size, c*.3*size);
            }
            foliage.computeVertexNormals();
            const crown=new T.Mesh(foliage,paint('#458776',fade));crown.position.x=dx*size;island.add(crown);
            const stem=new T.Mesh(new T.CylinderGeometry(.07*size,.12*size,(height-.35)*size,6),paint('#648d7f',fade));
            stem.position.set(dx*size,(height+.35)*size/2,0);island.add(stem);
        }
    };
    const mist = variant === 'mist';
    // Orthographic distance does not shrink objects: explicitly author the remote scale.
    islet(-4, -6.8, .55, mist ? .62 : .32);
    if (variant !== 'cove') islet(-1.6, -8.5, .40, mist ? .76 : .52);
    group.traverse(object => { if (object instanceof T.Mesh) { object.userData.cameraDecoration = true; object.raycast = () => {}; } });
    water.uniforms.distanceHaze={value:haze};water.uniforms.distanceStrength={value:mist?.65:.4};
    water.fragmentShader=water.fragmentShader.replace('uniform float time;', 'uniform vec3 distanceHaze; uniform float distanceStrength; uniform float time;')
        .replace('gl_FragColor=vec4(color,1.0);', 'color=mix(color,distanceHaze,smoothstep(6.0,22.0,-vWorld.y)*distanceStrength); gl_FragColor=vec4(color,1.0);');
    return () => materials.forEach(material=>material.dispose());
}
