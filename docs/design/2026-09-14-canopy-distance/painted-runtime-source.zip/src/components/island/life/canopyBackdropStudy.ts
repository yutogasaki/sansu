import * as T from 'three';
import { canopyClearanceStudy } from './canopyClearanceStudy';

export type BackdropStudy = 'cove' | 'archipelago' | 'mist';
const requested = import.meta.env.VITE_CANOPY_BACKDROP_STUDY;
export const canopyBackdropStudy: BackdropStudy | undefined = canopyClearanceStudy === 'vault'
    && (requested === 'cove' || requested === 'archipelago' || requested === 'mist') ? requested : undefined;
export const canopyBackdropCandidate = canopyBackdropStudy ? `canopy-backdrop-${canopyBackdropStudy}-study-v1` : undefined;

/** A distant scenic layer, outside playable land and camera pan limits. */
export function makeCanopyBackdropStudy(root: T.Group, variant: BackdropStudy) {
    let disposed=false;
    const material=new T.ShaderMaterial({transparent:true,depthWrite:false,
        uniforms:{panorama:{value:null}},
        vertexShader:'varying vec2 backdropPoint;void main(){vec4 p=modelMatrix*vec4(position,1.0);backdropPoint=p.xy;gl_Position=projectionMatrix*viewMatrix*p;}',
        fragmentShader:`uniform sampler2D panorama;varying vec2 backdropPoint;void main(){
            vec2 uv=vec2(backdropPoint.x/18.0+.5,(backdropPoint.y+.46)/8.0+.495);
            vec3 color=texture2D(panorama,uv).rgb;
            gl_FragColor=vec4(color,smoothstep(0.0,.18,backdropPoint.y+.46));
            #include <colorspace_fragment>
        }`});
    const mesh=new T.Mesh(new T.PlaneGeometry(80,40),material);mesh.position.set(0,19.54,-8);
    mesh.name='life-canopy-backdrop';mesh.visible=false;mesh.userData.cameraDecoration=true;mesh.raycast=()=>{};root.add(mesh);
    root.userData.backdropStatus='loading';
    const texture=new T.TextureLoader().load(`/docs/design/2026-09-14-canopy-distance/painted/${variant}.png`,loaded=>{
        if(disposed){loaded.dispose();return;}
        loaded.colorSpace=T.SRGBColorSpace;loaded.wrapS=loaded.wrapT=T.ClampToEdgeWrapping;
        material.uniforms.panorama.value=loaded;mesh.visible=true;root.userData.backdropStatus='ready';
    },undefined,()=>{if(!disposed)root.userData.backdropStatus='fallback';});
    return ()=>{disposed=true;texture.dispose();material.dispose();};
}
