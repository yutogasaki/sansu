import { describe, expect, it } from 'vitest';
import { deriveAuthoredGrowthTerrainPlan, composeAuthoredGrowthTerrainWorld, rejectAuthoredGrowthTerrainPlan, type AuthoredGrowthTerrainCatalog } from './authoredGrowthTerrain';
import { compileWorldDefinition } from './worldDefinition';
import { newIsland } from './island';
import { TREE_MATURE_HOURS } from './environment';
import type { Cell } from './types';
import type { WorldDistrict, WorldEdge, WorldFloor } from './worldTypes';

const source = { artifact: 'growth-fixture.glb', sha256: 'a'.repeat(64) };
const ref = (districtId: string, siteId: string) => ({ districtId, siteId });
const cellId = ({ x, z }: Cell) => `${x},${z}`;
function floor(id: string, xs: number[], zs: number[], height = 0): WorldFloor {
    const vertices = zs.flatMap(z => xs.map(x => ({ cell: { x, z }, point: { x, y: (x - xs[0]) / (xs.at(-1)! - xs[0]) * height, z } })));
    const indices: number[] = [];
    for (let z = 0; z < zs.length - 1; z++) for (let x = 0; x < xs.length - 1; x++) {
        const i = z * xs.length + x; indices.push(i, i + xs.length, i + 1, i + 1, i + xs.length, i + xs.length + 1);
    }
    return { id, kind: 'ground', vertices, indices, color: '#bdb6c9' };
}
function fixture() {
    const templateId = 'growing-shore', id = 'acquired-coast';
    const points = [-1, 0, 1].flatMap(z => [0, 1].map(x => ({ x, z })));
    const district: WorldDistrict = { id: templateId, templateId, turn: 0, logicalOrigin: { x: 0, z: 0 }, worldOrigin: { x: 0, y: 0, z: 0 },
        floors: [floor('base', [-.6, 2.5], [-2, 2])], sites: [
            ...points.map(cell => ({ id: cellId(cell), cell, floorId: 'base', placement: true })),
            ...[-1, 1].map(z => ({ id: `landing-${z}`, cell: { x: 2.25, z }, floorId: 'base', placement: false })),
        ], ports: [], surfaces: [-1, 1].map(z => ({ id: `bank-${z}`, kind: 'bank',
            vertices: [{ x: 2.5, y: 0, z: z - 1 }, { x: 2.5, y: 0, z: z + 1 }, { x: 2.5, y: -.5, z: z - 1 }, { x: 2.5, y: -.5, z: z + 1 }],
            indices: [0, 2, 1, 1, 2, 3], material: { color: '#bdb6c9', roughness: .9, metalness: 0 } })) };
    const edges: WorldEdge[] = [];
    for (const a of points) for (const b of points) if (a.x <= b.x && a.z <= b.z && Math.abs(a.x - b.x) + Math.abs(a.z - b.z) === 1)
        edges.push({ from: ref(templateId, cellId(a)), to: ref(templateId, cellId(b)), allows: ['walk', 'join', 'water'] });
    for (const z of [-1, 1]) edges.push({ from: ref(templateId, `1,${z}`), to: ref(templateId, `landing-${z}`), allows: ['walk'] });
    const catalog: AuthoredGrowthTerrainCatalog = { version: 1, candidate: 'growing-shore-v1', revision: 'asset-v1', source,
        template: { id: templateId, label: '成長する岸', district, edges, ports: [] },
        profile: { trigger: [{ x: -.5, z: -1.5 }, { x: 1.5, z: -1.5 }, { x: 1.5, z: 1.5 }, { x: -.5, z: 1.5 }],
            scope: [{ x: 2.5, z: -3 }, { x: 6, z: -3 }, { x: 6, z: 3 }, { x: 2.5, z: 3 }], shoreFacing: 0,
            sockets: [-1, 1].map(z => ({ id: z < 0 ? 'lower' : 'upper', logicalOrigin: { x: 0, z }, worldOrigin: { x: 0, y: 0, z }, turn: 0,
                landings: [{ baseSiteId: `landing-${z}`, patchSiteId: 'entry' }], replaceSurfaceIds: [`bank-${z}`] })),
            variants: (['parallel', 'seaward'] as const).map(shape => {
                const end = shape === 'parallel' ? 3.5 : 5, width = shape === 'parallel' ? .9 : .5, height = shape === 'parallel' ? .25 : .6;
                return { id: shape, district: { id: shape, templateId: shape, turn: 0, logicalOrigin: { x: 0, z: 0 }, worldOrigin: { x: 0, y: 0, z: 0 },
                    floors: [floor('growth', [2.5, end], [-width, width], height)],
                    sites: [{ id: 'entry', cell: { x: 2.75, z: 0 }, floorId: 'growth', placement: false },
                        { id: 'tip', cell: { x: end - .2, z: 0 }, floorId: 'growth', placement: false }], ports: [] },
                    edges: [{ from: ref(shape, 'entry'), to: ref(shape, 'tip'), allows: ['walk'] }] };
            }),
        } };
    const world = compileWorldDefinition({ version: 1, id: 'world', source, districts: [{ ...district, id }],
        edges: edges.map(edge => ({ ...edge, from: { ...edge.from, districtId: id }, to: { ...edge.to, districtId: id } })) });
    const state = newIsland('terrain-test', 0);
    state.landmarks = [{ id: 'a', kind: 'sapling', growth: TREE_MATURE_HOURS, cell: { x: 1, z: -1 } },
        { id: 'b', kind: 'sapling', growth: TREE_MATURE_HOURS, cell: { x: 1, z: 0 } }];
    const compose = () => composeAuthoredGrowthTerrainWorld(world, catalog, deriveAuthoredGrowthTerrainPlan(state, world, catalog));
    return { world, catalog, state, compose };
}

describe('growth changes real terrain from current owned trees', () => {
    it('uses maturity, current join direction and position to choose actual relief and coastline', () => {
        const { state, world, catalog, compose } = fixture();
        state.landmarks[1].growth--;
        expect(compose()).toBe(world);
        state.landmarks[1].growth++;
        const along = compose(), alongPlan = deriveAuthoredGrowthTerrainPlan(state, world, catalog);
        expect(alongPlan.assemblies[0]).toMatchObject({ shape: 'parallel', socketId: 'lower', ownerIds: ['a', 'b'] });
        expect(along.floorAt({ x: 3.1, z: -1 })).toBeDefined();
        expect(along.floorAt({ x: 3.1, z: 1 })).toBeUndefined();
        state.landmarks[0].cell = { x: 1, z: 0 }; state.landmarks[1].cell = { x: 1, z: 1 };
        const shifted = compose();
        expect(deriveAuthoredGrowthTerrainPlan(state, world, catalog).assemblies[0].socketId).toBe('upper');
        expect(shifted.floorAt({ x: 3.1, z: 1 })).toBeDefined();
        expect(shifted.floorAt({ x: 3.1, z: -1 })).toBeUndefined();
        state.landmarks[0].cell = { x: 0, z: -1 }; state.landmarks[1].cell = { x: 1, z: -1 };
        const out = compose();
        expect(deriveAuthoredGrowthTerrainPlan(state, world, catalog).assemblies[0].shape).toBe('seaward');
        expect(out.bounds.max.x).toBeGreaterThan(along.bounds.max.x);
        expect(out.bounds.max.y).toBeGreaterThan(along.bounds.max.y);
    });

    it('keeps rights, full old supports and original floors while making the added real ground reachable', () => {
        const { state, world, catalog, compose } = fixture(), before = JSON.stringify(state), original = JSON.stringify(world.definition);
        const grown = compose();
        expect(grown.sites.filter(site => site.placement)).toEqual(world.sites.filter(site => site.placement));
        expect(grown.definition.districts[0].floors).toEqual(world.definition.districts[0].floors);
        expect(grown.definition.districts[0].surfaces?.map(s => s.id)).toEqual(['bank-1']);
        for (const old of world.sites) expect(grown.sites.find(site => JSON.stringify(site.ref) === JSON.stringify(old.ref))).toEqual(old);
        const reached = new Set(['0,0']), queue = [{ x: 0, z: 0 }];
        for (let i = 0; i < queue.length; i++) for (const cell of grown.neighbors(queue[i])) if (!reached.has(cellId(cell))) { reached.add(cellId(cell)); queue.push(cell); }
        const added = grown.sites.filter(site => site.ref.districtId === 'acquired-coast:growth-terrain');
        expect(added).toHaveLength(2);
        for (const site of added) {
            expect(reached.has(cellId(site.cell))).toBe(true); expect(grown.floorAt(site.cell)).toBeDefined(); expect(grown.owns(site.cell)).toBe(false);
            expect(grown.neighbors(site.cell, 'join')).toEqual([]); expect(grown.neighbors(site.cell, 'water')).toEqual([]);
        }
        expect(JSON.stringify(state)).toBe(before); expect(JSON.stringify(world.definition)).toBe(original);
        expect(JSON.stringify(deriveAuthoredGrowthTerrainPlan(state, world, catalog))).not.toMatch(/vertices|indices|floors/);
        expect(composeAuthoredGrowthTerrainWorld(world, catalog, deriveAuthoredGrowthTerrainPlan(JSON.parse(before), world, catalog)).definition).toEqual(grown.definition);
    });

    it('restores the original shore on separation/storage and produces the same preview after reconnecting', () => {
        const { state, world, compose } = fixture(), grown = compose();
        state.landmarks[1].cell = { x: 1, z: 1 }; expect(compose()).toBe(world);
        state.landmarks[1].cell = undefined; expect(compose()).toBe(world);
        state.landmarks[1].cell = { x: 1, z: 0 };
        expect(compose().definition).toEqual(grown.definition);
        expect(state.landmarks.every(tree => tree.growth === TREE_MATURE_HOURS)).toBe(true);
    });

    it('works for arbitrary owner IDs and a rotated acquired district, and requires explicit join edges', () => {
        const { state, world, catalog } = fixture(), definition = structuredClone(world.definition);
        definition.districts = definition.districts.map(d => ({ ...d, turn: 1, logicalOrigin: { x: 10, z: 5 }, worldOrigin: { x: 10, y: 0, z: 5 } }));
        const rotated = compileWorldDefinition(definition);
        state.landmarks = state.landmarks.map((tree, i) => ({ ...tree, id: `new-owner-${i}`, cell: { x: 10 - tree.cell!.z, z: 5 + tree.cell!.x } }));
        const plan = deriveAuthoredGrowthTerrainPlan(state, rotated, catalog), grown = composeAuthoredGrowthTerrainWorld(rotated, catalog, plan);
        expect(plan.assemblies[0]).toMatchObject({ shape: 'parallel', socketId: 'lower', ownerIds: ['new-owner-0', 'new-owner-1'] });
        expect(grown.floorAt({ x: 11, z: 8.1 })).toBeDefined();
        definition.edges = definition.edges.map(edge => ({ ...edge, allows: edge.allows.filter(kind => kind !== 'join') }));
        expect(deriveAuthoredGrowthTerrainPlan(state, compileWorldDefinition(definition), catalog).assemblies).toEqual([]);
    });

    it('rejects rights, out-of-scope geometry, overlapping terrain and stale plans without modifying inputs', () => {
        const { state, world, catalog } = fixture(), plan = deriveAuthoredGrowthTerrainPlan(state, world, catalog);
        const changeVariants = (fn: (variant: AuthoredGrowthTerrainCatalog['profile']['variants'][number]) => AuthoredGrowthTerrainCatalog['profile']['variants'][number]) =>
            ({ ...catalog, profile: { ...catalog.profile, variants: catalog.profile.variants.map(fn) } });
        const rights = changeVariants(v => ({ ...v, district: { ...v.district, sites: v.district.sites.map(site => ({ ...site, placement: true })) } }));
        expect(() => deriveAuthoredGrowthTerrainPlan(state, world, rights)).toThrow('walking');
        const out = { ...catalog, profile: { ...catalog.profile, scope: [{ x: 2.5, z: -2 }, { x: 3, z: -2 }, { x: 3, z: 2 }, { x: 2.5, z: 2 }] } };
        expect(() => deriveAuthoredGrowthTerrainPlan(state, world, out)).toThrow('scope');
        const overlap = changeVariants(v => ({ ...v, district: { ...v.district, floors: v.district.floors.map(f => ({ ...f,
            vertices: f.vertices.map(vertex => ({ cell: { ...vertex.cell, x: vertex.cell.x - .01 }, point: { ...vertex.point, x: vertex.point.x - .01 } })) })) } }));
        const overlappingCatalog = { ...overlap, profile: { ...overlap.profile, scope: [{ x: 2.4, z: -3 }, { x: 6, z: -3 }, { x: 6, z: 3 }, { x: 2.4, z: 3 }] } };
        expect(() => composeAuthoredGrowthTerrainWorld(world, overlappingCatalog, deriveAuthoredGrowthTerrainPlan(state, world, overlappingCatalog))).toThrow('overlaps');
        expect(() => composeAuthoredGrowthTerrainWorld(world, { ...catalog, revision: 'changed-art' }, plan)).toThrow('stale');
        const grown = composeAuthoredGrowthTerrainWorld(world, catalog, plan);
        expect(() => deriveAuthoredGrowthTerrainPlan(state, grown, catalog)).toThrow('immutable');
    });

    it('retains a rejection reason for the frame without making the rejected candidate composable', () => {
        const { state, world, catalog } = fixture(), plan = deriveAuthoredGrowthTerrainPlan(state, world, catalog);
        const rejected = rejectAuthoredGrowthTerrainPlan(plan, 'growth floor overlaps existing terrain');
        expect(rejected.assemblies).toEqual([]); expect(rejected.rejectedReason).toBe('growth floor overlaps existing terrain');
        expect(rejected.revision).not.toBe(plan.revision); expect(plan.assemblies).toHaveLength(1);
        expect(() => composeAuthoredGrowthTerrainWorld(world, catalog, rejected)).toThrow('rejected');
        expect(composeAuthoredGrowthTerrainWorld(world, catalog, plan).sites.filter(site => site.placement)).toHaveLength(6);
    });
});
