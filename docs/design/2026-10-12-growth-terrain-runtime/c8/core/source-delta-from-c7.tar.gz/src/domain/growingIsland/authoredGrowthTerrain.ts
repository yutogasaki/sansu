import type { AuthoredDistrictTemplate, DistrictFacing } from './authoredDistrictWorld';
import { compileWorldDefinition, type IslandWorld, type CompiledWorldFloor } from './worldDefinition';
import { TREE_MATURE_HOURS } from './environment';
import type { Cell, GrowingState } from './types';
import type { WorldDistrict, WorldEdge, WorldPoint } from './worldTypes';

export type AuthoredGrowthTerrainShape = 'parallel' | 'seaward';
export interface AuthoredGrowthTerrainSocket {
    readonly id: string;
    /** Both origins are in the acquired district's local frame. */
    readonly logicalOrigin: Cell;
    readonly worldOrigin: WorldPoint;
    readonly turn: DistrictFacing;
    readonly landings: readonly { readonly baseSiteId: string; readonly patchSiteId: string }[];
    /** Only this socket's seam bank is removed when its patch is present. */
    readonly replaceSurfaceIds: readonly string[];
}
export interface AuthoredGrowthTerrainVariant {
    readonly id: AuthoredGrowthTerrainShape;
    /** Local, unturned frame; all sites/edges grant walking only. */
    readonly district: WorldDistrict;
    readonly edges: readonly WorldEdge[];
}
export interface AuthoredGrowthTerrainCatalog {
    readonly version: 1;
    readonly candidate: string;
    /** Small immutable asset revision (normally expanded artifact SHA-256). */
    readonly revision: string;
    readonly source: { readonly artifact: string; readonly sha256: string };
    /** Acquired independently of trees using the ordinary diagnostic district ledger. */
    readonly template: AuthoredDistrictTemplate;
    readonly profile: {
        /** District-local polygons. Source art uses logical = physical X/Z. */
        readonly trigger: readonly Cell[];
        readonly scope: readonly Cell[];
        readonly shoreFacing: DistrictFacing;
        readonly sockets: readonly AuthoredGrowthTerrainSocket[];
        readonly variants: readonly AuthoredGrowthTerrainVariant[];
    };
}
export interface AuthoredGrowthTerrainAssembly {
    readonly id: string;
    readonly districtId: string;
    readonly ownerIds: readonly [string, string];
    readonly socketId: string;
    readonly shape: AuthoredGrowthTerrainShape;
}
export interface AuthoredGrowthTerrainPlan {
    readonly revision: string;
    readonly upstreamRevision: string;
    readonly catalogRevision: string;
    readonly assemblies: readonly AuthoredGrowthTerrainAssembly[];
    readonly rejectedReason?: string;
}

const EPSILON = 1e-7;
function fail(message: string): never { throw new Error(`Authored growth terrain: ${message}`); }
const key = ({ x, z }: Cell) => `${x},${z}`;
const rotate = ({ x, z }: Cell, turn: number): Cell => turn === 1 ? { x: -z, z: x }
    : turn === 2 ? { x: -x, z: -z } : turn === 3 ? { x: z, z: -x } : { x, z };
const near = (a: WorldPoint, b: WorldPoint) => Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z) < EPSILON;
const finite = (p: Cell) => Number.isFinite(p.x) && Number.isFinite(p.z);
const compareIds = (a: string, b: string) => a < b ? -1 : a > b ? 1 : 0;
const cross = (a: Cell, b: Cell, p: Cell) => (b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x);
const area = (poly: readonly Cell[]) => poly.reduce((sum, p, i) => {
    const q = poly[(i + 1) % poly.length]; return sum + p.x * q.z - q.x * p.z;
}, 0) / 2;
function polygon(poly: readonly Cell[]) {
    if (poly.length < 3 || !poly.every(finite) || Math.abs(area(poly)) < EPSILON) fail('invalid scope polygon');
    const sign = Math.sign(area(poly));
    if (poly.some((p, i) => poly.some(q => sign * cross(p, poly[(i + 1) % poly.length], q) < -EPSILON)))
        fail('scope polygon must be convex');
}
function inside(p: Cell, poly: readonly Cell[]) {
    const sign = Math.sign(area(poly));
    return poly.every((a, i) => sign * cross(a, poly[(i + 1) % poly.length], p) >= -EPSILON);
}
function fingerprint(value: unknown) {
    const text = JSON.stringify(value); let a = 2166136261, b = 2246822507;
    for (let i = 0; i < text.length; i++) { a = Math.imul(a ^ text.charCodeAt(i), 16777619); b = Math.imul(b ^ text.charCodeAt(i), 3266489909); }
    return (a >>> 0).toString(16).padStart(8, '0') + (b >>> 0).toString(16).padStart(8, '0');
}
const worldRevisions = new WeakMap<IslandWorld, string>();
function worldRevision(world: IslandWorld) {
    let revision = worldRevisions.get(world);
    if (!revision) { revision = fingerprint(world.definition); worldRevisions.set(world, revision); }
    return revision;
}
const derivedTemplate = (catalog: AuthoredGrowthTerrainCatalog, shape: AuthoredGrowthTerrainShape) => `${catalog.template.id}:growth:${shape}`;
const shapeIds: readonly AuthoredGrowthTerrainShape[] = ['parallel', 'seaward'];
const validated = new WeakMap<AuthoredGrowthTerrainCatalog, string>();
function deeplyFrozen(value: unknown): boolean {
    return !value || typeof value !== 'object' || Object.isFrozen(value) && Object.values(value).every(deeplyFrozen);
}

/** Read-only catalogs loaded by the caller may be deeply frozen and cached by identity. */
function validateCatalog(catalog: AuthoredGrowthTerrainCatalog) {
    if (validated.get(catalog) === catalog.revision) return;
    if (catalog.version !== 1 || !catalog.candidate || !catalog.revision || !/^[a-f0-9]{64}$/.test(catalog.source.sha256)) fail('invalid catalog identity');
    const { template, profile } = catalog, baseline = template.district;
    if (baseline.id !== template.id || baseline.turn !== 0 || baseline.logicalOrigin.x || baseline.logicalOrigin.z
        || Object.values(baseline.worldOrigin).some(n => n !== 0)) fail('template must use a local unturned frame');
    polygon(profile.trigger); polygon(profile.scope);
    if (![0, 1, 2, 3].includes(profile.shoreFacing) || !profile.sockets.length) fail('invalid shoreline or sockets');
    if (profile.variants.length !== 2 || !shapeIds.every(id => profile.variants.filter(v => v.id === id).length === 1)) fail('both authored growth shapes are required');
    const socketIds = new Set<string>();
    for (const socket of profile.sockets) {
        if (!socket.id || socketIds.has(socket.id) || ![0, 1, 2, 3].includes(socket.turn)
            || !Number.isInteger(socket.logicalOrigin.x) || !Number.isInteger(socket.logicalOrigin.z)
            || socket.worldOrigin.x !== socket.logicalOrigin.x || socket.worldOrigin.z !== socket.logicalOrigin.z
            || socket.worldOrigin.y !== 0 || !socket.landings.length) fail('invalid socket frame');
        socketIds.add(socket.id);
        if (new Set(socket.replaceSurfaceIds).size !== socket.replaceSurfaceIds.length) fail('duplicate seam bank');
        for (const id of socket.replaceSurfaceIds) {
            const surface = baseline.surfaces?.find(surface => surface.id === id);
            if (!surface || surface.kind !== 'bank' || surface.vertices.some(point => !inside(point, profile.scope))) fail('seam bank leaves growth scope');
        }
        for (const variant of profile.variants) {
            const district = variant.district;
            if (district.turn !== 0 || district.logicalOrigin.x || district.logicalOrigin.z || Object.values(district.worldOrigin).some(n => n !== 0)
                || district.anchorFloors?.length || district.waterCarvingScopes?.length || district.ports.length
                || !district.floors.length || district.floors.some(floor => floor.kind !== 'ground')
                || district.sites.some(site => site.placement || site.anchorPoint)
                || variant.edges.some(edge => edge.from.districtId !== district.id || edge.to.districtId !== district.id
                    || edge.allows.length !== 1 || edge.allows[0] !== 'walk')) fail('growth patch must grant only real ground walking');
            const local = (point: Cell) => {
                const p = rotate(point, socket.turn); return { x: p.x + socket.logicalOrigin.x, z: p.z + socket.logicalOrigin.z };
            };
            for (const floor of district.floors) for (const vertex of floor.vertices)
                if (Math.hypot(vertex.cell.x - vertex.point.x, vertex.cell.z - vertex.point.z) >= EPSILON || !inside(local(vertex.cell), profile.scope))
                    fail('growth floor leaves scope or its physical frame');
            for (const surface of district.surfaces ?? [])
                if (surface.kind !== 'bank' || surface.vertices.some(point => !inside(local(point), profile.scope))) fail('growth bank leaves scope');
            const landingKeys = new Set<string>();
            for (const landing of socket.landings) {
                const id = JSON.stringify(landing);
                if (landingKeys.has(id) || !baseline.sites.some(site => site.id === landing.baseSiteId)
                    || !district.sites.some(site => site.id === landing.patchSiteId)) fail('unknown or duplicate landing');
                landingKeys.add(id);
            }
        }
    }
    // JSON.parse callers remain fully checked until they explicitly freeze their
    // authored catalog. No geometry payload is serialized for ordinary frame keys.
    if (deeplyFrozen(catalog)) validated.set(catalog, catalog.revision);
}
function validateInput(upstream: IslandWorld, catalog: AuthoredGrowthTerrainCatalog) {
    validateCatalog(catalog);
    if (upstream.definition.source?.sha256 !== catalog.source.sha256) fail('source differs');
    if (upstream.definition.districts.some(district => shapeIds.some(shape => district.templateId === derivedTemplate(catalog, shape))))
        fail('requires immutable acquired terrain');
}
const planRevision = (upstreamRevision: string, catalogRevision: string, assemblies: readonly AuthoredGrowthTerrainAssembly[]) =>
    `growth-terrain:${fingerprint([upstreamRevision, catalogRevision, assemblies])}`;

/** Pure placement/maturity derivation; mesh data never enters this plan or owner state. */
export function deriveAuthoredGrowthTerrainPlan(state: GrowingState, upstream: IslandWorld,
    catalog: AuthoredGrowthTerrainCatalog): AuthoredGrowthTerrainPlan {
    validateInput(upstream, catalog);
    const assemblies: AuthoredGrowthTerrainAssembly[] = [], { profile } = catalog;
    const siteByCell = new Map(upstream.sites.map(site => [key(site.cell), site]));
    for (const district of upstream.definition.districts.filter(d => d.templateId === catalog.template.id)) {
        const local = (p: Cell) => rotate({ x: p.x - district.logicalOrigin.x, z: p.z - district.logicalOrigin.z }, (4 - district.turn) % 4);
        const trees = state.landmarks.filter(tree => tree.kind === 'sapling' && tree.cell && tree.growth >= TREE_MATURE_HOURS
            && siteByCell.get(key(tree.cell))?.ref.districtId === district.id && siteByCell.get(key(tree.cell))?.placement
            && siteByCell.get(key(tree.cell))?.support && inside(local(tree.cell), profile.trigger)).sort((a, b) => compareIds(a.id, b.id));
        const choices: { owners: readonly [string, string]; socket: AuthoredGrowthTerrainSocket; shape: AuthoredGrowthTerrainShape; distance: number }[] = [];
        for (let i = 0; i < trees.length; i++) for (let j = i + 1; j < trees.length; j++) {
            const a = trees[i], b = trees[j];
            if (a.id === b.id || !upstream.neighbors(a.cell!, 'join').some(cell => key(cell) === key(b.cell!))) continue;
            const p = local(a.cell!), q = local(b.cell!), midpoint = { x: (p.x + q.x) / 2, z: (p.z + q.z) / 2 };
            const normal = rotate({ x: 1, z: 0 }, profile.shoreFacing), dx = q.x - p.x, dz = q.z - p.z;
            const shape: AuthoredGrowthTerrainShape = Math.abs(dx * normal.x + dz * normal.z) > Math.abs(-dx * normal.z + dz * normal.x) ? 'seaward' : 'parallel';
            for (const socket of profile.sockets) choices.push({ owners: [a.id, b.id], socket, shape,
                distance: Math.hypot(midpoint.x - socket.logicalOrigin.x, midpoint.z - socket.logicalOrigin.z) });
        }
        const selected = choices.sort((a, b) => a.distance - b.distance || compareIds(a.owners[0], b.owners[0])
            || compareIds(a.owners[1], b.owners[1]) || compareIds(a.socket.id, b.socket.id))[0];
        if (selected) assemblies.push(Object.freeze({ id: `${district.id}:growth-terrain`, districtId: district.id,
            ownerIds: Object.freeze(selected.owners), socketId: selected.socket.id, shape: selected.shape }));
    }
    assemblies.sort((a, b) => compareIds(a.districtId, b.districtId));
    const upstreamRevision = worldRevision(upstream), catalogRevision = catalog.revision;
    return Object.freeze({ revision: planRevision(upstreamRevision, catalogRevision, assemblies), upstreamRevision, catalogRevision,
        assemblies: Object.freeze(assemblies) });
}

/** A failed candidate is explanatory evidence only, never a new geometry input. */
export function rejectAuthoredGrowthTerrainPlan(plan: AuthoredGrowthTerrainPlan, reason: string): AuthoredGrowthTerrainPlan {
    return Object.freeze({ ...plan, revision: `growth-terrain:rejected:${fingerprint([plan.revision, reason])}`,
        assemblies: Object.freeze([]), rejectedReason: reason });
}

interface Triangle2 { points: readonly Cell[]; minX: number; maxX: number; minZ: number; maxZ: number }
function triangles(floors: readonly CompiledWorldFloor[], physical: boolean): Triangle2[] {
    return floors.flatMap(floor => {
        const result: Triangle2[] = [];
        for (let i = 0; i < floor.indices.length; i += 3) {
            const points = floor.indices.slice(i, i + 3).map(index => physical ? floor.vertices[index].point : floor.vertices[index].cell);
            if (Math.abs(area(points)) <= 1e-12) continue;
            result.push({ points, minX: Math.min(...points.map(p => p.x)), maxX: Math.max(...points.map(p => p.x)),
                minZ: Math.min(...points.map(p => p.z)), maxZ: Math.max(...points.map(p => p.z)) });
        }
        return result;
    });
}
function intersectionArea(a: readonly Cell[], b: readonly Cell[]) {
    let result = [...a]; const sign = Math.sign(area(b));
    for (let j = 0; j < b.length && result.length; j++) {
        const p = b[j], q = b[(j + 1) % b.length], input = result; result = [];
        for (let i = 0; i < input.length; i++) {
            const u = input[i], v = input[(i + 1) % input.length], d = sign * cross(p, q, u), e = sign * cross(p, q, v);
            if (d >= 0) result.push(u);
            if ((d >= 0) !== (e >= 0)) { const t = d / (d - e); result.push({ x: u.x + (v.x - u.x) * t, z: u.z + (v.z - u.z) * t }); }
        }
    }
    return Math.abs(area(result));
}
/** Positive-area intersections are rejected, including narrow strips between sites. */
function rejectOverlap(old: readonly CompiledWorldFloor[], added: readonly CompiledWorldFloor[]) {
    for (const physical of [false, true]) {
        const index = new Map<string, Triangle2[]>();
        const buckets = (t: Triangle2) => {
            const keys: string[] = [];
            for (let x = Math.floor(t.minX); x <= Math.floor(t.maxX); x++) for (let z = Math.floor(t.minZ); z <= Math.floor(t.maxZ); z++) keys.push(`${x},${z}`);
            return keys;
        };
        for (const t of triangles(old, physical)) for (const id of buckets(t)) { const list = index.get(id) ?? []; list.push(t); index.set(id, list); }
        for (const t of triangles(added, physical)) {
            for (const other of new Set(buckets(t).flatMap(id => index.get(id) ?? [])))
                if (t.minX < other.maxX && t.maxX > other.minX && t.minZ < other.maxZ && t.maxZ > other.minZ
                    && intersectionArea(t.points, other.points) > 1e-8) fail('growth floor overlaps existing terrain');
            for (const id of buckets(t)) { const list = index.get(id) ?? []; list.push(t); index.set(id, list); }
        }
    }
}

/** Compose from the immutable acquired land, never from an earlier growth frame. */
export function composeAuthoredGrowthTerrainWorld(upstream: IslandWorld, catalog: AuthoredGrowthTerrainCatalog,
    plan: AuthoredGrowthTerrainPlan): IslandWorld {
    validateInput(upstream, catalog);
    if (plan.rejectedReason !== undefined) fail('rejected plan cannot be composed');
    if (plan.upstreamRevision !== worldRevision(upstream) || plan.catalogRevision !== catalog.revision
        || plan.revision !== planRevision(plan.upstreamRevision, plan.catalogRevision, plan.assemblies)) fail('plan is stale');
    if (!plan.assemblies.length) return upstream;
    const districts = [...upstream.definition.districts], edges = [...upstream.definition.edges], newFloors: CompiledWorldFloor[] = [];
    const assembled = new Set<string>(), landingRefs: { districtId: string; siteId: string }[] = [];
    for (const assembly of plan.assemblies) {
        const parentIndex = districts.findIndex(d => d.id === assembly.districtId && d.templateId === catalog.template.id), parent = districts[parentIndex];
        const variant = catalog.profile.variants.find(v => v.id === assembly.shape), socket = catalog.profile.sockets.find(s => s.id === assembly.socketId);
        if (!parent || !variant || !socket || assembled.has(parent.id) || assembly.id !== `${parent.id}:growth-terrain`
            || districts.some(d => d.id === assembly.id)) fail('invalid assembly');
        assembled.add(parent.id);
        const logical = rotate(socket.logicalOrigin, parent.turn), physical = rotate(socket.worldOrigin, parent.turn);
        const district: WorldDistrict = { ...variant.district, id: assembly.id, templateId: derivedTemplate(catalog, variant.id),
            logicalOrigin: { x: parent.logicalOrigin.x + logical.x, z: parent.logicalOrigin.z + logical.z },
            worldOrigin: { x: parent.worldOrigin.x + physical.x, y: parent.worldOrigin.y, z: parent.worldOrigin.z + physical.z },
            turn: (parent.turn + socket.turn) % 4 as DistrictFacing };
        const internal = variant.edges.map(edge => ({ ...edge, from: { districtId: district.id, siteId: edge.from.siteId }, to: { districtId: district.id, siteId: edge.to.siteId } }));
        const child = compileWorldDefinition({ version: 1, id: district.id, districts: [district], edges: internal });
        newFloors.push(...child.floors);
        const remove = new Set(socket.replaceSurfaceIds);
        for (const id of remove) {
            const original = parent.surfaces?.find(surface => surface.id === id), reference = catalog.template.district.surfaces?.find(surface => surface.id === id);
            if (!original || !reference || fingerprint(original) !== fingerprint(reference)) fail('seam bank source differs');
        }
        districts[parentIndex] = { ...parent, surfaces: parent.surfaces?.filter(surface => !remove.has(surface.id)) };
        landingRefs.push(...socket.landings.map(landing => ({ districtId: parent.id, siteId: landing.baseSiteId })));
        districts.push(district); edges.push(...internal, ...socket.landings.map(landing => ({
            from: { districtId: parent.id, siteId: landing.baseSiteId }, to: { districtId: district.id, siteId: landing.patchSiteId }, allows: ['walk'] as const,
        })));
    }
    rejectOverlap(upstream.floors, newFloors);
    const result = compileWorldDefinition({ ...upstream.definition, revision: plan.revision, districts, edges });
    const next = new Map(result.sites.map(site => [JSON.stringify(site.ref), site]));
    const queue = landingRefs.map(ref => next.get(JSON.stringify(ref))!.cell), reached = new Set(queue.map(key));
    for (let i = 0; i < queue.length; i++) for (const cell of result.neighbors(queue[i], 'walk'))
        if (!reached.has(key(cell))) { reached.add(key(cell)); queue.push(cell); }
    if (result.sites.some(site => plan.assemblies.some(assembly => assembly.id === site.ref.districtId) && !reached.has(key(site.cell))))
        fail('growth walking site is disconnected from its real landing');
    for (const old of upstream.sites) {
        const site = next.get(JSON.stringify(old.ref));
        if (!site || site.placement !== old.placement || !near(site.point, old.point) || Boolean(site.support) !== Boolean(old.support)
            || old.support && !near(site.support!.point, old.support.point)) fail('existing anchor or support changed');
        if (old.placement) for (const dx of [-.46, 0, .46]) for (const dz of [-.46, 0, .46]) {
            const cell = { x: old.cell.x + dx, z: old.cell.z + dz }, before = upstream.floorAt(cell), after = result.floorAt(cell);
            if (Boolean(before) !== Boolean(after) || before && !near(before.point, after!.point)) fail('existing placement footprint changed');
        }
    }
    return result;
}
