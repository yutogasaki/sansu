// src/domain/growingIsland/authoredWaterGeometry.ts
var polygonArea = (polygon) => polygon.reduce((sum, point, i) => {
  const next = polygon[(i + 1) % polygon.length];
  return sum + point.x * next.z - next.x * point.z;
}, 0) / 2;
var polygonHasArea = (polygon) => polygon.length >= 3 && Math.abs(polygonArea(polygon)) > 1e-12;
var cross = (a, b, point) => (b.x - a.x) * (point.z - a.z) - (b.z - a.z) * (point.x - a.x);
var polygonBounds = (polygon) => ({
  minX: Math.min(...polygon.map((p) => p.x)),
  maxX: Math.max(...polygon.map((p) => p.x)),
  minZ: Math.min(...polygon.map((p) => p.z)),
  maxZ: Math.max(...polygon.map((p) => p.z))
});
var polygonBoxesOverlap = (a, b) => a.minX <= b.maxX && a.maxX >= b.minX && a.minZ <= b.maxZ && a.maxZ >= b.minZ;
function clipPolygon(polygon, distance3) {
  const result = [];
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], da = distance3(a), db = distance3(b);
    if (da >= 0) result.push(a);
    if (da >= 0 !== db >= 0) {
      const t = da / (da - db);
      result.push({ x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t });
    }
  }
  return result;
}
function intersectPolygons(polygon, convex) {
  let result = [...polygon];
  const orientation = Math.sign(polygonArea(convex));
  for (let i = 0; i < convex.length && polygonHasArea(result); i++) {
    const a = convex[i], b = convex[(i + 1) % convex.length];
    result = clipPolygon(result, (p) => orientation * cross(a, b, p));
  }
  return result;
}
function subtractPolygon(polygon, convex) {
  const result = [], orientation = Math.sign(polygonArea(convex));
  let inside = [...polygon];
  for (let i = 0; i < convex.length && polygonHasArea(inside); i++) {
    const a = convex[i], b = convex[(i + 1) % convex.length], distance3 = (p) => orientation * cross(a, b, p);
    const outside = clipPolygon(inside, (p) => -distance3(p));
    if (polygonHasArea(outside)) result.push(outside);
    inside = clipPolygon(inside, distance3);
  }
  return result;
}
function triangulateWaterPolygon(input) {
  if (input.length < 3 || input.some((p) => !Number.isFinite(p.x) || !Number.isFinite(p.z))) return;
  let points = input.filter((p, i) => Math.hypot(p.x - input[(i + input.length - 1) % input.length].x, p.z - input[(i + input.length - 1) % input.length].z) > 1e-10);
  for (let i = points.length - 1; i >= 0 && points.length >= 3; i--) {
    if (Math.abs(cross(points[(i + points.length - 1) % points.length], points[(i + 1) % points.length], points[i])) <= 1e-12) points.splice(i, 1);
  }
  if (!polygonHasArea(points)) return;
  const onSegment = (a, b, p) => Math.abs(cross(a, b, p)) <= 1e-12 && p.x >= Math.min(a.x, b.x) - 1e-12 && p.x <= Math.max(a.x, b.x) + 1e-12 && p.z >= Math.min(a.z, b.z) - 1e-12 && p.z <= Math.max(a.z, b.z) + 1e-12;
  for (let i = 0; i < points.length; i++) for (let j = i + 1; j < points.length; j++) {
    if (j === i + 1 || i === 0 && j === points.length - 1) continue;
    const a = points[i], b = points[(i + 1) % points.length], c = points[j], d = points[(j + 1) % points.length];
    if (cross(a, b, c) * cross(a, b, d) < 0 && cross(c, d, a) * cross(c, d, b) < 0 || onSegment(a, b, c) || onSegment(a, b, d) || onSegment(c, d, a) || onSegment(c, d, b)) return;
  }
  const result = [], orientation = Math.sign(polygonArea(points));
  points = [...points];
  while (points.length > 3) {
    const ear = points.findIndex((b, i) => {
      const a = points[(i + points.length - 1) % points.length], c = points[(i + 1) % points.length];
      return orientation * cross(a, b, c) > 1e-12 && !points.some((p, j) => j !== i && j !== (i + points.length - 1) % points.length && j !== (i + 1) % points.length && orientation * cross(a, b, p) >= -1e-12 && orientation * cross(b, c, p) >= -1e-12 && orientation * cross(c, a, p) >= -1e-12);
    });
    if (ear < 0) return;
    result.push([points[(ear + points.length - 1) % points.length], points[ear], points[(ear + 1) % points.length]]);
    points.splice(ear, 1);
  }
  result.push(points);
  return result;
}
function mapTrianglePoint(point, from, to) {
  const [a, b, c] = from, determinant = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
  const u = ((b.z - c.z) * (point.x - c.x) + (c.x - b.x) * (point.z - c.z)) / determinant;
  const v = ((c.z - a.z) * (point.x - c.x) + (a.x - c.x) * (point.z - c.z)) / determinant;
  return { x: to[0].x * u + to[1].x * v + to[2].x * (1 - u - v), z: to[0].z * u + to[1].z * v + to[2].z * (1 - u - v) };
}
var protectionRectangle = (cell, half2) => [
  { x: cell.x - half2, z: cell.z - half2 },
  { x: cell.x + half2, z: cell.z - half2 },
  { x: cell.x + half2, z: cell.z + half2 },
  { x: cell.x - half2, z: cell.z + half2 }
];

// src/domain/growingIsland/authoredWorldAccess.ts
var AUTHORED_OWNER_HALF_EXTENT = 0.46;
var AUTHORED_WALK_HALF_WIDTH = 0.12;
var clearance = AUTHORED_OWNER_HALF_EXTENT + AUTHORED_WALK_HALF_WIDTH;
var cellKey = (cell) => `${cell.x},${cell.z}`;
var shoreIndexes = /* @__PURE__ */ new WeakMap();
var walkKeys = /* @__PURE__ */ new WeakMap();
var SHORE_DISTANCE = 0.65;
var MAX_SHORE_ANSWERS = 16384;
function shoreIndex(floors) {
  const existing = shoreIndexes.get(floors);
  if (existing) return existing;
  const index = { buckets: /* @__PURE__ */ new Map(), waterBuckets: /* @__PURE__ */ new Map(), waterFloors: /* @__PURE__ */ new Map(), footAnswers: /* @__PURE__ */ new Map(), waterDistances: /* @__PURE__ */ new Map() };
  let order = 0;
  for (const floor of floors) {
    if (floor.kind === "water") index.waterFloors.set(floor.id, polygonBounds(floor.vertices.map((vertex) => vertex.point)));
    for (let i = 0; i < floor.indices.length; i += 3) {
      const points = floor.indices.slice(i, i + 3).map((id) => floor.vertices[id].point), box = polygonBounds(points);
      const triangle = { floorId: floor.id, water: floor.kind === "water", points, box, order: order++ };
      for (let z = Math.floor(box.minZ); z <= Math.floor(box.maxZ); z++) for (let x = Math.floor(box.minX); x <= Math.floor(box.maxX); x++) {
        const id = cellKey({ x, z }), list = index.buckets.get(id) ?? [];
        list.push(triangle);
        index.buckets.set(id, list);
        if (triangle.water) {
          const water = index.waterBuckets.get(id) ?? [];
          water.push(triangle);
          index.waterBuckets.set(id, water);
        }
      }
    }
  }
  shoreIndexes.set(floors, index);
  return index;
}
function shoreTriangles(buckets, point, radius) {
  const triangles = /* @__PURE__ */ new Set();
  for (let z = Math.floor(point.z - radius); z <= Math.floor(point.z + radius); z++) for (let x = Math.floor(point.x - radius); x <= Math.floor(point.x + radius); x++)
    for (const triangle of buckets.get(cellKey({ x, z })) ?? []) if (triangle.box.minX <= point.x + radius && triangle.box.maxX >= point.x - radius && triangle.box.minZ <= point.z + radius && triangle.box.maxZ >= point.z - radius) triangles.add(triangle);
  return [...triangles];
}
function waterDistance(point, triangle) {
  const crosses = triangle.points.map((a, i) => {
    const b = triangle.points[(i + 1) % triangle.points.length];
    return (b.x - a.x) * (point.z - a.z) - (b.z - a.z) * (point.x - a.x);
  });
  if (crosses.every((value) => value >= -1e-12) || crosses.every((value) => value <= 1e-12)) return 0;
  return Math.min(...triangle.points.map((a, i) => {
    const b = triangle.points[(i + 1) % triangle.points.length], dx = b.x - a.x, dz = b.z - a.z;
    const t = Math.max(0, Math.min(1, ((point.x - a.x) * dx + (point.z - a.z) * dz) / (dx * dx + dz * dz)));
    return Math.hypot(point.x - a.x - dx * t, point.z - a.z - dz * t);
  }));
}
function shoreHeight(triangle, point) {
  return mapTrianglePoint(point, triangle.points, triangle.points.map((p) => ({ x: p.y, z: 0 }))).x;
}
function hasWalkRef(world, cell) {
  if (!Object.isFrozen(world.walkSites)) return world.walkSites.some((site) => cellKey(site.cell) === cellKey(cell));
  let keys = walkKeys.get(world.walkSites);
  if (!keys) {
    keys = new Set(world.walkSites.map((site) => cellKey(site.cell)));
    walkKeys.set(world.walkSites, keys);
  }
  return keys.has(cellKey(cell));
}
function distancesAt(index, point) {
  const id = cellKey(point), existing = index.waterDistances.get(id);
  if (existing) return existing;
  const distances = /* @__PURE__ */ new Map();
  for (const triangle of shoreTriangles(index.waterBuckets, point, SHORE_DISTANCE)) {
    const distance3 = waterDistance(point, triangle), previous = distances.get(triangle.floorId) ?? Infinity;
    distances.set(triangle.floorId, Math.min(previous, distance3));
  }
  if (index.waterDistances.size >= MAX_SHORE_ANSWERS) index.waterDistances.clear();
  index.waterDistances.set(id, distances);
  return distances;
}
function subtractShoreCover(polygon, cover, orientation) {
  for (let i = 0; i < cover.length; i++) {
    const a = cover[i], b = cover[(i + 1) % cover.length];
    let inside = true, outside = true;
    for (const p of polygon) {
      const distance3 = orientation * ((b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x));
      inside &&= distance3 > 0;
      outside &&= distance3 < 0;
      if (!inside && !outside) break;
    }
    if (inside) continue;
    if (outside) return [polygon];
    return subtractPolygon(polygon, cover);
  }
  return [];
}
function footSupported(index, point) {
  const id = `${point.x},${point.y},${point.z}`, existing = index.footAnswers.get(id);
  if (existing !== void 0) return existing;
  const square = protectionRectangle(point, AUTHORED_WALK_HALF_WIDTH);
  const triangles = shoreTriangles(index.buckets, point, AUTHORED_WALK_HALF_WIDTH);
  const minX = Math.floor(point.x - SHORE_DISTANCE), minZ = Math.floor(point.z - SHORE_DISTANCE);
  triangles.sort((a, b) => Math.max(minZ, Math.floor(a.box.minZ)) - Math.max(minZ, Math.floor(b.box.minZ)) || Math.max(minX, Math.floor(a.box.minX)) - Math.max(minX, Math.floor(b.box.minX)) || a.order - b.order);
  const overlaps3 = [];
  let answer = true;
  for (const triangle of triangles) {
    const overlap = intersectPolygons(square, triangle.points);
    if (!polygonHasArea(overlap)) continue;
    if (triangle.water || polygonHasArea(clipPolygon(overlap, (p) => shoreHeight(triangle, p) - point.y - 0.25 - 1e-7))) {
      answer = false;
      break;
    }
    overlaps3.push({ triangle, overlap });
  }
  if (answer) {
    let uncovered = [square];
    for (const { triangle, overlap } of overlaps3) {
      let cover = clipPolygon(overlap, (p) => shoreHeight(triangle, p) - point.y + 0.25 + 1e-7);
      cover = clipPolygon(cover, (p) => point.y + 0.25 + 1e-7 - shoreHeight(triangle, p));
      if (polygonHasArea(cover)) {
        const orientation = Math.sign(polygonArea(cover));
        uncovered = uncovered.flatMap((piece) => subtractShoreCover(piece, cover, orientation));
      }
      if (!uncovered.length) break;
    }
    answer = !uncovered.length;
  }
  if (index.footAnswers.size >= MAX_SHORE_ANSWERS) index.footAnswers.clear();
  index.footAnswers.set(id, answer);
  return answer;
}
function isAuthoredShoreEntrySupported(world, cell, waterFloorIds) {
  if (!hasWalkRef(world, cell)) return false;
  const support = world.floorAt(cell), original = world.anchorFloorAt(cell);
  if (!support || !original || Math.hypot(support.point.x - original.point.x, support.point.z - original.point.z) > 1e-5 || Math.abs(support.point.y - original.point.y) > 0.28) return false;
  const index = shoreIndex(world.floors);
  if (!waterFloorIds.length || waterFloorIds.some((id) => !index.waterFloors.has(id))) return false;
  const distances = distancesAt(index, support.point);
  const distance3 = Math.min(...waterFloorIds.map((id) => distances.get(id) ?? Infinity));
  return distance3 > AUTHORED_WALK_HALF_WIDTH * Math.SQRT2 && distance3 <= SHORE_DISTANCE && footSupported(index, support.point);
}
function findAuthoredShoreEntries(world, waterFloorIds) {
  const index = shoreIndex(world.floors), bounds2 = waterFloorIds.flatMap((id) => {
    const box = index.waterFloors.get(id);
    return box ? [box] : [];
  });
  if (!bounds2.length) return [];
  return world.walkSites.filter((site) => bounds2.some((box) => site.support.point.x >= box.minX - SHORE_DISTANCE && site.support.point.x <= box.maxX + SHORE_DISTANCE && site.support.point.z >= box.minZ - SHORE_DISTANCE && site.support.point.z <= box.maxZ + SHORE_DISTANCE) && isAuthoredShoreEntrySupported(world, site.cell, waterFloorIds)).sort((a, b) => a.cell.z - b.cell.z || a.cell.x - b.cell.x).map((site) => ({ ...site.ref }));
}
function authoredPointBlocked(point, owner) {
  return Math.abs(point.x - owner.x) <= clearance && Math.abs(point.z - owner.z) <= clearance;
}
function authoredApproachCells(cell, world) {
  const ownerSite = world.sites.find((site) => cellKey(site.cell) === cellKey(cell));
  if (!ownerSite) return [];
  const explicit = world.shoreApproachCells(cell);
  if (explicit !== void 0) return explicit.length ? [cell, ...explicit] : [];
  if (!ownerSite.support) {
    const bankSupported = (site) => {
      if (!site.support) return false;
      const anchor = ownerSite.point, p = site.support.point, dx = p.x - anchor.x, dz = p.z - anchor.z, length = Math.hypot(dx, dz);
      if (length <= clearance || length > 1.1 || Math.abs(p.y - anchor.y) > 0.28) return false;
      const stop = Math.min(length, clearance + 0.04), nx = -dz / length, nz = dx / length;
      for (let i = 0; i <= 4; i++) for (const side of [-AUTHORED_WALK_HALF_WIDTH, 0, AUTHORED_WALK_HALF_WIDTH]) {
        const r = length + (stop - length) * i / 4;
        const point = { x: anchor.x + dx / length * r + nx * side, z: anchor.z + dz / length * r + nz * side };
        const logical = world.logicalAt(point), floor = logical && world.floorAt(logical);
        if (!floor || Math.hypot(point.x - floor.point.x, point.z - floor.point.z) > 1e-5 || Math.abs(floor.point.y - p.y) > 0.25) return false;
      }
      return true;
    };
    return world.walkSites.filter((site) => site.ref.districtId === ownerSite.ref.districtId && !authoredPointBlocked(site.cell, cell) && Math.hypot(site.cell.x - cell.x, site.cell.z - cell.z) <= 1.1 && bankSupported(site)).map((site) => ({ ...site.cell })).sort((a, b) => Math.hypot(a.x - cell.x, a.z - cell.z) - Math.hypot(b.x - cell.x, b.z - cell.z) || b.z - cell.z - (a.z - cell.z) || a.x - b.x);
  }
  const queue = [cell], seen = /* @__PURE__ */ new Set([cellKey(cell)]), approaches = [];
  for (let i = 0; i < queue.length; i++) for (const next of world.neighbors(queue[i], "walk")) {
    const id = cellKey(next);
    if (seen.has(id) || Math.hypot(next.x - cell.x, next.z - cell.z) > 1.1) continue;
    seen.add(id);
    if (authoredPointBlocked(next, cell)) queue.push(next);
    else approaches.push(next);
  }
  return [cell, ...approaches.sort((a, b) => {
    const d = Math.hypot(a.x - cell.x, a.z - cell.z) - Math.hypot(b.x - cell.x, b.z - cell.z);
    return d || b.z - cell.z - (a.z - cell.z) || a.x - b.x;
  })];
}

// src/domain/growingIsland/worldDefinition.ts
var EPSILON = 1e-7;
var stable = (value) => Math.round(value * 1e9) / 1e9 || 0;
var cellKey2 = (cell) => `${cell.x},${cell.z}`;
var refKey = (ref) => JSON.stringify([ref.districtId, ref.siteId]);
var floorKey = (districtId, floorId2) => JSON.stringify([districtId, floorId2]);
var turn = (x, z, count2) => count2 === 1 ? { x: -z, z: x } : count2 === 2 ? { x: -x, z: -z } : count2 === 3 ? { x: z, z: -x } : { x, z };
function requireWorld(valid, message) {
  if (!valid) throw new Error(`Invalid island world: ${message}`);
}
function freeze(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
}
var FINE_DIVISIONS = 16;
var FINE_THRESHOLD = 64;
var fineCell = (value) => Math.max(0, Math.min(FINE_DIVISIONS - 1, Math.floor(value * FINE_DIVISIONS)));
function barycentric(at, a, b, c) {
  const determinant = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
  if (Math.abs(determinant) <= 1e-12) return void 0;
  const u = ((b.z - c.z) * (at.x - c.x) + (c.x - b.x) * (at.z - c.z)) / determinant;
  const v = ((c.z - a.z) * (at.x - c.x) + (a.x - c.x) * (at.z - c.z)) / determinant;
  const w = 1 - u - v;
  return u >= -EPSILON && v >= -EPSILON && w >= -EPSILON ? [u, v, w] : void 0;
}
var interpolate = (points, weights) => ({
  x: stable(points.reduce((value, point, i) => value + point.x * weights[i], 0)),
  y: stable(points.reduce((value, point, i) => value + point.y * weights[i], 0)),
  z: stable(points.reduce((value, point, i) => value + point.z * weights[i], 0))
});
function walkEdgeError(from, to, floorAt) {
  if (!from?.support || !to?.support) return "walk edge endpoint has no actual dry floor";
  const dx = to.cell.x - from.cell.x, dz = to.cell.z - from.cell.z, length = Math.hypot(dx, dz);
  if (!(length > 0 && length <= 256)) return "walk edge length";
  const steps = Math.max(8, Math.ceil(length * 8));
  const physicalStep = Math.hypot(to.support.point.x - from.support.point.x, to.support.point.z - from.support.point.z) / steps * 2 + 0.15;
  let previous;
  for (let i = 0; i <= steps; i++) {
    for (const side of [-0.12, 0, 0.12]) {
      const cell = { x: from.cell.x + dx * i / steps - dz / length * side, z: from.cell.z + dz * i / steps + dx / length * side };
      const floor = floorAt(cell);
      if (!floor) return "walk edge crosses missing floor or water";
      if (side !== 0) continue;
      if (previous) {
        if (Math.abs(floor.point.y - previous.y) > 0.25) return "walk edge has an unsupported vertical step";
        if (Math.hypot(floor.point.x - previous.x, floor.point.z - previous.z) > physicalStep) return "walk edge crosses separated physical floors";
      }
      const endpoint = i === 0 ? from.support : i === steps ? to.support : void 0;
      if (endpoint && Math.hypot(floor.point.x - endpoint.point.x, floor.point.y - endpoint.point.y, floor.point.z - endpoint.point.z) >= 0.025)
        return "walk endpoint differs from its site floor";
      previous = floor.point;
    }
  }
}
function compileWorldDefinition(input) {
  requireWorld(input.version === 1 && typeof input.id === "string" && input.id.length > 0, "unknown version or missing ID");
  requireWorld(input.revision === void 0 || typeof input.revision === "string" && input.revision.length > 0, "geometry revision");
  requireWorld(Array.isArray(input.districts) && Array.isArray(input.edges), "districts or edges");
  if (input.source) requireWorld(input.source.artifact && /^[a-f0-9]{64}$/.test(input.source.sha256), "source identity");
  const definition = structuredClone(input);
  const triangles = [], anchorTriangles = [], originalTriangles = [];
  const floors = [], anchorFloors = [], sites = [], surfaces = [];
  const districtIds = /* @__PURE__ */ new Set(), allFloors = /* @__PURE__ */ new Set(), allAnchorFloors = /* @__PURE__ */ new Set(), allSurfaces = /* @__PURE__ */ new Set();
  const refs = /* @__PURE__ */ new Map(), cells = /* @__PURE__ */ new Map();
  const finite = (point) => Number.isFinite(point.x) && Number.isFinite(point.z) && (!("y" in point) || Number.isFinite(point.y));
  const unit = (value) => Number.isFinite(value) && value >= 0 && value <= 1;
  const logicalPoint = (district, cell) => {
    const p = turn(cell.x, cell.z, district.turn);
    return { x: p.x + district.logicalOrigin.x, z: p.z + district.logicalOrigin.z };
  };
  const worldPoint2 = (district, point) => {
    const p = turn(point.x, point.z, district.turn);
    return { x: p.x + district.worldOrigin.x, y: point.y + district.worldOrigin.y, z: p.z + district.worldOrigin.z };
  };
  for (const district of definition.districts) {
    requireWorld(district.id && !districtIds.has(district.id), "duplicate district");
    districtIds.add(district.id);
    requireWorld(finite(district.logicalOrigin) && Number.isInteger(district.logicalOrigin.x) && Number.isInteger(district.logicalOrigin.z) && finite(district.worldOrigin) && Number.isFinite(district.worldOrigin.y) && [0, 1, 2, 3].includes(district.turn), "district origin or turn");
    requireWorld(district.waterCarvingScopes === void 0 || Array.isArray(district.waterCarvingScopes), "water carving scopes");
    const scopeIds = /* @__PURE__ */ new Set(), originals = district.anchorFloors?.length ? district.anchorFloors : district.floors;
    for (const scope of district.waterCarvingScopes ?? []) {
      requireWorld(typeof scope.id === "string" && scope.id.length && !scopeIds.has(scope.id), "duplicate or missing water carving scope");
      scopeIds.add(scope.id);
      requireWorld(Array.isArray(scope.floorIds) && scope.floorIds.length && new Set(scope.floorIds).size === scope.floorIds.length && scope.floorIds.every((id) => originals.some((floor) => floor.id === id && floor.kind === "ground")), "water carving original ground");
      requireWorld(Array.isArray(scope.envelope) && triangulateWaterPolygon(scope.envelope), "water carving envelope");
      const orientation = Math.sign(polygonArea(scope.envelope));
      requireWorld(scope.envelope.every((a, i) => {
        const b = scope.envelope[(i + 1) % scope.envelope.length], c = scope.envelope[(i + 2) % scope.envelope.length];
        return orientation * ((b.x - a.x) * (c.z - b.z) - (b.z - a.z) * (c.x - b.x)) >= -1e-12;
      }), "water carving envelope must be convex");
    }
    const compileFloor = (floor, anchor) => {
      const id = floorKey(district.id, floor.id);
      const ids = anchor ? allAnchorFloors : allFloors;
      requireWorld(floor.id && !ids.has(id), "duplicate floor");
      ids.add(id);
      requireWorld(["ground", "deck", "water"].includes(floor.kind) && floor.indices.length > 0 && floor.indices.length % 3 === 0, "floor kind or indices");
      requireWorld(/^#[a-fA-F0-9]{6}$/.test(floor.color), "floor color");
      if (floor.material !== void 0) requireWorld(floor.material && unit(floor.material.roughness) && unit(floor.material.metalness) && typeof floor.material.doubleSided === "boolean", "floor material");
      const vertices = floor.vertices.map((vertex) => {
        requireWorld(finite(vertex.cell) && finite(vertex.point) && Number.isFinite(vertex.point.y), "non-finite floor vertex");
        const normal = vertex.normal;
        if (normal !== void 0) requireWorld(normal && finite(normal) && Number.isFinite(normal.y) && Math.hypot(normal.x, normal.y, normal.z) > 1e-12, "floor normal");
        const rotated = normal ? turn(normal.x, normal.z, district.turn) : void 0;
        return {
          cell: logicalPoint(district, vertex.cell),
          point: worldPoint2(district, vertex.point),
          ...normal && rotated ? { normal: { x: rotated.x, y: normal.y, z: rotated.z } } : {}
        };
      });
      for (const index of floor.indices) requireWorld(Number.isInteger(index) && index >= 0 && index < vertices.length, "floor index out of range");
      for (let i = 0; i < floor.indices.length; i += 3) {
        const v = floor.indices.slice(i, i + 3).map((index) => vertices[index]);
        const area5 = (points2) => Math.abs((points2[1].x - points2[0].x) * (points2[2].z - points2[0].z) - (points2[2].x - points2[0].x) * (points2[1].z - points2[0].z));
        requireWorld(area5(v.map((vertex) => vertex.cell)) > 1e-12 && area5(v.map((vertex) => vertex.point)) > 1e-12, "collapsed floor triangle");
        const triangle = {
          floorId: id,
          kind: floor.kind,
          cells: v.map((vertex) => vertex.cell),
          points: v.map((vertex) => vertex.point)
        };
        (anchor ? anchorTriangles : triangles).push(triangle);
        if (anchor || !district.anchorFloors?.length) originalTriangles.push(triangle);
      }
      (anchor ? anchorFloors : floors).push({
        id,
        kind: floor.kind,
        color: floor.color,
        vertices,
        indices: [...floor.indices],
        ...floor.material ? { material: { ...floor.material } } : {}
      });
    };
    for (const floor of district.floors) compileFloor(floor, false);
    for (const floor of district.anchorFloors ?? []) compileFloor(floor, true);
    for (const surface of district.surfaces ?? []) {
      const id = floorKey(district.id, surface.id);
      requireWorld(surface.id && !allSurfaces.has(id), "duplicate surface");
      allSurfaces.add(id);
      requireWorld(["bank", "flow"].includes(surface.kind) && Array.isArray(surface.vertices) && Array.isArray(surface.indices) && surface.indices.length > 0 && surface.indices.length % 3 === 0, "surface kind or indices");
      const material = surface.material;
      requireWorld(material && /^#[a-fA-F0-9]{6}$/.test(material.color) && unit(material.roughness) && unit(material.metalness) && (material.opacity === void 0 || unit(material.opacity)), "surface material");
      const vertices = surface.vertices.map((point) => {
        requireWorld(finite(point) && Number.isFinite(point.y), "non-finite surface vertex");
        return worldPoint2(district, point);
      });
      for (const index of surface.indices) requireWorld(Number.isInteger(index) && index >= 0 && index < vertices.length, "surface index out of range");
      for (let i = 0; i < surface.indices.length; i += 3) {
        const [a, b, c] = surface.indices.slice(i, i + 3).map((index) => vertices[index]);
        const u = { x: b.x - a.x, y: b.y - a.y, z: b.z - a.z }, v = { x: c.x - a.x, y: c.y - a.y, z: c.z - a.z };
        requireWorld(Math.hypot(u.y * v.z - u.z * v.y, u.z * v.x - u.x * v.z, u.x * v.y - u.y * v.x) > 1e-12, "collapsed surface triangle");
      }
      surfaces.push({ id, kind: surface.kind, vertices, indices: [...surface.indices], material: { ...material } });
    }
  }
  const bins = (triangleList, physical) => {
    const buckets = /* @__PURE__ */ new Map();
    const bounds3 = triangleList.map((triangle) => {
      const points2 = physical ? triangle.points : triangle.cells;
      const minX = Math.min(...points2.map((p) => p.x)), maxX = Math.max(...points2.map((p) => p.x));
      const minZ = Math.min(...points2.map((p) => p.z)), maxZ = Math.max(...points2.map((p) => p.z));
      const pad = (min, max) => EPSILON * (1 + 2 * (max - min)) + Number.EPSILON * Math.max(1, Math.abs(min), Math.abs(max)) * 8;
      const area5 = Math.abs((points2[1].x - points2[0].x) * (points2[2].z - points2[0].z) - (points2[2].x - points2[0].x) * (points2[1].z - points2[0].z));
      const broad = area5 <= Math.max(maxX - minX, maxZ - minZ) ** 2 * 1e-8;
      return { minX, maxX, minZ, maxZ, padX: pad(minX, maxX), padZ: pad(minZ, maxZ), broad };
    });
    bounds3.forEach((box, index) => {
      const x0 = Math.floor(box.minX), x1 = Math.floor(box.maxX);
      const z0 = Math.floor(box.minZ), z1 = Math.floor(box.maxZ);
      requireWorld((x1 - x0 + 1) * (z1 - z0 + 1) <= 1e5, "floor triangle spans an excessive search area");
      for (let z = z0; z <= z1; z++) for (let x = x0; x <= x1; x++) {
        const id = cellKey2({ x, z }), bucket = buckets.get(id) ?? { indices: [] };
        bucket.indices.push(index);
        buckets.set(id, bucket);
      }
    });
    for (const [id, bucket] of buckets) {
      if (bucket.indices.length <= FINE_THRESHOLD) continue;
      const [x, z] = id.split(",").map(Number);
      const ranges = bucket.indices.map((index) => {
        const box = bounds3[index];
        return {
          index,
          x0: box.broad ? 0 : fineCell(box.minX - box.padX - x),
          x1: box.broad ? FINE_DIVISIONS - 1 : fineCell(box.maxX + box.padX - x),
          z0: box.broad ? 0 : fineCell(box.minZ - box.padZ - z),
          z1: box.broad ? FINE_DIVISIONS - 1 : fineCell(box.maxZ + box.padZ - z)
        };
      });
      if (ranges.reduce((count2, box) => count2 + (box.x1 - box.x0 + 1) * (box.z1 - box.z0 + 1), 0) >= bucket.indices.length * FINE_DIVISIONS ** 2 / 4) continue;
      const fine = /* @__PURE__ */ new Map();
      for (const { index, x0, x1, z0, z1 } of ranges) {
        for (let fz = z0; fz <= z1; fz++) for (let fx = x0; fx <= x1; fx++) {
          const cell = fz * FINE_DIVISIONS + fx, list = fine.get(cell) ?? [];
          list.push(index);
          fine.set(cell, list);
        }
      }
      bucket.fine = fine;
    }
    return buckets;
  };
  const createSampler = (triangleList, physicalQueries) => {
    const logicalBins = bins(triangleList, false);
    const sharedCoordinates = physicalQueries && triangleList.every((triangle) => triangle.cells.every((cell, i) => cell.x === triangle.points[i].x && cell.z === triangle.points[i].z));
    const physicalBins = physicalQueries && !sharedCoordinates ? bins(triangleList, true) : logicalBins;
    return (at, physical, floorId2, y, raw = false) => {
      if (!finite(at)) return void 0;
      let best;
      const water = [];
      const buckets = physical ? physicalBins : logicalBins;
      const candidates = /* @__PURE__ */ new Set();
      const seenBuckets = /* @__PURE__ */ new Set();
      for (const dx of [0, -EPSILON, EPSILON]) for (const dz of [0, -EPSILON, EPSILON]) {
        const x = Math.floor(at.x + dx), z = Math.floor(at.z + dz), id = cellKey2({ x, z });
        if (seenBuckets.has(id)) continue;
        seenBuckets.add(id);
        const bucket = buckets.get(id);
        if (!bucket) continue;
        const list = bucket.fine ? bucket.fine.get(fineCell(at.z - z) * FINE_DIVISIONS + fineCell(at.x - x)) : bucket.indices;
        for (const index of list ?? []) candidates.add(index);
      }
      for (const index of candidates) {
        const triangle = triangleList[index];
        if (floorId2 && triangle.floorId !== floorId2 && (raw || triangle.kind !== "water")) continue;
        const weights = barycentric(at, ...physical ? triangle.points : triangle.cells);
        if (!weights) continue;
        const point = interpolate(triangle.points, weights);
        if (triangle.kind === "water" && !raw) {
          water.push(point);
          continue;
        }
        const cell = { x: stable(triangle.cells.reduce((value, p, i) => value + p.x * weights[i], 0)), z: stable(triangle.cells.reduce((value, p, i) => value + p.z * weights[i], 0)) };
        if (!best || (y === void 0 ? point.y > best.point.y + EPSILON : Math.abs(point.y - y) < Math.abs(best.point.y - y) - EPSILON))
          best = { cell, point, floorId: triangle.floorId, triangle: index };
      }
      if (!raw && best && water.some((point) => Math.hypot(point.x - best.point.x, point.z - best.point.z) < 1e-5 && point.y > best.point.y + EPSILON)) return void 0;
      return best;
    };
  };
  const sample = createSampler(triangles, true), sampleAnchor = createSampler(anchorTriangles, false);
  const sampleOriginal = originalTriangles.length === anchorTriangles.length ? sampleAnchor : !anchorTriangles.length ? sample : createSampler(originalTriangles, false);
  for (const district of definition.districts) {
    for (const site of district.sites) {
      const ref = { districtId: district.id, siteId: site.id }, id = refKey(ref), cell = logicalPoint(district, site.cell), floorId2 = floorKey(district.id, site.floorId);
      requireWorld(site.id && !refs.has(id) && !cells.has(cellKey2(cell)), "duplicate site ID or logical cell");
      requireWorld(typeof site.placement === "boolean" && finite(site.cell) && (!site.placement || Number.isInteger(site.cell.x) && Number.isInteger(site.cell.z)), "site cell or placement right");
      const anchored = site.anchorPoint !== void 0;
      requireWorld((anchored ? allAnchorFloors : allFloors).has(floorId2), "site refers to an unknown floor");
      const anchor = anchored ? sampleAnchor(cell, false, floorId2, void 0, true) : sample(cell, false, floorId2);
      requireWorld(anchor, anchored ? "site anchor has no original floor" : "site has no actual dry floor");
      if (anchored) {
        requireWorld(finite(site.anchorPoint) && Number.isFinite(site.anchorPoint.y), "non-finite site anchor");
        const point = worldPoint2(district, site.anchorPoint);
        requireWorld(Math.hypot(point.x - anchor.point.x, point.y - anchor.point.y, point.z - anchor.point.z) <= 1e-6, "site anchor differs from its original floor");
      }
      const support = sample(cell, false);
      const compiled = { ref, cell, point: anchor.point, floorId: floorId2, placement: site.placement, ...support ? { support } : {} };
      refs.set(id, compiled);
      cells.set(cellKey2(cell), compiled);
      sites.push(compiled);
    }
    const ports = /* @__PURE__ */ new Set();
    for (const port of district.ports) {
      requireWorld(port.id && !ports.has(port.id) && refs.has(refKey({ districtId: district.id, siteId: port.siteId })), "port ID or site");
      ports.add(port.id);
    }
  }
  const graphs = Object.fromEntries(["walk", "join", "water"].map((kind) => [kind, /* @__PURE__ */ new Map()]));
  const edgeIds = /* @__PURE__ */ new Set();
  for (const edge of definition.edges) {
    const a = refKey(edge.from), b = refKey(edge.to), edgeId = JSON.stringify([a, b].sort());
    requireWorld(a !== b && refs.has(a) && refs.has(b) && !edgeIds.has(edgeId), "duplicate edge or unknown endpoint");
    edgeIds.add(edgeId);
    requireWorld(edge.allows.length > 0 && new Set(edge.allows).size === edge.allows.length && edge.allows.every((kind) => ["walk", "join", "water"].includes(kind)), "edge passage rights");
    if (edge.allows.includes("walk")) {
      const error = walkEdgeError(refs.get(a), refs.get(b), (cell) => sample(cell, false));
      requireWorld(!error, error);
    }
    for (const kind of edge.allows) {
      const graph = graphs[kind];
      for (const [from, to] of [[a, b], [b, a]]) {
        const next = graph.get(from) ?? /* @__PURE__ */ new Set();
        next.add(to);
        graph.set(from, next);
      }
    }
  }
  const neighbors2 = (cell, passage = "walk") => {
    const site = cells.get(cellKey2(cell));
    if (!site) return [];
    return [...graphs[passage].get(refKey(site.ref)) ?? []].map((id) => ({ ...refs.get(id).cell }));
  };
  const owns = (cell) => cells.get(cellKey2(cell))?.placement === true;
  const floorKinds = new Map(floors.map((floor) => [floor.id, floor.kind]));
  const walkSites = sites.filter((site) => site.support), shoreApproaches = /* @__PURE__ */ new Map();
  const shoreGeometry = { floors, walkSites, floorAt: (cell) => sample(cell, false), anchorFloorAt: (cell) => sampleOriginal(cell, false) };
  for (const district of definition.districts) {
    requireWorld(district.shoreAccess === void 0 || Array.isArray(district.shoreAccess), "shore access");
    for (const access of district.shoreAccess ?? []) {
      const owner = refs.get(refKey({ districtId: district.id, siteId: access.ownerSiteId }));
      requireWorld(owner?.placement && !shoreApproaches.has(cellKey2(owner.cell)), "shore owner");
      requireWorld(Array.isArray(access.waterFloorIds) && access.waterFloorIds.length && new Set(access.waterFloorIds).size === access.waterFloorIds.length, "shore water floors");
      const waterIds = access.waterFloorIds.map((id) => floorKey(district.id, id));
      requireWorld(waterIds.every((id) => floorKinds.get(id) === "water") && waterIds.some((id) => {
        const water = sample(owner.cell, false, id, void 0, true);
        return water && Math.hypot(water.point.x - owner.point.x, water.point.z - owner.point.z) < 1e-5;
      }), "shore water does not cover its original owner");
      requireWorld(Array.isArray(access.entrySiteIds) && new Set(access.entrySiteIds).size === access.entrySiteIds.length, "shore entries");
      const entries = access.entrySiteIds.map((id) => refs.get(refKey({ districtId: district.id, siteId: id })));
      requireWorld(entries.every((entry) => entry && isAuthoredShoreEntrySupported(shoreGeometry, entry.cell, waterIds)), "shore entry has no actual bank support");
      shoreApproaches.set(cellKey2(owner.cell), entries.map((entry) => ({ ...entry.cell })));
    }
  }
  const siteAt = (point) => {
    const floor = sample(point, true, void 0, point.y);
    if (!floor || Math.abs(floor.point.y - point.y) > 0.025) return void 0;
    const site = cells.get(cellKey2({ x: Math.round(floor.cell.x), z: Math.round(floor.cell.z) }));
    return site?.placement && site.support && JSON.parse(floor.floorId)[0] === site.ref.districtId && floorKinds.get(floor.floorId) === floorKinds.get(site.support.floorId) ? site : void 0;
  };
  const route = (from, to, open, passage = "walk") => {
    if (!cells.has(cellKey2(from)) || !cells.has(cellKey2(to)) || !open.has(cellKey2(from)) || !open.has(cellKey2(to))) return void 0;
    if (passage === "walk" && (!cells.get(cellKey2(from))?.support || !cells.get(cellKey2(to))?.support)) return void 0;
    const queue = [from], previous = /* @__PURE__ */ new Map([[cellKey2(from), void 0]]);
    for (let i = 0; i < queue.length; i++) {
      const cell = queue[i];
      if (cellKey2(cell) === cellKey2(to)) {
        const result = [];
        let at = cell;
        while (at) {
          result.unshift({ ...at });
          at = previous.get(cellKey2(at));
        }
        return result;
      }
      for (const next of neighbors2(cell, passage)) if (open.has(cellKey2(next)) && !previous.has(cellKey2(next))) {
        previous.set(cellKey2(next), cell);
        queue.push(next);
      }
    }
  };
  const points = floors.filter((floor) => floor.kind !== "water").flatMap((floor) => floor.vertices.map((v) => v.point));
  requireWorld(points.length > 0, "world has no dry floor");
  const bounds2 = points.reduce((box, point) => ({
    min: { x: Math.min(box.min.x, point.x), y: Math.min(box.min.y, point.y), z: Math.min(box.min.z, point.z) },
    max: { x: Math.max(box.max.x, point.x), y: Math.max(box.max.y, point.y), z: Math.max(box.max.z, point.z) }
  }), { min: { ...points[0] }, max: { ...points[0] } });
  const isWalkEdgeSupported = (from, to) => !walkEdgeError(cells.get(cellKey2(from)), cells.get(cellKey2(to)), (cell) => sample(cell, false));
  return Object.freeze({
    id: definition.id,
    revision: definition.revision,
    definition: freeze(definition),
    floors: freeze(floors),
    anchorFloors: freeze(anchorFloors),
    surfaces: freeze(surfaces),
    sites: freeze(sites),
    walkSites: freeze(walkSites),
    bounds: freeze(bounds2),
    owns,
    neighbors: neighbors2,
    route,
    siteAt,
    isWalkEdgeSupported,
    shoreApproachCells: (cell) => shoreApproaches.get(cellKey2(cell))?.map((entry) => ({ ...entry })),
    anchorAt: (cell) => {
      const point = cells.get(cellKey2(cell))?.point;
      return point ? { ...point } : void 0;
    },
    anchorFloorAt: (cell) => sampleOriginal(cell, false),
    sampleFloorAt: (cell, floorId2) => allFloors.has(floorId2) ? sample(cell, false, floorId2, void 0, true) : void 0,
    floorAt: (cell, floorId2) => sample(cell, false, floorId2),
    logicalAt: (point) => sample(point, true, void 0, point.y)?.cell
  });
}
function isWorldWalkEdgeSupported(world, from, to) {
  return world.isWalkEdgeSupported(from, to);
}

// src/domain/growingIsland/authoredWaterCarving.ts
var indexes = /* @__PURE__ */ new WeakMap();
var key = (x, z) => `${x},${z}`;
var compiledId = (districtId, floorId2) => JSON.stringify([districtId, floorId2]);
var turn2 = (cell, count2) => count2 === 1 ? { x: -cell.z, z: cell.x } : count2 === 2 ? { x: -cell.x, z: -cell.z } : count2 === 3 ? { x: cell.z, z: -cell.x } : { ...cell };
function logicalEnvelope(district, envelope) {
  return envelope.map((cell) => {
    const p = turn2(cell, district.turn);
    return { x: p.x + district.logicalOrigin.x, z: p.z + district.logicalOrigin.z };
  });
}
function withNative05WaterCarvingScope(base) {
  if (base.id !== "native05-authored-world-m0-v2" || base.definition.source?.sha256 !== "8398eda9ac084a6e80ed22f1a82670c380b017544a177106325aaa7ba7f8f68d")
    throw new Error("Native05 water carving requires the fixed original world");
  const districtId = "native05-inlet-core", floorId2 = "Island / continuous sculpted mature terrain:1";
  const original = base.definition.districts.find((district) => district.id === districtId);
  if (!original || !(original.anchorFloors ?? original.floors).some((floor) => floor.id === floorId2 && floor.kind === "ground"))
    throw new Error("Native05 water carving requires the original hill ground");
  const definition = structuredClone(base.definition);
  definition.districts = definition.districts.map((district) => district.id === districtId ? { ...district, waterCarvingScopes: [{
    id: "native05-hill-water-v1",
    floorIds: [floorId2],
    envelope: [
      { x: 4.4, z: -10.5 },
      { x: 8.6, z: -10.5 },
      { x: 8.6, z: -7.4 },
      { x: 4.4, z: -7.4 }
    ]
  }] } : district);
  return compileWorldDefinition(definition);
}
function authoredWaterCarvingFloorIds(base, districtId) {
  const scopes = base.definition.districts.find((district) => district.id === districtId)?.waterCarvingScopes;
  return scopes?.length ? [...new Set(scopes.flatMap((scope) => scope.floorIds.map((id) => compiledId(districtId, id))))] : void 0;
}
function sourceIndex(base, districtId) {
  let districts = indexes.get(base);
  if (!districts) {
    districts = /* @__PURE__ */ new Map();
    indexes.set(base, districts);
  }
  const existing = districts.get(districtId);
  if (existing) return existing;
  const buckets = /* @__PURE__ */ new Map(), district = base.definition.districts.find((district2) => district2.id === districtId);
  const index = { buckets, identity: true };
  if (!district) return index;
  const sourceFloors = district.anchorFloors?.length ? base.anchorFloors : base.floors;
  const scopes = district.waterCarvingScopes;
  const strictRectangles = base.sites.filter((site) => site.placement && site.ref.districtId === districtId).map((site) => protectionRectangle(site.cell, 0.5));
  for (const floor of sourceFloors) {
    if (floor.kind !== "ground" || JSON.parse(floor.id)[0] !== districtId) continue;
    const regions = scopes?.length ? scopes.filter((scope) => scope.floorIds.some((id) => compiledId(districtId, id) === floor.id)).map((scope) => logicalEnvelope(district, scope.envelope)) : strictRectangles;
    if (!regions.length) continue;
    index.identity &&= floor.vertices.every((vertex) => vertex.cell.x === vertex.point.x && vertex.cell.z === vertex.point.z);
    const regionBoxes = regions.map(polygonBounds);
    for (let i = 0; i < floor.indices.length; i += 3) {
      const vertices = floor.indices.slice(i, i + 3).map((id) => floor.vertices[id]), cells = vertices.map((vertex) => vertex.cell), points = vertices.map((vertex) => vertex.point);
      const logicalBox = polygonBounds(cells);
      for (let r = 0; r < regions.length; r++) {
        if (!polygonBoxesOverlap(logicalBox, regionBoxes[r])) continue;
        const logical = intersectPolygons(cells, regions[r]);
        if (!polygonHasArea(logical)) continue;
        const polygon = logical.map((cell) => mapTrianglePoint(cell, cells, points)), box = polygonBounds(polygon);
        const cover = { cells, points, polygon, box, logicalBox };
        for (let z = Math.floor(box.minZ); z <= Math.floor(box.maxZ); z++) for (let x = Math.floor(box.minX); x <= Math.floor(box.maxX); x++) {
          const id = key(x, z), list = buckets.get(id) ?? [];
          list.push(cover);
          buckets.set(id, list);
        }
      }
    }
  }
  districts.set(districtId, index);
  return index;
}
function candidatesIn(index, box) {
  const candidates = /* @__PURE__ */ new Set();
  for (let z = Math.floor(box.minZ); z <= Math.floor(box.maxZ); z++) for (let x = Math.floor(box.minX); x <= Math.floor(box.maxX); x++)
    for (const source of index.buckets.get(key(x, z)) ?? []) if (polygonBoxesOverlap(box, source.box)) candidates.add(source);
  return candidates;
}
function isAuthoredWaterCarvingSafe(base, districtId, outline, protections2) {
  if (outline.some((point) => !Number.isFinite(point.y)) || protections2.some((p) => !Number.isFinite(p.cell.x) || !Number.isFinite(p.cell.z) || !Number.isFinite(p.half) || p.half <= 0)) return false;
  const triangles = triangulateWaterPolygon(outline);
  if (!triangles) return false;
  if (triangles.some((triangle) => {
    const box = polygonBounds(triangle);
    return ![box.minX, box.maxX, box.minZ, box.maxZ].every((value) => Number.isSafeInteger(Math.floor(value))) || (Math.floor(box.maxX) - Math.floor(box.minX) + 1) * (Math.floor(box.maxZ) - Math.floor(box.minZ) + 1) > 1e5;
  })) return false;
  const index = sourceIndex(base, districtId), protectedRegions = protections2.map((p) => ({ polygon: protectionRectangle(p.cell, p.half), box: polygonBounds(protectionRectangle(p.cell, p.half)) }));
  if (index.identity) {
    for (const triangle of triangles) {
      const box = polygonBounds(triangle);
      for (const protection of protectedRegions) {
        if (!polygonBoxesOverlap(box, protection.box)) continue;
        const joint = {
          minX: Math.max(box.minX, protection.box.minX),
          maxX: Math.min(box.maxX, protection.box.maxX),
          minZ: Math.max(box.minZ, protection.box.minZ),
          maxZ: Math.min(box.maxZ, protection.box.maxZ)
        };
        for (const source of candidatesIn(index, joint)) {
          if (!polygonBoxesOverlap(source.logicalBox, protection.box)) continue;
          const overlap = intersectPolygons(triangle, source.polygon);
          if (!polygonHasArea(overlap)) continue;
          const logical = overlap.map((point) => mapTrianglePoint(point, source.points, source.cells));
          if (polygonHasArea(intersectPolygons(logical, protection.polygon))) return false;
        }
      }
    }
  }
  for (const triangle of triangles) {
    const box = polygonBounds(triangle);
    let uncovered = [{ polygon: triangle, box }];
    for (const source of candidatesIn(index, box)) {
      if (index.identity && !uncovered.some((piece) => polygonBoxesOverlap(piece.box, source.box))) continue;
      const overlap = intersectPolygons(triangle, source.polygon);
      if (!polygonHasArea(overlap)) continue;
      if (!index.identity) {
        const logical = overlap.map((point) => mapTrianglePoint(point, source.points, source.cells));
        if (protectedRegions.some((p) => polygonBoxesOverlap(source.logicalBox, p.box) && polygonHasArea(intersectPolygons(logical, p.polygon)))) return false;
      }
      uncovered = uncovered.flatMap((piece) => polygonBoxesOverlap(piece.box, source.box) ? subtractPolygon(piece.polygon, source.polygon).map((polygon) => ({ polygon, box: polygonBounds(polygon) })) : [piece]);
      if (index.identity && !uncovered.length) break;
    }
    if (uncovered.length) return false;
  }
  return true;
}

// src/domain/islandLife/economyRules.ts
var HOUR_MS = 36e5;
var GROWTH_WINDOW_MS = 24 * HOUR_MS;

// src/domain/islandLife/model.ts
var HOUR = 36e5;
var LIFE_RULES = {
  dropsPerProblem: 2,
  dailyGoal: 6,
  activityMs: HOUR / 2,
  expansionPrice: 12,
  maxItems: 30,
  budHours: 2,
  bloomHours: 6,
  stylePrice: 4
};
function plantThresholds(kind) {
  return kind === "flower" ? [LIFE_RULES.budHours, LIFE_RULES.bloomHours] : kind === "sapling" ? [6, 18] : void 0;
}
function growthStage(item) {
  const thresholds = plantThresholds(item.kind);
  return !thresholds ? 2 : item.growth >= thresholds[1] ? 2 : item.growth >= thresholds[0] ? 1 : 0;
}

// src/domain/islandLife/footprint.ts
function isFacility(kind) {
  return kind === "garden-hut" || kind === "library";
}
function occupiedCells(item) {
  if (!item.cell) return [];
  return (isFacility(item.kind) ? [[0, 0], [1, 0], [0, 1], [1, 1]] : [[0, 0]]).map(([x, z]) => ({ x: item.cell.x + x, z: item.cell.z + z }));
}

// src/domain/islandLife/space.ts
var cellKey3 = (p) => `${p.x},${p.z}`;

// src/domain/islandLife/waterChannels.ts
var clamp = (value) => Math.max(0, Math.min(1, value));
var distance = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.z - b.z);
var MAX_CHANNEL_STEPS = 8;
var directions = [{ x: 0, z: -1, bit: 1 }, { x: 1, z: 0, bit: 2 }, { x: 0, z: 1, bit: 4 }, { x: -1, z: 0, bit: 8 }];
var waterNeighbors = (state, cell) => (state.neighbors?.(cell) ?? directions.map(({ x, z }) => ({ x: cell.x + x, z: cell.z + z }))).filter((next) => Number.isInteger(cell.x) && Number.isInteger(cell.z) && Number.isInteger(next.x) && Number.isInteger(next.z) && distance(cell, next) === 1);
function connectedWaterChannels(state) {
  const channels = new Map(state.items.filter((item) => item.kind === "water-channel" && item.cell).map((item) => [cellKey3(item.cell), item]));
  const bowls = state.items.filter((item) => item.kind === "water-bowl" && item.cell);
  const reached = /* @__PURE__ */ new Set();
  let frontier = [...channels.entries()].filter(([key6, item]) => {
    if (!item.cell || !bowls.some((bowl) => waterNeighbors(state, bowl.cell).some((next) => cellKey3(next) === key6))) return false;
    reached.add(key6);
    return true;
  }).map(([key6]) => key6);
  for (let step = 1; step < MAX_CHANNEL_STEPS && frontier.length; step++) {
    const next = [];
    for (const key6 of frontier) {
      const item = channels.get(key6);
      for (const nextCell of waterNeighbors(state, item.cell)) {
        const neighbor = cellKey3(nextCell);
        if (channels.has(neighbor) && !reached.has(neighbor)) {
          reached.add(neighbor);
          next.push(neighbor);
        }
      }
    }
    frontier = next;
  }
  return reached;
}
function waterInfluence(state, cell, reached = connectedWaterChannels(state)) {
  const sources = state.items.filter((item) => item.cell && (item.kind === "water-bowl" || item.kind === "water-channel" && reached.has(cellKey3(item.cell))));
  return Math.max(0, ...sources.map((item) => clamp(1 - Math.max(0, distance(item.cell, cell) - 1) / 3)));
}
function shadeInfluence(state, cell, elapsedGrowthHours = 0) {
  return Math.max(0, ...state.items.filter((item) => item.kind === "sapling" && item.cell && growthStage({ ...item, growth: item.growth + elapsedGrowthHours }) === 2).map((item) => clamp(1 - distance(item.cell, cell) / 3)));
}

// src/domain/growingIsland/rules.ts
var RULES = {
  dropsPerCompletion: 2,
  townHoursPerCompletion: 2,
  buildHours: 6,
  dawnHour: 6,
  /** Homes stay small so each new friend usually needs a new seed: the core loop. */
  homeCapacity: [0, 1, 1, 2, 2],
  /** Town hours after building, comfort average and island level for each home stage. */
  homeGrowth: [
    void 0,
    { hours: 24, comfort: 1, level: 2 },
    { hours: 48, comfort: 2, level: 4 },
    { hours: 96, comfort: 3, level: 6 }
  ],
  /** Pokomoko's basket feeds the first two friends; farms feed the rest. */
  baseFood: 2,
  basePlay: 2,
  /** The next boat docks this many town hours after the previous friend arrived. */
  boatBaseHours: 48,
  boatHoursPerVillager: 2,
  likeRadius: 3,
  quietRadius: 2,
  styleRadius: 2,
  genkiLevels: [0, 3, 8, 15, 25, 40, 60, 85, 115, 150],
  characterShare: 0.3,
  characterMinimum: 6,
  favoredWeight: 3,
  rareBase: 0.05,
  rareBonus: 0.1,
  rareRichness: 40,
  natureHourCap: 24 * 7,
  soilBase: 0.2,
  soilHalfLife: 3,
  spreadEvery: 12,
  spreadChance: 0.5,
  spreadMoisture: 0.35,
  wildShare: 0.4,
  bigTreeHours: 24 * 7,
  lordTreeHours: 24 * 30,
  appliedMemory: 500,
  /** Completion ids kept for de-duplication; older ones collapse into a time floor. */
  learnedMemory: 3e3
};
var SEED_PRICE = { home: 40, farm: 40, play: 60, wild: 10, market: 120, festival: 160, wonder: 0 };
var WONDER_LEVELS = [3, 5, 7, 9];
var LANDMARK_PRICE = {
  flower: 10,
  bench: 20,
  "water-bowl": 20,
  sapling: 20,
  "water-channel": 10,
  "picnic-table": 40,
  planter: 30,
  swing: 30,
  lantern: 40,
  fence: 20,
  lighthouse: 80,
  bandstand: 30,
  slide: 40,
  trampoline: 40,
  fountain: 50,
  bakery: 70,
  postbox: 20
};
var LAND_PRICE = [120, 240, 480, 720, 960];
var DISTRICT_PRICE_STEP = 240;
var CAPE_LEVEL = [5, 6];
var LIKES = {
  rabbit: ["flower", "play"],
  otter: ["water", "food"],
  fox: ["tree", "light"],
  duck: ["water", "play"],
  squirrel: ["tree", "food"],
  hedgehog: ["farm", "quiet"],
  bird: ["flower", "light"],
  girl: ["water", "play"],
  boy: ["tree", "food"],
  penguin: ["water", "quiet"],
  owl: ["tree", "light"],
  frog: ["water", "flower"]
};
var RARE = {
  penguin: { weight: 0.35, home: "water" },
  owl: { weight: 0.35, home: "tree" },
  frog: { weight: 0.35, home: "flower" }
};
var likesOf = (friend) => LIKES[friend.species];
var KIDS = ["girl", "boy"];
var KID = {
  girl: { name: "\u3048\u307E", trait: "lively", variant: { color: 0, accessory: 0, sparkle: false } },
  boy: { name: "\u3048\u3044\u305F", trait: "lively", variant: { color: 1, accessory: 1, sparkle: false } }
};
var isKid = (species) => species === "girl" || species === "boy";
var FAVORED = {
  water: ["otter", "duck"],
  tree: ["fox", "squirrel"],
  flower: ["rabbit", "bird"],
  farm: ["hedgehog", "rabbit"],
  light: ["bird", "fox"]
};
var SPECIES = ["rabbit", "otter", "fox", "duck", "squirrel", "hedgehog", "bird", "girl", "boy", "penguin", "owl", "frog"];
var AVAILABLE_SPECIES = SPECIES;
var UNLOCKS = [
  { key: "seed:home" },
  { key: "seed:wild" },
  { key: "landmark:flower" },
  { key: "landmark:bench" },
  { key: "landmark:water-bowl" },
  { key: "seed:farm", villagers: 1 },
  { key: "landmark:sapling", villagers: 1 },
  { key: "landmark:water-channel", villagers: 1 },
  { key: "landmark:picnic-table", villagers: 2 },
  { key: "landmark:planter", villagers: 2 },
  { key: "seed:play", level: 2 },
  { key: "landmark:swing", level: 2 },
  { key: "landmark:bandstand", level: 4 },
  { key: "landmark:slide", level: 6 },
  { key: "landmark:postbox", villagers: 3 },
  { key: "landmark:lantern", level: 3 },
  { key: "landmark:fence", level: 3 },
  { key: "landmark:trampoline", level: 7 },
  { key: "landmark:fountain", level: 8 },
  { key: "landmark:bakery", level: 4 },
  { key: "seed:market", level: 4 },
  { key: "seed:festival", level: 5 },
  { key: "landmark:lighthouse", level: 6 }
];
var STYLE_LEVEL = { flagPattern: 7, clothes: 8, hats: 9, cardFrame: 10 };
var FLAG_PATTERNS = 5;
var HATS = 5;
var FOOD_SUPPORT = { farm: 2, market: 4 };
var PLAY_SUPPORT = {
  play: 4,
  festival: 6,
  wonder: 3,
  bench: 1,
  swing: 2,
  bandstand: 2,
  slide: 2,
  trampoline: 2,
  postbox: 1,
  sandbox: 2,
  "garden-hut": 2,
  library: 2
};

// src/domain/growingIsland/types.ts
var OWN_LANDMARKS = ["lighthouse", "bandstand", "slide", "trampoline", "fountain", "bakery", "postbox"];

// src/domain/growingIsland/space.ts
var HOME_CELL = { x: 2, z: 1 };
var HOUSE_CELLS = [{ x: 2, z: 0 }, { x: 3, z: 0 }, HOME_CELL];
var key2 = (cell) => `${cell.x},${cell.z}`;
var same = (a, b) => a.x === b.x && a.z === b.z;
var distance2 = (a, b) => Math.abs(a.x - b.x) + Math.abs(a.z - b.z);
var NEIGHBORS = [{ x: 1, z: 0 }, { x: -1, z: 0 }, { x: 0, z: 1 }, { x: 0, z: -1 }];
var neighbors = (cell) => NEIGHBORS.map((d) => ({ x: cell.x + d.x, z: cell.z + d.z }));
var passageNeighbors = (cell, world, passage = "walk") => world ? world.neighbors(cell, passage) : neighbors(cell);
var approachCells = (cell, world) => world ? authoredApproachCells(cell, world) : [cell, ...neighbors(cell)];
function landBounds2({ land }) {
  const sides = [land.expanded, ...land.extra];
  const west = sides.includes("west"), east = sides.includes("east");
  const districts = land.districts ?? [];
  return {
    minX: (land.capes.includes("west") ? -6 : west ? -3 : 0) - 3 * districts.filter((s) => s === "west").length,
    maxX: (land.capes.includes("east") ? 11 : east ? 8 : 5) + 3 * districts.filter((s) => s === "east").length,
    depth: (sides.includes("south") ? 8 : 5) + 3 * districts.filter((s) => s === "south").length
  };
}
function landCells2(state, world) {
  if (world) return world.sites.filter((site) => site.placement).map((site) => ({ ...site.cell }));
  const { minX, maxX, depth } = landBounds2(state), cells = [];
  for (let z = 0; z < depth; z++) for (let x = minX; x <= maxX; x++) cells.push({ x, z });
  return cells;
}
function onLand(state, cell, world) {
  if (world) return world.owns(cell);
  const { minX, maxX, depth } = landBounds2(state);
  return Number.isInteger(cell.x) && Number.isInteger(cell.z) && cell.x >= minX && cell.x <= maxX && cell.z >= 0 && cell.z < depth;
}
var isHouseCell = (cell) => HOUSE_CELLS.some((c) => same(c, cell));
function landmarkCells(landmark) {
  if (!landmark.cell) return [];
  return OWN_LANDMARKS.includes(landmark.kind) ? [landmark.cell] : occupiedCells({ kind: landmark.kind, cell: landmark.cell });
}
function occupant(state, cell, except) {
  if (isHouseCell(cell)) return { type: "house" };
  if (state.bridge && same(cell, bridgeAnchor(state))) return { type: "bridge" };
  const landmark = state.landmarks.find((l) => l.id !== except && landmarkCells(l).some((c) => same(c, cell)));
  if (landmark) return { type: "landmark", id: landmark.id };
  const plot = state.plots.find((p) => p.id !== except && p.cell && same(p.cell, cell));
  if (plot) return { type: "plot", id: plot.id, spread: plot.origin === "spread" };
  const keepsake = state.keepsakes.find((k) => k.id !== except && k.cell && same(k.cell, cell));
  if (keepsake) return { type: "keepsake", id: keepsake.id };
}
function isVacant(state, cell, except, world) {
  return onLand(state, cell, world) && !occupant(state, cell, except);
}
function plotBlocks(plot) {
  if (plot.kind === "wonder") return plot.stage === 0 || !(plot.style === "water" || plot.style === "light");
  return plot.kind !== "farm" && plot.kind !== "wild";
}
var OPEN_LANDMARKS = /* @__PURE__ */ new Set(["water-channel", "flower-arch", "flower"]);
function landmarkBlocks(landmark) {
  return !OPEN_LANDMARKS.has(landmark.kind);
}
function walkableCells(state, world) {
  const blocked = /* @__PURE__ */ new Set([key2({ x: 2, z: 0 }), key2({ x: 3, z: 0 })]);
  for (const l of state.landmarks) if (landmarkBlocks(l)) landmarkCells(l).forEach((c) => blocked.add(key2(c)));
  for (const p of state.plots) if (p.cell && plotBlocks(p)) blocked.add(key2(p.cell));
  for (const k of state.keepsakes) if (k.cell) blocked.add(key2(k.cell));
  if (world) {
    const ownerCells = [...blocked].map((text2) => {
      const [x, z] = text2.split(",").map(Number);
      return { x, z };
    });
    return new Set(world.walkSites.filter((site) => !ownerCells.some((owner) => authoredPointBlocked(site.cell, owner))).map((site) => key2(site.cell)));
  }
  const open = new Set(landCells2(state).map(key2).filter((k) => !blocked.has(k)));
  if (state.bridge) {
    const { depth } = landBounds2(state);
    open.add(key2({ x: state.bridge.x, z: depth }));
    open.add(key2({ x: state.bridge.x, z: depth + 1 }));
  }
  return open;
}
function bridgeAnchor(state, x = state.bridge?.x ?? 2) {
  return { x, z: landBounds2(state).depth - 1 };
}
function canBuildBridge(state, x) {
  const bounds2 = landBounds2(state), shore = bridgeAnchor(state, x);
  if (!Number.isInteger(x) || x < bounds2.minX + 1 || x > bounds2.maxX - 2) return false;
  const withoutBridge = { ...state, bridge: void 0 };
  return !occupant(withoutBridge, shore) && reachableFromHome(withoutBridge).has(key2(shore));
}
function bridgeSite(state) {
  const { minX, maxX } = landBounds2(state), preferred = state.bridge?.x ?? minX + 2;
  const candidates = [preferred, ...Array.from({ length: maxX - minX - 2 }, (_, i) => minX + 1 + i)];
  return candidates.find((x) => canBuildBridge(state, x));
}
function reachableFromHome(state, walkable, world) {
  walkable ??= walkableCells(state, world);
  if (world && !walkable.has(key2(HOME_CELL))) return /* @__PURE__ */ new Set();
  const start = key2(HOME_CELL), seen = /* @__PURE__ */ new Set([start]), queue = [HOME_CELL];
  while (queue.length) {
    const cell = queue.shift();
    for (const next of passageNeighbors(cell, world)) {
      const k = key2(next);
      if (walkable.has(k) && !seen.has(k)) {
        seen.add(k);
        queue.push(next);
      }
    }
  }
  return seen;
}
function isReachable(cell, reached, world) {
  return approachCells(cell, world).some((n) => reached.has(key2(n)));
}

// src/domain/growingIsland/environment.ts
var empty = () => ({ water: 0, tree: 0, flower: 0, farm: 0, light: 0 });
function waterLayout(state, world) {
  return {
    items: state.landmarks.filter((l) => !OWN_LANDMARKS.includes(l.kind) && l.cell && (!world || onLand(state, l.cell, world))).map((l) => ({ kind: l.kind, cell: l.cell, growth: l.growth })),
    ...world ? { neighbors: (cell) => world.neighbors(cell, "water") } : {}
  };
}
var TREE_MATURE_HOURS = 18;
var wonderForm = (style) => style === "tree" || style === "flower" ? "heart-tree" : style === "water" || style === "light" ? "dot-arch" : "pumpkin";
var wonderFeature = (style) => {
  const form = wonderForm(style);
  return form === "heart-tree" ? "flower" : form === "dot-arch" ? "light" : "farm";
};
var BLOOM_HOURS = 6;
function features(state, world) {
  const reached = connectedWaterChannels(waterLayout(state, world)), out = [];
  for (const l of state.landmarks) {
    if (!l.cell || world && !onLand(state, l.cell, world)) continue;
    if (l.kind === "water-bowl" || l.kind === "fountain") out.push({ cell: l.cell, feature: "water", points: 2 });
    else if (l.kind === "water-channel" && reached.has(key2(l.cell))) out.push({ cell: l.cell, feature: "water", points: 1 });
    else if (l.kind === "sapling") out.push({ cell: l.cell, feature: "tree", points: l.growth >= TREE_MATURE_HOURS ? 2 : 1 });
    else if (l.kind === "flower" && growthStage({ kind: "flower", growth: l.growth }) === 2) out.push({ cell: l.cell, feature: "flower", points: 1 });
    else if (l.kind === "lantern") out.push({ cell: l.cell, feature: "light", points: 2 });
    else if (l.kind === "lighthouse") out.push({ cell: l.cell, feature: "light", points: 4 });
    else if (l.kind === "planter") out.push({ cell: l.cell, feature: "farm", points: 1 });
  }
  for (const p of state.plots) {
    if (!p.cell || p.stage === 0 || world && !onLand(state, p.cell, world)) continue;
    if (p.kind === "farm" || p.kind === "market") out.push({ cell: p.cell, feature: "farm", points: 2 });
    else if (p.kind === "wonder") out.push({ cell: p.cell, feature: wonderFeature(p.style), points: 2 });
    else if (p.kind === "wild" && p.growth >= BLOOM_HOURS) {
      const feature = p.style === "tree" ? "tree" : p.style === "water" ? "water" : p.style === "light" ? "light" : "flower";
      out.push({ cell: p.cell, feature, points: 1 });
    }
  }
  return out;
}
function scoresNear(state, cell, radius = RULES.styleRadius, all, world) {
  const scores = empty();
  for (const f of all ?? features(state, world)) if (distance2(f.cell, cell) <= radius && (!world || onLand(state, f.cell, world))) scores[f.feature] += f.points;
  return scores;
}
var STYLE_ORDER = ["water", "tree", "flower", "light"];
function styleAt(state, cell, all, world) {
  const scores = scoresNear(state, cell, RULES.styleRadius, all, world);
  let best = "plain", bestPoints = 0;
  for (const s of STYLE_ORDER) if (scores[s] > bestPoints) {
    best = s;
    bestPoints = scores[s];
  }
  return bestPoints >= 1 ? best : "plain";
}
var CHARACTER_ORDER = ["water", "tree", "flower", "farm", "light"];
function islandScores(state, world) {
  const scores = empty();
  for (const f of features(state, world)) scores[f.feature] += f.points;
  return scores;
}
function islandCharacter(state, world) {
  const scores = islandScores(state, world), total = CHARACTER_ORDER.reduce((sum, f) => sum + scores[f], 0);
  if (total < RULES.characterMinimum) return "mixed";
  let best = "water";
  for (const f of CHARACTER_ORDER) if (scores[f] > scores[best]) best = f;
  return scores[best] / total >= RULES.characterShare ? best : "mixed";
}
function richness(state, world) {
  const scores = islandScores(state, world);
  return CHARACTER_ORDER.reduce((sum, f) => sum + scores[f], 0);
}
function waterAt(state, cell, world) {
  return !world || onLand(state, cell, world) ? waterInfluence(waterLayout(state, world), cell) : 0;
}
function syncSoil(state, world) {
  for (const cell of landCells2(state, world)) state.soil[key2(cell)] ??= RULES.soilBase;
}

// src/domain/growingIsland/authoredWaterContour.ts
var EPS = 1e-9;
var cross2 = (a, b, c) => (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x);
var same2 = (a, b) => Math.abs(a.x - b.x) < EPS && Math.abs(a.z - b.z) < EPS;
var outlineArea = (outline) => outline.reduce((sum, p, i) => {
  const q = outline[(i + 1) % outline.length];
  return sum + p.x * q.z - p.z * q.x;
}, 0) / 2;
function pointInWaterOutline(point, outline) {
  let inside = false;
  for (let i = 0, j = outline.length - 1; i < outline.length; j = i++) {
    const a = outline[j], b = outline[i], length = Math.hypot(b.x - a.x, b.z - a.z);
    if (length > EPS && Math.abs(cross2(a, b, point)) <= EPS * length && point.x >= Math.min(a.x, b.x) - EPS && point.x <= Math.max(a.x, b.x) + EPS && point.z >= Math.min(a.z, b.z) - EPS && point.z <= Math.max(a.z, b.z) + EPS) return true;
    if (a.z > point.z !== b.z > point.z && point.x < (b.x - a.x) * (point.z - a.z) / (b.z - a.z) + a.x) inside = !inside;
  }
  return inside;
}
var isConvex = (p) => p.every((a, i) => cross2(a, p[(i + 1) % p.length], p[(i + 2) % p.length]) >= -EPS);
function decomposeWaterOutline(outline) {
  if (outline.length < 3 || outline.length > 128 || !outline.every((p) => [p.x, p.y, p.z].every(Number.isFinite))) return [];
  const vertices = [...outlineArea(outline) < 0 ? [...outline].reverse() : outline];
  const pieces = [];
  while (vertices.length > 3) {
    let clipped = false;
    for (let i = 0; i < vertices.length; i++) {
      const a = vertices[(i + vertices.length - 1) % vertices.length], b = vertices[i], c = vertices[(i + 1) % vertices.length];
      if (cross2(a, b, c) <= EPS) continue;
      if (vertices.some((p) => p !== a && p !== b && p !== c && cross2(a, b, p) >= -EPS && cross2(b, c, p) >= -EPS && cross2(c, a, p) >= -EPS)) continue;
      pieces.push([a, b, c]);
      vertices.splice(i, 1);
      clipped = true;
      break;
    }
    if (!clipped) return [];
  }
  if (outlineArea(vertices) <= EPS) return [];
  pieces.push(vertices);
  for (let changed = true; changed; ) {
    changed = false;
    merge: for (let a = 0; a < pieces.length; a++) for (let b = a + 1; b < pieces.length; b++) {
      const left = pieces[a], right = pieces[b];
      for (let i = 0; i < left.length; i++) for (let j = 0; j < right.length; j++) {
        if (!same2(left[i], right[(j + 1) % right.length]) || !same2(left[(i + 1) % left.length], right[j])) continue;
        const joined = [
          ...Array.from({ length: left.length }, (_, k) => left[(i + 1 + k) % left.length]),
          ...Array.from({ length: right.length - 2 }, (_, k) => right[(j + 2 + k) % right.length])
        ];
        if (!isConvex(joined)) continue;
        pieces[a] = joined;
        pieces.splice(b, 1);
        changed = true;
        break merge;
      }
    }
  }
  return pieces;
}
function waterRayExit(origin, dx, dz, outline) {
  if (!pointInWaterOutline(origin, outline)) return;
  let nearest = Infinity;
  for (let i = 0; i < outline.length; i++) {
    const a = outline[i], b = outline[(i + 1) % outline.length], ex = b.x - a.x, ez = b.z - a.z;
    const determinant = dx * ez - dz * ex;
    if (Math.abs(determinant) < EPS) continue;
    const ax = a.x - origin.x, az = a.z - origin.z, t = (ax * ez - az * ex) / determinant, u = (ax * dz - az * dx) / determinant;
    if (t >= -EPS && u >= -EPS && u <= 1 + EPS) nearest = Math.min(nearest, t);
  }
  return Number.isFinite(nearest) ? nearest : void 0;
}
function waterSegmentIntervals(a, b, outline) {
  const dx = b.x - a.x, dz = b.z - a.z, values = [0, 1];
  for (let i = 0; i < outline.length; i++) {
    const p = outline[i], q = outline[(i + 1) % outline.length], ex = q.x - p.x, ez = q.z - p.z, det = dx * ez - dz * ex;
    if (Math.abs(det) < EPS) continue;
    const px = p.x - a.x, pz = p.z - a.z, t = (px * ez - pz * ex) / det, u = (px * dz - pz * dx) / det;
    if (t > EPS && t < 1 - EPS && u >= -EPS && u <= 1 + EPS) values.push(t);
  }
  values.sort((x, y) => x - y);
  return values.slice(1).flatMap((end, i) => {
    const start = values[i], t = (start + end) / 2;
    return end - start > EPS && pointInWaterOutline({ x: a.x + dx * t, y: a.y, z: a.z + dz * t }, outline) ? [[start, end]] : [];
  });
}
function subtractWaterConvexPieces(polygon, pieces) {
  let remaining = [[...polygon]];
  const box = (points) => ({
    minX: Math.min(...points.map((p) => p.x)),
    maxX: Math.max(...points.map((p) => p.x)),
    minZ: Math.min(...points.map((p) => p.z)),
    maxZ: Math.max(...points.map((p) => p.z))
  });
  const sourceBox = box(polygon);
  for (const piece of pieces) {
    const cutBox = box(piece);
    if (sourceBox.maxX < cutBox.minX - EPS || sourceBox.minX > cutBox.maxX + EPS || sourceBox.maxZ < cutBox.minZ - EPS || sourceBox.minZ > cutBox.maxZ + EPS) continue;
    remaining = remaining.flatMap((input) => {
      let inside = input;
      const outside = [];
      for (let i = 0; i < piece.length && inside.length; i++) {
        const a = piece[i], b = piece[(i + 1) % piece.length];
        const split = (keepInside) => {
          const result = [];
          for (let j = 0; j < inside.length; j++) {
            const p = inside[j], q = inside[(j + 1) % inside.length], dp = cross2(a, b, p), dq = cross2(a, b, q);
            const keepP = keepInside ? dp >= -EPS : dp <= EPS, keepQ = keepInside ? dq >= -EPS : dq <= EPS;
            if (keepP) result.push(p);
            if (keepP !== keepQ && Math.abs(dp - dq) > EPS) {
              const t = Math.max(0, Math.min(1, dp / (dp - dq)));
              result.push({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t, z: p.z + (q.z - p.z) * t });
            }
          }
          const clean2 = result.filter((point, index) => !same2(point, result[(index + result.length - 1) % result.length]));
          return clean2.length >= 3 && Math.abs(outlineArea(clean2)) > 1e-12 ? clean2 : [];
        };
        const removed = split(false);
        if (removed.length) outside.push(removed);
        inside = split(true);
      }
      return outside;
    });
  }
  return remaining;
}
function adaptWaterContour(source, center, along, across, yaw, negativeAlong = along, negativeAcross = across) {
  const maxX = Math.max(...source.map((p) => p.x)), minX = -Math.min(...source.map((p) => p.x)), maxZ = Math.max(...source.map((p) => p.z)), minZ = -Math.min(...source.map((p) => p.z));
  const outline = source.map((p) => {
    const x = p.x * (p.x < 0 ? negativeAlong / minX : along / maxX), z = p.z * (p.z < 0 ? negativeAcross / minZ : across / maxZ);
    return {
      x: center.x + x * Math.cos(yaw) - z * Math.sin(yaw),
      y: center.y,
      z: center.z + x * Math.sin(yaw) + z * Math.cos(yaw)
    };
  });
  return outlineArea(outline) < 0 ? outline.reverse() : outline;
}

// src/domain/growingIsland/authoredWaterRim.ts
function scaledWaterOutline(outline, center, scale) {
  return outline.map((p) => ({ x: center.x + (p.x - center.x) * scale, y: p.y, z: center.z + (p.z - center.z) * scale }));
}
function buildWaterRim({ id, outline, center, waterY, rings, groundAt, mouths, body, lip }) {
  const rows = rings.map((ring, row) => scaledWaterOutline(outline, center, ring.scale).map((p) => {
    const y = row === 0 ? groundAt(p) : waterY + ring.height;
    return y === void 0 ? void 0 : { ...p, y };
  }));
  if (rows.some((row) => row.some((point) => !point))) return;
  const mouthPieces = mouths.flatMap(decomposeWaterOutline);
  const result = [];
  for (let band = 0; band + 1 < rows.length; band++) {
    const vertices = [], indices = [];
    for (let i = 0; i < outline.length; i++) {
      const next = (i + 1) % outline.length;
      const quad = [rows[band][i], rows[band][next], rows[band + 1][next], rows[band + 1][i]];
      for (const triangle of [[quad[0], quad[1], quad[2]], [quad[0], quad[2], quad[3]]]) {
        for (const polygon of subtractWaterConvexPieces(triangle, mouthPieces)) {
          const offset = vertices.length;
          vertices.push(...polygon);
          for (let vertex = 1; vertex + 1 < polygon.length; vertex++) indices.push(offset, offset + vertex, offset + vertex + 1);
        }
      }
    }
    if (indices.length) result.push({
      id: `${id}:${band}`,
      kind: "bank",
      vertices,
      indices,
      material: { ...band === 1 ? lip : body, metalness: 0 }
    });
  }
  return result;
}

// src/domain/growingIsland/nativeWaterBridgeProfile.json
var nativeWaterBridgeProfile_default = { version: 1, source: { artifact: "docs/design/2026-10-10-island-final-3d/whole-island.glb", sha256: "8398eda9ac084a6e80ed22f1a82670c380b017544a177106325aaa7ba7f8f68d", id: "native05-forest-garden-bridge" }, scale: 0.45, span: 1.49329318, width: 0.44100001, archHeight: 0.126, deckBaseY: 0.02281418, deckRows: [{ x: -0.74664659, y: 0.02281418 }, { x: -0.72189325, y: 0.02281418 }, { x: -0.63709272, y: 0.04597338 }, { x: -0.55210455, y: 0.06835518 }, { x: -0.46693438, y: 0.0891909 }, { x: -0.38159269, y: 0.10776066 }, { x: -0.29980389, y: 0.12280462 }, { x: -0.21424523, y: 0.13515493 }, { x: -0.12858882, y: 0.14363851 }, { x: -0.04287008, y: 0.14795665 }, { x: 0.04287008, y: 0.14795665 }, { x: 0.12858881, y: 0.14363851 }, { x: 0.21424522, y: 0.13515493 }, { x: 0.29980391, y: 0.12280462 }, { x: 0.38159267, y: 0.10776066 }, { x: 0.46693441, y: 0.0891909 }, { x: 0.55210458, y: 0.06835517 }, { x: 0.63709272, y: 0.04597338 }, { x: 0.72189326, y: 0.02281418 }, { x: 0.74664659, y: 0.02281418 }], bounds: { min: [-0.75771431, -0.07620783, -0.22049992], max: [0.75771431, 0.46973076, 0.22050009] }, material: { name: "house / honey wood", color: "#b98b62", roughness: 0.77999997, metalness: 0 }, counts: { parts: 33, vertices: 9465, triangles: 8568 }, artifact: { path: "/prototypes/place-qa/native-water-bridge.json.gz", sha256: "b5bf0ea46ac72b0604a741a4d2058f83ec09b17592895691d991ea18b4731168", expandedSha256: "ec89fbae2f29ea5ba2f3d548f11e711c8ff3ff2b1800362405aac453f5091353", bytes: 736430, gzipBytes: 90731 } };

// src/domain/growingIsland/authoredWaterBridge.ts
var EPS2 = 1e-9;
var key3 = (cell) => `${cell.x},${cell.z}`;
var refKey2 = (ref) => JSON.stringify([ref.districtId, ref.siteId]);
var edgeKey = (edge) => JSON.stringify([refKey2(edge.from), refKey2(edge.to)].sort());
var round = (n) => Math.round(n * 1e9) / 1e9 || 0;
var cross3 = (a, b, p) => (b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x);
var area = (polygon) => polygon.reduce((sum, p, i) => {
  const q = polygon[(i + 1) % polygon.length];
  return sum + p.point.x * q.point.z - p.point.z * q.point.x;
}, 0) / 2;
var turn3 = (x, z, n) => n === 1 ? { x: -z, z: x } : n === 2 ? { x: -x, z: -z } : n === 3 ? { x: z, z: -x } : { x, z };
function localPoint(district, p) {
  const xy = turn3(p.x - district.worldOrigin.x, p.z - district.worldOrigin.z, (4 - district.turn) % 4);
  return { x: round(xy.x), y: round(p.y - district.worldOrigin.y), z: round(xy.z) };
}
function worldPoint(district, p) {
  const xy = turn3(p.x, p.z, district.turn);
  return { x: xy.x + district.worldOrigin.x, y: p.y + district.worldOrigin.y, z: xy.z + district.worldOrigin.z };
}
function intersect(polygon, outline) {
  let out = [...polygon];
  for (let i = 0; i < outline.length && out.length; i++) {
    const a = outline[i], b = outline[(i + 1) % outline.length], input = out;
    out = [];
    for (let j = 0; j < input.length; j++) {
      const p = input[j], q = input[(j + 1) % input.length], dp = cross3(a, b, p.point), dq = cross3(a, b, q.point);
      if (dp >= -EPS2) out.push(p);
      if (dp >= -EPS2 !== dq >= -EPS2 && Math.abs(dp - dq) > EPS2) {
        const t = Math.max(0, Math.min(1, dp / (dp - dq)));
        out.push({
          cell: { x: round(p.cell.x + (q.cell.x - p.cell.x) * t), z: round(p.cell.z + (q.cell.z - p.cell.z) * t) },
          point: { x: round(p.point.x + (q.point.x - p.point.x) * t), y: round(p.point.y + (q.point.y - p.point.y) * t), z: round(p.point.z + (q.point.z - p.point.z) * t) }
        });
      }
    }
    out = out.filter((p, j) => Math.hypot(
      p.point.x - out[(j + out.length - 1) % out.length].point.x,
      p.point.z - out[(j + out.length - 1) % out.length].point.z
    ) > 1e-8);
    if (out.length < 3 || Math.abs(area(out)) < 1e-12) return [];
  }
  return out;
}
function overlaps(a, b) {
  return a.some((p) => pointInWaterOutline(p, b)) || b.some((p) => pointInWaterOutline(p, a)) || a.some((p, i) => waterSegmentIntervals(p, a[(i + 1) % a.length], b).some(([from, to]) => to - from > EPS2));
}
function protections(state, waterOwners) {
  const out = HOUSE_CELLS.map((cell) => ({ cell, half: AUTHORED_OWNER_HALF_EXTENT + AUTHORED_WALK_HALF_WIDTH }));
  for (const owner of [...state.plots, ...state.landmarks, ...state.keepsakes]) {
    if (!owner.cell || waterOwners.has(owner.id)) continue;
    out.push({ cell: owner.cell, half: AUTHORED_OWNER_HALF_EXTENT + AUTHORED_WALK_HALF_WIDTH });
    if ("kind" in owner && owner.kind === "home") out.push({ cell: { x: owner.cell.x, z: owner.cell.z + 0.75 }, half: 0.18 });
  }
  return out;
}
function footBand(base, from, to) {
  const dx = to.x - from.x, dz = to.z - from.z, length = Math.hypot(dx, dz), steps = Math.max(8, Math.ceil(length * 8)), points = [];
  for (let i = 0; i <= steps; i++) for (const side of [-AUTHORED_WALK_HALF_WIDTH, 0, AUTHORED_WALK_HALF_WIDTH]) {
    const cell = { x: from.x + dx * i / steps - dz / length * side, z: from.z + dz * i / steps + dx / length * side };
    const floor = base.anchorFloorAt(cell);
    if (!floor) return;
    points.push(floor.point);
  }
  return points;
}
function bandIntersects(points, outline) {
  return points.some((p, i) => pointInWaterOutline(p, outline) || i % 3 < 2 && waterSegmentIntervals(p, points[i + 1], outline).length > 0 || i + 3 < points.length && waterSegmentIntervals(p, points[i + 3], outline).length > 0);
}
function authoredBridgeHeightAt(plan, localX) {
  const sourceX = localX * nativeWaterBridgeProfile_default.span / plan.span, rows = nativeWaterBridgeProfile_default.deckRows;
  const index = rows.findIndex((row) => row.x >= sourceX - EPS2), b = rows[index < 0 ? rows.length - 1 : index], a = rows[Math.max(0, (index < 0 ? rows.length - 1 : index) - 1)];
  const t = a === b ? 0 : Math.max(0, Math.min(1, (sourceX - a.x) / (b.x - a.x)));
  return plan.deckY + (a.y + (b.y - a.y) * t - nativeWaterBridgeProfile_default.deckBaseY) * plan.archHeight / nativeWaterBridgeProfile_default.archHeight;
}
function rectangle(center, across, flow, minX, maxX, minZ, maxZ) {
  return [[minX, minZ], [maxX, minZ], [maxX, maxZ], [minX, maxZ]].map(([x, z]) => ({ x: center.x + across.x * x + flow.x * z, y: center.y, z: center.z + across.z * x + flow.z * z }));
}
function makeDeck(base, district, plan, across, flow) {
  const vertices = [], indices = [], allowed = authoredWaterCarvingFloorIds(base, district.id);
  const box = { minX: Math.min(...plan.outline.map((p) => p.x)), maxX: Math.max(...plan.outline.map((p) => p.x)), minZ: Math.min(...plan.outline.map((p) => p.z)), maxZ: Math.max(...plan.outline.map((p) => p.z)) };
  const strips = nativeWaterBridgeProfile_default.deckRows.slice(1).map((row, i) => rectangle(
    plan.center,
    across,
    flow,
    nativeWaterBridgeProfile_default.deckRows[i].x * plan.span / nativeWaterBridgeProfile_default.span,
    row.x * plan.span / nativeWaterBridgeProfile_default.span,
    -plan.width / 2,
    plan.width / 2
  ));
  for (const floor of district.floors) {
    if (floor.kind !== "ground" || allowed && !allowed.includes(JSON.stringify([district.id, floor.id]))) continue;
    for (let i = 0; i < floor.indices.length; i += 3) {
      const triangle = floor.indices.slice(i, i + 3).map((index) => ({ cell: floor.vertices[index].cell, point: worldPoint(district, floor.vertices[index].point) }));
      if (triangle.every((v) => v.point.x < box.minX) || triangle.every((v) => v.point.x > box.maxX) || triangle.every((v) => v.point.z < box.minZ) || triangle.every((v) => v.point.z > box.maxZ)) continue;
      const clipped = intersect(triangle, plan.outline);
      if (!clipped.length) continue;
      for (const strip of strips) {
        const polygon = intersect(clipped, strip);
        if (!polygon.length) continue;
        const offset = vertices.length;
        vertices.push(...polygon.map((vertex) => ({ cell: { ...vertex.cell }, point: localPoint(district, {
          ...vertex.point,
          y: authoredBridgeHeightAt(plan, (vertex.point.x - plan.center.x) * across.x + (vertex.point.z - plan.center.z) * across.z)
        }) })));
        for (let j = 1; j + 1 < polygon.length; j++) indices.push(
          offset,
          offset + (area(polygon) > 0 ? j + 1 : j),
          offset + (area(polygon) > 0 ? j : j + 1)
        );
      }
    }
  }
  return indices.length ? { id: JSON.parse(plan.deckFloorId)[1], kind: "deck", color: nativeWaterBridgeProfile_default.material.color, vertices, indices } : void 0;
}
function waterClearance(world, ids, center, across, flow, span, width, archHeight) {
  let minimumDeckY = -Infinity;
  const strips = nativeWaterBridgeProfile_default.deckRows.slice(1).map((row, i) => rectangle(
    center,
    across,
    flow,
    nativeWaterBridgeProfile_default.deckRows[i].x * span / nativeWaterBridgeProfile_default.span,
    row.x * span / nativeWaterBridgeProfile_default.span,
    -width / 2,
    width / 2
  ));
  for (const floor of world.floors.filter((floor2) => floor2.kind === "water" && ids.includes(floor2.id))) for (let i = 0; i < floor.indices.length; i += 3) {
    const triangle = floor.indices.slice(i, i + 3).map((index) => floor.vertices[index]);
    for (const strip of strips) for (const vertex of intersect(triangle, strip)) {
      const localX = (vertex.point.x - center.x) * across.x + (vertex.point.z - center.z) * across.z;
      minimumDeckY = Math.max(minimumDeckY, vertex.point.y + 0.018 - authoredBridgeHeightAt({ span, archHeight, deckY: 0 }, localX));
    }
  }
  return Number.isFinite(minimumDeckY) ? minimumDeckY : void 0;
}
function dryLanding(world, outline, bedIds) {
  const box = { minX: Math.min(...outline.map((p) => p.x)), maxX: Math.max(...outline.map((p) => p.x)), minZ: Math.min(...outline.map((p) => p.z)), maxZ: Math.max(...outline.map((p) => p.z)) };
  let uncovered = [[...outline]];
  const points = [];
  for (const floor of world.floors) {
    if (floor.kind === "deck" || bedIds.has(floor.id)) continue;
    for (let i = 0; i < floor.indices.length; i += 3) {
      const triangle = floor.indices.slice(i, i + 3).map((index) => floor.vertices[index]);
      if (triangle.every((v) => v.point.x < box.minX) || triangle.every((v) => v.point.x > box.maxX) || triangle.every((v) => v.point.z < box.minZ) || triangle.every((v) => v.point.z > box.maxZ)) continue;
      const clipped = intersect(triangle, outline);
      if (!clipped.length) continue;
      if (floor.kind === "water") return;
      points.push(...clipped.map((v) => v.point));
      const stencil = clipped.map((v) => v.point);
      if (outlineArea(stencil) < 0) stencil.reverse();
      uncovered = uncovered.flatMap((piece) => subtractWaterConvexPieces(piece, [stencil]));
    }
  }
  return uncovered.reduce((sum, p) => sum + Math.abs(outlineArea(p)), 0) < 1e-9 && points.length ? points : void 0;
}
function composeAuthoredWaterBridges(state, base, cutWorld, water) {
  let definition = structuredClone(cutWorld.definition), current = cutWorld;
  const bridges = [], sites = new Map(base.sites.map((site) => [refKey2(site.ref), site]));
  const protectedOwners = protections(state, new Set(water.ownerIds));
  const bedIds = /* @__PURE__ */ new Set([...water.pools.map((pool) => pool.bedFloorId), ...water.streams.flatMap((stream) => stream.bedFloorIds)]);
  for (const owner of state.landmarks.filter((owner2) => owner2.cell && owner2.kind === "water-channel" && water.ownerIds.includes(owner2.id)).sort((a, b) => a.id.localeCompare(b.id))) {
    const links = water.streams.filter((stream2) => stream2.ownerIds.includes(owner.id));
    if (links.length !== 1) continue;
    const anchor = base.anchorAt(owner.cell), site = base.sites.find((site2) => key3(site2.cell) === key3(owner.cell)), stream = links[0];
    if (!site) continue;
    const other = Math.hypot(stream.from.x - anchor.x, stream.from.z - anchor.z) < Math.hypot(stream.to.x - anchor.x, stream.to.z - anchor.z) ? stream.to : stream.from;
    const length = Math.hypot(anchor.x - other.x, anchor.z - other.z);
    if (length < 0.05) continue;
    const flow = { x: (anchor.x - other.x) / length, z: (anchor.z - other.z) / length }, across = { x: flow.z, z: -flow.x };
    const project = (p) => ({ x: (p.x - anchor.x) * across.x + (p.z - anchor.z) * across.z, z: (p.x - anchor.x) * flow.x + (p.z - anchor.z) * flow.z });
    const candidates = [];
    for (const edge of base.definition.edges) {
      if (!edge.allows.includes("walk") || edge.from.districtId !== site.ref.districtId || edge.to.districtId !== site.ref.districtId) continue;
      const a = sites.get(refKey2(edge.from)), b = sites.get(refKey2(edge.to));
      const mid = project({ x: (a.point.x + b.point.x) / 2, y: 0, z: (a.point.z + b.point.z) / 2 });
      if (Math.abs(mid.x) > nativeWaterBridgeProfile_default.span / 2 || mid.z < -0.13 || mid.z > 0.28 || isWorldWalkEdgeSupported(current, a.cell, b.cell)) continue;
      const points2 = footBand(base, a.cell, b.cell);
      if (!points2) continue;
      if (!bandIntersects(points2, stream.outline)) continue;
      if (points2.some((p) => {
        const q = project(p);
        return q.z < -0.16 || q.z > 0.41 || Math.abs(q.x) > nativeWaterBridgeProfile_default.span / 2;
      })) continue;
      candidates.push({ edge, points: points2 });
    }
    if (!candidates.length) continue;
    const points = candidates.flatMap((candidate) => candidate.points).map(project), minX = Math.min(...points.map((p) => p.x)) - 0.01, maxX = Math.max(...points.map((p) => p.x)) + 0.01, minZ = Math.min(...points.map((p) => p.z)) - 0.01, maxZ = Math.max(...points.map((p) => p.z)) + 0.01;
    const span = Math.max(nativeWaterBridgeProfile_default.span * 0.4, maxX - minX), width = Math.max(nativeWaterBridgeProfile_default.width, maxZ - minZ);
    if (span > nativeWaterBridgeProfile_default.span + EPS2 || width > nativeWaterBridgeProfile_default.width * 1.4) continue;
    const cx = (minX + maxX) / 2, cz = (minZ + maxZ) / 2, center = { x: anchor.x + across.x * cx + flow.x * cz, y: 0, z: anchor.z + across.z * cx + flow.z * cz };
    const outline = rectangle(center, across, flow, -span / 2, span / 2, -width / 2, width / 2), footprint = rectangle(
      center,
      across,
      flow,
      nativeWaterBridgeProfile_default.bounds.min[0] * span / nativeWaterBridgeProfile_default.span,
      nativeWaterBridgeProfile_default.bounds.max[0] * span / nativeWaterBridgeProfile_default.span,
      nativeWaterBridgeProfile_default.bounds.min[2] * width / nativeWaterBridgeProfile_default.width,
      nativeWaterBridgeProfile_default.bounds.max[2] * width / nativeWaterBridgeProfile_default.width
    );
    if (!isAuthoredWaterCarvingSafe(base, site.ref.districtId, footprint, protectedOwners) || water.pools.some((pool) => overlaps(outline, pool.outline)) || water.grottos.some((grotto) => overlaps(footprint, grotto.footprint))) continue;
    const landings = [-1, 1].map((side) => dryLanding(current, rectangle(
      center,
      across,
      flow,
      side * span / 2 - 0.015,
      side * span / 2 + 0.015,
      -width / 2,
      width / 2
    ), bedIds));
    if (landings.some((landing) => !landing)) continue;
    const landingPoints = landings.flatMap((landing) => landing);
    if (Math.max(...landingPoints.map((p) => p.y)) - Math.min(...landingPoints.map((p) => p.y)) > 0.12) continue;
    const archHeight = nativeWaterBridgeProfile_default.archHeight * span / nativeWaterBridgeProfile_default.span;
    const clearDeckY = waterClearance(current, stream.waterFloorIds, center, across, flow, span, width, archHeight);
    if (clearDeckY === void 0) continue;
    const deckY = Math.max(Math.max(...landingPoints.map((p) => p.y)) + 6e-3, clearDeckY);
    if (deckY - Math.min(...landingPoints.map((p) => p.y)) > 0.12) continue;
    const localId2 = `authored-water:bridge:${encodeURIComponent(owner.id)}`;
    const plan = {
      ownerId: owner.id,
      districtId: site.ref.districtId,
      deckFloorId: JSON.stringify([site.ref.districtId, localId2]),
      sourceId: nativeWaterBridgeProfile_default.source.id,
      sourceSHA: nativeWaterBridgeProfile_default.source.sha256,
      center: { ...center, y: round(deckY) },
      yaw: Math.atan2(flow.x, flow.z),
      span: round(span),
      width: round(width),
      deckY: round(deckY),
      archHeight: round(archHeight),
      outline,
      footprint,
      landingPoints,
      restoredEdgeIds: []
    };
    const district = base.definition.districts.find((district2) => district2.id === site.ref.districtId), deck = makeDeck(base, district, plan, across, flow);
    if (!deck) continue;
    const next = { ...definition, districts: definition.districts.map((district2) => district2.id === site.ref.districtId ? { ...district2, floors: [...district2.floors, deck] } : district2) };
    const supported = compileWorldDefinition(next);
    if (candidates.some(({ edge }) => !isWorldWalkEdgeSupported(supported, sites.get(refKey2(edge.from)).cell, sites.get(refKey2(edge.to)).cell))) continue;
    plan.restoredEdgeIds = candidates.map(({ edge }) => edgeKey(edge));
    definition = next;
    current = supported;
    bridges.push(plan);
  }
  return { definition, bridges, supportWorld: current };
}

// src/domain/growingIsland/nativeWaterSource.json
var nativeWaterSource_default = { version: 1, source: { artifact: "docs/design/2026-10-10-island-final-3d/whole-island.glb", sha256: "8398eda9ac084a6e80ed22f1a82670c380b017544a177106325aaa7ba7f8f68d" }, scale: 0.45, pools: [{ role: "upper", outline: [{ x: 0.61480136, z: 0 }, { x: 0.61775286, z: -0.05185461 }, { x: 0.61266267, z: -0.10364914 }, { x: 0.59892118, z: -0.15397425 }, { x: 0.57668653, z: -0.20138712 }, { x: 0.54691765, z: -0.24469213 }, { x: 0.51123719, z: -0.28319664 }, { x: 0.47164736, z: -0.31686201 }, { x: 0.43016646, z: -0.3463191 }, { x: 0.38846519, z: -0.37271633 }, { x: 0.34759068, z: -0.39744844 }, { x: 0.30783691, z: -0.4218132 }, { x: 0.26878867, z: -0.44668093 }, { x: 0.22952414, z: -0.47226105 }, { x: 0.18891892, z: -0.49800768 }, { x: 0.14597611, z: -0.52270374 }, { x: 0.10010197, z: -0.54469013 }, { x: 0.05126388, z: -0.56219358 }, { x: 0, z: -0.57366228 }, { x: -0.0527097, z: -0.5780508 }, { x: -0.10566745, z: -0.57497463 }, { x: -0.15770745, z: -0.564711 }, { x: -0.20790585, z: -0.54805899 }, { x: -0.25569187, z: -0.52610264 }, { x: -0.30083978, z: -0.49994488 }, { x: -0.34335161, z: -0.47047749 }, { x: -0.38327458, z: -0.43825064 }, { x: -0.4205163, z: -0.40346775 }, { x: -0.45471897, z: -0.36608591 }, { x: -0.48523779, z: -0.32599268 }, { x: -0.51123708, z: -0.28319664 }, { x: -0.53188108, z: -0.23796473 }, { x: -0.54656811, z: -0.19086943 }, { x: -0.55513841, z: -0.14271841 }, { x: -0.55799153, z: -0.09440002 }, { x: -0.55606999, z: -0.0466773 }, { x: -0.55069871, z: 0 }, { x: -0.54331212, z: 0.04560699 }, { x: -0.53513074, z: 0.09053335 }, { x: -0.52686524, z: 0.13545027 }, { x: -0.51852518, z: 0.181077 }, { x: -0.509384, z: 0.22790022 }, { x: -0.4981155, z: 0.2759285 }, { x: -0.48307432, z: 0.32453957 }, { x: -0.46265842, z: 0.37247858 }, { x: -0.43566778, z: 0.41800575 }, { x: -0.4015783, z: 0.45918045 }, { x: -0.36066656, z: 0.49420366 }, { x: -0.31396136, z: 0.52175188 }, { x: -0.26303737, z: 0.54121742 }, { x: -0.20970562, z: 0.55280371 }, { x: -0.15567756, z: 0.55744286 }, { x: -0.10228508, z: 0.55657082 }, { x: -0.0503161, z: 0.5518012 }, { x: 0, z: 0.54458799 }, { x: 0.04887028, z: 0.53594398 }, { x: 0.0967196, z: 0.52628632 }, { x: 0.143946, z: 0.5154356 }, { x: 0.19071858, z: 0.5027524 }, { x: 0.23686974, z: 0.48737583 }, { x: 0.28191025, z: 0.46848793 }, { x: 0.32515175, z: 0.44553938 }, { x: 0.36589429, z: 0.41837826 }, { x: 0.40361667, z: 0.38725433 }, { x: 0.4381058, z: 0.35271177 }, { x: 0.469484, z: 0.31540976 }, { x: 0.49811561, z: 0.2759285 }, { x: 0.52442057, z: 0.23462763 }, { x: 0.54864371, z: 0.1915947 }, { x: 0.57064812, z: 0.1467061 }, { x: 0.58980188, z: 0.09978247 }, { x: 0.60499499, z: 0.0507843 }], radiusX: 0.61775286, radiusZ: 0.5780508 }, { role: "middle", outline: [{ x: 0.68957437, z: 0 }, { x: 0.69288486, z: -0.04601254 }, { x: 0.68717562, z: -0.09197059 }, { x: 0.671763, z: -0.13662572 }, { x: 0.64682404, z: -0.17869563 }, { x: 0.61343472, z: -0.21712203 }, { x: 0.57341455, z: -0.25128779 }, { x: 0.52900983, z: -0.28115945 }, { x: 0.48248391, z: -0.30729747 }, { x: 0.43571091, z: -0.33072066 }, { x: 0.3898652, z: -0.35266585 }, { x: 0.34527637, z: -0.37428489 }, { x: 0.30147911, z: -0.3963511 }, { x: 0.25743928, z: -0.41904902 }, { x: 0.21189548, z: -0.44189458 }, { x: 0.16372987, z: -0.46380715 }, { x: 0.11227641, z: -0.48331733 }, { x: 0.05749862, z: -0.49884753 }, { x: 0, z: -0.50902448 }, { x: -0.0591205, z: -0.51291862 }, { x: -0.11851888, z: -0.5101892 }, { x: -0.17688814, z: -0.50108171 }, { x: -0.23319168, z: -0.48630595 }, { x: -0.28678957, z: -0.4668241 }, { x: -0.33742844, z: -0.44361377 }, { x: -0.3851106, z: -0.41746631 }, { x: -0.42988907, z: -0.38887095 }, { x: -0.47166023, z: -0.3580071 }, { x: -0.51002263, z: -0.32483697 }, { x: -0.5442532, z: -0.28926101 }, { x: -0.57341455, z: -0.25128779 }, { x: -0.59656937, z: -0.21115251 }, { x: -0.61304263, z: -0.16936326 }, { x: -0.62265524, z: -0.1266376 }, { x: -0.62585544, z: -0.08376346 }, { x: -0.62370018, z: -0.04141803 }, { x: -0.61767561, z: 0 }, { x: -0.6093907, z: 0.04046788 }, { x: -0.60021427, z: 0.08033152 }, { x: -0.59094354, z: 0.12018785 }, { x: -0.58158912, z: 0.16067376 }, { x: -0.57133616, z: 0.20222096 }, { x: -0.55869711, z: 0.24483762 }, { x: -0.54182666, z: 0.2879714 }, { x: -0.51892773, z: 0.33050866 }, { x: -0.48865444, z: 0.37090616 }, { x: -0.45041891, z: 0.40744171 }, { x: -0.40453141, z: 0.43851843 }, { x: -0.35214588, z: 0.46296215 }, { x: -0.29502851, z: 0.48023515 }, { x: -0.23521031, z: 0.49051595 }, { x: -0.17461138, z: 0.49463239 }, { x: -0.11472516, z: 0.49385819 }, { x: -0.05643572, z: 0.48962631 }, { x: 0, z: 0.48322549 }, { x: 0.05481384, z: 0.47555523 }, { x: 0.10848269, z: 0.46698589 }, { x: 0.161453, z: 0.45735784 }, { x: 0.21391411, z: 0.44610372 }, { x: 0.26567817, z: 0.43245964 }, { x: 0.31619661, z: 0.41569991 }, { x: 0.36469717, z: 0.39533744 }, { x: 0.41039504, z: 0.37123661 }, { x: 0.45270517, z: 0.3436193 }, { x: 0.49138895, z: 0.31296873 }, { x: 0.52658329, z: 0.27986984 }, { x: 0.55869716, z: 0.24483762 }, { x: 0.58820146, z: 0.20819049 }, { x: 0.61537052, z: 0.17000613 }, { x: 0.64005135, z: 0.13017554 }, { x: 0.66153456, z: 0.08853865 }, { x: 0.67857538, z: 0.04506197 }], radiusX: 0.69288486, radiusZ: 0.51291862 }, { role: "lower", outline: [{ x: 0.73942315, z: 0 }, { x: 0.74297289, z: -0.04345651 }, { x: 0.73685102, z: -0.08686109 }, { x: 0.72032421, z: -0.12903528 }, { x: 0.69358237, z: -0.16876845 }, { x: 0.65777939, z: -0.20505939 }, { x: 0.6148663, z: -0.237327 }, { x: 0.56725151, z: -0.26553998 }, { x: 0.5173622, z: -0.29022532 }, { x: 0.46720801, z: -0.31234732 }, { x: 0.41804821, z: -0.33307328 }, { x: 0.37023612, z: -0.35349154 }, { x: 0.32327279, z: -0.37433209 }, { x: 0.27604928, z: -0.39576831 }, { x: 0.22721322, z: -0.41734486 }, { x: 0.17556568, z: -0.43804078 }, { x: 0.12039275, z: -0.45646648 }, { x: 0.06165516, z: -0.47113409 }, { x: 0, z: -0.48074541 }, { x: -0.06339425, z: -0.48442369 }, { x: -0.12708658, z: -0.48184576 }, { x: -0.18967528, z: -0.47324424 }, { x: -0.25004898, z: -0.45928946 }, { x: -0.30752134, z: -0.4408895 }, { x: -0.36182088, z: -0.41896834 }, { x: -0.41294992, z: -0.39427357 }, { x: -0.4609654, z: -0.36726694 }, { x: -0.50575614, z: -0.33811798 }, { x: -0.54689177, z: -0.30679064 }, { x: -0.58359685, z: -0.27319136 }, { x: -0.61486623, z: -0.237327 }, { x: -0.63969489, z: -0.19942203 }, { x: -0.657359, z: -0.1599545 }, { x: -0.66766647, z: -0.11960249 }, { x: -0.671098, z: -0.07911015 }, { x: -0.66878698, z: -0.03911734 }, { x: -0.66232686, z: 0 }, { x: -0.65344306, z: 0.03821955 }, { x: -0.64360328, z: 0.07586875 }, { x: -0.63366234, z: 0.11351066 }, { x: -0.62363173, z: 0.15174694 }, { x: -0.61263761, z: 0.19098659 }, { x: -0.59908486, z: 0.2312356 }, { x: -0.58099486, z: 0.27197299 }, { x: -0.55644059, z: 0.3121469 }, { x: -0.5239789, z: 0.35030036 }, { x: -0.48297932, z: 0.38480601 }, { x: -0.43377465, z: 0.41415625 }, { x: -0.37760224, z: 0.43724213 }, { x: -0.31635587, z: 0.45355511 }, { x: -0.25221352, z: 0.4632647 }, { x: -0.18723391, z: 0.46715283 }, { x: -0.12301855, z: 0.46642156 }, { x: -0.06051541, z: 0.46242485 }, { x: 0, z: 0.4563798 }, { x: 0.05877635, z: 0.44913568 }, { x: 0.11632475, z: 0.44104228 }, { x: 0.17312433, z: 0.43194895 }, { x: 0.22937777, z: 0.4213201 }, { x: 0.28488383, z: 0.40843391 }, { x: 0.3390541, z: 0.39260545 }, { x: 0.39106084, z: 0.37337422 }, { x: 0.44006212, z: 0.35061235 }, { x: 0.48543083, z: 0.32452927 }, { x: 0.52691098, z: 0.29558158 }, { x: 0.56464955, z: 0.26432161 }, { x: 0.59908493, z: 0.2312356 }, { x: 0.63072201, z: 0.19662437 }, { x: 0.65985509, z: 0.16056132 }, { x: 0.68632002, z: 0.12294345 }, { x: 0.70935623, z: 0.08361969 }, { x: 0.72762894, z: 0.04255872 }], radiusX: 0.74297289, radiusZ: 0.48442369 }], rim: { rings: [{ scale: 1.2, height: -0.2295 }, { scale: 1.13142857, height: 0.04275 }, { scale: 1.00571429, height: 0.0315 }, { scale: 0.94857143, height: -0.108 }], body: { color: "#8295ba", roughness: 0.56 }, lip: { color: "#ad9bc9", roughness: 0.43000001 } }, water: { deepColor: "#287ca6", shoreColor: "#69c9cd" }, grotto: { pivot: { x: 4.35, y: 5.26, z: -19.18 }, primitives: [{ vertices: [{ x: 0.37554012, y: 0.11675623, z: 0.16200014 }, { x: 0.32246757, y: 0.16584431, z: 0.16200014 }, { x: 0.29910832, y: 0.21107643, z: 0.16200014 }, { x: 0.23505352, y: 0.2748628, z: 0.16200014 }, { x: 0.15609701, y: 0.34483369, z: 0.16200014 }, { x: 0.08640571, y: 0.40548809, z: 0.16200014 }, { x: -4e-8, y: 0.35596228, z: 0.16200014 }, { x: -0.08159456, y: 0.32664531, z: 0.16200014 }, { x: -0.16859748, y: 0.35115555, z: 0.16200014 }, { x: -0.22459685, y: 0.31283966, z: 0.16200014 }, { x: -0.29405587, y: 0.24405001, z: 0.16200014 }, { x: -0.34533649, y: 0.13834694, z: 0.16200014 }, { x: -0.34886488, y: 0.06057382, z: 0.16200014 }, { x: -0.38457764, y: 0.02148181, z: 0.16200014 }, { x: -0.38457764, y: 0.02148181, z: 0.16200014 }, { x: 0.61200002, y: 1e-7, z: 0.16200014 }, { x: 0.61534291, y: 0.1714896, z: 0.16200014 }, { x: 0.61534291, y: 0.1714896, z: 0.16200014 }, { x: 0.61534291, y: 0.1714896, z: 0.16200014 }, { x: 0.52838054, y: 0.26500686, z: 0.16200014 }, { x: 0.52838054, y: 0.26500686, z: 0.16200014 }, { x: 0.52838054, y: 0.26500686, z: 0.16200014 }, { x: 0.4901052, y: 0.36339136, z: 0.16200014 }, { x: 0.4901052, y: 0.36339136, z: 0.16200014 }, { x: 0.4901052, y: 0.36339136, z: 0.16200014 }, { x: 0.38514779, y: 0.46307512, z: 0.16200014 }, { x: 0.38514779, y: 0.46307512, z: 0.16200014 }, { x: 0.38514779, y: 0.46307512, z: 0.16200014 }, { x: 0.25577326, y: 0.55181397, z: 0.16200014 }, { x: 0.25577326, y: 0.55181397, z: 0.16200014 }, { x: 0.25577326, y: 0.55181397, z: 0.16200014 }, { x: 0.14158047, y: 0.64722443, z: 0.16200014 }, { x: 0.14158047, y: 0.64722443, z: 0.16200014 }, { x: 0.14158047, y: 0.64722443, z: 0.16200014 }, { x: -4e-8, y: 0.59063519, z: 0.16200014 }, { x: -4e-8, y: 0.59063519, z: 0.16200014 }, { x: -4e-8, y: 0.59063519, z: 0.16200014 }, { x: -0.13369722, y: 0.55492168, z: 0.16200014 }, { x: -0.13369722, y: 0.55492168, z: 0.16200014 }, { x: -0.13369722, y: 0.55492168, z: 0.16200014 }, { x: -0.2762562, y: 0.57471102, z: 0.16200014 }, { x: -0.2762562, y: 0.57471102, z: 0.16200014 }, { x: -0.2762562, y: 0.57471102, z: 0.16200014 }, { x: -0.36801403, y: 0.4926792, z: 0.16200014 }, { x: -0.36801403, y: 0.4926792, z: 0.16200014 }, { x: -0.36801403, y: 0.4926792, z: 0.16200014 }, { x: -0.48182649, y: 0.39379195, z: 0.16200014 }, { x: -0.48182649, y: 0.39379195, z: 0.16200014 }, { x: -0.48182649, y: 0.39379195, z: 0.16200014 }, { x: -0.56585259, y: 0.24454182, z: 0.16200014 }, { x: -0.56585259, y: 0.24454182, z: 0.16200014 }, { x: -0.56585259, y: 0.24454182, z: 0.16200014 }, { x: -0.57163404, y: 0.11141949, z: 0.16200014 }, { x: -0.57163404, y: 0.11141949, z: 0.16200014 }, { x: -0.57163404, y: 0.11141949, z: 0.16200014 }, { x: -0.63015136, y: 0.02148181, z: 0.16200014 }, { x: -0.63015136, y: 0.02148181, z: 0.16200014 }, { x: -0.63015136, y: 0.02148181, z: 0.16200014 }, { x: 0.37349992, y: 1e-7, z: -0.27899966 }, { x: 0.37554012, y: 0.11675623, z: -0.27899966 }, { x: 0.32246757, y: 0.16584431, z: -0.27899966 }, { x: 0.29910832, y: 0.21107643, z: -0.27899966 }, { x: 0.23505352, y: 0.2748628, z: -0.27899966 }, { x: 0.15609701, y: 0.34483369, z: -0.27899966 }, { x: 0.08640571, y: 0.40548809, z: -0.27899966 }, { x: -4e-8, y: 0.35596228, z: -0.27899966 }, { x: -0.08159456, y: 0.32664531, z: -0.27899966 }, { x: -0.16859748, y: 0.35115555, z: -0.27899966 }, { x: -0.22459685, y: 0.31283966, z: -0.27899966 }, { x: -0.29405587, y: 0.24405001, z: -0.27899966 }, { x: -0.34533649, y: 0.13834694, z: -0.27899966 }, { x: -0.34886488, y: 0.06057382, z: -0.27899966 }, { x: -0.38457764, y: 0.02148181, z: -0.27899966 }, { x: -0.38457764, y: 0.02148181, z: -0.27899966 }, { x: 0.61200002, y: 1e-7, z: -0.27899966 }, { x: 0.61200002, y: 1e-7, z: -0.27899966 }, { x: 0.61534291, y: 0.1714896, z: -0.27899966 }, { x: 0.61534291, y: 0.1714896, z: -0.27899966 }, { x: 0.61534291, y: 0.1714896, z: -0.27899966 }, { x: 0.52838054, y: 0.26500686, z: -0.27899966 }, { x: 0.52838054, y: 0.26500686, z: -0.27899966 }, { x: 0.52838054, y: 0.26500686, z: -0.27899966 }, { x: 0.4901052, y: 0.36339136, z: -0.27899966 }, { x: 0.4901052, y: 0.36339136, z: -0.27899966 }, { x: 0.4901052, y: 0.36339136, z: -0.27899966 }, { x: 0.38514779, y: 0.46307512, z: -0.27899966 }, { x: 0.38514779, y: 0.46307512, z: -0.27899966 }, { x: 0.38514779, y: 0.46307512, z: -0.27899966 }, { x: 0.25577326, y: 0.55181397, z: -0.27899966 }, { x: 0.25577326, y: 0.55181397, z: -0.27899966 }, { x: 0.25577326, y: 0.55181397, z: -0.27899966 }, { x: 0.14158047, y: 0.64722443, z: -0.27899966 }, { x: 0.14158047, y: 0.64722443, z: -0.27899966 }, { x: 0.14158047, y: 0.64722443, z: -0.27899966 }, { x: -4e-8, y: 0.59063519, z: -0.27899966 }, { x: -4e-8, y: 0.59063519, z: -0.27899966 }, { x: -4e-8, y: 0.59063519, z: -0.27899966 }, { x: -0.13369722, y: 0.55492168, z: -0.27899966 }, { x: -0.13369722, y: 0.55492168, z: -0.27899966 }, { x: -0.13369722, y: 0.55492168, z: -0.27899966 }, { x: -0.2762562, y: 0.57471102, z: -0.27899966 }, { x: -0.2762562, y: 0.57471102, z: -0.27899966 }, { x: -0.2762562, y: 0.57471102, z: -0.27899966 }, { x: -0.36801403, y: 0.4926792, z: -0.27899966 }, { x: -0.36801403, y: 0.4926792, z: -0.27899966 }, { x: -0.36801403, y: 0.4926792, z: -0.27899966 }, { x: -0.48182649, y: 0.39379195, z: -0.27899966 }, { x: -0.48182649, y: 0.39379195, z: -0.27899966 }, { x: -0.48182649, y: 0.39379195, z: -0.27899966 }, { x: -0.56585259, y: 0.24454182, z: -0.27899966 }, { x: -0.56585259, y: 0.24454182, z: -0.27899966 }, { x: -0.56585259, y: 0.24454182, z: -0.27899966 }, { x: -0.57163404, y: 0.11141949, z: -0.27899966 }, { x: -0.57163404, y: 0.11141949, z: -0.27899966 }, { x: -0.57163404, y: 0.11141949, z: -0.27899966 }, { x: -0.63015136, y: 0.02148181, z: -0.27899966 }, { x: -0.63015136, y: 0.02148181, z: -0.27899966 }, { x: -0.63015136, y: 0.02148181, z: -0.27899966 }], indices: [58, 74, 76, 58, 76, 59, 15, 18, 78, 15, 78, 75, 0, 1, 19, 0, 19, 16, 59, 76, 79, 59, 79, 60, 17, 20, 80, 17, 80, 77, 60, 79, 82, 60, 82, 61, 21, 24, 84, 21, 84, 81, 2, 3, 25, 2, 25, 22, 61, 82, 85, 61, 85, 62, 23, 27, 87, 23, 87, 83, 62, 85, 88, 62, 88, 63, 26, 29, 89, 26, 89, 86, 4, 5, 31, 4, 31, 28, 63, 88, 91, 63, 91, 64, 30, 33, 93, 30, 93, 90, 64, 91, 94, 64, 94, 65, 32, 36, 96, 32, 96, 92, 6, 7, 37, 6, 37, 34, 65, 94, 97, 65, 97, 66, 35, 38, 98, 35, 98, 95, 66, 97, 100, 66, 100, 67, 39, 42, 102, 39, 102, 99, 8, 9, 43, 8, 43, 40, 67, 100, 103, 67, 103, 68, 41, 45, 105, 41, 105, 101, 68, 103, 106, 68, 106, 69, 44, 47, 107, 44, 107, 104, 10, 11, 49, 10, 49, 46, 69, 106, 109, 69, 109, 70, 48, 50, 110, 48, 110, 108, 70, 109, 112, 70, 112, 71, 51, 54, 114, 51, 114, 111, 12, 13, 55, 12, 55, 52, 71, 112, 115, 71, 115, 72, 53, 57, 117, 53, 117, 113, 14, 73, 116, 14, 116, 56], material: { color: "#8b78af", roughness: 0.36000001, metalness: 0 } }, { vertices: [{ x: 0.37349992, y: 1e-7, z: 0.16200014 }, { x: 0.37554012, y: 0.11675623, z: 0.16200014 }, { x: 0.37554012, y: 0.11675623, z: 0.16200014 }, { x: 0.32246757, y: 0.16584431, z: 0.16200014 }, { x: 0.32246757, y: 0.16584431, z: 0.16200014 }, { x: 0.29910832, y: 0.21107643, z: 0.16200014 }, { x: 0.29910832, y: 0.21107643, z: 0.16200014 }, { x: 0.23505352, y: 0.2748628, z: 0.16200014 }, { x: 0.23505352, y: 0.2748628, z: 0.16200014 }, { x: 0.15609701, y: 0.34483369, z: 0.16200014 }, { x: 0.15609701, y: 0.34483369, z: 0.16200014 }, { x: 0.08640571, y: 0.40548809, z: 0.16200014 }, { x: 0.08640571, y: 0.40548809, z: 0.16200014 }, { x: -4e-8, y: 0.35596228, z: 0.16200014 }, { x: -4e-8, y: 0.35596228, z: 0.16200014 }, { x: -0.08159456, y: 0.32664531, z: 0.16200014 }, { x: -0.08159456, y: 0.32664531, z: 0.16200014 }, { x: -0.16859748, y: 0.35115555, z: 0.16200014 }, { x: -0.16859748, y: 0.35115555, z: 0.16200014 }, { x: -0.22459685, y: 0.31283966, z: 0.16200014 }, { x: -0.22459685, y: 0.31283966, z: 0.16200014 }, { x: -0.29405587, y: 0.24405001, z: 0.16200014 }, { x: -0.29405587, y: 0.24405001, z: 0.16200014 }, { x: -0.34533649, y: 0.13834694, z: 0.16200014 }, { x: -0.34533649, y: 0.13834694, z: 0.16200014 }, { x: -0.34886488, y: 0.06057382, z: 0.16200014 }, { x: -0.34886488, y: 0.06057382, z: 0.16200014 }, { x: -0.38457764, y: 0.02148181, z: 0.16200014 }, { x: 0.37349992, y: 1e-7, z: -0.27899966 }, { x: 0.37554012, y: 0.11675623, z: -0.27899966 }, { x: 0.37554012, y: 0.11675623, z: -0.27899966 }, { x: 0.32246757, y: 0.16584431, z: -0.27899966 }, { x: 0.32246757, y: 0.16584431, z: -0.27899966 }, { x: 0.29910832, y: 0.21107643, z: -0.27899966 }, { x: 0.29910832, y: 0.21107643, z: -0.27899966 }, { x: 0.23505352, y: 0.2748628, z: -0.27899966 }, { x: 0.23505352, y: 0.2748628, z: -0.27899966 }, { x: 0.15609701, y: 0.34483369, z: -0.27899966 }, { x: 0.15609701, y: 0.34483369, z: -0.27899966 }, { x: 0.08640571, y: 0.40548809, z: -0.27899966 }, { x: 0.08640571, y: 0.40548809, z: -0.27899966 }, { x: -4e-8, y: 0.35596228, z: -0.27899966 }, { x: -4e-8, y: 0.35596228, z: -0.27899966 }, { x: -0.08159456, y: 0.32664531, z: -0.27899966 }, { x: -0.08159456, y: 0.32664531, z: -0.27899966 }, { x: -0.16859748, y: 0.35115555, z: -0.27899966 }, { x: -0.16859748, y: 0.35115555, z: -0.27899966 }, { x: -0.22459685, y: 0.31283966, z: -0.27899966 }, { x: -0.22459685, y: 0.31283966, z: -0.27899966 }, { x: -0.29405587, y: 0.24405001, z: -0.27899966 }, { x: -0.29405587, y: 0.24405001, z: -0.27899966 }, { x: -0.34533649, y: 0.13834694, z: -0.27899966 }, { x: -0.34533649, y: 0.13834694, z: -0.27899966 }, { x: -0.34886488, y: 0.06057382, z: -0.27899966 }, { x: -0.34886488, y: 0.06057382, z: -0.27899966 }, { x: -0.38457764, y: 0.02148181, z: -0.27899966 }], indices: [0, 28, 30, 0, 30, 2, 1, 29, 31, 1, 31, 3, 4, 32, 34, 4, 34, 6, 5, 33, 36, 5, 36, 8, 7, 35, 38, 7, 38, 10, 9, 37, 39, 9, 39, 11, 12, 40, 42, 12, 42, 14, 13, 41, 44, 13, 44, 16, 15, 43, 45, 15, 45, 17, 18, 46, 47, 18, 47, 19, 20, 48, 49, 20, 49, 21, 22, 50, 51, 22, 51, 23, 24, 52, 54, 24, 54, 26, 25, 53, 55, 25, 55, 27], material: { color: "#6eabbf", roughness: 0.23999999, metalness: 0 } }, { vertices: [{ x: 0.37349992, y: 1e-7, z: 0.16200014 }, { x: 0.37349992, y: 1e-7, z: 0.16200014 }, { x: 0.37554012, y: 0.11675623, z: 0.16200014 }, { x: 0.32246757, y: 0.16584431, z: 0.16200014 }, { x: 0.29910832, y: 0.21107643, z: 0.16200014 }, { x: 0.23505352, y: 0.2748628, z: 0.16200014 }, { x: 0.15609701, y: 0.34483369, z: 0.16200014 }, { x: 0.08640571, y: 0.40548809, z: 0.16200014 }, { x: -4e-8, y: 0.35596228, z: 0.16200014 }, { x: -0.08159456, y: 0.32664531, z: 0.16200014 }, { x: -0.16859748, y: 0.35115555, z: 0.16200014 }, { x: -0.22459685, y: 0.31283966, z: 0.16200014 }, { x: -0.29405587, y: 0.24405001, z: 0.16200014 }, { x: -0.34533649, y: 0.13834694, z: 0.16200014 }, { x: -0.34886488, y: 0.06057382, z: 0.16200014 }, { x: 0.61200002, y: 1e-7, z: 0.16200014 }, { x: 0.61200002, y: 1e-7, z: 0.16200014 }, { x: 0.61534291, y: 0.1714896, z: 0.16200014 }, { x: 0.52838054, y: 0.26500686, z: 0.16200014 }, { x: 0.4901052, y: 0.36339136, z: 0.16200014 }, { x: 0.38514779, y: 0.46307512, z: 0.16200014 }, { x: 0.25577326, y: 0.55181397, z: 0.16200014 }, { x: 0.14158047, y: 0.64722443, z: 0.16200014 }, { x: -4e-8, y: 0.59063519, z: 0.16200014 }, { x: -0.13369722, y: 0.55492168, z: 0.16200014 }, { x: -0.2762562, y: 0.57471102, z: 0.16200014 }, { x: -0.36801403, y: 0.4926792, z: 0.16200014 }, { x: -0.48182649, y: 0.39379195, z: 0.16200014 }, { x: -0.56585259, y: 0.24454182, z: 0.16200014 }, { x: -0.57163404, y: 0.11141949, z: 0.16200014 }, { x: 0.37349992, y: 1e-7, z: -0.27899966 }, { x: 0.61200002, y: 1e-7, z: -0.27899966 }], indices: [0, 2, 17, 0, 17, 15, 3, 4, 19, 3, 19, 18, 5, 6, 21, 5, 21, 20, 7, 8, 23, 7, 23, 22, 9, 10, 25, 9, 25, 24, 11, 12, 27, 11, 27, 26, 13, 14, 29, 13, 29, 28, 1, 16, 31, 1, 31, 30], material: { color: "#b69abd", roughness: 0.5, metalness: 0 } }] } };

// src/domain/growingIsland/authoredWaterWorld.ts
var EPS3 = 1e-9;
var SURFACE_RISE = 0.025;
var DEPTH = 0.18;
var WATER_COLORS = ["#287ca6", "#287ca6", "#287ca6"];
var BED_COLORS = ["#667e96", "#727e9c", "#647f8d"];
var key4 = (cell) => `${cell.x},${cell.z}`;
var waterNeighbors2 = (base, cell) => base.neighbors(cell, "water").filter((next) => Number.isInteger(cell.x) && Number.isInteger(cell.z) && Number.isInteger(next.x) && Number.isInteger(next.z) && Math.abs(cell.x - next.x) + Math.abs(cell.z - next.z) === 1);
var round2 = (value) => Math.round(value * 1e9) / 1e9 || 0;
var horizontal = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
var cross4 = (a, b, p) => (b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x);
var area2 = (polygon) => polygon.reduce((sum, vertex, i) => {
  const next = polygon[(i + 1) % polygon.length];
  return sum + vertex.point.x * next.point.z - vertex.point.z * next.point.x;
}, 0) / 2;
var turn4 = (x, z, count2) => count2 === 1 ? { x: -z, z: x } : count2 === 2 ? { x: -x, z: -z } : count2 === 3 ? { x: z, z: -x } : { x, z };
var pointToLocal = (district, point) => {
  const p = turn4(point.x - district.worldOrigin.x, point.z - district.worldOrigin.z, (4 - district.turn) % 4);
  return { x: round2(p.x), y: round2(point.y - district.worldOrigin.y), z: round2(p.z) };
};
var pointToWorld = (district, point) => {
  const p = turn4(point.x, point.z, district.turn);
  return { x: p.x + district.worldOrigin.x, y: point.y + district.worldOrigin.y, z: p.z + district.worldOrigin.z };
};
var cellToWorld = (district, cell) => {
  const p = turn4(cell.x, cell.z, district.turn);
  return { x: p.x + district.logicalOrigin.x, z: p.z + district.logicalOrigin.z };
};
var floorId = (districtId, local) => JSON.stringify([districtId, local]);
var localId = (kind, id) => `authored-water:${kind}:${encodeURIComponent(id)}`;
var refKey3 = (ref) => JSON.stringify([ref.districtId, ref.siteId]);
function freeze2(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze2);
    Object.freeze(value);
  }
  return value;
}
function fingerprint(text2) {
  let a = 2166136261, b = 2246822507;
  for (let i = 0; i < text2.length; i++) {
    a = Math.imul(a ^ text2.charCodeAt(i), 16777619);
    b = Math.imul(b ^ text2.charCodeAt(i), 3266489909);
  }
  return `${(a >>> 0).toString(16).padStart(8, "0")}${(b >>> 0).toString(16).padStart(8, "0")}`;
}
function clean(polygon) {
  const out = polygon.filter((vertex, i) => horizontal(vertex.point, polygon[(i + polygon.length - 1) % polygon.length].point) > 1e-8);
  return out.length >= 3 && Math.abs(area2(out)) > 1e-10 ? out : [];
}
function interpolate2(a, b, t) {
  return {
    cell: { x: round2(a.cell.x + (b.cell.x - a.cell.x) * t), z: round2(a.cell.z + (b.cell.z - a.cell.z) * t) },
    point: {
      x: round2(a.point.x + (b.point.x - a.point.x) * t),
      y: round2(a.point.y + (b.point.y - a.point.y) * t),
      z: round2(a.point.z + (b.point.z - a.point.z) * t)
    },
    // Keep the linear source field through repeated cuts. Normalizing each
    // intermediate split would change later barycentric interpolation.
    ...a.normal && b.normal ? { normal: {
      x: a.normal.x + (b.normal.x - a.normal.x) * t,
      y: a.normal.y + (b.normal.y - a.normal.y) * t,
      z: a.normal.z + (b.normal.z - a.normal.z) * t
    } } : {}
  };
}
function halfPlane(polygon, a, b, inside) {
  const out = [];
  for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i], q = polygon[(i + 1) % polygon.length];
    const dp = cross4(a, b, p.point), dq = cross4(a, b, q.point);
    const keepP = inside ? dp >= -EPS3 : dp <= EPS3, keepQ = inside ? dq >= -EPS3 : dq <= EPS3;
    if (keepP) out.push(p);
    if (keepP !== keepQ && Math.abs(dp - dq) > EPS3) out.push(interpolate2(p, q, Math.max(0, Math.min(1, dp / (dp - dq)))));
  }
  return clean(out);
}
function subtract(polygon, outline) {
  const outside = [];
  let inside = [...polygon];
  for (let i = 0; i < outline.length && inside.length; i++) {
    const a = outline[i], b = outline[(i + 1) % outline.length];
    const piece = halfPlane(inside, a, b, false);
    if (piece.length) outside.push(piece);
    inside = halfPlane(inside, a, b, true);
  }
  return { outside, inside };
}
function append(floor, polygon, up = false) {
  if (!polygon.length) return;
  const offset = floor.vertices.length;
  floor.vertices.push(...polygon);
  const reverse = up && area2(polygon) > 0;
  for (let i = 1; i + 1 < polygon.length; i++) {
    const a = polygon[0].cell, b = polygon[i].cell, c = polygon[i + 1].cell;
    if (Math.abs((b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x)) <= 1e-12) continue;
    floor.indices.push(offset, offset + (reverse ? i + 1 : i), offset + (reverse ? i : i + 1));
  }
}
function protectedCells(state, excluded) {
  const half2 = AUTHORED_OWNER_HALF_EXTENT + AUTHORED_WALK_HALF_WIDTH;
  const out = HOUSE_CELLS.map((cell) => ({ cell, half: half2 }));
  for (const item of [...state.plots, ...state.landmarks, ...state.keepsakes]) {
    if (!item.cell || excluded.has(item.id)) continue;
    out.push({ cell: item.cell, half: half2 });
    if ("kind" in item && item.kind === "home") out.push({ cell: { x: item.cell.x, z: item.cell.z + 0.75 }, half: 0.18 });
  }
  return out;
}
function safeOutline(base, outline, protections2, districtId) {
  const candidates = districtId ? [districtId] : base.definition.districts.map((district) => district.id);
  return candidates.some((id) => isAuthoredWaterCarvingSafe(base, id, outline, protections2));
}
function poolFor(owner, index, bowls, base, protections2) {
  const site = base.sites.find((site2) => key4(site2.cell) === key4(owner.cell));
  const center = base.anchorAt(owner.cell) ?? base.floorAt(owner.cell)?.point;
  if (!site?.placement || !center) return;
  const source = nativeWaterSource_default.pools[index % nativeWaterSource_default.pools.length];
  const neighbors2 = bowls.filter((bowl) => bowl.id !== owner.id).map((bowl) => base.anchorAt(bowl.cell)).filter(Boolean).sort((a, b) => horizontal(center, a) - horizontal(center, b));
  const nearest = neighbors2[0], yaw = nearest ? Math.atan2(nearest.z - center.z, nearest.x - center.x) : 0;
  const requested = [source.radiusX, source.radiusZ, source.radiusX, source.radiusZ];
  const axes = requested.map((value) => Math.min(value, 0.24));
  const outerScale = nativeWaterSource_default.rim.rings[0].scale;
  const shape = () => adaptWaterContour(source.outline, center, axes[0], axes[1], yaw, axes[2], axes[3]);
  const valid = (outline2) => {
    const outer = scaledWaterOutline(outline2, center, outerScale);
    if (outer.some((p) => neighbors2.some((other) => {
      const d = horizontal(center, other), projection = ((p.x - center.x) * (other.x - center.x) + (p.z - center.z) * (other.z - center.z)) / d;
      return projection > d / 2 - 0.025;
    }))) return false;
    return safeOutline(base, outer, protections2, site.ref.districtId);
  };
  if (!valid(shape()) || !decomposeWaterOutline(shape()).length) return;
  for (const axis of [1, 3, 0, 2]) {
    while (axes[axis] + 0.02 <= requested[axis] + EPS3) {
      axes[axis] += 0.02;
      if (!valid(shape())) {
        axes[axis] -= 0.02;
        break;
      }
    }
  }
  const outline = shape(), waterY = round2(center.y + SURFACE_RISE), bedY = round2(waterY - DEPTH);
  return {
    ownerId: owner.id,
    ownerIds: [owner.id],
    districtId: site.ref.districtId,
    center: { ...center },
    radius: round2(Math.max(...axes)),
    axes: axes.map(round2),
    sourceRole: source.role,
    waterY,
    bedY,
    outline,
    outerOutline: scaledWaterOutline(outline, center, outerScale),
    waterFloorId: floorId(site.ref.districtId, localId("pool-water", owner.id)),
    bedFloorId: floorId(site.ref.districtId, localId("pool-bed", owner.id)),
    color: WATER_COLORS[index % 3],
    bedColor: BED_COLORS[index % 3]
  };
}
function poolMouthDistance(pool, dx, dz, width) {
  if (!pool) return 0;
  let distance3 = Infinity;
  for (const side of [-width, width]) {
    const origin = { x: pool.center.x + dz * side, y: pool.center.y, z: pool.center.z - dx * side };
    const exit = waterRayExit(origin, dx, dz, pool.outline);
    if (exit === void 0) return;
    distance3 = Math.min(distance3, exit);
  }
  return Number.isFinite(distance3) && distance3 > 0.025 ? distance3 - 0.025 : void 0;
}
function intersectionPoints(a, b) {
  return [
    ...a.filter((p) => pointInWaterOutline(p, b)),
    ...b.filter((p) => pointInWaterOutline(p, a)),
    ...a.flatMap((p, i) => waterSegmentIntervals(p, a[(i + 1) % a.length], b).flatMap((interval) => interval.map((t) => ({
      x: p.x + (a[(i + 1) % a.length].x - p.x) * t,
      y: p.y,
      z: p.z + (a[(i + 1) % a.length].z - p.z) * t
    }))))
  ];
}
function streamFor(a, b, pools, base, protections2, adjoining = []) {
  const a0 = base.anchorAt(a.cell), b0 = base.anchorAt(b.cell);
  if (!a0 || !b0) return;
  const length = horizontal(a0, b0);
  if (length <= 0.05) return;
  const dx = (b0.x - a0.x) / length, dz = (b0.z - a0.z) / length;
  const aPool = pools.find((pool) => pool.ownerId === a.id), bPool = pools.find((pool) => pool.ownerId === b.id);
  const width = 0.135, fromTrim = poolMouthDistance(aPool, dx, dz, width), toTrim = poolMouthDistance(bPool, -dx, -dz, width);
  if (fromTrim === void 0 || toTrim === void 0) return;
  const from = { x: a0.x + dx * fromTrim, y: a0.y + SURFACE_RISE, z: a0.z + dz * fromTrim };
  const to = { x: b0.x - dx * toTrim, y: b0.y + SURFACE_RISE, z: b0.z - dz * toTrim };
  if (horizontal(from, to) <= 0.05) return;
  const seed = Array.from({ length: 9 }, (_, i) => {
    const t = i / 8, bend = 0.035 * Math.sin(Math.PI * t);
    return {
      x: from.x + (to.x - from.x) * t + dz * bend,
      y: from.y,
      z: from.z + (to.z - from.z) * t - dx * bend
    };
  });
  const seedOutline = [
    ...seed.map((p) => ({ ...p, x: p.x + dz * width, z: p.z - dx * width })),
    ...[...seed].reverse().map((p) => ({ ...p, x: p.x - dz * width, z: p.z + dx * width }))
  ];
  const vx = to.x - from.x, vz = to.z - from.z, squared = vx * vx + vz * vz;
  const projection = (p) => ((p.x - from.x) * vx + (p.z - from.z) * vz) / squared;
  const id = JSON.stringify([a.id, b.id].sort());
  const junctionPoints = (ownerId) => adjoining.filter((other) => other.id !== id && other.ownerIds.includes(ownerId)).flatMap((other) => intersectionPoints(seedOutline, other.outline));
  const startPoints = [...aPool?.outline ?? [], ...junctionPoints(a.id)], endPoints = [...bPool?.outline ?? [], ...junctionPoints(b.id)];
  const dropStart = Math.max(0, Math.min(1, Math.max(0, ...startPoints.map(projection))));
  const dropEnd = Math.max(0, Math.min(1, Math.min(1, ...endPoints.map(projection))));
  if (dropEnd - dropStart < 1e-6 && Math.abs(from.y - to.y) > EPS3) return;
  const knots = [...new Set([...seed.map((_, i) => i / 8), dropStart, dropEnd].map(round2))].sort((a2, b2) => a2 - b2);
  const centerline = knots.map((t) => {
    const i = Math.min(7, Math.floor(t * 8)), u = t * 8 - i;
    const fall = dropEnd - dropStart > EPS3 ? smoothFall(Math.max(0, Math.min(1, (t - dropStart) / (dropEnd - dropStart)))) : 0;
    return {
      x: seed[i].x + (seed[i + 1].x - seed[i].x) * u,
      y: from.y + (to.y - from.y) * fall,
      z: seed[i].z + (seed[i + 1].z - seed[i].z) * u
    };
  });
  const left = centerline.map((p) => ({ ...p, x: p.x + dz * width, z: p.z - dx * width }));
  const right = centerline.map((p) => ({ ...p, x: p.x - dz * width, z: p.z + dx * width }));
  const outline = [...left, ...[...right].reverse()];
  const ownerDistricts = new Set([a, b].map((owner) => base.sites.find((site) => key4(site.cell) === key4(owner.cell))?.ref.districtId));
  if (ownerDistricts.size !== 1 || ownerDistricts.has(void 0)) return;
  const districtIds = base.definition.districts.filter((district) => ownerDistricts.has(district.id) && isAuthoredWaterCarvingSafe(base, district.id, outline, protections2)).map((district) => district.id);
  if (!districtIds.length) return;
  const stream = {
    id,
    ownerIds: [a.id, b.id],
    from,
    to,
    outline,
    centerline,
    width: width * 2,
    waterFloorIds: [],
    bedFloorIds: [],
    falling: Math.abs(from.y - to.y) > 0.06
  };
  const common = { districtIds, ownerIds: [...stream.ownerIds], color: "#50b5ca", bedColor: "#667e96", stream };
  return centerline.slice(1).map((end, i) => ({
    ...common,
    id: `stream:${id}:${i}`,
    outline: [left[i], left[i + 1], right[i + 1], right[i]],
    heightAt: (point) => {
      const t = Math.max(0, Math.min(1, (projection(point) - knots[i]) / (knots[i + 1] - knots[i])));
      return round2(centerline[i].y + (end.y - centerline[i].y) * t);
    }
  }));
}
var smoothFall = (t) => t * t * (3 - 2 * t);
function bounds(outline) {
  return {
    minX: Math.min(...outline.map((p) => p.x)),
    maxX: Math.max(...outline.map((p) => p.x)),
    minZ: Math.min(...outline.map((p) => p.z)),
    maxZ: Math.max(...outline.map((p) => p.z))
  };
}
var overlaps2 = (a, b) => a.minX <= b.maxX + EPS3 && a.maxX + EPS3 >= b.minX && a.minZ <= b.maxZ + EPS3 && a.maxZ + EPS3 >= b.minZ;
function floorIntersectsOutline(floor, district, outline) {
  const box = bounds(outline), pieces = decomposeWaterOutline(outline), vertices = floor.vertices.map((vertex) => ({ ...vertex, point: pointToWorld(district, vertex.point) }));
  for (let i = 0; i < floor.indices.length; i += 3) {
    const triangle = floor.indices.slice(i, i + 3).map((index) => vertices[index]);
    if (overlaps2(bounds(triangle.map((vertex) => vertex.point)), box) && pieces.some((piece) => subtract(triangle, piece).inside.length)) return true;
  }
  return false;
}
function bankIntervals(a, b, outlines) {
  let intervals = [[0, 1]];
  for (const outline of outlines) for (const [min, max] of waterSegmentIntervals(a, b, outline)) {
    intervals = intervals.flatMap(([lo, hi]) => max <= lo || min >= hi ? [[lo, hi]] : [...lo < min ? [[lo, min]] : [], ...max < hi ? [[max, hi]] : []]);
  }
  return intervals;
}
function bankFor(cut, district, base, others) {
  if (cut.pool) {
    const surfaces = buildWaterRim({
      id: localId("bank", cut.id),
      outline: cut.pool.outline,
      center: cut.pool.center,
      waterY: cut.pool.waterY,
      rings: nativeWaterSource_default.rim.rings,
      groundAt: (p) => {
        const cell = base.logicalAt(p);
        return cell ? base.floorAt(cell)?.point.y : void 0;
      },
      mouths: others.filter((other) => other !== cut).map((other) => other.outline),
      body: nativeWaterSource_default.rim.body,
      lip: nativeWaterSource_default.rim.lip
    });
    return (surfaces ?? []).map((surface) => ({ ...surface, vertices: surface.vertices.map((p) => pointToLocal(district, p)) }));
  }
  const vertices = [], indices = [];
  for (let i = 0; i < cut.outline.length; i++) {
    const a0 = cut.outline[i], b0 = cut.outline[(i + 1) % cut.outline.length];
    const top = (p) => {
      const cell = base.logicalAt(p), y = cell ? base.floorAt(cell)?.point.y : void 0;
      return pointToLocal(district, { ...p, y: Math.max(y ?? cut.heightAt(p), cut.heightAt(p) + 0.035) });
    };
    for (const [from, to] of bankIntervals(a0, b0, others.filter((other) => other !== cut).map((other) => other.outline))) {
      const at = (t) => ({ x: a0.x + (b0.x - a0.x) * t, y: a0.y + (b0.y - a0.y) * t, z: a0.z + (b0.z - a0.z) * t });
      const a = at(from), b = at(to), offset = vertices.length;
      if (horizontal(a, b) <= 1e-9) continue;
      vertices.push(top(a), top(b), pointToLocal(district, { ...b, y: cut.heightAt(b) - DEPTH }), pointToLocal(district, { ...a, y: cut.heightAt(a) - DEPTH }));
      indices.push(offset, offset + 1, offset + 2, offset, offset + 2, offset + 3);
    }
  }
  if (!indices.length) return [];
  return [{ id: localId("bank", cut.id), kind: "bank", vertices, indices, material: { color: nativeWaterSource_default.rim.body.color, roughness: 0.56, metalness: 0 } }];
}
function flowFor(cut, district) {
  if (!cut.stream?.falling) return;
  const stream = cut.stream, length = horizontal(stream.from, stream.to), dx = (stream.to.x - stream.from.x) / length, dz = (stream.to.z - stream.from.z) / length, width = stream.width / 2;
  const vertices = stream.centerline.flatMap((p) => [
    { x: p.x + dz * width, y: p.y + 2e-3, z: p.z - dx * width },
    { x: p.x - dz * width, y: p.y + 2e-3, z: p.z + dx * width }
  ].map((p2) => pointToLocal(district, p2)));
  const indices = stream.centerline.slice(1).flatMap((_, i) => [i * 2, i * 2 + 2, i * 2 + 3, i * 2, i * 2 + 3, i * 2 + 1]);
  return {
    id: localId("flow", stream.id),
    kind: "flow",
    vertices,
    indices,
    material: { color: "#50b5ca", roughness: 0.16, metalness: 0, opacity: 0.82 }
  };
}
function grottoFor(pool, streams, base, protections2) {
  const link = streams.find((stream) => stream.ownerIds.includes(pool.ownerId));
  if (!link) return;
  const target2 = horizontal(link.from, pool.center) < horizontal(link.to, pool.center) ? link.to : link.from;
  const length = horizontal(target2, pool.center), dx = (target2.x - pool.center.x) / length, dz = (target2.z - pool.center.z) / length;
  const yaw = Math.atan2(-dx, dz), sourceVertices = nativeWaterSource_default.grotto.primitives.flatMap((part) => part.vertices);
  for (const scale of [1, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7, 0.65, 0.6]) {
    const pivot = { x: pool.center.x - dx * 0.07, y: pool.bedY - 0.025, z: pool.center.z - dz * 0.07 };
    const transform = (p) => ({
      x: pivot.x + scale * (p.x * Math.cos(yaw) - p.z * Math.sin(yaw)),
      y: pivot.y + p.y * scale,
      z: pivot.z + scale * (p.x * Math.sin(yaw) + p.z * Math.cos(yaw))
    });
    const vertices = sourceVertices.map(transform), box = bounds(vertices);
    const footprint = [
      { x: box.minX, y: pivot.y, z: box.minZ },
      { x: box.maxX, y: pivot.y, z: box.minZ },
      { x: box.maxX, y: pivot.y, z: box.maxZ },
      { x: box.minX, y: pivot.y, z: box.maxZ }
    ];
    if (!safeOutline(base, footprint, protections2, pool.districtId) || sourceVertices.filter((p) => p.y < 0.035).some((p) => !pointInWaterOutline(transform(p), pool.outline))) continue;
    const surfaces = nativeWaterSource_default.grotto.primitives.map((part, i) => ({
      id: localId("grotto", `${pool.ownerId}:${i}`),
      kind: "bank",
      vertices: part.vertices.map(transform),
      indices: part.indices,
      material: part.material
    }));
    return { plan: {
      ownerId: pool.ownerId,
      pivot,
      yaw,
      scale,
      footprint,
      surfaceIds: surfaces.map((surface) => floorId(pool.districtId, surface.id))
    }, surfaces };
  }
}
function composeAuthoredWaterWorld(state, base) {
  const supplied = connectedWaterChannels(waterLayout(state, base));
  const owners = state.landmarks.filter((owner) => !!owner.cell && base.owns(owner.cell) && (owner.kind === "water-bowl" || owner.kind === "water-channel" && supplied.has(key4(owner.cell)))).sort((a, b) => a.id.localeCompare(b.id));
  const byCell = new Map(owners.map((owner) => [key4(owner.cell), owner]));
  const groups = [], pools = [], cuts = [], streams = [];
  const seen = /* @__PURE__ */ new Set();
  for (const owner of owners) {
    if (seen.has(owner.id)) continue;
    const members = [owner];
    seen.add(owner.id);
    for (let i = 0; i < members.length; i++) for (const cell of waterNeighbors2(base, members[i].cell)) {
      const other = byCell.get(key4(cell));
      if (!other || seen.has(other.id)) continue;
      seen.add(other.id);
      members.push(other);
    }
    members.sort((a, b) => a.id.localeCompare(b.id));
    const bowls = members.filter((member) => member.kind === "water-bowl").sort((a, b) => (base.anchorAt(b.cell)?.y ?? 0) - (base.anchorAt(a.cell)?.y ?? 0) || a.id.localeCompare(b.id)), channels = members.filter((member) => member.kind === "water-channel");
    const group = {
      id: `water-group:${JSON.stringify(members.map((member) => member.id))}`,
      ownerIds: members.map((member) => member.id),
      bowlIds: bowls.map((bowl) => bowl.id),
      channelIds: channels.map((channel) => channel.id),
      cut: false,
      reason: "individual-bodies"
    };
    groups.push(group);
    if (bowls.length < 3 || channels.length < 2) continue;
    const protections2 = protectedCells(state, new Set(group.ownerIds));
    const nextPools = bowls.map((bowl, i) => poolFor(bowl, i, bowls, base, protections2));
    if (nextPools.some((pool) => !pool)) {
      group.reason = "insufficient-clearance";
      continue;
    }
    const edgeIds = /* @__PURE__ */ new Set(), links = [];
    for (const member of members) for (const cell of waterNeighbors2(base, member.cell)) {
      const other = byCell.get(key4(cell));
      if (!other || !group.ownerIds.includes(other.id)) continue;
      const id = JSON.stringify([member.id, other.id].sort());
      if (edgeIds.has(id)) continue;
      edgeIds.add(id);
      links.push([member, other]);
    }
    const initialStreams = links.map(([a, b]) => streamFor(a, b, nextPools, base, protections2));
    const adjoining = initialStreams.filter((cut) => !!cut).map((cut) => cut[0].stream);
    const nextStreams = initialStreams.some((stream) => !stream) ? initialStreams : links.map(([a, b]) => streamFor(a, b, nextPools, base, protections2, adjoining));
    if (nextStreams.some((stream) => !stream)) {
      group.reason = "insufficient-clearance";
      continue;
    }
    group.cut = true;
    delete group.reason;
    for (const pool of nextPools) {
      pools.push(pool);
      cuts.push({
        id: `pool:${pool.ownerId}`,
        outline: pool.outline,
        outerOutline: pool.outerOutline,
        districtIds: [pool.districtId],
        color: pool.color,
        bedColor: pool.bedColor,
        ownerIds: [pool.ownerId],
        heightAt: () => pool.waterY,
        pool
      });
    }
    for (const nextCuts of nextStreams) {
      cuts.push(...nextCuts);
      streams.push(nextCuts[0].stream);
    }
  }
  const grottoCandidates = groups.filter((group) => group.cut).flatMap((group) => {
    const upper = pools.find((pool) => group.bowlIds.includes(pool.ownerId));
    const result = upper && grottoFor(upper, streams, base, protectedCells(state, new Set(group.ownerIds)));
    return result ? [{ districtId: upper.districtId, ...result }] : [];
  });
  const revision = `authored-water-v2:${fingerprint(JSON.stringify({
    base: [base.id, base.definition.revision, base.definition.source],
    profile: nativeWaterSource_default,
    scopes: base.definition.districts.map((district) => [district.id, district.waterCarvingScopes]),
    water: owners.map((owner) => [owner.id, owner.kind, owner.cell, owner.growth]),
    obstacles: protectedCells(state, /* @__PURE__ */ new Set()).map((p) => [p.cell, p.half]),
    pools: pools.map((pool) => [pool.ownerId, pool.axes, pool.outline, pool.outerOutline]),
    streams: streams.map((stream) => [stream.id, stream.outline, stream.centerline]),
    grottos: grottoCandidates.map((grotto) => grotto.plan)
  }))}`;
  const plan = { revision, ownerIds: [...new Set(cuts.flatMap((cut) => cut.ownerIds))], groups, pools, streams, grottos: grottoCandidates.map((grotto) => grotto.plan), bridges: [] };
  const actualCuts = [];
  let definition = structuredClone(base.definition);
  definition.revision = revision;
  definition.districts = definition.districts.map((district) => {
    const worldCuts = cuts.filter((cut) => cut.districtIds.includes(district.id));
    const localCuts = worldCuts.map((cut) => {
      const outline = cut.outline.map((p) => pointToLocal(district, p)), outerOutline = (cut.outerOutline ?? cut.outline).map((p) => pointToLocal(district, p));
      return { cut, pieces: decomposeWaterOutline(outline), outerPieces: decomposeWaterOutline(outerOutline), box: bounds(outerOutline) };
    });
    const additions = /* @__PURE__ */ new Map();
    const floors = district.floors.flatMap((floor) => {
      const allowedFloors = authoredWaterCarvingFloorIds(base, district.id);
      if (floor.kind !== "ground" || !localCuts.length || allowedFloors && !allowedFloors.includes(floorId(district.id, floor.id))) return [floor];
      const vertices = [...floor.vertices], indices = [];
      for (let i = 0; i < floor.indices.length; i += 3) {
        const sourceIndices = floor.indices.slice(i, i + 3), triangle = sourceIndices.map((index) => floor.vertices[index]);
        const box = bounds(triangle.map((v) => v.point)), applicable = localCuts.filter((cut) => overlaps2(box, cut.box));
        if (!applicable.length) {
          indices.push(...sourceIndices);
          continue;
        }
        let remaining = [triangle], changed = false;
        for (const { outerPieces } of applicable) for (const outline of outerPieces) {
          const next = [];
          for (const polygon of remaining) {
            const pieces = subtract(polygon, outline);
            changed ||= !!pieces.inside.length;
            next.push(...pieces.inside.length ? pieces.outside : [polygon]);
          }
          remaining = next;
        }
        if (!changed) indices.push(...sourceIndices);
        else for (const polygon of remaining) append({ vertices, indices }, polygon);
        let wetRemaining = [triangle];
        for (const { cut, pieces: wetPieces } of applicable) for (const outline of wetPieces) {
          const next = [];
          for (const polygon of wetRemaining) {
            const pieces = subtract(polygon, outline);
            if (!pieces.inside.length) {
              next.push(polygon);
              continue;
            }
            next.push(...pieces.outside);
            let addition = additions.get(cut);
            if (!addition) {
              const waterLocalId = cut.pool ? localId("pool-water", cut.pool.ownerId) : localId("stream-water", cut.id);
              const bedLocalId = cut.pool ? localId("pool-bed", cut.pool.ownerId) : localId("stream-bed", cut.id);
              addition = {
                water: { id: waterLocalId, kind: "water", color: cut.color, vertices: [], indices: [] },
                bed: { id: bedLocalId, kind: "ground", color: cut.bedColor, vertices: [], indices: [] }
              };
              additions.set(cut, addition);
            }
            const wet = pieces.inside.map((vertex) => ({ cell: { ...vertex.cell }, point: {
              ...vertex.point,
              y: round2(cut.heightAt(pointToWorld(district, vertex.point)) - district.worldOrigin.y)
            } }));
            append(addition.water, wet, true);
            append(addition.bed, wet.map((vertex) => ({ cell: { ...vertex.cell }, point: { ...vertex.point, y: round2(vertex.point.y - DEPTH) } })), true);
          }
          wetRemaining = next;
        }
      }
      return indices.length ? [{ ...floor, vertices, indices }] : [];
    });
    const surfaces = [...district.surfaces ?? [], ...grottoCandidates.filter((grotto) => grotto.districtId === district.id).flatMap((grotto) => grotto.surfaces.map((surface) => ({ ...surface, vertices: surface.vertices.map((p) => pointToLocal(district, p)) })))];
    for (const [cut, addition] of additions) {
      if (!addition.water.indices.length || !addition.bed.indices.length) continue;
      floors.push(addition.water, addition.bed);
      actualCuts.push({ cut, district, ...addition });
      if (cut.stream) {
        cut.stream.waterFloorIds.push(floorId(district.id, addition.water.id));
        cut.stream.bedFloorIds.push(floorId(district.id, addition.bed.id));
      }
      surfaces.push(...bankFor(cut, district, base, worldCuts));
      const flow = flowFor(cut, district);
      if (flow && !surfaces.some((surface) => surface.id === flow.id)) surfaces.push(flow);
    }
    return {
      ...district,
      floors,
      surfaces,
      anchorFloors: district.anchorFloors ?? district.floors,
      sites: district.sites.map((site) => ({ ...site, anchorPoint: pointToLocal(district, base.anchorAt(cellToWorld(district, site.cell))) }))
    };
  });
  for (const stream of streams) {
    const group = groups.find((group2) => group2.cut && stream.ownerIds.every((id) => group2.ownerIds.includes(id)));
    const waterIds = new Set(stream.waterFloorIds), bedIds = new Set(stream.bedFloorIds);
    for (const actual of actualCuts) {
      if (!actual.cut.ownerIds.every((id) => group.ownerIds.includes(id)) || !floorIntersectsOutline(actual.water, actual.district, stream.outline)) continue;
      waterIds.add(floorId(actual.district.id, actual.water.id));
      bedIds.add(floorId(actual.district.id, actual.bed.id));
    }
    stream.waterFloorIds = [...waterIds];
    stream.bedFloorIds = [...bedIds];
  }
  const sourceEdges = definition.edges;
  definition.edges = sourceEdges.map((edge) => ({ ...edge, allows: edge.allows.filter((kind) => kind !== "walk") })).filter((edge) => edge.allows.length);
  const cutWorld = compileWorldDefinition(definition), bridgeComposition = composeAuthoredWaterBridges(state, base, cutWorld, plan);
  definition = bridgeComposition.definition;
  plan.bridges = bridgeComposition.bridges;
  const supportWorld = bridgeComposition.supportWorld, refs = new Map(supportWorld.sites.map((site) => [refKey3(site.ref), site.cell]));
  definition.edges = sourceEdges.map((edge) => ({ ...edge, allows: edge.allows.filter((kind) => kind !== "walk" || isWorldWalkEdgeSupported(supportWorld, refs.get(refKey3(edge.from)), refs.get(refKey3(edge.to)))) })).filter((edge) => edge.allows.length);
  const dryWorld = compileWorldDefinition(definition);
  definition.districts = definition.districts.map((district) => ({ ...district, shoreAccess: owners.filter((owner) => plan.ownerIds.includes(owner.id)).map((owner) => {
    const site = dryWorld.sites.find((site2) => site2.ref.districtId === district.id && key4(site2.cell) === key4(owner.cell));
    if (!site) return void 0;
    const waterFloorIds = [.../* @__PURE__ */ new Set([
      ...pools.filter((pool) => pool.ownerIds.includes(owner.id)).map((pool) => pool.waterFloorId),
      ...streams.filter((stream) => stream.ownerIds.includes(owner.id)).flatMap((stream) => stream.waterFloorIds)
    ])];
    return { ownerSiteId: site.ref.siteId, waterFloorIds: waterFloorIds.filter((id) => JSON.parse(id)[0] === district.id).map((id) => JSON.parse(id)[1]), entrySiteIds: findAuthoredShoreEntries(dryWorld, waterFloorIds).filter((ref) => ref.districtId === district.id).map((ref) => ref.siteId) };
  }).filter((access) => !!access) }));
  const finalRevision = `${revision}:${fingerprint(JSON.stringify({ bridgeProfile: nativeWaterBridgeProfile_default, bridges: plan.bridges, shore: definition.districts.map((district) => [district.id, district.shoreAccess]) }))}`;
  definition.revision = finalRevision;
  plan.revision = finalRevision;
  return { world: compileWorldDefinition(definition), plan: freeze2(plan) };
}

// src/domain/growingIsland/authoredWaterFrame.ts
var frames = /* @__PURE__ */ new WeakMap();
function authoredWaterFrame(state, base) {
  const key6 = JSON.stringify([state.plots, state.landmarks, state.keepsakes]);
  let cache = frames.get(base);
  if (!cache) {
    cache = /* @__PURE__ */ new Map();
    frames.set(base, cache);
  }
  const existing = cache.get(key6);
  if (existing) return existing;
  cache.clear();
  const frame = composeAuthoredWaterWorld(state, base);
  cache.set(key6, frame);
  return frame;
}

// docs/design/2026-10-12-authored-cove-entrance/source-manifest.json
var source_manifest_default = {
  candidate: "native05-authored-cove-corner-v3",
  scope: "editable source only; not app acceptance",
  original_hashes: {
    "whole-island.blend": "d1c7bb078b8f4fafad97862fcd1d691e63cfbcce9c378f21da47ccd167139c2a",
    "whole-island.glb": "8398eda9ac084a6e80ed22f1a82670c380b017544a177106325aaa7ba7f8f68d",
    "whole-island-render.png": "9de26a7f8a83176df37a7848cae4beea7962eb782247d07cf7e3b970a856f9c6",
    "varied-world.py": "9090dbd0923437d449309bc95ffb27a00ec673e3252ca9f98849e8ce53611c22",
    "build-final-scene.py": "007cb5dbaee09aa8f235641409729a71409910c9f24c03f139258af47b135234"
  },
  original_inputs_unchanged: true,
  source_transform: {
    pivot_gltf: [
      13.9,
      0.89,
      1.2
    ],
    position: [
      8,
      0.0475,
      0.5
    ],
    uniform_scale: 0.45,
    yaw: 0
  },
  opening: {
    cut_width: 0.7,
    cut_spring_world_y: 0.455666217,
    cut_apex_world_y: 0.805666217,
    center_world_z: -0.25,
    front_world_z: 0.09999999999999998,
    rim_world_radius: 0.026,
    requested_initial_clear: [
      0.64,
      0.72
    ]
  },
  construction: {
    shell_thickness_source: 0.043,
    boolean: "EXACT solid difference; manifold closed reveal",
    continuous_frame_points: 65,
    curves_editable_in_blend: true,
    original_skin_materials_preserved: true
  },
  geometry_qa: [
    {
      name: "Harbor / continuous entrance runner jamb rear arch",
      vertices: 7710,
      polygons: 7696,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / corner structural rib joined to rim",
      vertices: 3630,
      polygons: 3616,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / longitudinal seam joined to corner rim 5",
      vertices: 2190,
      polygons: 2176,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / longitudinal seam joined to corner rim 6",
      vertices: 2190,
      polygons: 2176,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / continuous grounded runner socket left",
      vertices: 196,
      polygons: 194,
      boundary_edges: 0,
      nonmanifold_edges: 0,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / continuous grounded runner socket right",
      vertices: 196,
      polygons: 194,
      boundary_edges: 0,
      nonmanifold_edges: 0,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / continuous translucent shell hall",
      vertices: 4146,
      polygons: 4077,
      boundary_edges: 0,
      nonmanifold_edges: 0,
      materials: [
        "harbor / translucent pearl shell",
        "harbor / translucent violet shell panels"
      ]
    },
    {
      name: "Harbor / curved shell structural rib",
      vertices: 2910,
      polygons: 2896,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / curved shell structural rib.001",
      vertices: 2910,
      polygons: 2896,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / curved shell structural rib.002",
      vertices: 2910,
      polygons: 2896,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / curved shell structural rib.003",
      vertices: 2910,
      polygons: 2896,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / curved shell structural rib.004",
      vertices: 2910,
      polygons: 2896,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / coral shell ribs"
      ]
    },
    {
      name: "Harbor / shell longitudinal seam",
      vertices: 990,
      polygons: 976,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / shell longitudinal seam.001",
      vertices: 990,
      polygons: 976,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / shell longitudinal seam.002",
      vertices: 990,
      polygons: 976,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / shell longitudinal seam.003",
      vertices: 990,
      polygons: 976,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / shell longitudinal seam.004",
      vertices: 990,
      polygons: 976,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    },
    {
      name: "Harbor / shell grown footing.001",
      vertices: 270,
      polygons: 256,
      boundary_edges: 40,
      nonmanifold_edges: 40,
      materials: [
        "harbor / blue porcelain shell footing"
      ]
    }
  ],
  ground_sockets: [
    {
      name: "Harbor / continuous grounded runner socket left",
      bottom_vertices_world: [
        [
          6.876492023468018,
          -0.014999990351498127,
          1.2026574611663818
        ],
        [
          7.017508029937744,
          -0.014999990351498127,
          1.2193424701690674
        ],
        [
          6.880510330200195,
          -0.014999990351498127,
          1.1686939001083374
        ],
        [
          7.021556854248047,
          -0.014999990351498127,
          1.1851247549057007
        ],
        [
          6.8842573165893555,
          -0.014999990351498127,
          1.135998249053955
        ],
        [
          7.025361061096191,
          -0.014999990351498127,
          1.1519298553466797
        ],
        [
          6.8877787590026855,
          -0.014999990351498127,
          1.1043213605880737
        ],
        [
          7.028932094573975,
          -0.014999990351498127,
          1.1198004484176636
        ],
        [
          6.8911051750183105,
          -0.014999990351498127,
          1.0735548734664917
        ],
        [
          7.032301425933838,
          -0.014999990351498127,
          1.0886386632919312
        ],
        [
          6.894266128540039,
          -0.014999990351498127,
          1.0435928106307983
        ],
        [
          7.035497665405273,
          -0.014999990351498127,
          1.058343768119812
        ],
        [
          6.89729118347168,
          -0.014999990351498127,
          1.0143266916275024
        ],
        [
          7.038549423217773,
          -0.014999990351498127,
          1.0288177728652954
        ],
        [
          6.900210380554199,
          -0.014999990351498127,
          0.9856478571891785
        ],
        [
          7.041486740112305,
          -0.014999990351498127,
          0.9999629855155945
        ],
        [
          6.903054237365723,
          -0.014999990351498127,
          0.9574506282806396
        ],
        [
          7.044339179992676,
          -0.014999990351498127,
          0.9716783761978149
        ],
        [
          6.905851364135742,
          -0.014999990351498127,
          0.9296296238899231
        ],
        [
          7.047136306762695,
          -0.014999990351498127,
          0.9438630938529968
        ],
        [
          6.908632278442383,
          -0.014999990351498127,
          0.9020785093307495
        ],
        [
          7.0499067306518555,
          -0.014999990351498127,
          0.9164168834686279
        ],
        [
          6.911427021026611,
          -0.014999990351498127,
          0.8746926188468933
        ],
        [
          7.052680492401123,
          -0.014999990351498127,
          0.8892380595207214
        ],
        [
          6.914266109466553,
          -0.014999990351498127,
          0.8473709225654602
        ],
        [
          7.055487155914307,
          -0.014999990351498127,
          0.8622211813926697
        ],
        [
          6.917177200317383,
          -0.014999990351498127,
          0.8200116157531738
        ],
        [
          7.058356285095215,
          -0.014999990351498127,
          0.835261344909668
        ],
        [
          6.920191764831543,
          -0.014999990351498127,
          0.792512834072113
        ],
        [
          7.06131649017334,
          -0.014999990351498127,
          0.808254063129425
        ],
        [
          6.923338890075684,
          -0.014999990351498127,
          0.7647750377655029
        ],
        [
          7.064397811889648,
          -0.014999990351498127,
          0.7810924053192139
        ],
        [
          6.926648139953613,
          -0.014999990351498127,
          0.7367000579833984
        ],
        [
          7.067630767822266,
          -0.014999990351498127,
          0.7536680698394775
        ],
        [
          6.930149078369141,
          -0.014999990351498127,
          0.7081892490386963
        ],
        [
          7.071043968200684,
          -0.014999990351498127,
          0.7258732318878174
        ],
        [
          6.933872222900391,
          -0.014999990351498127,
          0.6791460514068604
        ],
        [
          7.074667930603027,
          -0.014999990351498127,
          0.697597861289978
        ],
        [
          6.937844276428223,
          -0.014999990351498127,
          0.6494722962379456
        ],
        [
          7.0785322189331055,
          -0.014999990351498127,
          0.6687336564064026
        ],
        [
          6.942097187042236,
          -0.014999990351498127,
          0.619069516658783
        ],
        [
          7.082666873931885,
          -0.014999990351498127,
          0.6391727328300476
        ],
        [
          6.946658611297607,
          -0.014999990351498127,
          0.5878416299819946
        ],
        [
          7.08710241317749,
          -0.014999990351498127,
          0.6088047027587891
        ],
        [
          6.951557636260986,
          -0.014999990351498127,
          0.555689811706543
        ],
        [
          7.091868877410889,
          -0.014999990351498127,
          0.577521800994873
        ],
        [
          6.956822872161865,
          -0.014999990351498127,
          0.522515594959259
        ],
        [
          7.096996784210205,
          -0.014999990351498127,
          0.5452161431312561
        ],
        [
          6.96246337890625,
          -0.014999990351498127,
          0.4883430302143097
        ],
        [
          7.102536201477051,
          -0.014999990351498127,
          0.5116569399833679
        ],
        [
          6.965802192687988,
          -0.014999990351498127,
          0.46856606006622314
        ],
        [
          7.105804443359375,
          -0.014999990351498127,
          0.49229925870895386
        ],
        [
          6.969106674194336,
          -0.014999990351498127,
          0.44915205240249634
        ],
        [
          7.109072685241699,
          -0.014999990351498127,
          0.47310006618499756
        ],
        [
          6.972404956817627,
          -0.014999990351498127,
          0.42997416853904724
        ],
        [
          7.112326145172119,
          -0.014999990351498127,
          0.45418408513069153
        ],
        [
          6.97570276260376,
          -0.014999990351498127,
          0.4110293984413147
        ],
        [
          7.115569591522217,
          -0.014999990351498127,
          0.43555182218551636
        ],
        [
          6.979007720947266,
          -0.014999990351498127,
          0.39231571555137634
        ],
        [
          7.118809700012207,
          -0.014999990351498127,
          0.4172030985355377
        ],
        [
          6.982324600219727,
          -0.014999990351498127,
          0.3738335371017456
        ],
        [
          7.122052192687988,
          -0.014999990351498127,
          0.3991350531578064
        ],
        [
          6.985660076141357,
          -0.014999990351498127,
          0.3555772602558136
        ],
        [
          7.125301837921143,
          -0.014999990351498127,
          0.3813510239124298
        ],
        [
          6.9890217781066895,
          -0.014999990351498127,
          0.3375474214553833
        ],
        [
          7.128565311431885,
          -0.014999990351498127,
          0.36384814977645874
        ],
        [
          6.992414474487305,
          -0.014999990351498127,
          0.3197419047355652
        ],
        [
          7.1318464279174805,
          -0.014999990351498127,
          0.3466262221336365
        ],
        [
          6.995846271514893,
          -0.014999990351498127,
          0.30215567350387573
        ],
        [
          7.135151386260986,
          -0.014999990351498127,
          0.3296878933906555
        ],
        [
          6.999322891235352,
          -0.014999990351498127,
          0.2847893238067627
        ],
        [
          7.138485908508301,
          -0.014999990351498127,
          0.31303030252456665
        ],
        [
          7.0028510093688965,
          -0.014999990351498127,
          0.26763975620269775
        ],
        [
          7.141854763031006,
          -0.014999990351498127,
          0.29665422439575195
        ],
        [
          7.006437301635742,
          -0.014999990351498127,
          0.25070470571517944
        ],
        [
          7.145263671875,
          -0.014999990351498127,
          0.2805594801902771
        ],
        [
          7.01008939743042,
          -0.014999990351498127,
          0.2339809387922287
        ],
        [
          7.148716449737549,
          -0.014999990351498127,
          0.2647470235824585
        ],
        [
          7.0138139724731445,
          -0.014999990351498127,
          0.21746721863746643
        ],
        [
          7.152219772338867,
          -0.014999990351498127,
          0.24921578168869019
        ],
        [
          7.017618179321289,
          -0.014999990351498127,
          0.20116136968135834
        ],
        [
          7.1557769775390625,
          -0.014999990351498127,
          0.23396562039852142
        ],
        [
          7.021509170532227,
          -0.014999990351498127,
          0.18506117165088654
        ],
        [
          7.159394264221191,
          -0.014999990351498127,
          0.21899639070034027
        ],
        [
          7.025493144989014,
          -0.014999990351498127,
          0.1691654771566391
        ],
        [
          7.163075923919678,
          -0.014999990351498127,
          0.20430691540241241
        ],
        [
          7.02957820892334,
          -0.014999990351498127,
          0.1534712016582489
        ],
        [
          7.166826248168945,
          -0.014999990351498127,
          0.18989795446395874
        ],
        [
          7.033771514892578,
          -0.014999990351498127,
          0.13797627389431
        ],
        [
          7.170649528503418,
          -0.014999990351498127,
          0.17576922476291656
        ],
        [
          7.038081169128418,
          -0.014999990351498127,
          0.12267662584781647
        ],
        [
          7.1745500564575195,
          -0.014999990351498127,
          0.16192246973514557
        ],
        [
          7.042515277862549,
          -0.014999990351498127,
          0.10757347196340561
        ],
        [
          7.17853307723999,
          -0.014999990351498127,
          0.14835414290428162
        ],
        [
          7.047079563140869,
          -0.014999990351498127,
          0.09266509115695953
        ],
        [
          7.182602405548096,
          -0.014999990351498127,
          0.13506367802619934
        ],
        [
          7.0516438484191895,
          -0.014999990351498127,
          0.07838248461484909
        ],
        [
          7.186901569366455,
          -0.014999990351498127,
          0.12161765247583389
        ]
      ],
      buried_depth: 6e-3,
      cross_sections: 49
    },
    {
      name: "Harbor / continuous grounded runner socket right",
      bottom_vertices_world: [
        [
          8.98249626159668,
          -0.014999990351498127,
          1.2193865776062012
        ],
        [
          9.082789421081543,
          -0.014999990351498127,
          1.207456350326538
        ],
        [
          8.978431701660156,
          -0.014999990351498127,
          1.1852145195007324
        ],
        [
          9.07873821258545,
          -0.014999990351498127,
          1.1734023094177246
        ],
        [
          8.974574089050293,
          -0.014999990351498127,
          1.1521096229553223
        ],
        [
          9.074908256530762,
          -0.014999990351498127,
          1.1405305862426758
        ],
        [
          8.97091293334961,
          -0.014999990351498127,
          1.120064377784729
        ],
        [
          9.071270942687988,
          -0.014999990351498127,
          1.1086969375610352
        ],
        [
          8.967423439025879,
          -0.014999990351498127,
          1.088979721069336
        ],
        [
          9.067802429199219,
          -0.014999990351498127,
          1.0777961015701294
        ],
        [
          8.964081764221191,
          -0.014999990351498127,
          1.0587514638900757
        ],
        [
          9.064477920532227,
          -0.014999990351498127,
          1.0477243661880493
        ],
        [
          8.96086597442627,
          -0.014999990351498127,
          1.0292812585830688
        ],
        [
          9.061275482177734,
          -0.014999990351498127,
          1.018376111984253
        ],
        [
          8.957752227783203,
          -0.014999990351498127,
          1.0004678964614868
        ],
        [
          9.058170318603516,
          -0.014999990351498127,
          0.9896463751792908
        ],
        [
          8.954715728759766,
          -0.014999990351498127,
          0.972211480140686
        ],
        [
          9.055139541625977,
          -0.014999990351498127,
          0.9614300727844238
        ],
        [
          8.951733589172363,
          -0.014999990351498127,
          0.9444101452827454
        ],
        [
          9.052155494689941,
          -0.014999990351498127,
          0.9336227774620056
        ],
        [
          8.94878101348877,
          -0.014999990351498127,
          0.9169580340385437
        ],
        [
          9.049198150634766,
          -0.014999990351498127,
          0.9061218500137329
        ],
        [
          8.94583511352539,
          -0.014999990351498127,
          0.8897532224655151
        ],
        [
          9.046242713928223,
          -0.014999990351498127,
          0.8788230419158936
        ],
        [
          8.94287395477295,
          -0.014999990351498127,
          0.8626953959465027
        ],
        [
          9.043265342712402,
          -0.014999990351498127,
          0.8516212105751038
        ],
        [
          8.93986988067627,
          -0.014999990351498127,
          0.8356763124465942
        ],
        [
          9.040240287780762,
          -0.014999990351498127,
          0.8244145512580872
        ],
        [
          8.936802864074707,
          -0.014999990351498127,
          0.8085907101631165
        ],
        [
          9.037147521972656,
          -0.014999990351498127,
          0.7971002459526062
        ],
        [
          8.933648109436035,
          -0.014999990351498127,
          0.7813349962234497
        ],
        [
          9.033960342407227,
          -0.014999990351498127,
          0.7695747017860413
        ],
        [
          8.930379867553711,
          -0.014999990351498127,
          0.7538012862205505
        ],
        [
          9.030656814575195,
          -0.014999990351498127,
          0.7417358756065369
        ],
        [
          8.92697525024414,
          -0.014999990351498127,
          0.7258827090263367
        ],
        [
          9.02721118927002,
          -0.014999990351498127,
          0.7134817242622375
        ],
        [
          8.92341136932373,
          -0.014999990351498127,
          0.6974707841873169
        ],
        [
          9.023601531982422,
          -0.014999990351498127,
          0.6847105622291565
        ],
        [
          8.919662475585938,
          -0.014999990351498127,
          0.6684603095054626
        ],
        [
          9.019804000854492,
          -0.014999990351498127,
          0.6553192734718323
        ],
        [
          8.915704727172852,
          -0.014999990351498127,
          0.6387429237365723
        ],
        [
          9.015792846679688,
          -0.014999990351498127,
          0.6252064108848572
        ],
        [
          8.911514282226562,
          -0.014999990351498127,
          0.6082102060317993
        ],
        [
          9.011547088623047,
          -0.014999990351498127,
          0.5942702889442444
        ],
        [
          8.907066345214844,
          -0.014999990351498127,
          0.5767563581466675
        ],
        [
          9.007041931152344,
          -0.014999990351498127,
          0.5624081492424011
        ],
        [
          8.902338027954102,
          -0.014999990351498127,
          0.54427570104599
        ],
        [
          9.002254486083984,
          -0.014999990351498127,
          0.5295173525810242
        ],
        [
          8.89730453491211,
          -0.014999990351498127,
          0.5106648802757263
        ],
        [
          8.99715805053711,
          -0.014999990351498127,
          0.4954940378665924
        ],
        [
          8.891510009765625,
          -0.014999990351498127,
          0.4730040729045868
        ],
        [
          8.991304397583008,
          -0.014999990351498127,
          0.4574446976184845
        ],
        [
          8.885773658752441,
          -0.014999990351498127,
          0.436707466840744
        ],
        [
          8.985503196716309,
          -0.014999990351498127,
          0.42073753476142883
        ],
        [
          8.880082130432129,
          -0.0021675117313861847,
          0.40163785219192505
        ],
        [
          8.979744911193848,
          -0.014999990351498127,
          0.38525813817977905
        ],
        [
          8.87442684173584,
          0.0015155031578615308,
          0.36767226457595825
        ],
        [
          8.97402286529541,
          -0.004875937011092901,
          0.35088643431663513
        ],
        [
          8.868797302246094,
          0.004833539482206106,
          0.33468544483184814
        ],
        [
          8.9683256149292,
          13289062189869583e-20,
          0.3175033628940582
        ],
        [
          8.863184928894043,
          0.007291698362678289,
          0.3025517761707306
        ],
        [
          8.962646484375,
          0.0029534175992012024,
          0.2849899232387543
        ],
        [
          8.857579231262207,
          0.009004461579024792,
          0.27114951610565186
        ],
        [
          8.956975936889648,
          0.0057175601832568645,
          0.25322556495666504
        ],
        [
          8.851968765258789,
          0.01052369549870491,
          0.24035294353961945
        ],
        [
          8.95130443572998,
          0.0074869380332529545,
          0.22209127247333527
        ],
        [
          8.846343994140625,
          0.011955834925174713,
          0.21003751456737518
        ],
        [
          8.945622444152832,
          0.00893363356590271,
          0.191467747092247
        ],
        [
          8.840694427490234,
          0.013370629400014877,
          0.1800767183303833
        ],
        [
          8.939921379089355,
          0.010218138806521893,
          0.16123636066913605
        ],
        [
          8.835010528564453,
          0.014201301150023937,
          0.15034767985343933
        ],
        [
          8.93419361114502,
          0.011361082084476948,
          0.13127700984477997
        ],
        [
          8.829282760620117,
          0.015030337497591972,
          0.12072916328907013
        ],
        [
          8.92842960357666,
          0.012501077726483345,
          0.10146888345479965
        ],
        [
          8.823500633239746,
          0.015714367851614952,
          0.09109635651111603
        ],
        [
          8.922618865966797,
          0.013528121635317802,
          0.07169269770383835
        ],
        [
          8.817654609680176,
          0.01638697274029255,
          0.06132836639881134
        ],
        [
          8.916753768920898,
          0.014134613797068596,
          0.04182747006416321
        ],
        [
          8.811734199523926,
          0.017066000029444695,
          0.03130297362804413
        ],
        [
          8.910823822021484,
          0.0146243991330266,
          0.011752820573747158
        ],
        [
          8.805732727050781,
          0.017649685963988304,
          9008478373289108e-19
        ],
        [
          8.904821395874023,
          0.015119774267077446,
          -0.018652861937880516
        ],
        [
          8.799637794494629,
          0.018152959644794464,
          -0.029997728765010834
        ],
        [
          8.898735046386719,
          0.015592945739626884,
          -0.049511030316352844
        ],
        [
          8.793442726135254,
          0.01866569183766842,
          -0.06151386350393295
        ],
        [
          8.892556190490723,
          0.01588568091392517,
          -0.0809425413608551
        ],
        [
          8.787137985229492,
          0.01885661482810974,
          -0.0937630757689476
        ],
        [
          8.886275291442871,
          0.016183901578187943,
          -0.11307063698768616
        ],
        [
          8.780714988708496,
          0.01902172714471817,
          -0.12686558067798615
        ],
        [
          8.8798828125,
          0.01637118123471737,
          -0.14601653814315796
        ],
        [
          8.774165153503418,
          0.019068580120801926,
          -0.1609392762184143
        ],
        [
          8.873369216918945,
          0.016434691846370697,
          -0.17990244925022125
        ],
        [
          8.76747989654541,
          0.019096259027719498,
          -0.1961010992527008
        ],
        [
          8.866724014282227,
          0.01646084524691105,
          -0.2148510366678238
        ],
        [
          8.760651588439941,
          0.018985634669661522,
          -0.23246890306472778
        ],
        [
          8.859939575195312,
          0.016257235780358315,
          -0.2509845197200775
        ],
        [
          8.753686904907227,
          0.018831629306077957,
          -0.2700677514076233
        ],
        [
          8.852996826171875,
          0.01604342646896839,
          -0.2884643077850342
        ]
      ],
      buried_depth: 6e-3,
      cross_sections: 49
    }
  ],
  ground_input_sha256: "3fd007a67719b534cc7538f5632572c2e123eb2c865887a6e072cc069235dfb6",
  outputs: {
    "cove-corner-v3.blend": "c45edc72343d9ff597631c89f37541575838ddd5038d98c848653513f012ab03",
    "cove-corner-v3.glb": "f08ada4907c76a617e2c22090049b9b2880dde2d75fa11ad61f6e76c7eec7146"
  }
};

// docs/design/2026-10-12-authored-cove-entrance/shared-apron-world-patch-v1.json
var shared_apron_world_patch_v1_default = {
  candidate: "native05-authored-cove-shore-v4",
  sourceId: "native05-authored-cove-corner-v3",
  scope: "unintegrated visible shared floor and walk-only graph candidate; no placement grants",
  district: {
    id: "native05-cove-corner-shared-apron-v1",
    templateId: "native05-cove-corner-shared-apron-v1",
    logicalOrigin: {
      x: 0,
      z: 0
    },
    worldOrigin: {
      x: 0,
      y: 0,
      z: 0
    },
    turn: 0,
    floors: [
      {
        id: "shared-apron",
        kind: "ground",
        color: "#a4cb87",
        vertices: [
          {
            cell: {
              x: 6.1632886340351565,
              z: -0.9135008043613282
            },
            point: {
              x: 6.1632886340351565,
              y: -899999e-8,
              z: -0.9135008043613282
            }
          },
          {
            cell: {
              x: 6.171727869156067,
              z: -0.8888441487845764
            },
            point: {
              x: 6.171727869156067,
              y: -899999e-8,
              z: -0.8888441487845764
            }
          },
          {
            cell: {
              x: 6.178778290442872,
              z: -0.8630777839128417
            },
            point: {
              x: 6.178778290442872,
              y: -899999e-8,
              z: -0.8630777839128417
            }
          },
          {
            cell: {
              x: 6.184508696556091,
              z: -0.8362708048820495
            },
            point: {
              x: 6.184508696556091,
              y: -899999e-8,
              z: -0.8362708048820495
            }
          },
          {
            cell: {
              x: 6.188987886156251,
              z: -0.808492306828125
            },
            point: {
              x: 6.188987886156251,
              y: -899999e-8,
              z: -0.808492306828125
            }
          },
          {
            cell: {
              x: 6.19228465790387,
              z: -0.7798113848869934
            },
            point: {
              x: 6.19228465790387,
              y: -899999e-8,
              z: -0.7798113848869934
            }
          },
          {
            cell: {
              x: 6.194467810459473,
              z: -0.7502971341945801
            },
            point: {
              x: 6.194467810459473,
              y: -899999e-8,
              z: -0.7502971341945801
            }
          },
          {
            cell: {
              x: 6.195606142483582,
              z: -0.7200186498868103
            },
            point: {
              x: 6.195606142483582,
              y: -899999e-8,
              z: -0.7200186498868103
            }
          },
          {
            cell: {
              x: 6.1957684526367185,
              z: -0.6890450270996094
            },
            point: {
              x: 6.1957684526367185,
              y: -899999e-8,
              z: -0.6890450270996094
            }
          },
          {
            cell: {
              x: 6.195023539579408,
              z: -0.6574453609689026
            },
            point: {
              x: 6.195023539579408,
              y: -899999e-8,
              z: -0.6574453609689026
            }
          },
          {
            cell: {
              x: 6.193440201972169,
              z: -0.6252887466306152
            },
            point: {
              x: 6.193440201972169,
              y: -899999e-8,
              z: -0.6252887466306152
            }
          },
          {
            cell: {
              x: 6.191087238475525,
              z: -0.5926442792206726
            },
            point: {
              x: 6.191087238475525,
              y: -899999e-8,
              z: -0.5926442792206726
            }
          },
          {
            cell: {
              x: 6.1880334477500005,
              z: -0.559581053875
            },
            point: {
              x: 6.1880334477500005,
              y: -899999e-8,
              z: -0.559581053875
            }
          },
          {
            cell: {
              x: 6.184347628456115,
              z: -0.5261681657295227
            },
            point: {
              x: 6.184347628456115,
              y: -899999e-8,
              z: -0.5261681657295227
            }
          },
          {
            cell: {
              x: 6.180098579254395,
              z: -0.49247470992016595
            },
            point: {
              x: 6.180098579254395,
              y: -899999e-8,
              z: -0.49247470992016595
            }
          },
          {
            cell: {
              x: 6.175355098805359,
              z: -0.4585697815828553
            },
            point: {
              x: 6.175355098805359,
              y: -899999e-8,
              z: -0.4585697815828553
            }
          },
          {
            cell: {
              x: 6.170185985769532,
              z: -0.42452247585351566
            },
            point: {
              x: 6.170185985769532,
              y: -899999e-8,
              z: -0.42452247585351566
            }
          },
          {
            cell: {
              x: 6.164660038807434,
              z: -0.39040188786807245
            },
            point: {
              x: 6.164660038807434,
              y: -899999e-8,
              z: -0.39040188786807245
            }
          },
          {
            cell: {
              x: 6.1588460565795895,
              z: -0.35627711276245116
            },
            point: {
              x: 6.1588460565795895,
              y: -899999e-8,
              z: -0.35627711276245116
            }
          },
          {
            cell: {
              x: 6.152812837746522,
              z: -0.32221724567257687
            },
            point: {
              x: 6.152812837746522,
              y: -899999e-8,
              z: -0.32221724567257687
            }
          },
          {
            cell: {
              x: 6.14662918096875,
              z: -0.288291381734375
            },
            point: {
              x: 6.14662918096875,
              y: -899999e-8,
              z: -0.288291381734375
            }
          },
          {
            cell: {
              x: 6.140363884906799,
              z: -0.2545686160837708
            },
            point: {
              x: 6.140363884906799,
              y: -899999e-8,
              z: -0.2545686160837708
            }
          },
          {
            cell: {
              x: 6.134085748221191,
              z: -0.22111804385668946
            },
            point: {
              x: 6.134085748221191,
              y: -899999e-8,
              z: -0.22111804385668946
            }
          },
          {
            cell: {
              x: 6.127863569572448,
              z: -0.18800876018905638
            },
            point: {
              x: 6.127863569572448,
              y: -899999e-8,
              z: -0.18800876018905638
            }
          },
          {
            cell: {
              x: 6.121766147621093,
              z: -0.15530986021679688
            },
            point: {
              x: 6.121766147621093,
              y: -899999e-8,
              z: -0.15530986021679688
            }
          },
          {
            cell: {
              x: 6.115862281027649,
              z: -0.12309043907583617
            },
            point: {
              x: 6.115862281027649,
              y: -899999e-8,
              z: -0.12309043907583617
            }
          },
          {
            cell: {
              x: 6.110220768452637,
              z: -0.0914195919020996
            },
            point: {
              x: 6.110220768452637,
              y: -899999e-8,
              z: -0.0914195919020996
            }
          },
          {
            cell: {
              x: 6.104910408556579,
              z: -0.06036641383151245
            },
            point: {
              x: 6.104910408556579,
              y: -899999e-8,
              z: -0.06036641383151245
            }
          },
          {
            cell: {
              x: 6.1,
              z: -0.03
            },
            point: {
              x: 6.1,
              y: -899999e-8,
              z: -0.03
            }
          },
          {
            cell: {
              x: 6.093614807128905,
              z: 0.015889282226562502
            },
            point: {
              x: 6.093614807128905,
              y: -899999e-8,
              z: 0.015889282226562502
            }
          },
          {
            cell: {
              x: 6.08759033203125,
              z: 0.06348144531250001
            },
            point: {
              x: 6.08759033203125,
              y: -899999e-8,
              z: 0.06348144531250001
            }
          },
          {
            cell: {
              x: 6.081935729980469,
              z: 0.11266296386718751
            },
            point: {
              x: 6.081935729980469,
              y: -899999e-8,
              z: 0.11266296386718751
            }
          },
          {
            cell: {
              x: 6.07666015625,
              z: 0.1633203125
            },
            point: {
              x: 6.07666015625,
              y: -899999e-8,
              z: 0.1633203125
            }
          },
          {
            cell: {
              x: 6.0717727661132805,
              z: 0.2153399658203125
            },
            point: {
              x: 6.0717727661132805,
              y: -899999e-8,
              z: 0.2153399658203125
            }
          },
          {
            cell: {
              x: 6.067282714843751,
              z: 0.26860839843750006
            },
            point: {
              x: 6.067282714843751,
              y: -899999e-8,
              z: 0.26860839843750006
            }
          },
          {
            cell: {
              x: 6.063199157714844,
              z: 0.3230120849609375
            },
            point: {
              x: 6.063199157714844,
              y: -899999e-8,
              z: 0.3230120849609375
            }
          },
          {
            cell: {
              x: 6.05953125,
              z: 0.3784375
            },
            point: {
              x: 6.05953125,
              y: -899999e-8,
              z: 0.3784375
            }
          },
          {
            cell: {
              x: 6.056288146972657,
              z: 0.4347711181640625
            },
            point: {
              x: 6.056288146972657,
              y: -899999e-8,
              z: 0.4347711181640625
            }
          },
          {
            cell: {
              x: 6.05347900390625,
              z: 0.49189941406250004
            },
            point: {
              x: 6.05347900390625,
              y: -899999e-8,
              z: 0.49189941406250004
            }
          },
          {
            cell: {
              x: 6.051112976074219,
              z: 0.5497088623046875
            },
            point: {
              x: 6.051112976074219,
              y: -899999e-8,
              z: 0.5497088623046875
            }
          },
          {
            cell: {
              x: 6.049199218749999,
              z: 0.6080859375
            },
            point: {
              x: 6.049199218749999,
              y: -899999e-8,
              z: 0.6080859375
            }
          },
          {
            cell: {
              x: 6.0477468872070315,
              z: 0.6669171142578125
            },
            point: {
              x: 6.0477468872070315,
              y: -899999e-8,
              z: 0.6669171142578125
            }
          },
          {
            cell: {
              x: 6.04676513671875,
              z: 0.7260888671875
            },
            point: {
              x: 6.04676513671875,
              y: -899999e-8,
              z: 0.7260888671875
            }
          },
          {
            cell: {
              x: 6.046263122558594,
              z: 0.7854876708984375
            },
            point: {
              x: 6.046263122558594,
              y: -899999e-8,
              z: 0.7854876708984375
            }
          },
          {
            cell: {
              x: 6.04625,
              z: 0.845
            },
            point: {
              x: 6.04625,
              y: -899999e-8,
              z: 0.845
            }
          },
          {
            cell: {
              x: 6.0467349243164055,
              z: 0.9045123291015625
            },
            point: {
              x: 6.0467349243164055,
              y: -899999e-8,
              z: 0.9045123291015625
            }
          },
          {
            cell: {
              x: 6.0477270507812495,
              z: 0.9639111328124998
            },
            point: {
              x: 6.0477270507812495,
              y: -899999e-8,
              z: 0.9639111328124998
            }
          },
          {
            cell: {
              x: 6.049235534667968,
              z: 1.0230828857421876
            },
            point: {
              x: 6.049235534667968,
              y: -899999e-8,
              z: 1.0230828857421876
            }
          },
          {
            cell: {
              x: 6.05126953125,
              z: 1.0819140625
            },
            point: {
              x: 6.05126953125,
              y: -899999e-8,
              z: 1.0819140625
            }
          },
          {
            cell: {
              x: 6.053838195800782,
              z: 1.1402911376953124
            },
            point: {
              x: 6.053838195800782,
              y: -899999e-8,
              z: 1.1402911376953124
            }
          },
          {
            cell: {
              x: 6.05695068359375,
              z: 1.1981005859375
            },
            point: {
              x: 6.05695068359375,
              y: -899999e-8,
              z: 1.1981005859375
            }
          },
          {
            cell: {
              x: 6.060616149902343,
              z: 1.2552288818359374
            },
            point: {
              x: 6.060616149902343,
              y: -899999e-8,
              z: 1.2552288818359374
            }
          },
          {
            cell: {
              x: 6.06484375,
              z: 1.3115625
            },
            point: {
              x: 6.06484375,
              y: -899999e-8,
              z: 1.3115625
            }
          },
          {
            cell: {
              x: 6.069642639160156,
              z: 1.3669879150390625
            },
            point: {
              x: 6.069642639160156,
              y: -899999e-8,
              z: 1.3669879150390625
            }
          },
          {
            cell: {
              x: 6.07502197265625,
              z: 1.4213916015625
            },
            point: {
              x: 6.07502197265625,
              y: -899999e-8,
              z: 1.4213916015625
            }
          },
          {
            cell: {
              x: 6.080990905761719,
              z: 1.4746600341796876
            },
            point: {
              x: 6.080990905761719,
              y: -899999e-8,
              z: 1.4746600341796876
            }
          },
          {
            cell: {
              x: 6.08755859375,
              z: 1.5266796875000002
            },
            point: {
              x: 6.08755859375,
              y: -899999e-8,
              z: 1.5266796875000002
            }
          },
          {
            cell: {
              x: 6.094734191894531,
              z: 1.5773370361328125
            },
            point: {
              x: 6.094734191894531,
              y: -899999e-8,
              z: 1.5773370361328125
            }
          },
          {
            cell: {
              x: 6.10252685546875,
              z: 1.6265185546875
            },
            point: {
              x: 6.10252685546875,
              y: -899999e-8,
              z: 1.6265185546875
            }
          },
          {
            cell: {
              x: 6.110945739746094,
              z: 1.6741107177734373
            },
            point: {
              x: 6.110945739746094,
              y: -899999e-8,
              z: 1.6741107177734373
            }
          },
          {
            cell: {
              x: 6.12,
              z: 1.72
            },
            point: {
              x: 6.12,
              y: -899999e-8,
              z: 1.72
            }
          },
          {
            cell: {
              x: 6.127033996582031,
              z: 1.750769805908203
            },
            point: {
              x: 6.127033996582031,
              y: -899999e-8,
              z: 1.750769805908203
            }
          },
          {
            cell: {
              x: 6.135021972656251,
              z: 1.780299072265625
            },
            point: {
              x: 6.135021972656251,
              y: -899999e-8,
              z: 1.780299072265625
            }
          },
          {
            cell: {
              x: 6.143980407714842,
              z: 1.8086363220214845
            },
            point: {
              x: 6.143980407714842,
              y: -899999e-8,
              z: 1.8086363220214845
            }
          },
          {
            cell: {
              x: 6.153925781250001,
              z: 1.8358300781250003
            },
            point: {
              x: 6.153925781250001,
              y: -899999e-8,
              z: 1.8358300781250003
            }
          },
          {
            cell: {
              x: 6.164874572753907,
              z: 1.8619288635253908
            },
            point: {
              x: 6.164874572753907,
              y: -899999e-8,
              z: 1.8619288635253908
            }
          },
          {
            cell: {
              x: 6.176843261718749,
              z: 1.8869812011718752
            },
            point: {
              x: 6.176843261718749,
              y: -899999e-8,
              z: 1.8869812011718752
            }
          },
          {
            cell: {
              x: 6.189848327636719,
              z: 1.911035614013672
            },
            point: {
              x: 6.189848327636719,
              y: -899999e-8,
              z: 1.911035614013672
            }
          },
          {
            cell: {
              x: 6.203906249999999,
              z: 1.9341406250000002
            },
            point: {
              x: 6.203906249999999,
              y: -899999e-8,
              z: 1.9341406250000002
            }
          },
          {
            cell: {
              x: 6.2190335083007815,
              z: 1.956344757080078
            },
            point: {
              x: 6.2190335083007815,
              y: -899999e-8,
              z: 1.956344757080078
            }
          },
          {
            cell: {
              x: 6.23524658203125,
              z: 1.977696533203125
            },
            point: {
              x: 6.23524658203125,
              y: -899999e-8,
              z: 1.977696533203125
            }
          },
          {
            cell: {
              x: 6.252561950683594,
              z: 1.9982444763183593
            },
            point: {
              x: 6.252561950683594,
              y: -899999e-8,
              z: 1.9982444763183593
            }
          },
          {
            cell: {
              x: 6.27099609375,
              z: 2.0180371093750002
            },
            point: {
              x: 6.27099609375,
              y: -899999e-8,
              z: 2.0180371093750002
            }
          },
          {
            cell: {
              x: 6.290565490722656,
              z: 2.0371229553222654
            },
            point: {
              x: 6.290565490722656,
              y: -899999e-8,
              z: 2.0371229553222654
            }
          },
          {
            cell: {
              x: 6.311286621093751,
              z: 2.055550537109375
            },
            point: {
              x: 6.311286621093751,
              y: -899999e-8,
              z: 2.055550537109375
            }
          },
          {
            cell: {
              x: 6.333175964355469,
              z: 2.073368377685547
            },
            point: {
              x: 6.333175964355469,
              y: -899999e-8,
              z: 2.073368377685547
            }
          },
          {
            cell: {
              x: 6.35625,
              z: 2.090625
            },
            point: {
              x: 6.35625,
              y: -899999e-8,
              z: 2.090625
            }
          },
          {
            cell: {
              x: 6.380525207519532,
              z: 2.1073689270019536
            },
            point: {
              x: 6.380525207519532,
              y: -899999e-8,
              z: 2.1073689270019536
            }
          },
          {
            cell: {
              x: 6.406018066406251,
              z: 2.123648681640625
            },
            point: {
              x: 6.406018066406251,
              y: -899999e-8,
              z: 2.123648681640625
            }
          },
          {
            cell: {
              x: 6.432745056152344,
              z: 2.1395127868652346
            },
            point: {
              x: 6.432745056152344,
              y: -899999e-8,
              z: 2.1395127868652346
            }
          },
          {
            cell: {
              x: 6.460722656250001,
              z: 2.155009765625
            },
            point: {
              x: 6.460722656250001,
              y: -899999e-8,
              z: 2.155009765625
            }
          },
          {
            cell: {
              x: 6.489967346191406,
              z: 2.170188140869141
            },
            point: {
              x: 6.489967346191406,
              y: -899999e-8,
              z: 2.170188140869141
            }
          },
          {
            cell: {
              x: 6.520495605468749,
              z: 2.185096435546875
            },
            point: {
              x: 6.520495605468749,
              y: -899999e-8,
              z: 2.185096435546875
            }
          },
          {
            cell: {
              x: 6.552323913574218,
              z: 2.1997831726074217
            },
            point: {
              x: 6.552323913574218,
              y: -899999e-8,
              z: 2.1997831726074217
            }
          },
          {
            cell: {
              x: 6.58546875,
              z: 2.214296875
            },
            point: {
              x: 6.58546875,
              y: -899999e-8,
              z: 2.214296875
            }
          },
          {
            cell: {
              x: 6.619946594238281,
              z: 2.228686065673828
            },
            point: {
              x: 6.619946594238281,
              y: -899999e-8,
              z: 2.228686065673828
            }
          },
          {
            cell: {
              x: 6.655773925781251,
              z: 2.242999267578125
            },
            point: {
              x: 6.655773925781251,
              y: -899999e-8,
              z: 2.242999267578125
            }
          },
          {
            cell: {
              x: 6.6929672241210945,
              z: 2.2572850036621093
            },
            point: {
              x: 6.6929672241210945,
              y: -899999e-8,
              z: 2.2572850036621093
            }
          },
          {
            cell: {
              x: 6.73154296875,
              z: 2.271591796875
            },
            point: {
              x: 6.73154296875,
              y: -899999e-8,
              z: 2.271591796875
            }
          },
          {
            cell: {
              x: 6.771517639160156,
              z: 2.285968170166016
            },
            point: {
              x: 6.771517639160156,
              y: -899999e-8,
              z: 2.285968170166016
            }
          },
          {
            cell: {
              x: 6.81290771484375,
              z: 2.300462646484375
            },
            point: {
              x: 6.81290771484375,
              y: -899999e-8,
              z: 2.300462646484375
            }
          },
          {
            cell: {
              x: 6.855729675292969,
              z: 2.315123748779297
            },
            point: {
              x: 6.855729675292969,
              y: -899999e-8,
              z: 2.315123748779297
            }
          },
          {
            cell: {
              x: 6.9,
              z: 2.33
            },
            point: {
              x: 6.9,
              y: -899999e-8,
              z: 2.33
            }
          },
          {
            cell: {
              x: 6.961369018554688,
              z: 2.3501465148925784
            },
            point: {
              x: 6.961369018554688,
              y: -899999e-8,
              z: 2.3501465148925784
            }
          },
          {
            cell: {
              x: 7.0235693359375,
              z: 2.369859619140625
            },
            point: {
              x: 7.0235693359375,
              y: -899999e-8,
              z: 2.369859619140625
            }
          },
          {
            cell: {
              x: 7.086553344726561,
              z: 2.38908090209961
            },
            point: {
              x: 7.086553344726561,
              y: -899999e-8,
              z: 2.38908090209961
            }
          },
          {
            cell: {
              x: 7.1502734375,
              z: 2.4077519531250005
            },
            point: {
              x: 7.1502734375,
              y: -899999e-8,
              z: 2.4077519531250005
            }
          },
          {
            cell: {
              x: 7.214682006835938,
              z: 2.425814361572266
            },
            point: {
              x: 7.214682006835938,
              y: -899999e-8,
              z: 2.425814361572266
            }
          },
          {
            cell: {
              x: 7.2797314453125,
              z: 2.443209716796875
            },
            point: {
              x: 7.2797314453125,
              y: -899999e-8,
              z: 2.443209716796875
            }
          },
          {
            cell: {
              x: 7.3453741455078125,
              z: 2.459879608154297
            },
            point: {
              x: 7.3453741455078125,
              y: -899999e-8,
              z: 2.459879608154297
            }
          },
          {
            cell: {
              x: 7.4115625,
              z: 2.475765625
            },
            point: {
              x: 7.4115625,
              y: -899999e-8,
              z: 2.475765625
            }
          },
          {
            cell: {
              x: 7.478248901367188,
              z: 2.490809356689453
            },
            point: {
              x: 7.478248901367188,
              y: -899999e-8,
              z: 2.490809356689453
            }
          },
          {
            cell: {
              x: 7.5453857421875,
              z: 2.504952392578125
            },
            point: {
              x: 7.5453857421875,
              y: -899999e-8,
              z: 2.504952392578125
            }
          },
          {
            cell: {
              x: 7.6129254150390615,
              z: 2.5181363220214847
            },
            point: {
              x: 7.6129254150390615,
              y: -899999e-8,
              z: 2.5181363220214847
            }
          },
          {
            cell: {
              x: 7.6808203125,
              z: 2.530302734375
            },
            point: {
              x: 7.6808203125,
              y: -899999e-8,
              z: 2.530302734375
            }
          },
          {
            cell: {
              x: 7.749022827148437,
              z: 2.541393218994141
            },
            point: {
              x: 7.749022827148437,
              y: -899999e-8,
              z: 2.541393218994141
            }
          },
          {
            cell: {
              x: 7.8174853515625005,
              z: 2.5513493652343753
            },
            point: {
              x: 7.8174853515625005,
              y: -899999e-8,
              z: 2.5513493652343753
            }
          },
          {
            cell: {
              x: 7.886160278320313,
              z: 2.560112762451172
            },
            point: {
              x: 7.886160278320313,
              y: -899999e-8,
              z: 2.560112762451172
            }
          },
          {
            cell: {
              x: 7.954999999999999,
              z: 2.567625
            },
            point: {
              x: 7.954999999999999,
              y: -899999e-8,
              z: 2.567625
            }
          },
          {
            cell: {
              x: 8.023956909179688,
              z: 2.573827667236328
            },
            point: {
              x: 8.023956909179688,
              y: -899999e-8,
              z: 2.573827667236328
            }
          },
          {
            cell: {
              x: 8.092983398437498,
              z: 2.5786623535156252
            },
            point: {
              x: 8.092983398437498,
              y: -899999e-8,
              z: 2.5786623535156252
            }
          },
          {
            cell: {
              x: 8.162031860351561,
              z: 2.5820706481933593
            },
            point: {
              x: 8.162031860351561,
              y: -899999e-8,
              z: 2.5820706481933593
            }
          },
          {
            cell: {
              x: 8.2310546875,
              z: 2.583994140625
            },
            point: {
              x: 8.2310546875,
              y: -899999e-8,
              z: 2.583994140625
            }
          },
          {
            cell: {
              x: 8.300004272460937,
              z: 2.5843744201660157
            },
            point: {
              x: 8.300004272460937,
              y: -899999e-8,
              z: 2.5843744201660157
            }
          },
          {
            cell: {
              x: 8.3688330078125,
              z: 2.583153076171875
            },
            point: {
              x: 8.3688330078125,
              y: -899999e-8,
              z: 2.583153076171875
            }
          },
          {
            cell: {
              x: 8.437493286132812,
              z: 2.580271697998047
            },
            point: {
              x: 8.437493286132812,
              y: -899999e-8,
              z: 2.580271697998047
            }
          },
          {
            cell: {
              x: 8.5059375,
              z: 2.5756718750000003
            },
            point: {
              x: 8.5059375,
              y: -899999e-8,
              z: 2.5756718750000003
            }
          },
          {
            cell: {
              x: 8.574118041992188,
              z: 2.5692951965332034
            },
            point: {
              x: 8.574118041992188,
              y: -899999e-8,
              z: 2.5692951965332034
            }
          },
          {
            cell: {
              x: 8.6419873046875,
              z: 2.561083251953125
            },
            point: {
              x: 8.6419873046875,
              y: -899999e-8,
              z: 2.561083251953125
            }
          },
          {
            cell: {
              x: 8.709497680664061,
              z: 2.5509776306152343
            },
            point: {
              x: 8.709497680664061,
              y: -899999e-8,
              z: 2.5509776306152343
            }
          },
          {
            cell: {
              x: 8.7766015625,
              z: 2.5389199218750003
            },
            point: {
              x: 8.7766015625,
              y: -899999e-8,
              z: 2.5389199218750003
            }
          },
          {
            cell: {
              x: 8.843251342773437,
              z: 2.5248517150878906
            },
            point: {
              x: 8.843251342773437,
              y: -899999e-8,
              z: 2.5248517150878906
            }
          },
          {
            cell: {
              x: 8.909399414062499,
              z: 2.508714599609375
            },
            point: {
              x: 8.909399414062499,
              y: -899999e-8,
              z: 2.508714599609375
            }
          },
          {
            cell: {
              x: 8.97499816894531,
              z: 2.490450164794922
            },
            point: {
              x: 8.97499816894531,
              y: -899999e-8,
              z: 2.490450164794922
            }
          },
          {
            cell: {
              x: 9.04,
              z: 2.47
            },
            point: {
              x: 9.04,
              y: -899999e-8,
              z: 2.47
            }
          },
          {
            cell: {
              x: 9.084846496582028,
              z: 2.455052795410156
            },
            point: {
              x: 9.084846496582028,
              y: -899999e-8,
              z: 2.455052795410156
            }
          },
          {
            cell: {
              x: 9.12935791015625,
              z: 2.44018798828125
            },
            point: {
              x: 9.12935791015625,
              y: -899999e-8,
              z: 2.44018798828125
            }
          },
          {
            cell: {
              x: 9.173492126464842,
              z: 2.425370788574219
            },
            point: {
              x: 9.173492126464842,
              y: -899999e-8,
              z: 2.425370788574219
            }
          },
          {
            cell: {
              x: 9.21720703125,
              z: 2.4105664062499996
            },
            point: {
              x: 9.21720703125,
              y: -899999e-8,
              z: 2.4105664062499996
            }
          },
          {
            cell: {
              x: 9.260460510253905,
              z: 2.3957400512695313
            },
            point: {
              x: 9.260460510253905,
              y: -899999e-8,
              z: 2.3957400512695313
            }
          },
          {
            cell: {
              x: 9.303210449218748,
              z: 2.38085693359375
            },
            point: {
              x: 9.303210449218748,
              y: -899999e-8,
              z: 2.38085693359375
            }
          },
          {
            cell: {
              x: 9.345414733886718,
              z: 2.3658822631835936
            },
            point: {
              x: 9.345414733886718,
              y: -899999e-8,
              z: 2.3658822631835936
            }
          },
          {
            cell: {
              x: 9.38703125,
              z: 2.3507812500000003
            },
            point: {
              x: 9.38703125,
              y: -899999e-8,
              z: 2.3507812500000003
            }
          },
          {
            cell: {
              x: 9.428017883300782,
              z: 2.3355191040039065
            },
            point: {
              x: 9.428017883300782,
              y: -899999e-8,
              z: 2.3355191040039065
            }
          },
          {
            cell: {
              x: 9.468332519531248,
              z: 2.3200610351562503
            },
            point: {
              x: 9.468332519531248,
              y: -899999e-8,
              z: 2.3200610351562503
            }
          },
          {
            cell: {
              x: 9.507933044433592,
              z: 2.304372253417969
            },
            point: {
              x: 9.507933044433592,
              y: -899999e-8,
              z: 2.304372253417969
            }
          },
          {
            cell: {
              x: 9.54677734375,
              z: 2.28841796875
            },
            point: {
              x: 9.54677734375,
              y: -899999e-8,
              z: 2.28841796875
            }
          },
          {
            cell: {
              x: 9.584823303222656,
              z: 2.2721633911132812
            },
            point: {
              x: 9.584823303222656,
              y: -899999e-8,
              z: 2.2721633911132812
            }
          },
          {
            cell: {
              x: 9.62202880859375,
              z: 2.25557373046875
            },
            point: {
              x: 9.62202880859375,
              y: -899999e-8,
              z: 2.25557373046875
            }
          },
          {
            cell: {
              x: 9.658351745605469,
              z: 2.238614196777344
            },
            point: {
              x: 9.658351745605469,
              y: -899999e-8,
              z: 2.238614196777344
            }
          },
          {
            cell: {
              x: 9.693749999999998,
              z: 2.22125
            },
            point: {
              x: 9.693749999999998,
              y: -899999e-8,
              z: 2.22125
            }
          },
          {
            cell: {
              x: 9.728181457519531,
              z: 2.203446350097656
            },
            point: {
              x: 9.728181457519531,
              y: -899999e-8,
              z: 2.203446350097656
            }
          },
          {
            cell: {
              x: 9.76160400390625,
              z: 2.18516845703125
            },
            point: {
              x: 9.76160400390625,
              y: -899999e-8,
              z: 2.18516845703125
            }
          },
          {
            cell: {
              x: 9.793975524902343,
              z: 2.166381530761719
            },
            point: {
              x: 9.793975524902343,
              y: -899999e-8,
              z: 2.166381530761719
            }
          },
          {
            cell: {
              x: 9.82525390625,
              z: 2.14705078125
            },
            point: {
              x: 9.82525390625,
              y: -899999e-8,
              z: 2.14705078125
            }
          },
          {
            cell: {
              x: 9.855397033691405,
              z: 2.127141418457031
            },
            point: {
              x: 9.855397033691405,
              y: -899999e-8,
              z: 2.127141418457031
            }
          },
          {
            cell: {
              x: 9.88436279296875,
              z: 2.10661865234375
            },
            point: {
              x: 9.88436279296875,
              y: -899999e-8,
              z: 2.10661865234375
            }
          },
          {
            cell: {
              x: 9.912109069824218,
              z: 2.085447692871094
            },
            point: {
              x: 9.912109069824218,
              y: -899999e-8,
              z: 2.085447692871094
            }
          },
          {
            cell: {
              x: 9.938593749999999,
              z: 2.06359375
            },
            point: {
              x: 9.938593749999999,
              y: -899999e-8,
              z: 2.06359375
            }
          },
          {
            cell: {
              x: 9.96377471923828,
              z: 2.041022033691406
            },
            point: {
              x: 9.96377471923828,
              y: -899999e-8,
              z: 2.041022033691406
            }
          },
          {
            cell: {
              x: 9.98760986328125,
              z: 2.01769775390625
            },
            point: {
              x: 9.98760986328125,
              y: -899999e-8,
              z: 2.01769775390625
            }
          },
          {
            cell: {
              x: 10.010057067871093,
              z: 1.9935861206054688
            },
            point: {
              x: 10.010057067871093,
              y: -899999e-8,
              z: 1.9935861206054688
            }
          },
          {
            cell: {
              x: 10.03107421875,
              z: 1.96865234375
            },
            point: {
              x: 10.03107421875,
              y: -899999e-8,
              z: 1.96865234375
            }
          },
          {
            cell: {
              x: 10.050619201660156,
              z: 1.9428616333007813
            },
            point: {
              x: 10.050619201660156,
              y: -899999e-8,
              z: 1.9428616333007813
            }
          },
          {
            cell: {
              x: 10.06864990234375,
              z: 1.91617919921875
            },
            point: {
              x: 10.06864990234375,
              y: -899999e-8,
              z: 1.91617919921875
            }
          },
          {
            cell: {
              x: 10.085124206542968,
              z: 1.8885702514648437
            },
            point: {
              x: 10.085124206542968,
              y: -899999e-8,
              z: 1.8885702514648437
            }
          },
          {
            cell: {
              x: 10.1,
              z: 1.86
            },
            point: {
              x: 10.1,
              y: -899999e-8,
              z: 1.86
            }
          },
          {
            cell: {
              x: 10.119722167971373,
              z: 1.8151988220221251
            },
            point: {
              x: 10.119722167971373,
              y: -899999e-8,
              z: 1.8151988220221251
            }
          },
          {
            cell: {
              x: 10.137695312520995,
              z: 1.767196044927002
            },
            point: {
              x: 10.137695312520995,
              y: -899999e-8,
              z: 1.767196044927002
            }
          },
          {
            cell: {
              x: 10.154004394602111,
              z: 1.7162178039723814
            },
            point: {
              x: 10.154004394602111,
              y: -899999e-8,
              z: 1.7162178039723814
            }
          },
          {
            cell: {
              x: 10.168734375167968,
              z: 1.6624902344160157
            },
            point: {
              x: 10.168734375167968,
              y: -899999e-8,
              z: 1.6624902344160157
            }
          },
          {
            cell: {
              x: 10.181970215171814,
              z: 1.6062394715156556
            },
            point: {
              x: 10.181970215171814,
              y: -899999e-8,
              z: 1.6062394715156556
            }
          },
          {
            cell: {
              x: 10.193796875566894,
              z: 1.5476916505290526
            },
            point: {
              x: 10.193796875566894,
              y: -899999e-8,
              z: 1.5476916505290526
            }
          },
          {
            cell: {
              x: 10.204299317306457,
              z: 1.4870729067139588
            },
            point: {
              x: 10.204299317306457,
              y: -899999e-8,
              z: 1.4870729067139588
            }
          },
          {
            cell: {
              x: 10.213562501343748,
              z: 1.424609375328125
            },
            point: {
              x: 10.213562501343748,
              y: -899999e-8,
              z: 1.424609375328125
            }
          },
          {
            cell: {
              x: 10.221671388632018,
              z: 1.360527191629303
            },
            point: {
              x: 10.221671388632018,
              y: -899999e-8,
              z: 1.360527191629303
            }
          },
          {
            cell: {
              x: 10.228710940124513,
              z: 1.295052490875244
            },
            point: {
              x: 10.228710940124513,
              y: -899999e-8,
              z: 1.295052490875244
            }
          },
          {
            cell: {
              x: 10.234766116774477,
              z: 1.2284114083236999
            },
            point: {
              x: 10.234766116774477,
              y: -899999e-8,
              z: 1.2284114083236999
            }
          },
          {
            cell: {
              x: 10.239921879535157,
              z: 1.1608300792324218
            },
            point: {
              x: 10.239921879535157,
              y: -899999e-8,
              z: 1.1608300792324218
            }
          },
          {
            cell: {
              x: 10.244263189359803,
              z: 1.0925346388591612
            },
            point: {
              x: 10.244263189359803,
              y: -899999e-8,
              z: 1.0925346388591612
            }
          },
          {
            cell: {
              x: 10.24787500720166,
              z: 1.0237512224616698
            },
            point: {
              x: 10.24787500720166,
              y: -899999e-8,
              z: 1.0237512224616698
            }
          },
          {
            cell: {
              x: 10.250842294013976,
              z: 0.954705965297699
            },
            point: {
              x: 10.250842294013976,
              y: -899999e-8,
              z: 0.954705965297699
            }
          },
          {
            cell: {
              x: 10.25325001075,
              z: 0.885625002625
            },
            point: {
              x: 10.25325001075,
              y: -899999e-8,
              z: 0.885625002625
            }
          },
          {
            cell: {
              x: 10.255183118362977,
              z: 0.8167344697013245
            },
            point: {
              x: 10.255183118362977,
              y: -899999e-8,
              z: 0.8167344697013245
            }
          },
          {
            cell: {
              x: 10.256726577806152,
              z: 0.7482605017844238
            },
            point: {
              x: 10.256726577806152,
              y: -899999e-8,
              z: 0.7482605017844238
            }
          },
          {
            cell: {
              x: 10.257965350032775,
              z: 0.6804292341320496
            },
            point: {
              x: 10.257965350032775,
              y: -899999e-8,
              z: 0.6804292341320496
            }
          },
          {
            cell: {
              x: 10.258984395996094,
              z: 0.6134668020019531
            },
            point: {
              x: 10.258984395996094,
              y: -899999e-8,
              z: 0.6134668020019531
            }
          },
          {
            cell: {
              x: 10.259868676649354,
              z: 0.547599340651886
            },
            point: {
              x: 10.259868676649354,
              y: -899999e-8,
              z: 0.547599340651886
            }
          },
          {
            cell: {
              x: 10.260703152945801,
              z: 0.48305298533959956
            },
            point: {
              x: 10.260703152945801,
              y: -899999e-8,
              z: 0.48305298533959956
            }
          },
          {
            cell: {
              x: 10.261572785838684,
              z: 0.42005387132284544
            },
            point: {
              x: 10.261572785838684,
              y: -899999e-8,
              z: 0.42005387132284544
            }
          },
          {
            cell: {
              x: 10.262562536281251,
              z: 0.35882813385937495
            },
            point: {
              x: 10.262562536281251,
              y: -899999e-8,
              z: 0.35882813385937495
            }
          },
          {
            cell: {
              x: 10.263757365226745,
              z: 0.29960190820693966
            },
            point: {
              x: 10.263757365226745,
              y: -899999e-8,
              z: 0.29960190820693966
            }
          },
          {
            cell: {
              x: 10.265242233628417,
              z: 0.24260132962329098
            },
            point: {
              x: 10.265242233628417,
              y: -899999e-8,
              z: 0.24260132962329098
            }
          },
          {
            cell: {
              x: 10.267102102439514,
              z: 0.18805253336618039
            },
            point: {
              x: 10.267102102439514,
              y: -899999e-8,
              z: 0.18805253336618039
            }
          },
          {
            cell: {
              x: 10.269421932613282,
              z: 0.13618165469335936
            },
            point: {
              x: 10.269421932613282,
              y: -899999e-8,
              z: 0.13618165469335936
            }
          },
          {
            cell: {
              x: 10.272286685102966,
              z: 0.08721482886257935
            },
            point: {
              x: 10.272286685102966,
              y: -899999e-8,
              z: 0.08721482886257935
            }
          },
          {
            cell: {
              x: 10.275781320861816,
              z: 0.0413781911315918
            },
            point: {
              x: 10.275781320861816,
              y: -899999e-8,
              z: 0.0413781911315918
            }
          },
          {
            cell: {
              x: 10.279990800843079,
              z: -0.001102123241851806
            },
            point: {
              x: 10.279990800843079,
              y: -899999e-8,
              z: -0.001102123241851806
            }
          },
          {
            cell: {
              x: 10.285000086,
              z: -0.039999979
            },
            point: {
              x: 10.285000086,
              y: -899999e-8,
              z: -0.039999979
            }
          },
          {
            cell: {
              x: 10.279023266,
              z: -0.023814993
            },
            point: {
              x: 10.279023266,
              y: -899999e-8,
              z: -0.023814993
            }
          },
          {
            cell: {
              x: 10.273046875,
              z: -7630115e-9
            },
            point: {
              x: 10.273046875,
              y: -899999e-8,
              z: -7630115e-9
            }
          },
          {
            cell: {
              x: 10.267070484,
              z: 8554764e-9
            },
            point: {
              x: 10.267070484,
              y: -899999e-8,
              z: 8554764e-9
            }
          },
          {
            cell: {
              x: 10.255117702,
              z: 0.04092452
            },
            point: {
              x: 10.255117702,
              y: -899999e-8,
              z: 0.04092452
            }
          },
          {
            cell: {
              x: 10.249140882,
              z: 0.057109399
            },
            point: {
              x: 10.249140882,
              y: -899999e-8,
              z: 0.057109399
            }
          },
          {
            cell: {
              x: 10.243164063,
              z: 0.073294277
            },
            point: {
              x: 10.243164063,
              y: -899999e-8,
              z: 0.073294277
            }
          },
          {
            cell: {
              x: 10.237187672,
              z: 0.089479156
            },
            point: {
              x: 10.237187672,
              y: -899999e-8,
              z: 0.089479156
            }
          },
          {
            cell: {
              x: 10.231211281,
              z: 0.105664034
            },
            point: {
              x: 10.231211281,
              y: -899999e-8,
              z: 0.105664034
            }
          },
          {
            cell: {
              x: 10.225234461,
              z: 0.121848912
            },
            point: {
              x: 10.225234461,
              y: -899999e-8,
              z: 0.121848912
            }
          },
          {
            cell: {
              x: 10.219257641,
              z: 0.138033791
            },
            point: {
              x: 10.219257641,
              y: -899999e-8,
              z: 0.138033791
            }
          },
          {
            cell: {
              x: 10.207304859,
              z: 0.170403547
            },
            point: {
              x: 10.207304859,
              y: -899999e-8,
              z: 0.170403547
            }
          },
          {
            cell: {
              x: 10.201328039,
              z: 0.186588426
            },
            point: {
              x: 10.201328039,
              y: -899999e-8,
              z: 0.186588426
            }
          },
          {
            cell: {
              x: 10.195351219,
              z: 0.202773304
            },
            point: {
              x: 10.195351219,
              y: -899999e-8,
              z: 0.202773304
            }
          },
          {
            cell: {
              x: 10.189374828,
              z: 0.218958182
            },
            point: {
              x: 10.189374828,
              y: -899999e-8,
              z: 0.218958182
            }
          },
          {
            cell: {
              x: 10.182538843,
              z: 0.236314971
            },
            point: {
              x: 10.182538843,
              y: -899999e-8,
              z: 0.236314971
            }
          },
          {
            cell: {
              x: 10.175702858,
              z: 0.253671761
            },
            point: {
              x: 10.175702858,
              y: -899999e-8,
              z: 0.253671761
            }
          },
          {
            cell: {
              x: 10.168866873,
              z: 0.271028442
            },
            point: {
              x: 10.168866873,
              y: -899999e-8,
              z: 0.271028442
            }
          },
          {
            cell: {
              x: 10.162030888,
              z: 0.288385231
            },
            point: {
              x: 10.162030888,
              y: -899999e-8,
              z: 0.288385231
            }
          },
          {
            cell: {
              x: 10.155194902,
              z: 0.305742021
            },
            point: {
              x: 10.155194902,
              y: -899999e-8,
              z: 0.305742021
            }
          },
          {
            cell: {
              x: 10.148358917,
              z: 0.323098702
            },
            point: {
              x: 10.148358917,
              y: -899999e-8,
              z: 0.323098702
            }
          },
          {
            cell: {
              x: 10.141522932,
              z: 0.340455492
            },
            point: {
              x: 10.141522932,
              y: -899999e-8,
              z: 0.340455492
            }
          },
          {
            cell: {
              x: 10.121014977,
              z: 0.392525859
            },
            point: {
              x: 10.121014977,
              y: -899999e-8,
              z: 0.392525859
            }
          },
          {
            cell: {
              x: 10.114178991,
              z: 0.409882648
            },
            point: {
              x: 10.114178991,
              y: -899999e-8,
              z: 0.409882648
            }
          },
          {
            cell: {
              x: 10.093671036,
              z: 0.461953015
            },
            point: {
              x: 10.093671036,
              y: -899999e-8,
              z: 0.461953015
            }
          },
          {
            cell: {
              x: 10.08683548,
              z: 0.479309697
            },
            point: {
              x: 10.08683548,
              y: -899999e-8,
              z: 0.479309697
            }
          },
          {
            cell: {
              x: 10.079999495,
              z: 0.496666486
            },
            point: {
              x: 10.079999495,
              y: -899999e-8,
              z: 0.496666486
            }
          },
          {
            cell: {
              x: 10.072070026,
              z: 0.514101381
            },
            point: {
              x: 10.072070026,
              y: -899999e-8,
              z: 0.514101381
            }
          },
          {
            cell: {
              x: 10.064140129,
              z: 0.531536384
            },
            point: {
              x: 10.064140129,
              y: -899999e-8,
              z: 0.531536384
            }
          },
          {
            cell: {
              x: 10.056210232,
              z: 0.548971279
            },
            point: {
              x: 10.056210232,
              y: -899999e-8,
              z: 0.548971279
            }
          },
          {
            cell: {
              x: 10.048280764,
              z: 0.566406174
            },
            point: {
              x: 10.048280764,
              y: -899999e-8,
              z: 0.566406174
            }
          },
          {
            cell: {
              x: 10.040351295,
              z: 0.583841069
            },
            point: {
              x: 10.040351295,
              y: -899999e-8,
              z: 0.583841069
            }
          },
          {
            cell: {
              x: 10.024491501,
              z: 0.618710859
            },
            point: {
              x: 10.024491501,
              y: -899999e-8,
              z: 0.618710859
            }
          },
          {
            cell: {
              x: 10.008632565,
              z: 0.653580649
            },
            point: {
              x: 10.008632565,
              y: -899999e-8,
              z: 0.653580649
            }
          },
          {
            cell: {
              x: 10.000702667,
              z: 0.671015544
            },
            point: {
              x: 10.000702667,
              y: -899999e-8,
              z: 0.671015544
            }
          },
          {
            cell: {
              x: 9.99277277,
              z: 0.688450439
            },
            point: {
              x: 9.99277277,
              y: -899999e-8,
              z: 0.688450439
            }
          },
          {
            cell: {
              x: 9.976913834,
              z: 0.723320229
            },
            point: {
              x: 9.976913834,
              y: -899999e-8,
              z: 0.723320229
            }
          },
          {
            cell: {
              x: 9.968983936,
              z: 0.740755124
            },
            point: {
              x: 9.968983936,
              y: -899999e-8,
              z: 0.740755124
            }
          },
          {
            cell: {
              x: 9.961054039,
              z: 0.758190019
            },
            point: {
              x: 9.961054039,
              y: -899999e-8,
              z: 0.758190019
            }
          },
          {
            cell: {
              x: 9.953124571,
              z: 0.775624914
            },
            point: {
              x: 9.953124571,
              y: -899999e-8,
              z: 0.775624914
            }
          },
          {
            cell: {
              x: 9.943866444,
              z: 0.79204411
            },
            point: {
              x: 9.943866444,
              y: -899999e-8,
              z: 0.79204411
            }
          },
          {
            cell: {
              x: 9.934608746,
              z: 0.808463306
            },
            point: {
              x: 9.934608746,
              y: -899999e-8,
              z: 0.808463306
            }
          },
          {
            cell: {
              x: 9.925351048,
              z: 0.824882717
            },
            point: {
              x: 9.925351048,
              y: -899999e-8,
              z: 0.824882717
            }
          },
          {
            cell: {
              x: 9.916093349,
              z: 0.841301913
            },
            point: {
              x: 9.916093349,
              y: -899999e-8,
              z: 0.841301913
            }
          },
          {
            cell: {
              x: 9.906835651,
              z: 0.857721109
            },
            point: {
              x: 9.906835651,
              y: -899999e-8,
              z: 0.857721109
            }
          },
          {
            cell: {
              x: 9.897577953,
              z: 0.87414052
            },
            point: {
              x: 9.897577953,
              y: -899999e-8,
              z: 0.87414052
            }
          },
          {
            cell: {
              x: 9.879062557,
              z: 0.906978912
            },
            point: {
              x: 9.879062557,
              y: -899999e-8,
              z: 0.906978912
            }
          },
          {
            cell: {
              x: 9.869804859,
              z: 0.923398323
            },
            point: {
              x: 9.869804859,
              y: -899999e-8,
              z: 0.923398323
            }
          },
          {
            cell: {
              x: 9.851289463,
              z: 0.956236715
            },
            point: {
              x: 9.851289463,
              y: -899999e-8,
              z: 0.956236715
            }
          },
          {
            cell: {
              x: 9.842031336,
              z: 0.972656126
            },
            point: {
              x: 9.842031336,
              y: -899999e-8,
              z: 0.972656126
            }
          },
          {
            cell: {
              x: 9.832773209,
              z: 0.989075322
            },
            point: {
              x: 9.832773209,
              y: -899999e-8,
              z: 0.989075322
            }
          },
          {
            cell: {
              x: 9.823515511,
              z: 1.005494518
            },
            point: {
              x: 9.823515511,
              y: -899999e-8,
              z: 1.005494518
            }
          },
          {
            cell: {
              x: 9.814257813,
              z: 1.021913929
            },
            point: {
              x: 9.814257813,
              y: -899999e-8,
              z: 1.021913929
            }
          },
          {
            cell: {
              x: 9.805000114,
              z: 1.038333125
            },
            point: {
              x: 9.805000114,
              y: -899999e-8,
              z: 1.038333125
            }
          },
          {
            cell: {
              x: 9.794179869,
              z: 1.052643032
            },
            point: {
              x: 9.794179869,
              y: -899999e-8,
              z: 1.052643032
            }
          },
          {
            cell: {
              x: 9.783359623,
              z: 1.066953154
            },
            point: {
              x: 9.783359623,
              y: -899999e-8,
              z: 1.066953154
            }
          },
          {
            cell: {
              x: 9.772538948,
              z: 1.081263061
            },
            point: {
              x: 9.772538948,
              y: -899999e-8,
              z: 1.081263061
            }
          },
          {
            cell: {
              x: 9.761718702,
              z: 1.095572968
            },
            point: {
              x: 9.761718702,
              y: -899999e-8,
              z: 1.095572968
            }
          },
          {
            cell: {
              x: 9.750898457,
              z: 1.109882874
            },
            point: {
              x: 9.750898457,
              y: -899999e-8,
              z: 1.109882874
            }
          },
          {
            cell: {
              x: 9.740077782,
              z: 1.124192781
            },
            point: {
              x: 9.740077782,
              y: -899999e-8,
              z: 1.124192781
            }
          },
          {
            cell: {
              x: 9.707617044,
              z: 1.167122502
            },
            point: {
              x: 9.707617044,
              y: -899999e-8,
              z: 1.167122502
            }
          },
          {
            cell: {
              x: 9.696796799,
              z: 1.181432409
            },
            point: {
              x: 9.696796799,
              y: -899999e-8,
              z: 1.181432409
            }
          },
          {
            cell: {
              x: 9.664336061,
              z: 1.22436213
            },
            point: {
              x: 9.664336061,
              y: -899999e-8,
              z: 1.22436213
            }
          },
          {
            cell: {
              x: 9.653515816,
              z: 1.238672037
            },
            point: {
              x: 9.653515816,
              y: -899999e-8,
              z: 1.238672037
            }
          },
          {
            cell: {
              x: 9.642695141,
              z: 1.252981944
            },
            point: {
              x: 9.642695141,
              y: -899999e-8,
              z: 1.252981944
            }
          },
          {
            cell: {
              x: 9.631874895,
              z: 1.267291851
            },
            point: {
              x: 9.631874895,
              y: -899999e-8,
              z: 1.267291851
            }
          },
          {
            cell: {
              x: 9.619257355,
              z: 1.278398557
            },
            point: {
              x: 9.619257355,
              y: -899999e-8,
              z: 1.278398557
            }
          },
          {
            cell: {
              x: 9.606640244,
              z: 1.289505262
            },
            point: {
              x: 9.606640244,
              y: -899999e-8,
              z: 1.289505262
            }
          },
          {
            cell: {
              x: 9.594023132,
              z: 1.300612183
            },
            point: {
              x: 9.594023132,
              y: -899999e-8,
              z: 1.300612183
            }
          },
          {
            cell: {
              x: 9.581406021,
              z: 1.311718888
            },
            point: {
              x: 9.581406021,
              y: -899999e-8,
              z: 1.311718888
            }
          },
          {
            cell: {
              x: 9.56878891,
              z: 1.322825594
            },
            point: {
              x: 9.56878891,
              y: -899999e-8,
              z: 1.322825594
            }
          },
          {
            cell: {
              x: 9.556171799,
              z: 1.333932514
            },
            point: {
              x: 9.556171799,
              y: -899999e-8,
              z: 1.333932514
            }
          },
          {
            cell: {
              x: 9.543554688,
              z: 1.34503922
            },
            point: {
              x: 9.543554688,
              y: -899999e-8,
              z: 1.34503922
            }
          },
          {
            cell: {
              x: 9.530937576,
              z: 1.356145926
            },
            point: {
              x: 9.530937576,
              y: -899999e-8,
              z: 1.356145926
            }
          },
          {
            cell: {
              x: 9.518320465,
              z: 1.367252631
            },
            point: {
              x: 9.518320465,
              y: -899999e-8,
              z: 1.367252631
            }
          },
          {
            cell: {
              x: 9.505703354,
              z: 1.378359337
            },
            point: {
              x: 9.505703354,
              y: -899999e-8,
              z: 1.378359337
            }
          },
          {
            cell: {
              x: 9.493086243,
              z: 1.389466257
            },
            point: {
              x: 9.493086243,
              y: -899999e-8,
              z: 1.389466257
            }
          },
          {
            cell: {
              x: 9.480468702,
              z: 1.400572963
            },
            point: {
              x: 9.480468702,
              y: -899999e-8,
              z: 1.400572963
            }
          },
          {
            cell: {
              x: 9.467851162,
              z: 1.411679668
            },
            point: {
              x: 9.467851162,
              y: -899999e-8,
              z: 1.411679668
            }
          },
          {
            cell: {
              x: 9.455234051,
              z: 1.422786589
            },
            point: {
              x: 9.455234051,
              y: -899999e-8,
              z: 1.422786589
            }
          },
          {
            cell: {
              x: 9.44261694,
              z: 1.433893294
            },
            point: {
              x: 9.44261694,
              y: -899999e-8,
              z: 1.433893294
            }
          },
          {
            cell: {
              x: 9.429999828,
              z: 1.445
            },
            point: {
              x: 9.429999828,
              y: -899999e-8,
              z: 1.445
            }
          },
          {
            cell: {
              x: 9.414550734,
              z: 1.453020878
            },
            point: {
              x: 9.414550734,
              y: -899999e-8,
              z: 1.453020878
            }
          },
          {
            cell: {
              x: 9.399101639,
              z: 1.461041756
            },
            point: {
              x: 9.399101639,
              y: -899999e-8,
              z: 1.461041756
            }
          },
          {
            cell: {
              x: 9.383652115,
              z: 1.469062634
            },
            point: {
              x: 9.383652115,
              y: -899999e-8,
              z: 1.469062634
            }
          },
          {
            cell: {
              x: 9.352753925,
              z: 1.48510396
            },
            point: {
              x: 9.352753925,
              y: -899999e-8,
              z: 1.48510396
            }
          },
          {
            cell: {
              x: 9.337304401,
              z: 1.493124838
            },
            point: {
              x: 9.337304401,
              y: -899999e-8,
              z: 1.493124838
            }
          },
          {
            cell: {
              x: 9.321855307,
              z: 1.501145716
            },
            point: {
              x: 9.321855307,
              y: -899999e-8,
              z: 1.501145716
            }
          },
          {
            cell: {
              x: 9.306406212,
              z: 1.509166594
            },
            point: {
              x: 9.306406212,
              y: -899999e-8,
              z: 1.509166594
            }
          },
          {
            cell: {
              x: 9.290956688,
              z: 1.517187471
            },
            point: {
              x: 9.290956688,
              y: -899999e-8,
              z: 1.517187471
            }
          },
          {
            cell: {
              x: 9.260058498,
              z: 1.533229227
            },
            point: {
              x: 9.260058498,
              y: -899999e-8,
              z: 1.533229227
            }
          },
          {
            cell: {
              x: 9.244609189,
              z: 1.54124989
            },
            point: {
              x: 9.244609189,
              y: -899999e-8,
              z: 1.54124989
            }
          },
          {
            cell: {
              x: 9.22915988,
              z: 1.549270554
            },
            point: {
              x: 9.22915988,
              y: -899999e-8,
              z: 1.549270554
            }
          },
          {
            cell: {
              x: 9.213710785,
              z: 1.557291431
            },
            point: {
              x: 9.213710785,
              y: -899999e-8,
              z: 1.557291431
            }
          },
          {
            cell: {
              x: 9.198261476,
              z: 1.565312309
            },
            point: {
              x: 9.198261476,
              y: -899999e-8,
              z: 1.565312309
            }
          },
          {
            cell: {
              x: 9.182812166,
              z: 1.573333187
            },
            point: {
              x: 9.182812166,
              y: -899999e-8,
              z: 1.573333187
            }
          },
          {
            cell: {
              x: 9.164511347,
              z: 1.579166455
            },
            point: {
              x: 9.164511347,
              y: -899999e-8,
              z: 1.579166455
            }
          },
          {
            cell: {
              x: 9.146210527,
              z: 1.584999723
            },
            point: {
              x: 9.146210527,
              y: -899999e-8,
              z: 1.584999723
            }
          },
          {
            cell: {
              x: 9.127909708,
              z: 1.590833206
            },
            point: {
              x: 9.127909708,
              y: -899999e-8,
              z: 1.590833206
            }
          },
          {
            cell: {
              x: 9.109609103,
              z: 1.596666474
            },
            point: {
              x: 9.109609103,
              y: -899999e-8,
              z: 1.596666474
            }
          },
          {
            cell: {
              x: 9.091308498,
              z: 1.602499743
            },
            point: {
              x: 9.091308498,
              y: -899999e-8,
              z: 1.602499743
            }
          },
          {
            cell: {
              x: 9.073007679,
              z: 1.608333225
            },
            point: {
              x: 9.073007679,
              y: -899999e-8,
              z: 1.608333225
            }
          },
          {
            cell: {
              x: 9.05470686,
              z: 1.614166493
            },
            point: {
              x: 9.05470686,
              y: -899999e-8,
              z: 1.614166493
            }
          },
          {
            cell: {
              x: 9.03640604,
              z: 1.619999762
            },
            point: {
              x: 9.03640604,
              y: -899999e-8,
              z: 1.619999762
            }
          },
          {
            cell: {
              x: 9.018105221,
              z: 1.625833244
            },
            point: {
              x: 9.018105221,
              y: -899999e-8,
              z: 1.625833244
            }
          },
          {
            cell: {
              x: 8.999804401,
              z: 1.631666512
            },
            point: {
              x: 8.999804401,
              y: -899999e-8,
              z: 1.631666512
            }
          },
          {
            cell: {
              x: 8.981503582,
              z: 1.637499781
            },
            point: {
              x: 8.981503582,
              y: -899999e-8,
              z: 1.637499781
            }
          },
          {
            cell: {
              x: 8.963202977,
              z: 1.643333263
            },
            point: {
              x: 8.963202977,
              y: -899999e-8,
              z: 1.643333263
            }
          },
          {
            cell: {
              x: 8.944902372,
              z: 1.649166532
            },
            point: {
              x: 8.944902372,
              y: -899999e-8,
              z: 1.649166532
            }
          },
          {
            cell: {
              x: 8.926601553,
              z: 1.6549998
            },
            point: {
              x: 8.926601553,
              y: -899999e-8,
              z: 1.6549998
            }
          },
          {
            cell: {
              x: 8.908300734,
              z: 1.660833282
            },
            point: {
              x: 8.908300734,
              y: -899999e-8,
              z: 1.660833282
            }
          },
          {
            cell: {
              x: 8.889999914,
              z: 1.666666551
            },
            point: {
              x: 8.889999914,
              y: -899999e-8,
              z: 1.666666551
            }
          },
          {
            cell: {
              x: 8.870136547,
              z: 1.67039053
            },
            point: {
              x: 8.870136547,
              y: -899999e-8,
              z: 1.67039053
            }
          },
          {
            cell: {
              x: 8.850273395,
              z: 1.674114509
            },
            point: {
              x: 8.850273395,
              y: -899999e-8,
              z: 1.674114509
            }
          },
          {
            cell: {
              x: 8.830410242,
              z: 1.677838488
            },
            point: {
              x: 8.830410242,
              y: -899999e-8,
              z: 1.677838488
            }
          },
          {
            cell: {
              x: 8.790683508,
              z: 1.685286446
            },
            point: {
              x: 8.790683508,
              y: -899999e-8,
              z: 1.685286446
            }
          },
          {
            cell: {
              x: 8.770820355,
              z: 1.689010425
            },
            point: {
              x: 8.770820355,
              y: -899999e-8,
              z: 1.689010425
            }
          },
          {
            cell: {
              x: 8.750957203,
              z: 1.692734404
            },
            point: {
              x: 8.750957203,
              y: -899999e-8,
              z: 1.692734404
            }
          },
          {
            cell: {
              x: 8.711230469,
              z: 1.700182362
            },
            point: {
              x: 8.711230469,
              y: -899999e-8,
              z: 1.700182362
            }
          },
          {
            cell: {
              x: 8.691367316,
              z: 1.703906341
            },
            point: {
              x: 8.691367316,
              y: -899999e-8,
              z: 1.703906341
            }
          },
          {
            cell: {
              x: 8.671504164,
              z: 1.70763032
            },
            point: {
              x: 8.671504164,
              y: -899999e-8,
              z: 1.70763032
            }
          },
          {
            cell: {
              x: 8.611914063,
              z: 1.718802257
            },
            point: {
              x: 8.611914063,
              y: -899999e-8,
              z: 1.718802257
            }
          },
          {
            cell: {
              x: 8.592050695,
              z: 1.722526236
            },
            point: {
              x: 8.592050695,
              y: -899999e-8,
              z: 1.722526236
            }
          },
          {
            cell: {
              x: 8.572187543,
              z: 1.726250215
            },
            point: {
              x: 8.572187543,
              y: -899999e-8,
              z: 1.726250215
            }
          },
          {
            cell: {
              x: 8.55205102,
              z: 1.72794301
            },
            point: {
              x: 8.55205102,
              y: -899999e-8,
              z: 1.72794301
            }
          },
          {
            cell: {
              x: 8.531914282,
              z: 1.729635592
            },
            point: {
              x: 8.531914282,
              y: -899999e-8,
              z: 1.729635592
            }
          },
          {
            cell: {
              x: 8.511777544,
              z: 1.731328173
            },
            point: {
              x: 8.511777544,
              y: -899999e-8,
              z: 1.731328173
            }
          },
          {
            cell: {
              x: 8.491640806,
              z: 1.733020968
            },
            point: {
              x: 8.491640806,
              y: -899999e-8,
              z: 1.733020968
            }
          },
          {
            cell: {
              x: 8.471504068,
              z: 1.734713764
            },
            point: {
              x: 8.471504068,
              y: -899999e-8,
              z: 1.734713764
            }
          },
          {
            cell: {
              x: 8.451367331,
              z: 1.736406345
            },
            point: {
              x: 8.451367331,
              y: -899999e-8,
              z: 1.736406345
            }
          },
          {
            cell: {
              x: 8.431230593,
              z: 1.738098927
            },
            point: {
              x: 8.431230593,
              y: -899999e-8,
              z: 1.738098927
            }
          },
          {
            cell: {
              x: 8.411093855,
              z: 1.739791722
            },
            point: {
              x: 8.411093855,
              y: -899999e-8,
              z: 1.739791722
            }
          },
          {
            cell: {
              x: 8.390957117,
              z: 1.741484518
            },
            point: {
              x: 8.390957117,
              y: -899999e-8,
              z: 1.741484518
            }
          },
          {
            cell: {
              x: 8.350683641,
              z: 1.74486968
            },
            point: {
              x: 8.350683641,
              y: -899999e-8,
              z: 1.74486968
            }
          },
          {
            cell: {
              x: 8.330546904,
              z: 1.746562476
            },
            point: {
              x: 8.330546904,
              y: -899999e-8,
              z: 1.746562476
            }
          },
          {
            cell: {
              x: 8.310410166,
              z: 1.748255272
            },
            point: {
              x: 8.310410166,
              y: -899999e-8,
              z: 1.748255272
            }
          },
          {
            cell: {
              x: 8.27013669,
              z: 1.751640434
            },
            point: {
              x: 8.27013669,
              y: -899999e-8,
              z: 1.751640434
            }
          },
          {
            cell: {
              x: 8.249999952,
              z: 1.75333323
            },
            point: {
              x: 8.249999952,
              y: -899999e-8,
              z: 1.75333323
            }
          },
          {
            cell: {
              x: 8.230878806,
              z: 1.753072948
            },
            point: {
              x: 8.230878806,
              y: -899999e-8,
              z: 1.753072948
            }
          },
          {
            cell: {
              x: 8.21175766,
              z: 1.752812452
            },
            point: {
              x: 8.21175766,
              y: -899999e-8,
              z: 1.752812452
            }
          },
          {
            cell: {
              x: 8.192636728,
              z: 1.752551956
            },
            point: {
              x: 8.192636728,
              y: -899999e-8,
              z: 1.752551956
            }
          },
          {
            cell: {
              x: 8.154394436,
              z: 1.752030964
            },
            point: {
              x: 8.154394436,
              y: -899999e-8,
              z: 1.752030964
            }
          },
          {
            cell: {
              x: 8.135273504,
              z: 1.751770682
            },
            point: {
              x: 8.135273504,
              y: -899999e-8,
              z: 1.751770682
            }
          },
          {
            cell: {
              x: 8.116152358,
              z: 1.751510401
            },
            point: {
              x: 8.116152358,
              y: -899999e-8,
              z: 1.751510401
            }
          },
          {
            cell: {
              x: 8.097031212,
              z: 1.751249905
            },
            point: {
              x: 8.097031212,
              y: -899999e-8,
              z: 1.751249905
            }
          },
          {
            cell: {
              x: 8.077910066,
              z: 1.750989408
            },
            point: {
              x: 8.077910066,
              y: -899999e-8,
              z: 1.750989408
            }
          },
          {
            cell: {
              x: 8.058788919,
              z: 1.750729127
            },
            point: {
              x: 8.058788919,
              y: -899999e-8,
              z: 1.750729127
            }
          },
          {
            cell: {
              x: 8.039667988,
              z: 1.750468845
            },
            point: {
              x: 8.039667988,
              y: -899999e-8,
              z: 1.750468845
            }
          },
          {
            cell: {
              x: 8.001425695,
              z: 1.749947853
            },
            point: {
              x: 8.001425695,
              y: -899999e-8,
              z: 1.749947853
            }
          },
          {
            cell: {
              x: 7.982304764,
              z: 1.749687357
            },
            point: {
              x: 7.982304764,
              y: -899999e-8,
              z: 1.749687357
            }
          },
          {
            cell: {
              x: 7.963183618,
              z: 1.749426861
            },
            point: {
              x: 7.963183618,
              y: -899999e-8,
              z: 1.749426861
            }
          },
          {
            cell: {
              x: 7.944062471,
              z: 1.749166579
            },
            point: {
              x: 7.944062471,
              y: -899999e-8,
              z: 1.749166579
            }
          },
          {
            cell: {
              x: 7.927246094,
              z: 1.747031326
            },
            point: {
              x: 7.927246094,
              y: -899999e-8,
              z: 1.747031326
            }
          },
          {
            cell: {
              x: 7.910429716,
              z: 1.744895859
            },
            point: {
              x: 7.910429716,
              y: -899999e-8,
              z: 1.744895859
            }
          },
          {
            cell: {
              x: 7.893613338,
              z: 1.742760391
            },
            point: {
              x: 7.893613338,
              y: -899999e-8,
              z: 1.742760391
            }
          },
          {
            cell: {
              x: 7.876796961,
              z: 1.740624924
            },
            point: {
              x: 7.876796961,
              y: -899999e-8,
              z: 1.740624924
            }
          },
          {
            cell: {
              x: 7.859980583,
              z: 1.738489456
            },
            point: {
              x: 7.859980583,
              y: -899999e-8,
              z: 1.738489456
            }
          },
          {
            cell: {
              x: 7.843164206,
              z: 1.736353989
            },
            point: {
              x: 7.843164206,
              y: -899999e-8,
              z: 1.736353989
            }
          },
          {
            cell: {
              x: 7.826347828,
              z: 1.734218521
            },
            point: {
              x: 7.826347828,
              y: -899999e-8,
              z: 1.734218521
            }
          },
          {
            cell: {
              x: 7.809531236,
              z: 1.732083268
            },
            point: {
              x: 7.809531236,
              y: -899999e-8,
              z: 1.732083268
            }
          },
          {
            cell: {
              x: 7.792714643,
              z: 1.729948015
            },
            point: {
              x: 7.792714643,
              y: -899999e-8,
              z: 1.729948015
            }
          },
          {
            cell: {
              x: 7.775898266,
              z: 1.727812548
            },
            point: {
              x: 7.775898266,
              y: -899999e-8,
              z: 1.727812548
            }
          },
          {
            cell: {
              x: 7.759081888,
              z: 1.72567708
            },
            point: {
              x: 7.759081888,
              y: -899999e-8,
              z: 1.72567708
            }
          },
          {
            cell: {
              x: 7.742265511,
              z: 1.723541613
            },
            point: {
              x: 7.742265511,
              y: -899999e-8,
              z: 1.723541613
            }
          },
          {
            cell: {
              x: 7.725449133,
              z: 1.721406145
            },
            point: {
              x: 7.725449133,
              y: -899999e-8,
              z: 1.721406145
            }
          },
          {
            cell: {
              x: 7.708632755,
              z: 1.719270678
            },
            point: {
              x: 7.708632755,
              y: -899999e-8,
              z: 1.719270678
            }
          },
          {
            cell: {
              x: 7.691816378,
              z: 1.71713521
            },
            point: {
              x: 7.691816378,
              y: -899999e-8,
              z: 1.71713521
            }
          },
          {
            cell: {
              x: 7.675,
              z: 1.714999957
            },
            point: {
              x: 7.675,
              y: -899999e-8,
              z: 1.714999957
            }
          },
          {
            cell: {
              x: 7.659752607,
              z: 1.710358019
            },
            point: {
              x: 7.659752607,
              y: -899999e-8,
              z: 1.710358019
            }
          },
          {
            cell: {
              x: 7.644505215,
              z: 1.705715866
            },
            point: {
              x: 7.644505215,
              y: -899999e-8,
              z: 1.705715866
            }
          },
          {
            cell: {
              x: 7.614010429,
              z: 1.69643199
            },
            point: {
              x: 7.614010429,
              y: -899999e-8,
              z: 1.69643199
            }
          },
          {
            cell: {
              x: 7.598763037,
              z: 1.691790051
            },
            point: {
              x: 7.598763037,
              y: -899999e-8,
              z: 1.691790051
            }
          },
          {
            cell: {
              x: 7.568268251,
              z: 1.682506175
            },
            point: {
              x: 7.568268251,
              y: -899999e-8,
              z: 1.682506175
            }
          },
          {
            cell: {
              x: 7.553020859,
              z: 1.677864237
            },
            point: {
              x: 7.553020859,
              y: -899999e-8,
              z: 1.677864237
            }
          },
          {
            cell: {
              x: 7.537773466,
              z: 1.673222299
            },
            point: {
              x: 7.537773466,
              y: -899999e-8,
              z: 1.673222299
            }
          },
          {
            cell: {
              x: 7.522526073,
              z: 1.66858036
            },
            point: {
              x: 7.522526073,
              y: -899999e-8,
              z: 1.66858036
            }
          },
          {
            cell: {
              x: 7.507278681,
              z: 1.663938422
            },
            point: {
              x: 7.507278681,
              y: -899999e-8,
              z: 1.663938422
            }
          },
          {
            cell: {
              x: 7.476783895,
              z: 1.654654546
            },
            point: {
              x: 7.476783895,
              y: -899999e-8,
              z: 1.654654546
            }
          },
          {
            cell: {
              x: 7.461536503,
              z: 1.650012608
            },
            point: {
              x: 7.461536503,
              y: -899999e-8,
              z: 1.650012608
            }
          },
          {
            cell: {
              x: 7.44628911,
              z: 1.645370669
            },
            point: {
              x: 7.44628911,
              y: -899999e-8,
              z: 1.645370669
            }
          },
          {
            cell: {
              x: 7.431041718,
              z: 1.640728731
            },
            point: {
              x: 7.431041718,
              y: -899999e-8,
              z: 1.640728731
            }
          },
          {
            cell: {
              x: 7.416184962,
              z: 1.633391495
            },
            point: {
              x: 7.416184962,
              y: -899999e-8,
              z: 1.633391495
            }
          },
          {
            cell: {
              x: 7.401328206,
              z: 1.626054258
            },
            point: {
              x: 7.401328206,
              y: -899999e-8,
              z: 1.626054258
            }
          },
          {
            cell: {
              x: 7.386471343,
              z: 1.618717022
            },
            point: {
              x: 7.386471343,
              y: -899999e-8,
              z: 1.618717022
            }
          },
          {
            cell: {
              x: 7.371614587,
              z: 1.611379786
            },
            point: {
              x: 7.371614587,
              y: -899999e-8,
              z: 1.611379786
            }
          },
          {
            cell: {
              x: 7.356757832,
              z: 1.604042549
            },
            point: {
              x: 7.356757832,
              y: -899999e-8,
              z: 1.604042549
            }
          },
          {
            cell: {
              x: 7.341900969,
              z: 1.596705313
            },
            point: {
              x: 7.341900969,
              y: -899999e-8,
              z: 1.596705313
            }
          },
          {
            cell: {
              x: 7.327044213,
              z: 1.589368076
            },
            point: {
              x: 7.327044213,
              y: -899999e-8,
              z: 1.589368076
            }
          },
          {
            cell: {
              x: 7.312187457,
              z: 1.582031054
            },
            point: {
              x: 7.312187457,
              y: -899999e-8,
              z: 1.582031054
            }
          },
          {
            cell: {
              x: 7.297330701,
              z: 1.574694033
            },
            point: {
              x: 7.297330701,
              y: -899999e-8,
              z: 1.574694033
            }
          },
          {
            cell: {
              x: 7.282473946,
              z: 1.567356796
            },
            point: {
              x: 7.282473946,
              y: -899999e-8,
              z: 1.567356796
            }
          },
          {
            cell: {
              x: 7.267617083,
              z: 1.56001956
            },
            point: {
              x: 7.267617083,
              y: -899999e-8,
              z: 1.56001956
            }
          },
          {
            cell: {
              x: 7.252760327,
              z: 1.552682323
            },
            point: {
              x: 7.252760327,
              y: -899999e-8,
              z: 1.552682323
            }
          },
          {
            cell: {
              x: 7.237903571,
              z: 1.545345087
            },
            point: {
              x: 7.237903571,
              y: -899999e-8,
              z: 1.545345087
            }
          },
          {
            cell: {
              x: 7.223046708,
              z: 1.538007851
            },
            point: {
              x: 7.223046708,
              y: -899999e-8,
              z: 1.538007851
            }
          },
          {
            cell: {
              x: 7.208189952,
              z: 1.530670614
            },
            point: {
              x: 7.208189952,
              y: -899999e-8,
              z: 1.530670614
            }
          },
          {
            cell: {
              x: 7.193333197,
              z: 1.523333378
            },
            point: {
              x: 7.193333197,
              y: -899999e-8,
              z: 1.523333378
            }
          },
          {
            cell: {
              x: 7.179492033,
              z: 1.514043064
            },
            point: {
              x: 7.179492033,
              y: -899999e-8,
              z: 1.514043064
            }
          },
          {
            cell: {
              x: 7.165650868,
              z: 1.50475275
            },
            point: {
              x: 7.165650868,
              y: -899999e-8,
              z: 1.50475275
            }
          },
          {
            cell: {
              x: 7.151809812,
              z: 1.495462437
            },
            point: {
              x: 7.151809812,
              y: -899999e-8,
              z: 1.495462437
            }
          },
          {
            cell: {
              x: 7.137968647,
              z: 1.486171908
            },
            point: {
              x: 7.137968647,
              y: -899999e-8,
              z: 1.486171908
            }
          },
          {
            cell: {
              x: 7.124127483,
              z: 1.47688138
            },
            point: {
              x: 7.124127483,
              y: -899999e-8,
              z: 1.47688138
            }
          },
          {
            cell: {
              x: 7.110286427,
              z: 1.467591066
            },
            point: {
              x: 7.110286427,
              y: -899999e-8,
              z: 1.467591066
            }
          },
          {
            cell: {
              x: 7.096445262,
              z: 1.458300753
            },
            point: {
              x: 7.096445262,
              y: -899999e-8,
              z: 1.458300753
            }
          },
          {
            cell: {
              x: 7.068762934,
              z: 1.439720125
            },
            point: {
              x: 7.068762934,
              y: -899999e-8,
              z: 1.439720125
            }
          },
          {
            cell: {
              x: 7.05492177,
              z: 1.430429597
            },
            point: {
              x: 7.05492177,
              y: -899999e-8,
              z: 1.430429597
            }
          },
          {
            cell: {
              x: 7.041080713,
              z: 1.421139069
            },
            point: {
              x: 7.041080713,
              y: -899999e-8,
              z: 1.421139069
            }
          },
          {
            cell: {
              x: 7.013398385,
              z: 1.402558441
            },
            point: {
              x: 7.013398385,
              y: -899999e-8,
              z: 1.402558441
            }
          },
          {
            cell: {
              x: 6.999557328,
              z: 1.393268127
            },
            point: {
              x: 6.999557328,
              y: -899999e-8,
              z: 1.393268127
            }
          },
          {
            cell: {
              x: 6.985716164,
              z: 1.383977814
            },
            point: {
              x: 6.985716164,
              y: -899999e-8,
              z: 1.383977814
            }
          },
          {
            cell: {
              x: 6.971875,
              z: 1.374687285
            },
            point: {
              x: 6.971875,
              y: -899999e-8,
              z: 1.374687285
            }
          },
          {
            cell: {
              x: 6.959674489,
              z: 1.364186115
            },
            point: {
              x: 6.959674489,
              y: -899999e-8,
              z: 1.364186115
            }
          },
          {
            cell: {
              x: 6.947473979,
              z: 1.353684731
            },
            point: {
              x: 6.947473979,
              y: -899999e-8,
              z: 1.353684731
            }
          },
          {
            cell: {
              x: 6.935273468,
              z: 1.343183346
            },
            point: {
              x: 6.935273468,
              y: -899999e-8,
              z: 1.343183346
            }
          },
          {
            cell: {
              x: 6.923072958,
              z: 1.332681961
            },
            point: {
              x: 6.923072958,
              y: -899999e-8,
              z: 1.332681961
            }
          },
          {
            cell: {
              x: 6.910872447,
              z: 1.322180576
            },
            point: {
              x: 6.910872447,
              y: -899999e-8,
              z: 1.322180576
            }
          },
          {
            cell: {
              x: 6.898671937,
              z: 1.311679406
            },
            point: {
              x: 6.898671937,
              y: -899999e-8,
              z: 1.311679406
            }
          },
          {
            cell: {
              x: 6.886471319,
              z: 1.301178236
            },
            point: {
              x: 6.886471319,
              y: -899999e-8,
              z: 1.301178236
            }
          },
          {
            cell: {
              x: 6.874270809,
              z: 1.290676851
            },
            point: {
              x: 6.874270809,
              y: -899999e-8,
              z: 1.290676851
            }
          },
          {
            cell: {
              x: 6.862070298,
              z: 1.280175467
            },
            point: {
              x: 6.862070298,
              y: -899999e-8,
              z: 1.280175467
            }
          },
          {
            cell: {
              x: 6.84986968,
              z: 1.269674296
            },
            point: {
              x: 6.84986968,
              y: -899999e-8,
              z: 1.269674296
            }
          },
          {
            cell: {
              x: 6.83766917,
              z: 1.259173126
            },
            point: {
              x: 6.83766917,
              y: -899999e-8,
              z: 1.259173126
            }
          },
          {
            cell: {
              x: 6.825468659,
              z: 1.248671741
            },
            point: {
              x: 6.825468659,
              y: -899999e-8,
              z: 1.248671741
            }
          },
          {
            cell: {
              x: 6.813268149,
              z: 1.238170357
            },
            point: {
              x: 6.813268149,
              y: -899999e-8,
              z: 1.238170357
            }
          },
          {
            cell: {
              x: 6.801067638,
              z: 1.227668972
            },
            point: {
              x: 6.801067638,
              y: -899999e-8,
              z: 1.227668972
            }
          },
          {
            cell: {
              x: 6.788867128,
              z: 1.217167587
            },
            point: {
              x: 6.788867128,
              y: -899999e-8,
              z: 1.217167587
            }
          },
          {
            cell: {
              x: 6.776666617,
              z: 1.206666417
            },
            point: {
              x: 6.776666617,
              y: -899999e-8,
              z: 1.206666417
            }
          },
          {
            cell: {
              x: 6.766731715,
              z: 1.195696182
            },
            point: {
              x: 6.766731715,
              y: -899999e-8,
              z: 1.195696182
            }
          },
          {
            cell: {
              x: 6.746861911,
              z: 1.173756142
            },
            point: {
              x: 6.746861911,
              y: -899999e-8,
              z: 1.173756142
            }
          },
          {
            cell: {
              x: 6.736927009,
              z: 1.162786121
            },
            point: {
              x: 6.736927009,
              y: -899999e-8,
              z: 1.162786121
            }
          },
          {
            cell: {
              x: 6.726992106,
              z: 1.151816101
            },
            point: {
              x: 6.726992106,
              y: -899999e-8,
              z: 1.151816101
            }
          },
          {
            cell: {
              x: 6.717057204,
              z: 1.140846081
            },
            point: {
              x: 6.717057204,
              y: -899999e-8,
              z: 1.140846081
            }
          },
          {
            cell: {
              x: 6.707122302,
              z: 1.12987606
            },
            point: {
              x: 6.707122302,
              y: -899999e-8,
              z: 1.12987606
            }
          },
          {
            cell: {
              x: 6.687252712,
              z: 1.10793602
            },
            point: {
              x: 6.687252712,
              y: -899999e-8,
              z: 1.10793602
            }
          },
          {
            cell: {
              x: 6.67731781,
              z: 1.096966
            },
            point: {
              x: 6.67731781,
              y: -899999e-8,
              z: 1.096966
            }
          },
          {
            cell: {
              x: 6.667382908,
              z: 1.085995979
            },
            point: {
              x: 6.667382908,
              y: -899999e-8,
              z: 1.085995979
            }
          },
          {
            cell: {
              x: 6.657448006,
              z: 1.075025959
            },
            point: {
              x: 6.657448006,
              y: -899999e-8,
              z: 1.075025959
            }
          },
          {
            cell: {
              x: 6.647513103,
              z: 1.064055939
            },
            point: {
              x: 6.647513103,
              y: -899999e-8,
              z: 1.064055939
            }
          },
          {
            cell: {
              x: 6.637578201,
              z: 1.053085918
            },
            point: {
              x: 6.637578201,
              y: -899999e-8,
              z: 1.053085918
            }
          },
          {
            cell: {
              x: 6.627643299,
              z: 1.042115898
            },
            point: {
              x: 6.627643299,
              y: -899999e-8,
              z: 1.042115898
            }
          },
          {
            cell: {
              x: 6.617708397,
              z: 1.031145663
            },
            point: {
              x: 6.617708397,
              y: -899999e-8,
              z: 1.031145663
            }
          },
          {
            cell: {
              x: 6.610664058,
              z: 1.020449228
            },
            point: {
              x: 6.610664058,
              y: -899999e-8,
              z: 1.020449228
            }
          },
          {
            cell: {
              x: 6.603619826,
              z: 1.009752579
            },
            point: {
              x: 6.603619826,
              y: -899999e-8,
              z: 1.009752579
            }
          },
          {
            cell: {
              x: 6.596575594,
              z: 0.999055929
            },
            point: {
              x: 6.596575594,
              y: -899999e-8,
              z: 0.999055929
            }
          },
          {
            cell: {
              x: 6.589531255,
              z: 0.98835928
            },
            point: {
              x: 6.589531255,
              y: -899999e-8,
              z: 0.98835928
            }
          },
          {
            cell: {
              x: 6.582487023,
              z: 0.97766263
            },
            point: {
              x: 6.582487023,
              y: -899999e-8,
              z: 0.97766263
            }
          },
          {
            cell: {
              x: 6.575442791,
              z: 0.966965981
            },
            point: {
              x: 6.575442791,
              y: -899999e-8,
              z: 0.966965981
            }
          },
          {
            cell: {
              x: 6.568398452,
              z: 0.956269331
            },
            point: {
              x: 6.568398452,
              y: -899999e-8,
              z: 0.956269331
            }
          },
          {
            cell: {
              x: 6.56135422,
              z: 0.945572681
            },
            point: {
              x: 6.56135422,
              y: -899999e-8,
              z: 0.945572681
            }
          },
          {
            cell: {
              x: 6.554309988,
              z: 0.934876032
            },
            point: {
              x: 6.554309988,
              y: -899999e-8,
              z: 0.934876032
            }
          },
          {
            cell: {
              x: 6.547265649,
              z: 0.924179382
            },
            point: {
              x: 6.547265649,
              y: -899999e-8,
              z: 0.924179382
            }
          },
          {
            cell: {
              x: 6.540221363,
              z: 0.913482733
            },
            point: {
              x: 6.540221363,
              y: -899999e-8,
              z: 0.913482733
            }
          },
          {
            cell: {
              x: 6.533177078,
              z: 0.902786298
            },
            point: {
              x: 6.533177078,
              y: -899999e-8,
              z: 0.902786298
            }
          },
          {
            cell: {
              x: 6.526132792,
              z: 0.892089863
            },
            point: {
              x: 6.526132792,
              y: -899999e-8,
              z: 0.892089863
            }
          },
          {
            cell: {
              x: 6.519088507,
              z: 0.881393213
            },
            point: {
              x: 6.519088507,
              y: -899999e-8,
              z: 0.881393213
            }
          },
          {
            cell: {
              x: 6.512044275,
              z: 0.870696564
            },
            point: {
              x: 6.512044275,
              y: -899999e-8,
              z: 0.870696564
            }
          },
          {
            cell: {
              x: 6.504999989,
              z: 0.859999914
            },
            point: {
              x: 6.504999989,
              y: -899999e-8,
              z: 0.859999914
            }
          },
          {
            cell: {
              x: 6.502190697,
              z: 0.849029894
            },
            point: {
              x: 6.502190697,
              y: -899999e-8,
              z: 0.849029894
            }
          },
          {
            cell: {
              x: 6.499381459,
              z: 0.838059874
            },
            point: {
              x: 6.499381459,
              y: -899999e-8,
              z: 0.838059874
            }
          },
          {
            cell: {
              x: 6.49657222,
              z: 0.827089853
            },
            point: {
              x: 6.49657222,
              y: -899999e-8,
              z: 0.827089853
            }
          },
          {
            cell: {
              x: 6.493762982,
              z: 0.816119833
            },
            point: {
              x: 6.493762982,
              y: -899999e-8,
              z: 0.816119833
            }
          },
          {
            cell: {
              x: 6.490953743,
              z: 0.805149813
            },
            point: {
              x: 6.490953743,
              y: -899999e-8,
              z: 0.805149813
            }
          },
          {
            cell: {
              x: 6.488144505,
              z: 0.794179792
            },
            point: {
              x: 6.488144505,
              y: -899999e-8,
              z: 0.794179792
            }
          },
          {
            cell: {
              x: 6.485335267,
              z: 0.783209772
            },
            point: {
              x: 6.485335267,
              y: -899999e-8,
              z: 0.783209772
            }
          },
          {
            cell: {
              x: 6.482526028,
              z: 0.772239537
            },
            point: {
              x: 6.482526028,
              y: -899999e-8,
              z: 0.772239537
            }
          },
          {
            cell: {
              x: 6.47971679,
              z: 0.761269517
            },
            point: {
              x: 6.47971679,
              y: -899999e-8,
              z: 0.761269517
            }
          },
          {
            cell: {
              x: 6.476907551,
              z: 0.750299497
            },
            point: {
              x: 6.476907551,
              y: -899999e-8,
              z: 0.750299497
            }
          },
          {
            cell: {
              x: 6.474098313,
              z: 0.739329476
            },
            point: {
              x: 6.474098313,
              y: -899999e-8,
              z: 0.739329476
            }
          },
          {
            cell: {
              x: 6.471289074,
              z: 0.728359349
            },
            point: {
              x: 6.471289074,
              y: -899999e-8,
              z: 0.728359349
            }
          },
          {
            cell: {
              x: 6.468479836,
              z: 0.717389221
            },
            point: {
              x: 6.468479836,
              y: -899999e-8,
              z: 0.717389221
            }
          },
          {
            cell: {
              x: 6.465670598,
              z: 0.706419201
            },
            point: {
              x: 6.465670598,
              y: -899999e-8,
              z: 0.706419201
            }
          },
          {
            cell: {
              x: 6.462861359,
              z: 0.695449181
            },
            point: {
              x: 6.462861359,
              y: -899999e-8,
              z: 0.695449181
            }
          },
          {
            cell: {
              x: 6.460052067,
              z: 0.68447916
            },
            point: {
              x: 6.460052067,
              y: -899999e-8,
              z: 0.68447916
            }
          },
          {
            cell: {
              x: 6.461246777,
              z: 0.672532601
            },
            point: {
              x: 6.461246777,
              y: -899999e-8,
              z: 0.672532601
            }
          },
          {
            cell: {
              x: 6.462441432,
              z: 0.660585935
            },
            point: {
              x: 6.462441432,
              y: -899999e-8,
              z: 0.660585935
            }
          },
          {
            cell: {
              x: 6.463636088,
              z: 0.648639269
            },
            point: {
              x: 6.463636088,
              y: -899999e-8,
              z: 0.648639269
            }
          },
          {
            cell: {
              x: 6.4660254,
              z: 0.624746151
            },
            point: {
              x: 6.4660254,
              y: -899999e-8,
              z: 0.624746151
            }
          },
          {
            cell: {
              x: 6.467220056,
              z: 0.612799485
            },
            point: {
              x: 6.467220056,
              y: -899999e-8,
              z: 0.612799485
            }
          },
          {
            cell: {
              x: 6.468414712,
              z: 0.600852818
            },
            point: {
              x: 6.468414712,
              y: -899999e-8,
              z: 0.600852818
            }
          },
          {
            cell: {
              x: 6.469609368,
              z: 0.58890626
            },
            point: {
              x: 6.469609368,
              y: -899999e-8,
              z: 0.58890626
            }
          },
          {
            cell: {
              x: 6.470804024,
              z: 0.576959701
            },
            point: {
              x: 6.470804024,
              y: -899999e-8,
              z: 0.576959701
            }
          },
          {
            cell: {
              x: 6.47199868,
              z: 0.565013034
            },
            point: {
              x: 6.47199868,
              y: -899999e-8,
              z: 0.565013034
            }
          },
          {
            cell: {
              x: 6.473193336,
              z: 0.553066368
            },
            point: {
              x: 6.473193336,
              y: -899999e-8,
              z: 0.553066368
            }
          },
          {
            cell: {
              x: 6.474387991,
              z: 0.541119809
            },
            point: {
              x: 6.474387991,
              y: -899999e-8,
              z: 0.541119809
            }
          },
          {
            cell: {
              x: 6.475582647,
              z: 0.52917325
            },
            point: {
              x: 6.475582647,
              y: -899999e-8,
              z: 0.52917325
            }
          },
          {
            cell: {
              x: 6.477971959,
              z: 0.505279918
            },
            point: {
              x: 6.477971959,
              y: -899999e-8,
              z: 0.505279918
            }
          },
          {
            cell: {
              x: 6.479166669,
              z: 0.493333359
            },
            point: {
              x: 6.479166669,
              y: -899999e-8,
              z: 0.493333359
            }
          },
          {
            cell: {
              x: 6.482626987,
              z: 0.48091795
            },
            point: {
              x: 6.482626987,
              y: -899999e-8,
              z: 0.48091795
            }
          },
          {
            cell: {
              x: 6.489547515,
              z: 0.456087346
            },
            point: {
              x: 6.489547515,
              y: -899999e-8,
              z: 0.456087346
            }
          },
          {
            cell: {
              x: 6.496468043,
              z: 0.431256528
            },
            point: {
              x: 6.496468043,
              y: -899999e-8,
              z: 0.431256528
            }
          },
          {
            cell: {
              x: 6.503388679,
              z: 0.406425924
            },
            point: {
              x: 6.503388679,
              y: -899999e-8,
              z: 0.406425924
            }
          },
          {
            cell: {
              x: 6.510309207,
              z: 0.381595106
            },
            point: {
              x: 6.510309207,
              y: -899999e-8,
              z: 0.381595106
            }
          },
          {
            cell: {
              x: 6.513769525,
              z: 0.369179804
            },
            point: {
              x: 6.513769525,
              y: -899999e-8,
              z: 0.369179804
            }
          },
          {
            cell: {
              x: 6.517229843,
              z: 0.356764503
            },
            point: {
              x: 6.517229843,
              y: -899999e-8,
              z: 0.356764503
            }
          },
          {
            cell: {
              x: 6.520690107,
              z: 0.344349093
            },
            point: {
              x: 6.520690107,
              y: -899999e-8,
              z: 0.344349093
            }
          },
          {
            cell: {
              x: 6.524150372,
              z: 0.331933684
            },
            point: {
              x: 6.524150372,
              y: -899999e-8,
              z: 0.331933684
            }
          },
          {
            cell: {
              x: 6.527610689,
              z: 0.319518275
            },
            point: {
              x: 6.527610689,
              y: -899999e-8,
              z: 0.319518275
            }
          },
          {
            cell: {
              x: 6.531071007,
              z: 0.307102866
            },
            point: {
              x: 6.531071007,
              y: -899999e-8,
              z: 0.307102866
            }
          },
          {
            cell: {
              x: 6.534531271,
              z: 0.294687564
            },
            point: {
              x: 6.534531271,
              y: -899999e-8,
              z: 0.294687564
            }
          },
          {
            cell: {
              x: 6.538518858,
              z: 0.282311316
            },
            point: {
              x: 6.538518858,
              y: -899999e-8,
              z: 0.282311316
            }
          },
          {
            cell: {
              x: 6.542506498,
              z: 0.269934959
            },
            point: {
              x: 6.542506498,
              y: -899999e-8,
              z: 0.269934959
            }
          },
          {
            cell: {
              x: 6.546494138,
              z: 0.257558603
            },
            point: {
              x: 6.546494138,
              y: -899999e-8,
              z: 0.257558603
            }
          },
          {
            cell: {
              x: 6.550481725,
              z: 0.245182354
            },
            point: {
              x: 6.550481725,
              y: -899999e-8,
              z: 0.245182354
            }
          },
          {
            cell: {
              x: 6.554469419,
              z: 0.232806106
            },
            point: {
              x: 6.554469419,
              y: -899999e-8,
              z: 0.232806106
            }
          },
          {
            cell: {
              x: 6.558457005,
              z: 0.220429749
            },
            point: {
              x: 6.558457005,
              y: -899999e-8,
              z: 0.220429749
            }
          },
          {
            cell: {
              x: 6.562444592,
              z: 0.208053393
            },
            point: {
              x: 6.562444592,
              y: -899999e-8,
              z: 0.208053393
            }
          },
          {
            cell: {
              x: 6.566432285,
              z: 0.195677145
            },
            point: {
              x: 6.566432285,
              y: -899999e-8,
              z: 0.195677145
            }
          },
          {
            cell: {
              x: 6.570419979,
              z: 0.183300896
            },
            point: {
              x: 6.570419979,
              y: -899999e-8,
              z: 0.183300896
            }
          },
          {
            cell: {
              x: 6.574407566,
              z: 0.17092454
            },
            point: {
              x: 6.574407566,
              y: -899999e-8,
              z: 0.17092454
            }
          },
          {
            cell: {
              x: 6.578395152,
              z: 0.158548183
            },
            point: {
              x: 6.578395152,
              y: -899999e-8,
              z: 0.158548183
            }
          },
          {
            cell: {
              x: 6.582382846,
              z: 0.146171935
            },
            point: {
              x: 6.582382846,
              y: -899999e-8,
              z: 0.146171935
            }
          },
          {
            cell: {
              x: 6.58637054,
              z: 0.133795686
            },
            point: {
              x: 6.58637054,
              y: -899999e-8,
              z: 0.133795686
            }
          },
          {
            cell: {
              x: 6.590358126,
              z: 0.12141933
            },
            point: {
              x: 6.590358126,
              y: -899999e-8,
              z: 0.12141933
            }
          },
          {
            cell: {
              x: 6.594345713,
              z: 0.109042974
            },
            point: {
              x: 6.594345713,
              y: -899999e-8,
              z: 0.109042974
            }
          },
          {
            cell: {
              x: 6.598333406,
              z: 0.096666725
            },
            point: {
              x: 6.598333406,
              y: -899999e-8,
              z: 0.096666725
            }
          },
          {
            cell: {
              x: 6.601110029,
              z: 0.084837217
            },
            point: {
              x: 6.601110029,
              y: -899999e-8,
              z: 0.084837217
            }
          },
          {
            cell: {
              x: 6.606663489,
              z: 0.061178417
            },
            point: {
              x: 6.606663489,
              y: -899999e-8,
              z: 0.061178417
            }
          },
          {
            cell: {
              x: 6.609440112,
              z: 0.049349017
            },
            point: {
              x: 6.609440112,
              y: -899999e-8,
              z: 0.049349017
            }
          },
          {
            cell: {
              x: 6.612216842,
              z: 0.037519617
            },
            point: {
              x: 6.612216842,
              y: -899999e-8,
              z: 0.037519617
            }
          },
          {
            cell: {
              x: 6.614993572,
              z: 0.02569011
            },
            point: {
              x: 6.614993572,
              y: -899999e-8,
              z: 0.02569011
            }
          },
          {
            cell: {
              x: 6.617770195,
              z: 0.013860602
            },
            point: {
              x: 6.617770195,
              y: -899999e-8,
              z: 0.013860602
            }
          },
          {
            cell: {
              x: 6.623323655,
              z: -9798198e-9
            },
            point: {
              x: 6.623323655,
              y: -899999e-8,
              z: -9798198e-9
            }
          },
          {
            cell: {
              x: 6.626100278,
              z: -0.021627598
            },
            point: {
              x: 6.626100278,
              y: -899999e-8,
              z: -0.021627598
            }
          },
          {
            cell: {
              x: 6.628877008,
              z: -0.033456998
            },
            point: {
              x: 6.628877008,
              y: -899999e-8,
              z: -0.033456998
            }
          },
          {
            cell: {
              x: 6.631653738,
              z: -0.045286505
            },
            point: {
              x: 6.631653738,
              y: -899999e-8,
              z: -0.045286505
            }
          },
          {
            cell: {
              x: 6.634430361,
              z: -0.057116013
            },
            point: {
              x: 6.634430361,
              y: -899999e-8,
              z: -0.057116013
            }
          },
          {
            cell: {
              x: 6.639983821,
              z: -0.080774813
            },
            point: {
              x: 6.639983821,
              y: -899999e-8,
              z: -0.080774813
            }
          },
          {
            cell: {
              x: 6.642760444,
              z: -0.092604213
            },
            point: {
              x: 6.642760444,
              y: -899999e-8,
              z: -0.092604213
            }
          },
          {
            cell: {
              x: 6.642415404,
              z: -0.114153724
            },
            point: {
              x: 6.642415404,
              y: -899999e-8,
              z: -0.114153724
            }
          },
          {
            cell: {
              x: 6.642242885,
              z: -0.124928479
            },
            point: {
              x: 6.642242885,
              y: -899999e-8,
              z: -0.124928479
            }
          },
          {
            cell: {
              x: 6.642070365,
              z: -0.135703127
            },
            point: {
              x: 6.642070365,
              y: -899999e-8,
              z: -0.135703127
            }
          },
          {
            cell: {
              x: 6.641897845,
              z: -0.146477883
            },
            point: {
              x: 6.641897845,
              y: -899999e-8,
              z: -0.146477883
            }
          },
          {
            cell: {
              x: 6.641725326,
              z: -0.157252638
            },
            point: {
              x: 6.641725326,
              y: -899999e-8,
              z: -0.157252638
            }
          },
          {
            cell: {
              x: 6.641552806,
              z: -0.168027394
            },
            point: {
              x: 6.641552806,
              y: -899999e-8,
              z: -0.168027394
            }
          },
          {
            cell: {
              x: 6.641380286,
              z: -0.178802096
            },
            point: {
              x: 6.641380286,
              y: -899999e-8,
              z: -0.178802096
            }
          },
          {
            cell: {
              x: 6.641207767,
              z: -0.189576797
            },
            point: {
              x: 6.641207767,
              y: -899999e-8,
              z: -0.189576797
            }
          },
          {
            cell: {
              x: 6.640690207,
              z: -0.221901064
            },
            point: {
              x: 6.640690207,
              y: -899999e-8,
              z: -0.221901064
            }
          },
          {
            cell: {
              x: 6.640517688,
              z: -0.232675819
            },
            point: {
              x: 6.640517688,
              y: -899999e-8,
              z: -0.232675819
            }
          },
          {
            cell: {
              x: 6.640172648,
              z: -0.254225223
            },
            point: {
              x: 6.640172648,
              y: -899999e-8,
              z: -0.254225223
            }
          },
          {
            cell: {
              x: 6.640000021,
              z: -0.264999979
            },
            point: {
              x: 6.640000021,
              y: -899999e-8,
              z: -0.264999979
            }
          },
          {
            cell: {
              x: 6.6362077,
              z: -0.274544244
            },
            point: {
              x: 6.6362077,
              y: -899999e-8,
              z: -0.274544244
            }
          },
          {
            cell: {
              x: 6.632415271,
              z: -0.284088509
            },
            point: {
              x: 6.632415271,
              y: -899999e-8,
              z: -0.284088509
            }
          },
          {
            cell: {
              x: 6.628622949,
              z: -0.293632774
            },
            point: {
              x: 6.628622949,
              y: -899999e-8,
              z: -0.293632774
            }
          },
          {
            cell: {
              x: 6.624830627,
              z: -0.303177093
            },
            point: {
              x: 6.624830627,
              y: -899999e-8,
              z: -0.303177093
            }
          },
          {
            cell: {
              x: 6.621038306,
              z: -0.312721412
            },
            point: {
              x: 6.621038306,
              y: -899999e-8,
              z: -0.312721412
            }
          },
          {
            cell: {
              x: 6.617245984,
              z: -0.322265677
            },
            point: {
              x: 6.617245984,
              y: -899999e-8,
              z: -0.322265677
            }
          },
          {
            cell: {
              x: 6.613453662,
              z: -0.331809943
            },
            point: {
              x: 6.613453662,
              y: -899999e-8,
              z: -0.331809943
            }
          },
          {
            cell: {
              x: 6.609661341,
              z: -0.341354208
            },
            point: {
              x: 6.609661341,
              y: -899999e-8,
              z: -0.341354208
            }
          },
          {
            cell: {
              x: 6.605869019,
              z: -0.350898473
            },
            point: {
              x: 6.605869019,
              y: -899999e-8,
              z: -0.350898473
            }
          },
          {
            cell: {
              x: 6.602076697,
              z: -0.360442739
            },
            point: {
              x: 6.602076697,
              y: -899999e-8,
              z: -0.360442739
            }
          },
          {
            cell: {
              x: 6.598284376,
              z: -0.369987004
            },
            point: {
              x: 6.598284376,
              y: -899999e-8,
              z: -0.369987004
            }
          },
          {
            cell: {
              x: 6.590699732,
              z: -0.389075534
            },
            point: {
              x: 6.590699732,
              y: -899999e-8,
              z: -0.389075534
            }
          },
          {
            cell: {
              x: 6.586907411,
              z: -0.3986198
            },
            point: {
              x: 6.586907411,
              y: -899999e-8,
              z: -0.3986198
            }
          },
          {
            cell: {
              x: 6.583115089,
              z: -0.408164065
            },
            point: {
              x: 6.583115089,
              y: -899999e-8,
              z: -0.408164065
            }
          },
          {
            cell: {
              x: 6.579322767,
              z: -0.417708384
            },
            point: {
              x: 6.579322767,
              y: -899999e-8,
              z: -0.417708384
            }
          },
          {
            cell: {
              x: 6.573167205,
              z: -0.426393323
            },
            point: {
              x: 6.573167205,
              y: -899999e-8,
              z: -0.426393323
            }
          },
          {
            cell: {
              x: 6.567011642,
              z: -0.435078208
            },
            point: {
              x: 6.567011642,
              y: -899999e-8,
              z: -0.435078208
            }
          },
          {
            cell: {
              x: 6.56085608,
              z: -0.443763094
            },
            point: {
              x: 6.56085608,
              y: -899999e-8,
              z: -0.443763094
            }
          },
          {
            cell: {
              x: 6.55470041,
              z: -0.452447979
            },
            point: {
              x: 6.55470041,
              y: -899999e-8,
              z: -0.452447979
            }
          },
          {
            cell: {
              x: 6.548544848,
              z: -0.461132865
            },
            point: {
              x: 6.548544848,
              y: -899999e-8,
              z: -0.461132865
            }
          },
          {
            cell: {
              x: 6.542389232,
              z: -0.46981775
            },
            point: {
              x: 6.542389232,
              y: -899999e-8,
              z: -0.46981775
            }
          },
          {
            cell: {
              x: 6.536233616,
              z: -0.478502636
            },
            point: {
              x: 6.536233616,
              y: -899999e-8,
              z: -0.478502636
            }
          },
          {
            cell: {
              x: 6.530078053,
              z: -0.487187521
            },
            point: {
              x: 6.530078053,
              y: -899999e-8,
              z: -0.487187521
            }
          },
          {
            cell: {
              x: 6.523922491,
              z: -0.495872407
            },
            point: {
              x: 6.523922491,
              y: -899999e-8,
              z: -0.495872407
            }
          },
          {
            cell: {
              x: 6.517766875,
              z: -0.504557292
            },
            point: {
              x: 6.517766875,
              y: -899999e-8,
              z: -0.504557292
            }
          },
          {
            cell: {
              x: 6.511611259,
              z: -0.513242178
            },
            point: {
              x: 6.511611259,
              y: -899999e-8,
              z: -0.513242178
            }
          },
          {
            cell: {
              x: 6.505455697,
              z: -0.521927063
            },
            point: {
              x: 6.505455697,
              y: -899999e-8,
              z: -0.521927063
            }
          },
          {
            cell: {
              x: 6.499300081,
              z: -0.530611949
            },
            point: {
              x: 6.499300081,
              y: -899999e-8,
              z: -0.530611949
            }
          },
          {
            cell: {
              x: 6.493144464,
              z: -0.539296834
            },
            point: {
              x: 6.493144464,
              y: -899999e-8,
              z: -0.539296834
            }
          },
          {
            cell: {
              x: 6.486988902,
              z: -0.54798172
            },
            point: {
              x: 6.486988902,
              y: -899999e-8,
              z: -0.54798172
            }
          },
          {
            cell: {
              x: 6.480833286,
              z: -0.556666659
            },
            point: {
              x: 6.480833286,
              y: -899999e-8,
              z: -0.556666659
            }
          },
          {
            cell: {
              x: 6.473466706,
              z: -0.564804642
            },
            point: {
              x: 6.473466706,
              y: -899999e-8,
              z: -0.564804642
            }
          },
          {
            cell: {
              x: 6.458733654,
              z: -0.581080716
            },
            point: {
              x: 6.458733654,
              y: -899999e-8,
              z: -0.581080716
            }
          },
          {
            cell: {
              x: 6.451367128,
              z: -0.589218752
            },
            point: {
              x: 6.451367128,
              y: -899999e-8,
              z: -0.589218752
            }
          },
          {
            cell: {
              x: 6.444000602,
              z: -0.597356789
            },
            point: {
              x: 6.444000602,
              y: -899999e-8,
              z: -0.597356789
            }
          },
          {
            cell: {
              x: 6.42926755,
              z: -0.613632809
            },
            point: {
              x: 6.42926755,
              y: -899999e-8,
              z: -0.613632809
            }
          },
          {
            cell: {
              x: 6.414534497,
              z: -0.629908882
            },
            point: {
              x: 6.414534497,
              y: -899999e-8,
              z: -0.629908882
            }
          },
          {
            cell: {
              x: 6.399801445,
              z: -0.646184902
            },
            point: {
              x: 6.399801445,
              y: -899999e-8,
              z: -0.646184902
            }
          },
          {
            cell: {
              x: 6.392434865,
              z: -0.654322939
            },
            point: {
              x: 6.392434865,
              y: -899999e-8,
              z: -0.654322939
            }
          },
          {
            cell: {
              x: 6.385068285,
              z: -0.662460949
            },
            point: {
              x: 6.385068285,
              y: -899999e-8,
              z: -0.662460949
            }
          },
          {
            cell: {
              x: 6.377701759,
              z: -0.670598959
            },
            point: {
              x: 6.377701759,
              y: -899999e-8,
              z: -0.670598959
            }
          },
          {
            cell: {
              x: 6.370335233,
              z: -0.678736995
            },
            point: {
              x: 6.370335233,
              y: -899999e-8,
              z: -0.678736995
            }
          },
          {
            cell: {
              x: 6.362968707,
              z: -0.686875005
            },
            point: {
              x: 6.362968707,
              y: -899999e-8,
              z: -0.686875005
            }
          },
          {
            cell: {
              x: 6.355543602,
              z: -0.694778644
            },
            point: {
              x: 6.355543602,
              y: -899999e-8,
              z: -0.694778644
            }
          },
          {
            cell: {
              x: 6.348118442,
              z: -0.702682309
            },
            point: {
              x: 6.348118442,
              y: -899999e-8,
              z: -0.702682309
            }
          },
          {
            cell: {
              x: 6.340693283,
              z: -0.710585948
            },
            point: {
              x: 6.340693283,
              y: -899999e-8,
              z: -0.710585948
            }
          },
          {
            cell: {
              x: 6.325843072,
              z: -0.726393225
            },
            point: {
              x: 6.325843072,
              y: -899999e-8,
              z: -0.726393225
            }
          },
          {
            cell: {
              x: 6.318417913,
              z: -0.734296863
            },
            point: {
              x: 6.318417913,
              y: -899999e-8,
              z: -0.734296863
            }
          },
          {
            cell: {
              x: 6.310992754,
              z: -0.742200528
            },
            point: {
              x: 6.310992754,
              y: -899999e-8,
              z: -0.742200528
            }
          },
          {
            cell: {
              x: 6.303567648,
              z: -0.750104167
            },
            point: {
              x: 6.303567648,
              y: -899999e-8,
              z: -0.750104167
            }
          },
          {
            cell: {
              x: 6.296142542,
              z: -0.758007805
            },
            point: {
              x: 6.296142542,
              y: -899999e-8,
              z: -0.758007805
            }
          },
          {
            cell: {
              x: 6.288717383,
              z: -0.765911471
            },
            point: {
              x: 6.288717383,
              y: -899999e-8,
              z: -0.765911471
            }
          },
          {
            cell: {
              x: 6.281292224,
              z: -0.773815109
            },
            point: {
              x: 6.281292224,
              y: -899999e-8,
              z: -0.773815109
            }
          },
          {
            cell: {
              x: 6.273867118,
              z: -0.781718748
            },
            point: {
              x: 6.273867118,
              y: -899999e-8,
              z: -0.781718748
            }
          },
          {
            cell: {
              x: 6.266442013,
              z: -0.789622413
            },
            point: {
              x: 6.266442013,
              y: -899999e-8,
              z: -0.789622413
            }
          },
          {
            cell: {
              x: 6.259016907,
              z: -0.797526051
            },
            point: {
              x: 6.259016907,
              y: -899999e-8,
              z: -0.797526051
            }
          },
          {
            cell: {
              x: 6.251591802,
              z: -0.80542969
            },
            point: {
              x: 6.251591802,
              y: -899999e-8,
              z: -0.80542969
            }
          },
          {
            cell: {
              x: 6.244166642,
              z: -0.813333342
            },
            point: {
              x: 6.244166642,
              y: -899999e-8,
              z: -0.813333342
            }
          },
          {
            cell: {
              x: 6.237835288,
              z: -0.8213151
            },
            point: {
              x: 6.237835288,
              y: -899999e-8,
              z: -0.8213151
            }
          },
          {
            cell: {
              x: 6.23150388,
              z: -0.829296871
            },
            point: {
              x: 6.23150388,
              y: -899999e-8,
              z: -0.829296871
            }
          },
          {
            cell: {
              x: 6.225172526,
              z: -0.837278642
            },
            point: {
              x: 6.225172526,
              y: -899999e-8,
              z: -0.837278642
            }
          },
          {
            cell: {
              x: 6.218841171,
              z: -0.845260413
            },
            point: {
              x: 6.218841171,
              y: -899999e-8,
              z: -0.845260413
            }
          },
          {
            cell: {
              x: 6.212509763,
              z: -0.853242185
            },
            point: {
              x: 6.212509763,
              y: -899999e-8,
              z: -0.853242185
            }
          },
          {
            cell: {
              x: 6.206178409,
              z: -0.861223956
            },
            point: {
              x: 6.206178409,
              y: -899999e-8,
              z: -0.861223956
            }
          },
          {
            cell: {
              x: 6.199847054,
              z: -0.869205727
            },
            point: {
              x: 6.199847054,
              y: -899999e-8,
              z: -0.869205727
            }
          },
          {
            cell: {
              x: 6.187184238,
              z: -0.885169269
            },
            point: {
              x: 6.187184238,
              y: -899999e-8,
              z: -0.885169269
            }
          },
          {
            cell: {
              x: 6.180852884,
              z: -0.893151041
            },
            point: {
              x: 6.180852884,
              y: -899999e-8,
              z: -0.893151041
            }
          },
          {
            cell: {
              x: 6.17452153,
              z: -0.901132812
            },
            point: {
              x: 6.17452153,
              y: -899999e-8,
              z: -0.901132812
            }
          },
          {
            cell: {
              x: 6.161858714,
              z: -0.917096354
            },
            point: {
              x: 6.161858714,
              y: -899999e-8,
              z: -0.917096354
            }
          },
          {
            cell: {
              x: 6.161675719141545,
              z: -0.9173270505817582
            },
            point: {
              x: 6.161675719141545,
              y: -899999e-8,
              z: -0.9173270505817582
            }
          }
        ],
        indices: [
          22,
          23,
          24,
          21,
          22,
          24,
          21,
          24,
          25,
          21,
          25,
          26,
          20,
          21,
          26,
          20,
          26,
          27,
          20,
          27,
          28,
          19,
          20,
          28,
          19,
          28,
          29,
          18,
          19,
          29,
          18,
          29,
          30,
          17,
          18,
          30,
          17,
          30,
          31,
          17,
          31,
          32,
          16,
          17,
          32,
          16,
          32,
          33,
          16,
          33,
          34,
          15,
          16,
          34,
          15,
          34,
          35,
          15,
          35,
          36,
          14,
          15,
          36,
          14,
          36,
          37,
          14,
          37,
          38,
          14,
          38,
          39,
          13,
          14,
          39,
          13,
          39,
          40,
          13,
          40,
          41,
          13,
          41,
          42,
          12,
          13,
          42,
          12,
          42,
          43,
          12,
          43,
          44,
          12,
          44,
          45,
          12,
          45,
          46,
          11,
          12,
          46,
          11,
          46,
          47,
          11,
          47,
          48,
          11,
          48,
          49,
          11,
          49,
          50,
          11,
          50,
          51,
          10,
          11,
          51,
          10,
          51,
          52,
          10,
          52,
          53,
          10,
          53,
          54,
          10,
          54,
          55,
          10,
          55,
          56,
          9,
          10,
          56,
          9,
          56,
          57,
          9,
          57,
          58,
          9,
          58,
          59,
          9,
          59,
          60,
          9,
          60,
          61,
          9,
          61,
          62,
          9,
          62,
          63,
          8,
          9,
          63,
          8,
          63,
          64,
          8,
          64,
          65,
          8,
          65,
          66,
          8,
          66,
          67,
          8,
          67,
          68,
          8,
          68,
          69,
          7,
          8,
          69,
          7,
          69,
          70,
          7,
          70,
          71,
          7,
          71,
          72,
          7,
          72,
          73,
          7,
          73,
          74,
          6,
          7,
          74,
          6,
          74,
          75,
          6,
          75,
          76,
          6,
          76,
          77,
          6,
          77,
          78,
          6,
          78,
          79,
          5,
          6,
          79,
          5,
          79,
          80,
          5,
          80,
          81,
          5,
          81,
          82,
          5,
          82,
          83,
          4,
          5,
          83,
          4,
          83,
          84,
          4,
          84,
          85,
          4,
          85,
          86,
          4,
          86,
          87,
          3,
          4,
          87,
          3,
          87,
          88,
          88,
          89,
          90,
          88,
          90,
          91,
          88,
          91,
          92,
          88,
          92,
          93,
          88,
          93,
          94,
          88,
          94,
          95,
          88,
          95,
          96,
          88,
          96,
          97,
          88,
          97,
          98,
          88,
          98,
          99,
          88,
          99,
          100,
          88,
          100,
          101,
          88,
          101,
          102,
          88,
          102,
          103,
          88,
          103,
          104,
          88,
          104,
          105,
          88,
          105,
          106,
          88,
          106,
          107,
          88,
          107,
          108,
          88,
          108,
          109,
          88,
          109,
          110,
          88,
          110,
          111,
          88,
          111,
          112,
          88,
          112,
          113,
          88,
          113,
          114,
          88,
          114,
          115,
          88,
          115,
          116,
          88,
          116,
          117,
          88,
          117,
          118,
          88,
          118,
          119,
          88,
          119,
          120,
          88,
          120,
          121,
          88,
          121,
          122,
          88,
          122,
          123,
          88,
          123,
          124,
          88,
          124,
          125,
          88,
          125,
          126,
          88,
          126,
          127,
          88,
          127,
          128,
          88,
          128,
          129,
          88,
          129,
          130,
          88,
          130,
          131,
          88,
          131,
          132,
          88,
          132,
          133,
          88,
          133,
          134,
          88,
          134,
          135,
          88,
          135,
          136,
          88,
          136,
          137,
          88,
          137,
          138,
          88,
          138,
          139,
          88,
          139,
          140,
          88,
          140,
          141,
          88,
          141,
          142,
          88,
          142,
          143,
          88,
          143,
          144,
          88,
          144,
          145,
          88,
          145,
          146,
          88,
          146,
          147,
          88,
          147,
          148,
          88,
          148,
          149,
          88,
          149,
          150,
          88,
          150,
          151,
          88,
          151,
          152,
          88,
          152,
          153,
          88,
          153,
          154,
          88,
          154,
          155,
          88,
          155,
          156,
          88,
          156,
          157,
          88,
          157,
          158,
          88,
          158,
          159,
          88,
          159,
          160,
          88,
          160,
          161,
          88,
          161,
          162,
          88,
          162,
          163,
          88,
          163,
          164,
          88,
          164,
          165,
          88,
          165,
          166,
          166,
          167,
          168,
          166,
          168,
          169,
          166,
          169,
          170,
          166,
          170,
          171,
          166,
          171,
          172,
          166,
          172,
          173,
          166,
          173,
          174,
          166,
          174,
          175,
          166,
          175,
          176,
          166,
          176,
          177,
          166,
          177,
          178,
          166,
          178,
          179,
          166,
          179,
          180,
          166,
          180,
          181,
          166,
          181,
          182,
          166,
          182,
          183,
          187,
          188,
          189,
          186,
          187,
          189,
          185,
          186,
          189,
          185,
          189,
          190,
          184,
          185,
          190,
          183,
          184,
          190,
          166,
          183,
          190,
          166,
          190,
          191,
          166,
          191,
          192,
          166,
          192,
          193,
          166,
          193,
          194,
          166,
          194,
          195,
          166,
          195,
          196,
          166,
          196,
          197,
          166,
          197,
          198,
          166,
          198,
          199,
          166,
          199,
          200,
          166,
          200,
          201,
          166,
          201,
          202,
          166,
          202,
          203,
          166,
          203,
          204,
          166,
          204,
          205,
          166,
          205,
          206,
          166,
          206,
          207,
          166,
          207,
          208,
          166,
          208,
          209,
          166,
          209,
          210,
          166,
          210,
          211,
          166,
          211,
          212,
          166,
          212,
          213,
          166,
          213,
          214,
          166,
          214,
          215,
          166,
          215,
          216,
          166,
          216,
          217,
          166,
          217,
          218,
          166,
          218,
          219,
          166,
          219,
          220,
          166,
          220,
          221,
          166,
          221,
          222,
          166,
          222,
          223,
          166,
          223,
          224,
          166,
          224,
          225,
          166,
          225,
          226,
          166,
          226,
          227,
          166,
          227,
          228,
          166,
          228,
          229,
          166,
          229,
          230,
          166,
          230,
          231,
          166,
          231,
          232,
          166,
          232,
          233,
          166,
          233,
          234,
          166,
          234,
          235,
          166,
          235,
          236,
          166,
          236,
          237,
          166,
          237,
          238,
          166,
          238,
          239,
          166,
          239,
          240,
          166,
          240,
          241,
          166,
          241,
          242,
          166,
          242,
          243,
          166,
          243,
          244,
          166,
          244,
          245,
          166,
          245,
          246,
          166,
          246,
          247,
          166,
          247,
          248,
          166,
          248,
          249,
          166,
          249,
          250,
          166,
          250,
          251,
          166,
          251,
          252,
          166,
          252,
          253,
          166,
          253,
          254,
          166,
          254,
          255,
          166,
          255,
          256,
          166,
          256,
          257,
          166,
          257,
          258,
          166,
          258,
          259,
          166,
          259,
          260,
          166,
          260,
          261,
          166,
          261,
          262,
          166,
          262,
          263,
          166,
          263,
          264,
          166,
          264,
          265,
          166,
          265,
          266,
          166,
          266,
          267,
          166,
          267,
          268,
          166,
          268,
          269,
          166,
          269,
          270,
          166,
          270,
          271,
          166,
          271,
          272,
          166,
          272,
          273,
          166,
          273,
          274,
          166,
          274,
          275,
          166,
          275,
          276,
          166,
          276,
          277,
          166,
          277,
          278,
          166,
          278,
          279,
          166,
          279,
          280,
          166,
          280,
          281,
          166,
          281,
          282,
          166,
          282,
          283,
          166,
          283,
          284,
          166,
          284,
          285,
          166,
          285,
          286,
          166,
          286,
          287,
          166,
          287,
          288,
          166,
          288,
          289,
          166,
          289,
          290,
          166,
          290,
          291,
          166,
          291,
          292,
          166,
          292,
          293,
          166,
          293,
          294,
          166,
          294,
          295,
          166,
          295,
          296,
          166,
          296,
          297,
          166,
          297,
          298,
          166,
          298,
          299,
          88,
          166,
          299,
          88,
          299,
          300,
          88,
          300,
          301,
          88,
          301,
          302,
          88,
          302,
          303,
          88,
          303,
          304,
          88,
          304,
          305,
          88,
          305,
          306,
          88,
          306,
          307,
          88,
          307,
          308,
          88,
          308,
          309,
          88,
          309,
          310,
          88,
          310,
          311,
          88,
          311,
          312,
          88,
          312,
          313,
          88,
          313,
          314,
          88,
          314,
          315,
          88,
          315,
          316,
          88,
          316,
          317,
          88,
          317,
          318,
          88,
          318,
          319,
          88,
          319,
          320,
          88,
          320,
          321,
          88,
          321,
          322,
          88,
          322,
          323,
          88,
          323,
          324,
          88,
          324,
          325,
          88,
          325,
          326,
          88,
          326,
          327,
          88,
          327,
          328,
          88,
          328,
          329,
          88,
          329,
          330,
          88,
          330,
          331,
          88,
          331,
          332,
          88,
          332,
          333,
          88,
          333,
          334,
          88,
          334,
          335,
          88,
          335,
          336,
          88,
          336,
          337,
          88,
          337,
          338,
          88,
          338,
          339,
          88,
          339,
          340,
          88,
          340,
          341,
          88,
          341,
          342,
          88,
          342,
          343,
          88,
          343,
          344,
          88,
          344,
          345,
          88,
          345,
          346,
          88,
          346,
          347,
          88,
          347,
          348,
          88,
          348,
          349,
          88,
          349,
          350,
          88,
          350,
          351,
          88,
          351,
          352,
          88,
          352,
          353,
          88,
          353,
          354,
          88,
          354,
          355,
          88,
          355,
          356,
          88,
          356,
          357,
          88,
          357,
          358,
          88,
          358,
          359,
          88,
          359,
          360,
          88,
          360,
          361,
          88,
          361,
          362,
          88,
          362,
          363,
          88,
          363,
          364,
          88,
          364,
          365,
          88,
          365,
          366,
          88,
          366,
          367,
          88,
          367,
          368,
          88,
          368,
          369,
          88,
          369,
          370,
          88,
          370,
          371,
          88,
          371,
          372,
          88,
          372,
          373,
          88,
          373,
          374,
          88,
          374,
          375,
          88,
          375,
          376,
          88,
          376,
          377,
          88,
          377,
          378,
          88,
          378,
          379,
          88,
          379,
          380,
          88,
          380,
          381,
          88,
          381,
          382,
          88,
          382,
          383,
          88,
          383,
          384,
          88,
          384,
          385,
          88,
          385,
          386,
          88,
          386,
          387,
          88,
          387,
          388,
          88,
          388,
          389,
          88,
          389,
          390,
          88,
          390,
          391,
          88,
          391,
          392,
          88,
          392,
          393,
          88,
          393,
          394,
          88,
          394,
          395,
          88,
          395,
          396,
          88,
          396,
          397,
          88,
          397,
          398,
          88,
          398,
          399,
          88,
          399,
          400,
          88,
          400,
          401,
          88,
          401,
          402,
          88,
          402,
          403,
          88,
          403,
          404,
          88,
          404,
          405,
          88,
          405,
          406,
          88,
          406,
          407,
          88,
          407,
          408,
          88,
          408,
          409,
          88,
          409,
          410,
          88,
          410,
          411,
          88,
          411,
          412,
          88,
          412,
          413,
          88,
          413,
          414,
          88,
          414,
          415,
          88,
          415,
          416,
          88,
          416,
          417,
          88,
          417,
          418,
          88,
          418,
          419,
          88,
          419,
          420,
          88,
          420,
          421,
          88,
          421,
          422,
          88,
          422,
          423,
          88,
          423,
          424,
          88,
          424,
          425,
          88,
          425,
          426,
          88,
          426,
          427,
          88,
          427,
          428,
          88,
          428,
          429,
          88,
          429,
          430,
          88,
          430,
          431,
          88,
          431,
          432,
          88,
          432,
          433,
          88,
          433,
          434,
          88,
          434,
          435,
          88,
          435,
          436,
          88,
          436,
          437,
          88,
          437,
          438,
          88,
          438,
          439,
          88,
          439,
          440,
          88,
          440,
          441,
          88,
          441,
          442,
          88,
          442,
          443,
          88,
          443,
          444,
          88,
          444,
          445,
          88,
          445,
          446,
          88,
          446,
          447,
          88,
          447,
          448,
          88,
          448,
          449,
          88,
          449,
          450,
          88,
          450,
          451,
          88,
          451,
          452,
          88,
          452,
          453,
          88,
          453,
          454,
          88,
          454,
          455,
          88,
          455,
          456,
          88,
          456,
          457,
          88,
          457,
          458,
          88,
          458,
          459,
          88,
          459,
          460,
          3,
          88,
          460,
          3,
          460,
          461,
          3,
          461,
          462,
          3,
          462,
          463,
          3,
          463,
          464,
          3,
          464,
          465,
          3,
          465,
          466,
          3,
          466,
          467,
          3,
          467,
          468,
          3,
          468,
          469,
          3,
          469,
          470,
          3,
          470,
          471,
          3,
          471,
          472,
          3,
          472,
          473,
          2,
          3,
          473,
          2,
          473,
          474,
          2,
          474,
          475,
          2,
          475,
          476,
          2,
          476,
          477,
          2,
          477,
          478,
          2,
          478,
          479,
          2,
          479,
          480,
          2,
          480,
          481,
          1,
          2,
          481,
          1,
          481,
          482,
          1,
          482,
          483,
          1,
          483,
          484,
          1,
          484,
          485,
          1,
          485,
          486,
          1,
          486,
          487,
          1,
          487,
          488,
          1,
          488,
          489,
          1,
          489,
          490,
          1,
          490,
          491,
          1,
          491,
          492,
          0,
          1,
          492,
          0,
          492,
          493,
          0,
          493,
          494,
          0,
          494,
          495,
          0,
          495,
          496,
          0,
          496,
          497,
          0,
          497,
          498,
          0,
          498,
          499,
          0,
          499,
          500,
          0,
          500,
          501,
          597,
          0,
          501,
          597,
          501,
          502,
          597,
          502,
          503,
          597,
          503,
          504,
          597,
          504,
          505,
          597,
          505,
          506,
          597,
          506,
          507,
          597,
          507,
          508,
          597,
          508,
          509,
          597,
          509,
          510,
          597,
          510,
          511,
          597,
          511,
          512,
          597,
          512,
          513,
          597,
          513,
          514,
          597,
          514,
          515,
          597,
          515,
          516,
          597,
          516,
          517,
          597,
          517,
          518,
          597,
          518,
          519,
          597,
          519,
          520,
          597,
          520,
          521,
          597,
          521,
          522,
          597,
          522,
          523,
          597,
          523,
          524,
          597,
          524,
          525,
          597,
          525,
          526,
          597,
          526,
          527,
          597,
          527,
          528,
          597,
          528,
          529,
          597,
          529,
          530,
          597,
          530,
          531,
          597,
          531,
          532,
          597,
          532,
          533,
          597,
          533,
          534,
          597,
          534,
          535,
          597,
          535,
          536,
          597,
          536,
          537,
          537,
          538,
          539,
          539,
          540,
          541,
          541,
          542,
          543,
          539,
          541,
          543,
          537,
          539,
          543,
          537,
          543,
          544,
          537,
          544,
          545,
          537,
          545,
          546,
          537,
          546,
          547,
          537,
          547,
          548,
          537,
          548,
          549,
          537,
          549,
          550,
          537,
          550,
          551,
          537,
          551,
          552,
          537,
          552,
          553,
          537,
          553,
          554,
          537,
          554,
          555,
          537,
          555,
          556,
          537,
          556,
          557,
          537,
          557,
          558,
          537,
          558,
          559,
          537,
          559,
          560,
          537,
          560,
          561,
          537,
          561,
          562,
          537,
          562,
          563,
          537,
          563,
          564,
          537,
          564,
          565,
          537,
          565,
          566,
          537,
          566,
          567,
          537,
          567,
          568,
          537,
          568,
          569,
          537,
          569,
          570,
          537,
          570,
          571,
          537,
          571,
          572,
          537,
          572,
          573,
          537,
          573,
          574,
          537,
          574,
          575,
          537,
          575,
          576,
          537,
          576,
          577,
          537,
          577,
          578,
          537,
          578,
          579,
          537,
          579,
          580,
          537,
          580,
          581,
          537,
          581,
          582,
          537,
          582,
          583,
          537,
          583,
          584,
          537,
          584,
          585,
          537,
          585,
          586,
          537,
          586,
          587,
          537,
          587,
          588,
          537,
          588,
          589,
          537,
          589,
          590,
          537,
          590,
          591,
          537,
          591,
          592,
          537,
          592,
          593,
          537,
          593,
          594,
          537,
          594,
          595,
          537,
          595,
          596,
          537,
          596,
          597
        ]
      }
    ],
    surfaces: [
      {
        id: "shared-apron-solid-bank",
        kind: "bank",
        vertices: [
          {
            x: 6.1632886340351565,
            y: -899999e-8,
            z: -0.9135008043613282
          },
          {
            x: 6.171727869156067,
            y: -899999e-8,
            z: -0.8888441487845764
          },
          {
            x: 6.178778290442872,
            y: -899999e-8,
            z: -0.8630777839128417
          },
          {
            x: 6.184508696556091,
            y: -899999e-8,
            z: -0.8362708048820495
          },
          {
            x: 6.188987886156251,
            y: -899999e-8,
            z: -0.808492306828125
          },
          {
            x: 6.19228465790387,
            y: -899999e-8,
            z: -0.7798113848869934
          },
          {
            x: 6.194467810459473,
            y: -899999e-8,
            z: -0.7502971341945801
          },
          {
            x: 6.195606142483582,
            y: -899999e-8,
            z: -0.7200186498868103
          },
          {
            x: 6.1957684526367185,
            y: -899999e-8,
            z: -0.6890450270996094
          },
          {
            x: 6.195023539579408,
            y: -899999e-8,
            z: -0.6574453609689026
          },
          {
            x: 6.193440201972169,
            y: -899999e-8,
            z: -0.6252887466306152
          },
          {
            x: 6.191087238475525,
            y: -899999e-8,
            z: -0.5926442792206726
          },
          {
            x: 6.1880334477500005,
            y: -899999e-8,
            z: -0.559581053875
          },
          {
            x: 6.184347628456115,
            y: -899999e-8,
            z: -0.5261681657295227
          },
          {
            x: 6.180098579254395,
            y: -899999e-8,
            z: -0.49247470992016595
          },
          {
            x: 6.175355098805359,
            y: -899999e-8,
            z: -0.4585697815828553
          },
          {
            x: 6.170185985769532,
            y: -899999e-8,
            z: -0.42452247585351566
          },
          {
            x: 6.164660038807434,
            y: -899999e-8,
            z: -0.39040188786807245
          },
          {
            x: 6.1588460565795895,
            y: -899999e-8,
            z: -0.35627711276245116
          },
          {
            x: 6.152812837746522,
            y: -899999e-8,
            z: -0.32221724567257687
          },
          {
            x: 6.14662918096875,
            y: -899999e-8,
            z: -0.288291381734375
          },
          {
            x: 6.140363884906799,
            y: -899999e-8,
            z: -0.2545686160837708
          },
          {
            x: 6.134085748221191,
            y: -899999e-8,
            z: -0.22111804385668946
          },
          {
            x: 6.127863569572448,
            y: -899999e-8,
            z: -0.18800876018905638
          },
          {
            x: 6.121766147621093,
            y: -899999e-8,
            z: -0.15530986021679688
          },
          {
            x: 6.115862281027649,
            y: -899999e-8,
            z: -0.12309043907583617
          },
          {
            x: 6.110220768452637,
            y: -899999e-8,
            z: -0.0914195919020996
          },
          {
            x: 6.104910408556579,
            y: -899999e-8,
            z: -0.06036641383151245
          },
          {
            x: 6.1,
            y: -899999e-8,
            z: -0.03
          },
          {
            x: 6.093614807128905,
            y: -899999e-8,
            z: 0.015889282226562502
          },
          {
            x: 6.08759033203125,
            y: -899999e-8,
            z: 0.06348144531250001
          },
          {
            x: 6.081935729980469,
            y: -899999e-8,
            z: 0.11266296386718751
          },
          {
            x: 6.07666015625,
            y: -899999e-8,
            z: 0.1633203125
          },
          {
            x: 6.0717727661132805,
            y: -899999e-8,
            z: 0.2153399658203125
          },
          {
            x: 6.067282714843751,
            y: -899999e-8,
            z: 0.26860839843750006
          },
          {
            x: 6.063199157714844,
            y: -899999e-8,
            z: 0.3230120849609375
          },
          {
            x: 6.05953125,
            y: -899999e-8,
            z: 0.3784375
          },
          {
            x: 6.056288146972657,
            y: -899999e-8,
            z: 0.4347711181640625
          },
          {
            x: 6.05347900390625,
            y: -899999e-8,
            z: 0.49189941406250004
          },
          {
            x: 6.051112976074219,
            y: -899999e-8,
            z: 0.5497088623046875
          },
          {
            x: 6.049199218749999,
            y: -899999e-8,
            z: 0.6080859375
          },
          {
            x: 6.0477468872070315,
            y: -899999e-8,
            z: 0.6669171142578125
          },
          {
            x: 6.04676513671875,
            y: -899999e-8,
            z: 0.7260888671875
          },
          {
            x: 6.046263122558594,
            y: -899999e-8,
            z: 0.7854876708984375
          },
          {
            x: 6.04625,
            y: -899999e-8,
            z: 0.845
          },
          {
            x: 6.0467349243164055,
            y: -899999e-8,
            z: 0.9045123291015625
          },
          {
            x: 6.0477270507812495,
            y: -899999e-8,
            z: 0.9639111328124998
          },
          {
            x: 6.049235534667968,
            y: -899999e-8,
            z: 1.0230828857421876
          },
          {
            x: 6.05126953125,
            y: -899999e-8,
            z: 1.0819140625
          },
          {
            x: 6.053838195800782,
            y: -899999e-8,
            z: 1.1402911376953124
          },
          {
            x: 6.05695068359375,
            y: -899999e-8,
            z: 1.1981005859375
          },
          {
            x: 6.060616149902343,
            y: -899999e-8,
            z: 1.2552288818359374
          },
          {
            x: 6.06484375,
            y: -899999e-8,
            z: 1.3115625
          },
          {
            x: 6.069642639160156,
            y: -899999e-8,
            z: 1.3669879150390625
          },
          {
            x: 6.07502197265625,
            y: -899999e-8,
            z: 1.4213916015625
          },
          {
            x: 6.080990905761719,
            y: -899999e-8,
            z: 1.4746600341796876
          },
          {
            x: 6.08755859375,
            y: -899999e-8,
            z: 1.5266796875000002
          },
          {
            x: 6.094734191894531,
            y: -899999e-8,
            z: 1.5773370361328125
          },
          {
            x: 6.10252685546875,
            y: -899999e-8,
            z: 1.6265185546875
          },
          {
            x: 6.110945739746094,
            y: -899999e-8,
            z: 1.6741107177734373
          },
          {
            x: 6.12,
            y: -899999e-8,
            z: 1.72
          },
          {
            x: 6.127033996582031,
            y: -899999e-8,
            z: 1.750769805908203
          },
          {
            x: 6.135021972656251,
            y: -899999e-8,
            z: 1.780299072265625
          },
          {
            x: 6.143980407714842,
            y: -899999e-8,
            z: 1.8086363220214845
          },
          {
            x: 6.153925781250001,
            y: -899999e-8,
            z: 1.8358300781250003
          },
          {
            x: 6.164874572753907,
            y: -899999e-8,
            z: 1.8619288635253908
          },
          {
            x: 6.176843261718749,
            y: -899999e-8,
            z: 1.8869812011718752
          },
          {
            x: 6.189848327636719,
            y: -899999e-8,
            z: 1.911035614013672
          },
          {
            x: 6.203906249999999,
            y: -899999e-8,
            z: 1.9341406250000002
          },
          {
            x: 6.2190335083007815,
            y: -899999e-8,
            z: 1.956344757080078
          },
          {
            x: 6.23524658203125,
            y: -899999e-8,
            z: 1.977696533203125
          },
          {
            x: 6.252561950683594,
            y: -899999e-8,
            z: 1.9982444763183593
          },
          {
            x: 6.27099609375,
            y: -899999e-8,
            z: 2.0180371093750002
          },
          {
            x: 6.290565490722656,
            y: -899999e-8,
            z: 2.0371229553222654
          },
          {
            x: 6.311286621093751,
            y: -899999e-8,
            z: 2.055550537109375
          },
          {
            x: 6.333175964355469,
            y: -899999e-8,
            z: 2.073368377685547
          },
          {
            x: 6.35625,
            y: -899999e-8,
            z: 2.090625
          },
          {
            x: 6.380525207519532,
            y: -899999e-8,
            z: 2.1073689270019536
          },
          {
            x: 6.406018066406251,
            y: -899999e-8,
            z: 2.123648681640625
          },
          {
            x: 6.432745056152344,
            y: -899999e-8,
            z: 2.1395127868652346
          },
          {
            x: 6.460722656250001,
            y: -899999e-8,
            z: 2.155009765625
          },
          {
            x: 6.489967346191406,
            y: -899999e-8,
            z: 2.170188140869141
          },
          {
            x: 6.520495605468749,
            y: -899999e-8,
            z: 2.185096435546875
          },
          {
            x: 6.552323913574218,
            y: -899999e-8,
            z: 2.1997831726074217
          },
          {
            x: 6.58546875,
            y: -899999e-8,
            z: 2.214296875
          },
          {
            x: 6.619946594238281,
            y: -899999e-8,
            z: 2.228686065673828
          },
          {
            x: 6.655773925781251,
            y: -899999e-8,
            z: 2.242999267578125
          },
          {
            x: 6.6929672241210945,
            y: -899999e-8,
            z: 2.2572850036621093
          },
          {
            x: 6.73154296875,
            y: -899999e-8,
            z: 2.271591796875
          },
          {
            x: 6.771517639160156,
            y: -899999e-8,
            z: 2.285968170166016
          },
          {
            x: 6.81290771484375,
            y: -899999e-8,
            z: 2.300462646484375
          },
          {
            x: 6.855729675292969,
            y: -899999e-8,
            z: 2.315123748779297
          },
          {
            x: 6.9,
            y: -899999e-8,
            z: 2.33
          },
          {
            x: 6.961369018554688,
            y: -899999e-8,
            z: 2.3501465148925784
          },
          {
            x: 7.0235693359375,
            y: -899999e-8,
            z: 2.369859619140625
          },
          {
            x: 7.086553344726561,
            y: -899999e-8,
            z: 2.38908090209961
          },
          {
            x: 7.1502734375,
            y: -899999e-8,
            z: 2.4077519531250005
          },
          {
            x: 7.214682006835938,
            y: -899999e-8,
            z: 2.425814361572266
          },
          {
            x: 7.2797314453125,
            y: -899999e-8,
            z: 2.443209716796875
          },
          {
            x: 7.3453741455078125,
            y: -899999e-8,
            z: 2.459879608154297
          },
          {
            x: 7.4115625,
            y: -899999e-8,
            z: 2.475765625
          },
          {
            x: 7.478248901367188,
            y: -899999e-8,
            z: 2.490809356689453
          },
          {
            x: 7.5453857421875,
            y: -899999e-8,
            z: 2.504952392578125
          },
          {
            x: 7.6129254150390615,
            y: -899999e-8,
            z: 2.5181363220214847
          },
          {
            x: 7.6808203125,
            y: -899999e-8,
            z: 2.530302734375
          },
          {
            x: 7.749022827148437,
            y: -899999e-8,
            z: 2.541393218994141
          },
          {
            x: 7.8174853515625005,
            y: -899999e-8,
            z: 2.5513493652343753
          },
          {
            x: 7.886160278320313,
            y: -899999e-8,
            z: 2.560112762451172
          },
          {
            x: 7.954999999999999,
            y: -899999e-8,
            z: 2.567625
          },
          {
            x: 8.023956909179688,
            y: -899999e-8,
            z: 2.573827667236328
          },
          {
            x: 8.092983398437498,
            y: -899999e-8,
            z: 2.5786623535156252
          },
          {
            x: 8.162031860351561,
            y: -899999e-8,
            z: 2.5820706481933593
          },
          {
            x: 8.2310546875,
            y: -899999e-8,
            z: 2.583994140625
          },
          {
            x: 8.300004272460937,
            y: -899999e-8,
            z: 2.5843744201660157
          },
          {
            x: 8.3688330078125,
            y: -899999e-8,
            z: 2.583153076171875
          },
          {
            x: 8.437493286132812,
            y: -899999e-8,
            z: 2.580271697998047
          },
          {
            x: 8.5059375,
            y: -899999e-8,
            z: 2.5756718750000003
          },
          {
            x: 8.574118041992188,
            y: -899999e-8,
            z: 2.5692951965332034
          },
          {
            x: 8.6419873046875,
            y: -899999e-8,
            z: 2.561083251953125
          },
          {
            x: 8.709497680664061,
            y: -899999e-8,
            z: 2.5509776306152343
          },
          {
            x: 8.7766015625,
            y: -899999e-8,
            z: 2.5389199218750003
          },
          {
            x: 8.843251342773437,
            y: -899999e-8,
            z: 2.5248517150878906
          },
          {
            x: 8.909399414062499,
            y: -899999e-8,
            z: 2.508714599609375
          },
          {
            x: 8.97499816894531,
            y: -899999e-8,
            z: 2.490450164794922
          },
          {
            x: 9.04,
            y: -899999e-8,
            z: 2.47
          },
          {
            x: 9.084846496582028,
            y: -899999e-8,
            z: 2.455052795410156
          },
          {
            x: 9.12935791015625,
            y: -899999e-8,
            z: 2.44018798828125
          },
          {
            x: 9.173492126464842,
            y: -899999e-8,
            z: 2.425370788574219
          },
          {
            x: 9.21720703125,
            y: -899999e-8,
            z: 2.4105664062499996
          },
          {
            x: 9.260460510253905,
            y: -899999e-8,
            z: 2.3957400512695313
          },
          {
            x: 9.303210449218748,
            y: -899999e-8,
            z: 2.38085693359375
          },
          {
            x: 9.345414733886718,
            y: -899999e-8,
            z: 2.3658822631835936
          },
          {
            x: 9.38703125,
            y: -899999e-8,
            z: 2.3507812500000003
          },
          {
            x: 9.428017883300782,
            y: -899999e-8,
            z: 2.3355191040039065
          },
          {
            x: 9.468332519531248,
            y: -899999e-8,
            z: 2.3200610351562503
          },
          {
            x: 9.507933044433592,
            y: -899999e-8,
            z: 2.304372253417969
          },
          {
            x: 9.54677734375,
            y: -899999e-8,
            z: 2.28841796875
          },
          {
            x: 9.584823303222656,
            y: -899999e-8,
            z: 2.2721633911132812
          },
          {
            x: 9.62202880859375,
            y: -899999e-8,
            z: 2.25557373046875
          },
          {
            x: 9.658351745605469,
            y: -899999e-8,
            z: 2.238614196777344
          },
          {
            x: 9.693749999999998,
            y: -899999e-8,
            z: 2.22125
          },
          {
            x: 9.728181457519531,
            y: -899999e-8,
            z: 2.203446350097656
          },
          {
            x: 9.76160400390625,
            y: -899999e-8,
            z: 2.18516845703125
          },
          {
            x: 9.793975524902343,
            y: -899999e-8,
            z: 2.166381530761719
          },
          {
            x: 9.82525390625,
            y: -899999e-8,
            z: 2.14705078125
          },
          {
            x: 9.855397033691405,
            y: -899999e-8,
            z: 2.127141418457031
          },
          {
            x: 9.88436279296875,
            y: -899999e-8,
            z: 2.10661865234375
          },
          {
            x: 9.912109069824218,
            y: -899999e-8,
            z: 2.085447692871094
          },
          {
            x: 9.938593749999999,
            y: -899999e-8,
            z: 2.06359375
          },
          {
            x: 9.96377471923828,
            y: -899999e-8,
            z: 2.041022033691406
          },
          {
            x: 9.98760986328125,
            y: -899999e-8,
            z: 2.01769775390625
          },
          {
            x: 10.010057067871093,
            y: -899999e-8,
            z: 1.9935861206054688
          },
          {
            x: 10.03107421875,
            y: -899999e-8,
            z: 1.96865234375
          },
          {
            x: 10.050619201660156,
            y: -899999e-8,
            z: 1.9428616333007813
          },
          {
            x: 10.06864990234375,
            y: -899999e-8,
            z: 1.91617919921875
          },
          {
            x: 10.085124206542968,
            y: -899999e-8,
            z: 1.8885702514648437
          },
          {
            x: 10.1,
            y: -899999e-8,
            z: 1.86
          },
          {
            x: 10.119722167971373,
            y: -899999e-8,
            z: 1.8151988220221251
          },
          {
            x: 10.137695312520995,
            y: -899999e-8,
            z: 1.767196044927002
          },
          {
            x: 10.154004394602111,
            y: -899999e-8,
            z: 1.7162178039723814
          },
          {
            x: 10.168734375167968,
            y: -899999e-8,
            z: 1.6624902344160157
          },
          {
            x: 10.181970215171814,
            y: -899999e-8,
            z: 1.6062394715156556
          },
          {
            x: 10.193796875566894,
            y: -899999e-8,
            z: 1.5476916505290526
          },
          {
            x: 10.204299317306457,
            y: -899999e-8,
            z: 1.4870729067139588
          },
          {
            x: 10.213562501343748,
            y: -899999e-8,
            z: 1.424609375328125
          },
          {
            x: 10.221671388632018,
            y: -899999e-8,
            z: 1.360527191629303
          },
          {
            x: 10.228710940124513,
            y: -899999e-8,
            z: 1.295052490875244
          },
          {
            x: 10.234766116774477,
            y: -899999e-8,
            z: 1.2284114083236999
          },
          {
            x: 10.239921879535157,
            y: -899999e-8,
            z: 1.1608300792324218
          },
          {
            x: 10.244263189359803,
            y: -899999e-8,
            z: 1.0925346388591612
          },
          {
            x: 10.24787500720166,
            y: -899999e-8,
            z: 1.0237512224616698
          },
          {
            x: 10.250842294013976,
            y: -899999e-8,
            z: 0.954705965297699
          },
          {
            x: 10.25325001075,
            y: -899999e-8,
            z: 0.885625002625
          },
          {
            x: 10.255183118362977,
            y: -899999e-8,
            z: 0.8167344697013245
          },
          {
            x: 10.256726577806152,
            y: -899999e-8,
            z: 0.7482605017844238
          },
          {
            x: 10.257965350032775,
            y: -899999e-8,
            z: 0.6804292341320496
          },
          {
            x: 10.258984395996094,
            y: -899999e-8,
            z: 0.6134668020019531
          },
          {
            x: 10.259868676649354,
            y: -899999e-8,
            z: 0.547599340651886
          },
          {
            x: 10.260703152945801,
            y: -899999e-8,
            z: 0.48305298533959956
          },
          {
            x: 10.261572785838684,
            y: -899999e-8,
            z: 0.42005387132284544
          },
          {
            x: 10.262562536281251,
            y: -899999e-8,
            z: 0.35882813385937495
          },
          {
            x: 10.263757365226745,
            y: -899999e-8,
            z: 0.29960190820693966
          },
          {
            x: 10.265242233628417,
            y: -899999e-8,
            z: 0.24260132962329098
          },
          {
            x: 10.267102102439514,
            y: -899999e-8,
            z: 0.18805253336618039
          },
          {
            x: 10.269421932613282,
            y: -899999e-8,
            z: 0.13618165469335936
          },
          {
            x: 10.272286685102966,
            y: -899999e-8,
            z: 0.08721482886257935
          },
          {
            x: 10.275781320861816,
            y: -899999e-8,
            z: 0.0413781911315918
          },
          {
            x: 10.279990800843079,
            y: -899999e-8,
            z: -0.001102123241851806
          },
          {
            x: 10.285000086,
            y: -899999e-8,
            z: -0.039999979
          },
          {
            x: 10.279023266,
            y: -899999e-8,
            z: -0.023814993
          },
          {
            x: 10.273046875,
            y: -899999e-8,
            z: -7630115e-9
          },
          {
            x: 10.267070484,
            y: -899999e-8,
            z: 8554764e-9
          },
          {
            x: 10.255117702,
            y: -899999e-8,
            z: 0.04092452
          },
          {
            x: 10.249140882,
            y: -899999e-8,
            z: 0.057109399
          },
          {
            x: 10.243164063,
            y: -899999e-8,
            z: 0.073294277
          },
          {
            x: 10.237187672,
            y: -899999e-8,
            z: 0.089479156
          },
          {
            x: 10.231211281,
            y: -899999e-8,
            z: 0.105664034
          },
          {
            x: 10.225234461,
            y: -899999e-8,
            z: 0.121848912
          },
          {
            x: 10.219257641,
            y: -899999e-8,
            z: 0.138033791
          },
          {
            x: 10.207304859,
            y: -899999e-8,
            z: 0.170403547
          },
          {
            x: 10.201328039,
            y: -899999e-8,
            z: 0.186588426
          },
          {
            x: 10.195351219,
            y: -899999e-8,
            z: 0.202773304
          },
          {
            x: 10.189374828,
            y: -899999e-8,
            z: 0.218958182
          },
          {
            x: 10.182538843,
            y: -899999e-8,
            z: 0.236314971
          },
          {
            x: 10.175702858,
            y: -899999e-8,
            z: 0.253671761
          },
          {
            x: 10.168866873,
            y: -899999e-8,
            z: 0.271028442
          },
          {
            x: 10.162030888,
            y: -899999e-8,
            z: 0.288385231
          },
          {
            x: 10.155194902,
            y: -899999e-8,
            z: 0.305742021
          },
          {
            x: 10.148358917,
            y: -899999e-8,
            z: 0.323098702
          },
          {
            x: 10.141522932,
            y: -899999e-8,
            z: 0.340455492
          },
          {
            x: 10.121014977,
            y: -899999e-8,
            z: 0.392525859
          },
          {
            x: 10.114178991,
            y: -899999e-8,
            z: 0.409882648
          },
          {
            x: 10.093671036,
            y: -899999e-8,
            z: 0.461953015
          },
          {
            x: 10.08683548,
            y: -899999e-8,
            z: 0.479309697
          },
          {
            x: 10.079999495,
            y: -899999e-8,
            z: 0.496666486
          },
          {
            x: 10.072070026,
            y: -899999e-8,
            z: 0.514101381
          },
          {
            x: 10.064140129,
            y: -899999e-8,
            z: 0.531536384
          },
          {
            x: 10.056210232,
            y: -899999e-8,
            z: 0.548971279
          },
          {
            x: 10.048280764,
            y: -899999e-8,
            z: 0.566406174
          },
          {
            x: 10.040351295,
            y: -899999e-8,
            z: 0.583841069
          },
          {
            x: 10.024491501,
            y: -899999e-8,
            z: 0.618710859
          },
          {
            x: 10.008632565,
            y: -899999e-8,
            z: 0.653580649
          },
          {
            x: 10.000702667,
            y: -899999e-8,
            z: 0.671015544
          },
          {
            x: 9.99277277,
            y: -899999e-8,
            z: 0.688450439
          },
          {
            x: 9.976913834,
            y: -899999e-8,
            z: 0.723320229
          },
          {
            x: 9.968983936,
            y: -899999e-8,
            z: 0.740755124
          },
          {
            x: 9.961054039,
            y: -899999e-8,
            z: 0.758190019
          },
          {
            x: 9.953124571,
            y: -899999e-8,
            z: 0.775624914
          },
          {
            x: 9.943866444,
            y: -899999e-8,
            z: 0.79204411
          },
          {
            x: 9.934608746,
            y: -899999e-8,
            z: 0.808463306
          },
          {
            x: 9.925351048,
            y: -899999e-8,
            z: 0.824882717
          },
          {
            x: 9.916093349,
            y: -899999e-8,
            z: 0.841301913
          },
          {
            x: 9.906835651,
            y: -899999e-8,
            z: 0.857721109
          },
          {
            x: 9.897577953,
            y: -899999e-8,
            z: 0.87414052
          },
          {
            x: 9.879062557,
            y: -899999e-8,
            z: 0.906978912
          },
          {
            x: 9.869804859,
            y: -899999e-8,
            z: 0.923398323
          },
          {
            x: 9.851289463,
            y: -899999e-8,
            z: 0.956236715
          },
          {
            x: 9.842031336,
            y: -899999e-8,
            z: 0.972656126
          },
          {
            x: 9.832773209,
            y: -899999e-8,
            z: 0.989075322
          },
          {
            x: 9.823515511,
            y: -899999e-8,
            z: 1.005494518
          },
          {
            x: 9.814257813,
            y: -899999e-8,
            z: 1.021913929
          },
          {
            x: 9.805000114,
            y: -899999e-8,
            z: 1.038333125
          },
          {
            x: 9.794179869,
            y: -899999e-8,
            z: 1.052643032
          },
          {
            x: 9.783359623,
            y: -899999e-8,
            z: 1.066953154
          },
          {
            x: 9.772538948,
            y: -899999e-8,
            z: 1.081263061
          },
          {
            x: 9.761718702,
            y: -899999e-8,
            z: 1.095572968
          },
          {
            x: 9.750898457,
            y: -899999e-8,
            z: 1.109882874
          },
          {
            x: 9.740077782,
            y: -899999e-8,
            z: 1.124192781
          },
          {
            x: 9.707617044,
            y: -899999e-8,
            z: 1.167122502
          },
          {
            x: 9.696796799,
            y: -899999e-8,
            z: 1.181432409
          },
          {
            x: 9.664336061,
            y: -899999e-8,
            z: 1.22436213
          },
          {
            x: 9.653515816,
            y: -899999e-8,
            z: 1.238672037
          },
          {
            x: 9.642695141,
            y: -899999e-8,
            z: 1.252981944
          },
          {
            x: 9.631874895,
            y: -899999e-8,
            z: 1.267291851
          },
          {
            x: 9.619257355,
            y: -899999e-8,
            z: 1.278398557
          },
          {
            x: 9.606640244,
            y: -899999e-8,
            z: 1.289505262
          },
          {
            x: 9.594023132,
            y: -899999e-8,
            z: 1.300612183
          },
          {
            x: 9.581406021,
            y: -899999e-8,
            z: 1.311718888
          },
          {
            x: 9.56878891,
            y: -899999e-8,
            z: 1.322825594
          },
          {
            x: 9.556171799,
            y: -899999e-8,
            z: 1.333932514
          },
          {
            x: 9.543554688,
            y: -899999e-8,
            z: 1.34503922
          },
          {
            x: 9.530937576,
            y: -899999e-8,
            z: 1.356145926
          },
          {
            x: 9.518320465,
            y: -899999e-8,
            z: 1.367252631
          },
          {
            x: 9.505703354,
            y: -899999e-8,
            z: 1.378359337
          },
          {
            x: 9.493086243,
            y: -899999e-8,
            z: 1.389466257
          },
          {
            x: 9.480468702,
            y: -899999e-8,
            z: 1.400572963
          },
          {
            x: 9.467851162,
            y: -899999e-8,
            z: 1.411679668
          },
          {
            x: 9.455234051,
            y: -899999e-8,
            z: 1.422786589
          },
          {
            x: 9.44261694,
            y: -899999e-8,
            z: 1.433893294
          },
          {
            x: 9.429999828,
            y: -899999e-8,
            z: 1.445
          },
          {
            x: 9.414550734,
            y: -899999e-8,
            z: 1.453020878
          },
          {
            x: 9.399101639,
            y: -899999e-8,
            z: 1.461041756
          },
          {
            x: 9.383652115,
            y: -899999e-8,
            z: 1.469062634
          },
          {
            x: 9.352753925,
            y: -899999e-8,
            z: 1.48510396
          },
          {
            x: 9.337304401,
            y: -899999e-8,
            z: 1.493124838
          },
          {
            x: 9.321855307,
            y: -899999e-8,
            z: 1.501145716
          },
          {
            x: 9.306406212,
            y: -899999e-8,
            z: 1.509166594
          },
          {
            x: 9.290956688,
            y: -899999e-8,
            z: 1.517187471
          },
          {
            x: 9.260058498,
            y: -899999e-8,
            z: 1.533229227
          },
          {
            x: 9.244609189,
            y: -899999e-8,
            z: 1.54124989
          },
          {
            x: 9.22915988,
            y: -899999e-8,
            z: 1.549270554
          },
          {
            x: 9.213710785,
            y: -899999e-8,
            z: 1.557291431
          },
          {
            x: 9.198261476,
            y: -899999e-8,
            z: 1.565312309
          },
          {
            x: 9.182812166,
            y: -899999e-8,
            z: 1.573333187
          },
          {
            x: 9.164511347,
            y: -899999e-8,
            z: 1.579166455
          },
          {
            x: 9.146210527,
            y: -899999e-8,
            z: 1.584999723
          },
          {
            x: 9.127909708,
            y: -899999e-8,
            z: 1.590833206
          },
          {
            x: 9.109609103,
            y: -899999e-8,
            z: 1.596666474
          },
          {
            x: 9.091308498,
            y: -899999e-8,
            z: 1.602499743
          },
          {
            x: 9.073007679,
            y: -899999e-8,
            z: 1.608333225
          },
          {
            x: 9.05470686,
            y: -899999e-8,
            z: 1.614166493
          },
          {
            x: 9.03640604,
            y: -899999e-8,
            z: 1.619999762
          },
          {
            x: 9.018105221,
            y: -899999e-8,
            z: 1.625833244
          },
          {
            x: 8.999804401,
            y: -899999e-8,
            z: 1.631666512
          },
          {
            x: 8.981503582,
            y: -899999e-8,
            z: 1.637499781
          },
          {
            x: 8.963202977,
            y: -899999e-8,
            z: 1.643333263
          },
          {
            x: 8.944902372,
            y: -899999e-8,
            z: 1.649166532
          },
          {
            x: 8.926601553,
            y: -899999e-8,
            z: 1.6549998
          },
          {
            x: 8.908300734,
            y: -899999e-8,
            z: 1.660833282
          },
          {
            x: 8.889999914,
            y: -899999e-8,
            z: 1.666666551
          },
          {
            x: 8.870136547,
            y: -899999e-8,
            z: 1.67039053
          },
          {
            x: 8.850273395,
            y: -899999e-8,
            z: 1.674114509
          },
          {
            x: 8.830410242,
            y: -899999e-8,
            z: 1.677838488
          },
          {
            x: 8.790683508,
            y: -899999e-8,
            z: 1.685286446
          },
          {
            x: 8.770820355,
            y: -899999e-8,
            z: 1.689010425
          },
          {
            x: 8.750957203,
            y: -899999e-8,
            z: 1.692734404
          },
          {
            x: 8.711230469,
            y: -899999e-8,
            z: 1.700182362
          },
          {
            x: 8.691367316,
            y: -899999e-8,
            z: 1.703906341
          },
          {
            x: 8.671504164,
            y: -899999e-8,
            z: 1.70763032
          },
          {
            x: 8.611914063,
            y: -899999e-8,
            z: 1.718802257
          },
          {
            x: 8.592050695,
            y: -899999e-8,
            z: 1.722526236
          },
          {
            x: 8.572187543,
            y: -899999e-8,
            z: 1.726250215
          },
          {
            x: 8.55205102,
            y: -899999e-8,
            z: 1.72794301
          },
          {
            x: 8.531914282,
            y: -899999e-8,
            z: 1.729635592
          },
          {
            x: 8.511777544,
            y: -899999e-8,
            z: 1.731328173
          },
          {
            x: 8.491640806,
            y: -899999e-8,
            z: 1.733020968
          },
          {
            x: 8.471504068,
            y: -899999e-8,
            z: 1.734713764
          },
          {
            x: 8.451367331,
            y: -899999e-8,
            z: 1.736406345
          },
          {
            x: 8.431230593,
            y: -899999e-8,
            z: 1.738098927
          },
          {
            x: 8.411093855,
            y: -899999e-8,
            z: 1.739791722
          },
          {
            x: 8.390957117,
            y: -899999e-8,
            z: 1.741484518
          },
          {
            x: 8.350683641,
            y: -899999e-8,
            z: 1.74486968
          },
          {
            x: 8.330546904,
            y: -899999e-8,
            z: 1.746562476
          },
          {
            x: 8.310410166,
            y: -899999e-8,
            z: 1.748255272
          },
          {
            x: 8.27013669,
            y: -899999e-8,
            z: 1.751640434
          },
          {
            x: 8.249999952,
            y: -899999e-8,
            z: 1.75333323
          },
          {
            x: 8.230878806,
            y: -899999e-8,
            z: 1.753072948
          },
          {
            x: 8.21175766,
            y: -899999e-8,
            z: 1.752812452
          },
          {
            x: 8.192636728,
            y: -899999e-8,
            z: 1.752551956
          },
          {
            x: 8.154394436,
            y: -899999e-8,
            z: 1.752030964
          },
          {
            x: 8.135273504,
            y: -899999e-8,
            z: 1.751770682
          },
          {
            x: 8.116152358,
            y: -899999e-8,
            z: 1.751510401
          },
          {
            x: 8.097031212,
            y: -899999e-8,
            z: 1.751249905
          },
          {
            x: 8.077910066,
            y: -899999e-8,
            z: 1.750989408
          },
          {
            x: 8.058788919,
            y: -899999e-8,
            z: 1.750729127
          },
          {
            x: 8.039667988,
            y: -899999e-8,
            z: 1.750468845
          },
          {
            x: 8.001425695,
            y: -899999e-8,
            z: 1.749947853
          },
          {
            x: 7.982304764,
            y: -899999e-8,
            z: 1.749687357
          },
          {
            x: 7.963183618,
            y: -899999e-8,
            z: 1.749426861
          },
          {
            x: 7.944062471,
            y: -899999e-8,
            z: 1.749166579
          },
          {
            x: 7.927246094,
            y: -899999e-8,
            z: 1.747031326
          },
          {
            x: 7.910429716,
            y: -899999e-8,
            z: 1.744895859
          },
          {
            x: 7.893613338,
            y: -899999e-8,
            z: 1.742760391
          },
          {
            x: 7.876796961,
            y: -899999e-8,
            z: 1.740624924
          },
          {
            x: 7.859980583,
            y: -899999e-8,
            z: 1.738489456
          },
          {
            x: 7.843164206,
            y: -899999e-8,
            z: 1.736353989
          },
          {
            x: 7.826347828,
            y: -899999e-8,
            z: 1.734218521
          },
          {
            x: 7.809531236,
            y: -899999e-8,
            z: 1.732083268
          },
          {
            x: 7.792714643,
            y: -899999e-8,
            z: 1.729948015
          },
          {
            x: 7.775898266,
            y: -899999e-8,
            z: 1.727812548
          },
          {
            x: 7.759081888,
            y: -899999e-8,
            z: 1.72567708
          },
          {
            x: 7.742265511,
            y: -899999e-8,
            z: 1.723541613
          },
          {
            x: 7.725449133,
            y: -899999e-8,
            z: 1.721406145
          },
          {
            x: 7.708632755,
            y: -899999e-8,
            z: 1.719270678
          },
          {
            x: 7.691816378,
            y: -899999e-8,
            z: 1.71713521
          },
          {
            x: 7.675,
            y: -899999e-8,
            z: 1.714999957
          },
          {
            x: 7.659752607,
            y: -899999e-8,
            z: 1.710358019
          },
          {
            x: 7.644505215,
            y: -899999e-8,
            z: 1.705715866
          },
          {
            x: 7.614010429,
            y: -899999e-8,
            z: 1.69643199
          },
          {
            x: 7.598763037,
            y: -899999e-8,
            z: 1.691790051
          },
          {
            x: 7.568268251,
            y: -899999e-8,
            z: 1.682506175
          },
          {
            x: 7.553020859,
            y: -899999e-8,
            z: 1.677864237
          },
          {
            x: 7.537773466,
            y: -899999e-8,
            z: 1.673222299
          },
          {
            x: 7.522526073,
            y: -899999e-8,
            z: 1.66858036
          },
          {
            x: 7.507278681,
            y: -899999e-8,
            z: 1.663938422
          },
          {
            x: 7.476783895,
            y: -899999e-8,
            z: 1.654654546
          },
          {
            x: 7.461536503,
            y: -899999e-8,
            z: 1.650012608
          },
          {
            x: 7.44628911,
            y: -899999e-8,
            z: 1.645370669
          },
          {
            x: 7.431041718,
            y: -899999e-8,
            z: 1.640728731
          },
          {
            x: 7.416184962,
            y: -899999e-8,
            z: 1.633391495
          },
          {
            x: 7.401328206,
            y: -899999e-8,
            z: 1.626054258
          },
          {
            x: 7.386471343,
            y: -899999e-8,
            z: 1.618717022
          },
          {
            x: 7.371614587,
            y: -899999e-8,
            z: 1.611379786
          },
          {
            x: 7.356757832,
            y: -899999e-8,
            z: 1.604042549
          },
          {
            x: 7.341900969,
            y: -899999e-8,
            z: 1.596705313
          },
          {
            x: 7.327044213,
            y: -899999e-8,
            z: 1.589368076
          },
          {
            x: 7.312187457,
            y: -899999e-8,
            z: 1.582031054
          },
          {
            x: 7.297330701,
            y: -899999e-8,
            z: 1.574694033
          },
          {
            x: 7.282473946,
            y: -899999e-8,
            z: 1.567356796
          },
          {
            x: 7.267617083,
            y: -899999e-8,
            z: 1.56001956
          },
          {
            x: 7.252760327,
            y: -899999e-8,
            z: 1.552682323
          },
          {
            x: 7.237903571,
            y: -899999e-8,
            z: 1.545345087
          },
          {
            x: 7.223046708,
            y: -899999e-8,
            z: 1.538007851
          },
          {
            x: 7.208189952,
            y: -899999e-8,
            z: 1.530670614
          },
          {
            x: 7.193333197,
            y: -899999e-8,
            z: 1.523333378
          },
          {
            x: 7.179492033,
            y: -899999e-8,
            z: 1.514043064
          },
          {
            x: 7.165650868,
            y: -899999e-8,
            z: 1.50475275
          },
          {
            x: 7.151809812,
            y: -899999e-8,
            z: 1.495462437
          },
          {
            x: 7.137968647,
            y: -899999e-8,
            z: 1.486171908
          },
          {
            x: 7.124127483,
            y: -899999e-8,
            z: 1.47688138
          },
          {
            x: 7.110286427,
            y: -899999e-8,
            z: 1.467591066
          },
          {
            x: 7.096445262,
            y: -899999e-8,
            z: 1.458300753
          },
          {
            x: 7.068762934,
            y: -899999e-8,
            z: 1.439720125
          },
          {
            x: 7.05492177,
            y: -899999e-8,
            z: 1.430429597
          },
          {
            x: 7.041080713,
            y: -899999e-8,
            z: 1.421139069
          },
          {
            x: 7.013398385,
            y: -899999e-8,
            z: 1.402558441
          },
          {
            x: 6.999557328,
            y: -899999e-8,
            z: 1.393268127
          },
          {
            x: 6.985716164,
            y: -899999e-8,
            z: 1.383977814
          },
          {
            x: 6.971875,
            y: -899999e-8,
            z: 1.374687285
          },
          {
            x: 6.959674489,
            y: -899999e-8,
            z: 1.364186115
          },
          {
            x: 6.947473979,
            y: -899999e-8,
            z: 1.353684731
          },
          {
            x: 6.935273468,
            y: -899999e-8,
            z: 1.343183346
          },
          {
            x: 6.923072958,
            y: -899999e-8,
            z: 1.332681961
          },
          {
            x: 6.910872447,
            y: -899999e-8,
            z: 1.322180576
          },
          {
            x: 6.898671937,
            y: -899999e-8,
            z: 1.311679406
          },
          {
            x: 6.886471319,
            y: -899999e-8,
            z: 1.301178236
          },
          {
            x: 6.874270809,
            y: -899999e-8,
            z: 1.290676851
          },
          {
            x: 6.862070298,
            y: -899999e-8,
            z: 1.280175467
          },
          {
            x: 6.84986968,
            y: -899999e-8,
            z: 1.269674296
          },
          {
            x: 6.83766917,
            y: -899999e-8,
            z: 1.259173126
          },
          {
            x: 6.825468659,
            y: -899999e-8,
            z: 1.248671741
          },
          {
            x: 6.813268149,
            y: -899999e-8,
            z: 1.238170357
          },
          {
            x: 6.801067638,
            y: -899999e-8,
            z: 1.227668972
          },
          {
            x: 6.788867128,
            y: -899999e-8,
            z: 1.217167587
          },
          {
            x: 6.776666617,
            y: -899999e-8,
            z: 1.206666417
          },
          {
            x: 6.766731715,
            y: -899999e-8,
            z: 1.195696182
          },
          {
            x: 6.746861911,
            y: -899999e-8,
            z: 1.173756142
          },
          {
            x: 6.736927009,
            y: -899999e-8,
            z: 1.162786121
          },
          {
            x: 6.726992106,
            y: -899999e-8,
            z: 1.151816101
          },
          {
            x: 6.717057204,
            y: -899999e-8,
            z: 1.140846081
          },
          {
            x: 6.707122302,
            y: -899999e-8,
            z: 1.12987606
          },
          {
            x: 6.687252712,
            y: -899999e-8,
            z: 1.10793602
          },
          {
            x: 6.67731781,
            y: -899999e-8,
            z: 1.096966
          },
          {
            x: 6.667382908,
            y: -899999e-8,
            z: 1.085995979
          },
          {
            x: 6.657448006,
            y: -899999e-8,
            z: 1.075025959
          },
          {
            x: 6.647513103,
            y: -899999e-8,
            z: 1.064055939
          },
          {
            x: 6.637578201,
            y: -899999e-8,
            z: 1.053085918
          },
          {
            x: 6.627643299,
            y: -899999e-8,
            z: 1.042115898
          },
          {
            x: 6.617708397,
            y: -899999e-8,
            z: 1.031145663
          },
          {
            x: 6.610664058,
            y: -899999e-8,
            z: 1.020449228
          },
          {
            x: 6.603619826,
            y: -899999e-8,
            z: 1.009752579
          },
          {
            x: 6.596575594,
            y: -899999e-8,
            z: 0.999055929
          },
          {
            x: 6.589531255,
            y: -899999e-8,
            z: 0.98835928
          },
          {
            x: 6.582487023,
            y: -899999e-8,
            z: 0.97766263
          },
          {
            x: 6.575442791,
            y: -899999e-8,
            z: 0.966965981
          },
          {
            x: 6.568398452,
            y: -899999e-8,
            z: 0.956269331
          },
          {
            x: 6.56135422,
            y: -899999e-8,
            z: 0.945572681
          },
          {
            x: 6.554309988,
            y: -899999e-8,
            z: 0.934876032
          },
          {
            x: 6.547265649,
            y: -899999e-8,
            z: 0.924179382
          },
          {
            x: 6.540221363,
            y: -899999e-8,
            z: 0.913482733
          },
          {
            x: 6.533177078,
            y: -899999e-8,
            z: 0.902786298
          },
          {
            x: 6.526132792,
            y: -899999e-8,
            z: 0.892089863
          },
          {
            x: 6.519088507,
            y: -899999e-8,
            z: 0.881393213
          },
          {
            x: 6.512044275,
            y: -899999e-8,
            z: 0.870696564
          },
          {
            x: 6.504999989,
            y: -899999e-8,
            z: 0.859999914
          },
          {
            x: 6.502190697,
            y: -899999e-8,
            z: 0.849029894
          },
          {
            x: 6.499381459,
            y: -899999e-8,
            z: 0.838059874
          },
          {
            x: 6.49657222,
            y: -899999e-8,
            z: 0.827089853
          },
          {
            x: 6.493762982,
            y: -899999e-8,
            z: 0.816119833
          },
          {
            x: 6.490953743,
            y: -899999e-8,
            z: 0.805149813
          },
          {
            x: 6.488144505,
            y: -899999e-8,
            z: 0.794179792
          },
          {
            x: 6.485335267,
            y: -899999e-8,
            z: 0.783209772
          },
          {
            x: 6.482526028,
            y: -899999e-8,
            z: 0.772239537
          },
          {
            x: 6.47971679,
            y: -899999e-8,
            z: 0.761269517
          },
          {
            x: 6.476907551,
            y: -899999e-8,
            z: 0.750299497
          },
          {
            x: 6.474098313,
            y: -899999e-8,
            z: 0.739329476
          },
          {
            x: 6.471289074,
            y: -899999e-8,
            z: 0.728359349
          },
          {
            x: 6.468479836,
            y: -899999e-8,
            z: 0.717389221
          },
          {
            x: 6.465670598,
            y: -899999e-8,
            z: 0.706419201
          },
          {
            x: 6.462861359,
            y: -899999e-8,
            z: 0.695449181
          },
          {
            x: 6.460052067,
            y: -899999e-8,
            z: 0.68447916
          },
          {
            x: 6.461246777,
            y: -899999e-8,
            z: 0.672532601
          },
          {
            x: 6.462441432,
            y: -899999e-8,
            z: 0.660585935
          },
          {
            x: 6.463636088,
            y: -899999e-8,
            z: 0.648639269
          },
          {
            x: 6.4660254,
            y: -899999e-8,
            z: 0.624746151
          },
          {
            x: 6.467220056,
            y: -899999e-8,
            z: 0.612799485
          },
          {
            x: 6.468414712,
            y: -899999e-8,
            z: 0.600852818
          },
          {
            x: 6.469609368,
            y: -899999e-8,
            z: 0.58890626
          },
          {
            x: 6.470804024,
            y: -899999e-8,
            z: 0.576959701
          },
          {
            x: 6.47199868,
            y: -899999e-8,
            z: 0.565013034
          },
          {
            x: 6.473193336,
            y: -899999e-8,
            z: 0.553066368
          },
          {
            x: 6.474387991,
            y: -899999e-8,
            z: 0.541119809
          },
          {
            x: 6.475582647,
            y: -899999e-8,
            z: 0.52917325
          },
          {
            x: 6.477971959,
            y: -899999e-8,
            z: 0.505279918
          },
          {
            x: 6.479166669,
            y: -899999e-8,
            z: 0.493333359
          },
          {
            x: 6.482626987,
            y: -899999e-8,
            z: 0.48091795
          },
          {
            x: 6.489547515,
            y: -899999e-8,
            z: 0.456087346
          },
          {
            x: 6.496468043,
            y: -899999e-8,
            z: 0.431256528
          },
          {
            x: 6.503388679,
            y: -899999e-8,
            z: 0.406425924
          },
          {
            x: 6.510309207,
            y: -899999e-8,
            z: 0.381595106
          },
          {
            x: 6.513769525,
            y: -899999e-8,
            z: 0.369179804
          },
          {
            x: 6.517229843,
            y: -899999e-8,
            z: 0.356764503
          },
          {
            x: 6.520690107,
            y: -899999e-8,
            z: 0.344349093
          },
          {
            x: 6.524150372,
            y: -899999e-8,
            z: 0.331933684
          },
          {
            x: 6.527610689,
            y: -899999e-8,
            z: 0.319518275
          },
          {
            x: 6.531071007,
            y: -899999e-8,
            z: 0.307102866
          },
          {
            x: 6.534531271,
            y: -899999e-8,
            z: 0.294687564
          },
          {
            x: 6.538518858,
            y: -899999e-8,
            z: 0.282311316
          },
          {
            x: 6.542506498,
            y: -899999e-8,
            z: 0.269934959
          },
          {
            x: 6.546494138,
            y: -899999e-8,
            z: 0.257558603
          },
          {
            x: 6.550481725,
            y: -899999e-8,
            z: 0.245182354
          },
          {
            x: 6.554469419,
            y: -899999e-8,
            z: 0.232806106
          },
          {
            x: 6.558457005,
            y: -899999e-8,
            z: 0.220429749
          },
          {
            x: 6.562444592,
            y: -899999e-8,
            z: 0.208053393
          },
          {
            x: 6.566432285,
            y: -899999e-8,
            z: 0.195677145
          },
          {
            x: 6.570419979,
            y: -899999e-8,
            z: 0.183300896
          },
          {
            x: 6.574407566,
            y: -899999e-8,
            z: 0.17092454
          },
          {
            x: 6.578395152,
            y: -899999e-8,
            z: 0.158548183
          },
          {
            x: 6.582382846,
            y: -899999e-8,
            z: 0.146171935
          },
          {
            x: 6.58637054,
            y: -899999e-8,
            z: 0.133795686
          },
          {
            x: 6.590358126,
            y: -899999e-8,
            z: 0.12141933
          },
          {
            x: 6.594345713,
            y: -899999e-8,
            z: 0.109042974
          },
          {
            x: 6.598333406,
            y: -899999e-8,
            z: 0.096666725
          },
          {
            x: 6.601110029,
            y: -899999e-8,
            z: 0.084837217
          },
          {
            x: 6.606663489,
            y: -899999e-8,
            z: 0.061178417
          },
          {
            x: 6.609440112,
            y: -899999e-8,
            z: 0.049349017
          },
          {
            x: 6.612216842,
            y: -899999e-8,
            z: 0.037519617
          },
          {
            x: 6.614993572,
            y: -899999e-8,
            z: 0.02569011
          },
          {
            x: 6.617770195,
            y: -899999e-8,
            z: 0.013860602
          },
          {
            x: 6.623323655,
            y: -899999e-8,
            z: -9798198e-9
          },
          {
            x: 6.626100278,
            y: -899999e-8,
            z: -0.021627598
          },
          {
            x: 6.628877008,
            y: -899999e-8,
            z: -0.033456998
          },
          {
            x: 6.631653738,
            y: -899999e-8,
            z: -0.045286505
          },
          {
            x: 6.634430361,
            y: -899999e-8,
            z: -0.057116013
          },
          {
            x: 6.639983821,
            y: -899999e-8,
            z: -0.080774813
          },
          {
            x: 6.642760444,
            y: -899999e-8,
            z: -0.092604213
          },
          {
            x: 6.642415404,
            y: -899999e-8,
            z: -0.114153724
          },
          {
            x: 6.642242885,
            y: -899999e-8,
            z: -0.124928479
          },
          {
            x: 6.642070365,
            y: -899999e-8,
            z: -0.135703127
          },
          {
            x: 6.641897845,
            y: -899999e-8,
            z: -0.146477883
          },
          {
            x: 6.641725326,
            y: -899999e-8,
            z: -0.157252638
          },
          {
            x: 6.641552806,
            y: -899999e-8,
            z: -0.168027394
          },
          {
            x: 6.641380286,
            y: -899999e-8,
            z: -0.178802096
          },
          {
            x: 6.641207767,
            y: -899999e-8,
            z: -0.189576797
          },
          {
            x: 6.640690207,
            y: -899999e-8,
            z: -0.221901064
          },
          {
            x: 6.640517688,
            y: -899999e-8,
            z: -0.232675819
          },
          {
            x: 6.640172648,
            y: -899999e-8,
            z: -0.254225223
          },
          {
            x: 6.640000021,
            y: -899999e-8,
            z: -0.264999979
          },
          {
            x: 6.6362077,
            y: -899999e-8,
            z: -0.274544244
          },
          {
            x: 6.632415271,
            y: -899999e-8,
            z: -0.284088509
          },
          {
            x: 6.628622949,
            y: -899999e-8,
            z: -0.293632774
          },
          {
            x: 6.624830627,
            y: -899999e-8,
            z: -0.303177093
          },
          {
            x: 6.621038306,
            y: -899999e-8,
            z: -0.312721412
          },
          {
            x: 6.617245984,
            y: -899999e-8,
            z: -0.322265677
          },
          {
            x: 6.613453662,
            y: -899999e-8,
            z: -0.331809943
          },
          {
            x: 6.609661341,
            y: -899999e-8,
            z: -0.341354208
          },
          {
            x: 6.605869019,
            y: -899999e-8,
            z: -0.350898473
          },
          {
            x: 6.602076697,
            y: -899999e-8,
            z: -0.360442739
          },
          {
            x: 6.598284376,
            y: -899999e-8,
            z: -0.369987004
          },
          {
            x: 6.590699732,
            y: -899999e-8,
            z: -0.389075534
          },
          {
            x: 6.586907411,
            y: -899999e-8,
            z: -0.3986198
          },
          {
            x: 6.583115089,
            y: -899999e-8,
            z: -0.408164065
          },
          {
            x: 6.579322767,
            y: -899999e-8,
            z: -0.417708384
          },
          {
            x: 6.573167205,
            y: -899999e-8,
            z: -0.426393323
          },
          {
            x: 6.567011642,
            y: -899999e-8,
            z: -0.435078208
          },
          {
            x: 6.56085608,
            y: -899999e-8,
            z: -0.443763094
          },
          {
            x: 6.55470041,
            y: -899999e-8,
            z: -0.452447979
          },
          {
            x: 6.548544848,
            y: -899999e-8,
            z: -0.461132865
          },
          {
            x: 6.542389232,
            y: -899999e-8,
            z: -0.46981775
          },
          {
            x: 6.536233616,
            y: -899999e-8,
            z: -0.478502636
          },
          {
            x: 6.530078053,
            y: -899999e-8,
            z: -0.487187521
          },
          {
            x: 6.523922491,
            y: -899999e-8,
            z: -0.495872407
          },
          {
            x: 6.517766875,
            y: -899999e-8,
            z: -0.504557292
          },
          {
            x: 6.511611259,
            y: -899999e-8,
            z: -0.513242178
          },
          {
            x: 6.505455697,
            y: -899999e-8,
            z: -0.521927063
          },
          {
            x: 6.499300081,
            y: -899999e-8,
            z: -0.530611949
          },
          {
            x: 6.493144464,
            y: -899999e-8,
            z: -0.539296834
          },
          {
            x: 6.486988902,
            y: -899999e-8,
            z: -0.54798172
          },
          {
            x: 6.480833286,
            y: -899999e-8,
            z: -0.556666659
          },
          {
            x: 6.473466706,
            y: -899999e-8,
            z: -0.564804642
          },
          {
            x: 6.458733654,
            y: -899999e-8,
            z: -0.581080716
          },
          {
            x: 6.451367128,
            y: -899999e-8,
            z: -0.589218752
          },
          {
            x: 6.444000602,
            y: -899999e-8,
            z: -0.597356789
          },
          {
            x: 6.42926755,
            y: -899999e-8,
            z: -0.613632809
          },
          {
            x: 6.414534497,
            y: -899999e-8,
            z: -0.629908882
          },
          {
            x: 6.399801445,
            y: -899999e-8,
            z: -0.646184902
          },
          {
            x: 6.392434865,
            y: -899999e-8,
            z: -0.654322939
          },
          {
            x: 6.385068285,
            y: -899999e-8,
            z: -0.662460949
          },
          {
            x: 6.377701759,
            y: -899999e-8,
            z: -0.670598959
          },
          {
            x: 6.370335233,
            y: -899999e-8,
            z: -0.678736995
          },
          {
            x: 6.362968707,
            y: -899999e-8,
            z: -0.686875005
          },
          {
            x: 6.355543602,
            y: -899999e-8,
            z: -0.694778644
          },
          {
            x: 6.348118442,
            y: -899999e-8,
            z: -0.702682309
          },
          {
            x: 6.340693283,
            y: -899999e-8,
            z: -0.710585948
          },
          {
            x: 6.325843072,
            y: -899999e-8,
            z: -0.726393225
          },
          {
            x: 6.318417913,
            y: -899999e-8,
            z: -0.734296863
          },
          {
            x: 6.310992754,
            y: -899999e-8,
            z: -0.742200528
          },
          {
            x: 6.303567648,
            y: -899999e-8,
            z: -0.750104167
          },
          {
            x: 6.296142542,
            y: -899999e-8,
            z: -0.758007805
          },
          {
            x: 6.288717383,
            y: -899999e-8,
            z: -0.765911471
          },
          {
            x: 6.281292224,
            y: -899999e-8,
            z: -0.773815109
          },
          {
            x: 6.273867118,
            y: -899999e-8,
            z: -0.781718748
          },
          {
            x: 6.266442013,
            y: -899999e-8,
            z: -0.789622413
          },
          {
            x: 6.259016907,
            y: -899999e-8,
            z: -0.797526051
          },
          {
            x: 6.251591802,
            y: -899999e-8,
            z: -0.80542969
          },
          {
            x: 6.244166642,
            y: -899999e-8,
            z: -0.813333342
          },
          {
            x: 6.237835288,
            y: -899999e-8,
            z: -0.8213151
          },
          {
            x: 6.23150388,
            y: -899999e-8,
            z: -0.829296871
          },
          {
            x: 6.225172526,
            y: -899999e-8,
            z: -0.837278642
          },
          {
            x: 6.218841171,
            y: -899999e-8,
            z: -0.845260413
          },
          {
            x: 6.212509763,
            y: -899999e-8,
            z: -0.853242185
          },
          {
            x: 6.206178409,
            y: -899999e-8,
            z: -0.861223956
          },
          {
            x: 6.199847054,
            y: -899999e-8,
            z: -0.869205727
          },
          {
            x: 6.187184238,
            y: -899999e-8,
            z: -0.885169269
          },
          {
            x: 6.180852884,
            y: -899999e-8,
            z: -0.893151041
          },
          {
            x: 6.17452153,
            y: -899999e-8,
            z: -0.901132812
          },
          {
            x: 6.161858714,
            y: -899999e-8,
            z: -0.917096354
          },
          {
            x: 6.161675719141545,
            y: -899999e-8,
            z: -0.9173270505817582
          },
          {
            x: 6.1632886340351565,
            y: -0.32,
            z: -0.9135008043613282
          },
          {
            x: 6.171727869156067,
            y: -0.32,
            z: -0.8888441487845764
          },
          {
            x: 6.178778290442872,
            y: -0.32,
            z: -0.8630777839128417
          },
          {
            x: 6.184508696556091,
            y: -0.32,
            z: -0.8362708048820495
          },
          {
            x: 6.188987886156251,
            y: -0.32,
            z: -0.808492306828125
          },
          {
            x: 6.19228465790387,
            y: -0.32,
            z: -0.7798113848869934
          },
          {
            x: 6.194467810459473,
            y: -0.32,
            z: -0.7502971341945801
          },
          {
            x: 6.195606142483582,
            y: -0.32,
            z: -0.7200186498868103
          },
          {
            x: 6.1957684526367185,
            y: -0.32,
            z: -0.6890450270996094
          },
          {
            x: 6.195023539579408,
            y: -0.32,
            z: -0.6574453609689026
          },
          {
            x: 6.193440201972169,
            y: -0.32,
            z: -0.6252887466306152
          },
          {
            x: 6.191087238475525,
            y: -0.32,
            z: -0.5926442792206726
          },
          {
            x: 6.1880334477500005,
            y: -0.32,
            z: -0.559581053875
          },
          {
            x: 6.184347628456115,
            y: -0.32,
            z: -0.5261681657295227
          },
          {
            x: 6.180098579254395,
            y: -0.32,
            z: -0.49247470992016595
          },
          {
            x: 6.175355098805359,
            y: -0.32,
            z: -0.4585697815828553
          },
          {
            x: 6.170185985769532,
            y: -0.32,
            z: -0.42452247585351566
          },
          {
            x: 6.164660038807434,
            y: -0.32,
            z: -0.39040188786807245
          },
          {
            x: 6.1588460565795895,
            y: -0.32,
            z: -0.35627711276245116
          },
          {
            x: 6.152812837746522,
            y: -0.32,
            z: -0.32221724567257687
          },
          {
            x: 6.14662918096875,
            y: -0.32,
            z: -0.288291381734375
          },
          {
            x: 6.140363884906799,
            y: -0.32,
            z: -0.2545686160837708
          },
          {
            x: 6.134085748221191,
            y: -0.32,
            z: -0.22111804385668946
          },
          {
            x: 6.127863569572448,
            y: -0.32,
            z: -0.18800876018905638
          },
          {
            x: 6.121766147621093,
            y: -0.32,
            z: -0.15530986021679688
          },
          {
            x: 6.115862281027649,
            y: -0.32,
            z: -0.12309043907583617
          },
          {
            x: 6.110220768452637,
            y: -0.32,
            z: -0.0914195919020996
          },
          {
            x: 6.104910408556579,
            y: -0.32,
            z: -0.06036641383151245
          },
          {
            x: 6.1,
            y: -0.32,
            z: -0.03
          },
          {
            x: 6.093614807128905,
            y: -0.32,
            z: 0.015889282226562502
          },
          {
            x: 6.08759033203125,
            y: -0.32,
            z: 0.06348144531250001
          },
          {
            x: 6.081935729980469,
            y: -0.32,
            z: 0.11266296386718751
          },
          {
            x: 6.07666015625,
            y: -0.32,
            z: 0.1633203125
          },
          {
            x: 6.0717727661132805,
            y: -0.32,
            z: 0.2153399658203125
          },
          {
            x: 6.067282714843751,
            y: -0.32,
            z: 0.26860839843750006
          },
          {
            x: 6.063199157714844,
            y: -0.32,
            z: 0.3230120849609375
          },
          {
            x: 6.05953125,
            y: -0.32,
            z: 0.3784375
          },
          {
            x: 6.056288146972657,
            y: -0.32,
            z: 0.4347711181640625
          },
          {
            x: 6.05347900390625,
            y: -0.32,
            z: 0.49189941406250004
          },
          {
            x: 6.051112976074219,
            y: -0.32,
            z: 0.5497088623046875
          },
          {
            x: 6.049199218749999,
            y: -0.32,
            z: 0.6080859375
          },
          {
            x: 6.0477468872070315,
            y: -0.32,
            z: 0.6669171142578125
          },
          {
            x: 6.04676513671875,
            y: -0.32,
            z: 0.7260888671875
          },
          {
            x: 6.046263122558594,
            y: -0.32,
            z: 0.7854876708984375
          },
          {
            x: 6.04625,
            y: -0.32,
            z: 0.845
          },
          {
            x: 6.0467349243164055,
            y: -0.32,
            z: 0.9045123291015625
          },
          {
            x: 6.0477270507812495,
            y: -0.32,
            z: 0.9639111328124998
          },
          {
            x: 6.049235534667968,
            y: -0.32,
            z: 1.0230828857421876
          },
          {
            x: 6.05126953125,
            y: -0.32,
            z: 1.0819140625
          },
          {
            x: 6.053838195800782,
            y: -0.32,
            z: 1.1402911376953124
          },
          {
            x: 6.05695068359375,
            y: -0.32,
            z: 1.1981005859375
          },
          {
            x: 6.060616149902343,
            y: -0.32,
            z: 1.2552288818359374
          },
          {
            x: 6.06484375,
            y: -0.32,
            z: 1.3115625
          },
          {
            x: 6.069642639160156,
            y: -0.32,
            z: 1.3669879150390625
          },
          {
            x: 6.07502197265625,
            y: -0.32,
            z: 1.4213916015625
          },
          {
            x: 6.080990905761719,
            y: -0.32,
            z: 1.4746600341796876
          },
          {
            x: 6.08755859375,
            y: -0.32,
            z: 1.5266796875000002
          },
          {
            x: 6.094734191894531,
            y: -0.32,
            z: 1.5773370361328125
          },
          {
            x: 6.10252685546875,
            y: -0.32,
            z: 1.6265185546875
          },
          {
            x: 6.110945739746094,
            y: -0.32,
            z: 1.6741107177734373
          },
          {
            x: 6.12,
            y: -0.32,
            z: 1.72
          },
          {
            x: 6.127033996582031,
            y: -0.32,
            z: 1.750769805908203
          },
          {
            x: 6.135021972656251,
            y: -0.32,
            z: 1.780299072265625
          },
          {
            x: 6.143980407714842,
            y: -0.32,
            z: 1.8086363220214845
          },
          {
            x: 6.153925781250001,
            y: -0.32,
            z: 1.8358300781250003
          },
          {
            x: 6.164874572753907,
            y: -0.32,
            z: 1.8619288635253908
          },
          {
            x: 6.176843261718749,
            y: -0.32,
            z: 1.8869812011718752
          },
          {
            x: 6.189848327636719,
            y: -0.32,
            z: 1.911035614013672
          },
          {
            x: 6.203906249999999,
            y: -0.32,
            z: 1.9341406250000002
          },
          {
            x: 6.2190335083007815,
            y: -0.32,
            z: 1.956344757080078
          },
          {
            x: 6.23524658203125,
            y: -0.32,
            z: 1.977696533203125
          },
          {
            x: 6.252561950683594,
            y: -0.32,
            z: 1.9982444763183593
          },
          {
            x: 6.27099609375,
            y: -0.32,
            z: 2.0180371093750002
          },
          {
            x: 6.290565490722656,
            y: -0.32,
            z: 2.0371229553222654
          },
          {
            x: 6.311286621093751,
            y: -0.32,
            z: 2.055550537109375
          },
          {
            x: 6.333175964355469,
            y: -0.32,
            z: 2.073368377685547
          },
          {
            x: 6.35625,
            y: -0.32,
            z: 2.090625
          },
          {
            x: 6.380525207519532,
            y: -0.32,
            z: 2.1073689270019536
          },
          {
            x: 6.406018066406251,
            y: -0.32,
            z: 2.123648681640625
          },
          {
            x: 6.432745056152344,
            y: -0.32,
            z: 2.1395127868652346
          },
          {
            x: 6.460722656250001,
            y: -0.32,
            z: 2.155009765625
          },
          {
            x: 6.489967346191406,
            y: -0.32,
            z: 2.170188140869141
          },
          {
            x: 6.520495605468749,
            y: -0.32,
            z: 2.185096435546875
          },
          {
            x: 6.552323913574218,
            y: -0.32,
            z: 2.1997831726074217
          },
          {
            x: 6.58546875,
            y: -0.32,
            z: 2.214296875
          },
          {
            x: 6.619946594238281,
            y: -0.32,
            z: 2.228686065673828
          },
          {
            x: 6.655773925781251,
            y: -0.32,
            z: 2.242999267578125
          },
          {
            x: 6.6929672241210945,
            y: -0.32,
            z: 2.2572850036621093
          },
          {
            x: 6.73154296875,
            y: -0.32,
            z: 2.271591796875
          },
          {
            x: 6.771517639160156,
            y: -0.32,
            z: 2.285968170166016
          },
          {
            x: 6.81290771484375,
            y: -0.32,
            z: 2.300462646484375
          },
          {
            x: 6.855729675292969,
            y: -0.32,
            z: 2.315123748779297
          },
          {
            x: 6.9,
            y: -0.32,
            z: 2.33
          },
          {
            x: 6.961369018554688,
            y: -0.32,
            z: 2.3501465148925784
          },
          {
            x: 7.0235693359375,
            y: -0.32,
            z: 2.369859619140625
          },
          {
            x: 7.086553344726561,
            y: -0.32,
            z: 2.38908090209961
          },
          {
            x: 7.1502734375,
            y: -0.32,
            z: 2.4077519531250005
          },
          {
            x: 7.214682006835938,
            y: -0.32,
            z: 2.425814361572266
          },
          {
            x: 7.2797314453125,
            y: -0.32,
            z: 2.443209716796875
          },
          {
            x: 7.3453741455078125,
            y: -0.32,
            z: 2.459879608154297
          },
          {
            x: 7.4115625,
            y: -0.32,
            z: 2.475765625
          },
          {
            x: 7.478248901367188,
            y: -0.32,
            z: 2.490809356689453
          },
          {
            x: 7.5453857421875,
            y: -0.32,
            z: 2.504952392578125
          },
          {
            x: 7.6129254150390615,
            y: -0.32,
            z: 2.5181363220214847
          },
          {
            x: 7.6808203125,
            y: -0.32,
            z: 2.530302734375
          },
          {
            x: 7.749022827148437,
            y: -0.32,
            z: 2.541393218994141
          },
          {
            x: 7.8174853515625005,
            y: -0.32,
            z: 2.5513493652343753
          },
          {
            x: 7.886160278320313,
            y: -0.32,
            z: 2.560112762451172
          },
          {
            x: 7.954999999999999,
            y: -0.32,
            z: 2.567625
          },
          {
            x: 8.023956909179688,
            y: -0.32,
            z: 2.573827667236328
          },
          {
            x: 8.092983398437498,
            y: -0.32,
            z: 2.5786623535156252
          },
          {
            x: 8.162031860351561,
            y: -0.32,
            z: 2.5820706481933593
          },
          {
            x: 8.2310546875,
            y: -0.32,
            z: 2.583994140625
          },
          {
            x: 8.300004272460937,
            y: -0.32,
            z: 2.5843744201660157
          },
          {
            x: 8.3688330078125,
            y: -0.32,
            z: 2.583153076171875
          },
          {
            x: 8.437493286132812,
            y: -0.32,
            z: 2.580271697998047
          },
          {
            x: 8.5059375,
            y: -0.32,
            z: 2.5756718750000003
          },
          {
            x: 8.574118041992188,
            y: -0.32,
            z: 2.5692951965332034
          },
          {
            x: 8.6419873046875,
            y: -0.32,
            z: 2.561083251953125
          },
          {
            x: 8.709497680664061,
            y: -0.32,
            z: 2.5509776306152343
          },
          {
            x: 8.7766015625,
            y: -0.32,
            z: 2.5389199218750003
          },
          {
            x: 8.843251342773437,
            y: -0.32,
            z: 2.5248517150878906
          },
          {
            x: 8.909399414062499,
            y: -0.32,
            z: 2.508714599609375
          },
          {
            x: 8.97499816894531,
            y: -0.32,
            z: 2.490450164794922
          },
          {
            x: 9.04,
            y: -0.32,
            z: 2.47
          },
          {
            x: 9.084846496582028,
            y: -0.32,
            z: 2.455052795410156
          },
          {
            x: 9.12935791015625,
            y: -0.32,
            z: 2.44018798828125
          },
          {
            x: 9.173492126464842,
            y: -0.32,
            z: 2.425370788574219
          },
          {
            x: 9.21720703125,
            y: -0.32,
            z: 2.4105664062499996
          },
          {
            x: 9.260460510253905,
            y: -0.32,
            z: 2.3957400512695313
          },
          {
            x: 9.303210449218748,
            y: -0.32,
            z: 2.38085693359375
          },
          {
            x: 9.345414733886718,
            y: -0.32,
            z: 2.3658822631835936
          },
          {
            x: 9.38703125,
            y: -0.32,
            z: 2.3507812500000003
          },
          {
            x: 9.428017883300782,
            y: -0.32,
            z: 2.3355191040039065
          },
          {
            x: 9.468332519531248,
            y: -0.32,
            z: 2.3200610351562503
          },
          {
            x: 9.507933044433592,
            y: -0.32,
            z: 2.304372253417969
          },
          {
            x: 9.54677734375,
            y: -0.32,
            z: 2.28841796875
          },
          {
            x: 9.584823303222656,
            y: -0.32,
            z: 2.2721633911132812
          },
          {
            x: 9.62202880859375,
            y: -0.32,
            z: 2.25557373046875
          },
          {
            x: 9.658351745605469,
            y: -0.32,
            z: 2.238614196777344
          },
          {
            x: 9.693749999999998,
            y: -0.32,
            z: 2.22125
          },
          {
            x: 9.728181457519531,
            y: -0.32,
            z: 2.203446350097656
          },
          {
            x: 9.76160400390625,
            y: -0.32,
            z: 2.18516845703125
          },
          {
            x: 9.793975524902343,
            y: -0.32,
            z: 2.166381530761719
          },
          {
            x: 9.82525390625,
            y: -0.32,
            z: 2.14705078125
          },
          {
            x: 9.855397033691405,
            y: -0.32,
            z: 2.127141418457031
          },
          {
            x: 9.88436279296875,
            y: -0.32,
            z: 2.10661865234375
          },
          {
            x: 9.912109069824218,
            y: -0.32,
            z: 2.085447692871094
          },
          {
            x: 9.938593749999999,
            y: -0.32,
            z: 2.06359375
          },
          {
            x: 9.96377471923828,
            y: -0.32,
            z: 2.041022033691406
          },
          {
            x: 9.98760986328125,
            y: -0.32,
            z: 2.01769775390625
          },
          {
            x: 10.010057067871093,
            y: -0.32,
            z: 1.9935861206054688
          },
          {
            x: 10.03107421875,
            y: -0.32,
            z: 1.96865234375
          },
          {
            x: 10.050619201660156,
            y: -0.32,
            z: 1.9428616333007813
          },
          {
            x: 10.06864990234375,
            y: -0.32,
            z: 1.91617919921875
          },
          {
            x: 10.085124206542968,
            y: -0.32,
            z: 1.8885702514648437
          },
          {
            x: 10.1,
            y: -0.32,
            z: 1.86
          },
          {
            x: 10.119722167971373,
            y: -0.32,
            z: 1.8151988220221251
          },
          {
            x: 10.137695312520995,
            y: -0.32,
            z: 1.767196044927002
          },
          {
            x: 10.154004394602111,
            y: -0.32,
            z: 1.7162178039723814
          },
          {
            x: 10.168734375167968,
            y: -0.32,
            z: 1.6624902344160157
          },
          {
            x: 10.181970215171814,
            y: -0.32,
            z: 1.6062394715156556
          },
          {
            x: 10.193796875566894,
            y: -0.32,
            z: 1.5476916505290526
          },
          {
            x: 10.204299317306457,
            y: -0.32,
            z: 1.4870729067139588
          },
          {
            x: 10.213562501343748,
            y: -0.32,
            z: 1.424609375328125
          },
          {
            x: 10.221671388632018,
            y: -0.32,
            z: 1.360527191629303
          },
          {
            x: 10.228710940124513,
            y: -0.32,
            z: 1.295052490875244
          },
          {
            x: 10.234766116774477,
            y: -0.32,
            z: 1.2284114083236999
          },
          {
            x: 10.239921879535157,
            y: -0.32,
            z: 1.1608300792324218
          },
          {
            x: 10.244263189359803,
            y: -0.32,
            z: 1.0925346388591612
          },
          {
            x: 10.24787500720166,
            y: -0.32,
            z: 1.0237512224616698
          },
          {
            x: 10.250842294013976,
            y: -0.32,
            z: 0.954705965297699
          },
          {
            x: 10.25325001075,
            y: -0.32,
            z: 0.885625002625
          },
          {
            x: 10.255183118362977,
            y: -0.32,
            z: 0.8167344697013245
          },
          {
            x: 10.256726577806152,
            y: -0.32,
            z: 0.7482605017844238
          },
          {
            x: 10.257965350032775,
            y: -0.32,
            z: 0.6804292341320496
          },
          {
            x: 10.258984395996094,
            y: -0.32,
            z: 0.6134668020019531
          },
          {
            x: 10.259868676649354,
            y: -0.32,
            z: 0.547599340651886
          },
          {
            x: 10.260703152945801,
            y: -0.32,
            z: 0.48305298533959956
          },
          {
            x: 10.261572785838684,
            y: -0.32,
            z: 0.42005387132284544
          },
          {
            x: 10.262562536281251,
            y: -0.32,
            z: 0.35882813385937495
          },
          {
            x: 10.263757365226745,
            y: -0.32,
            z: 0.29960190820693966
          },
          {
            x: 10.265242233628417,
            y: -0.32,
            z: 0.24260132962329098
          },
          {
            x: 10.267102102439514,
            y: -0.32,
            z: 0.18805253336618039
          },
          {
            x: 10.269421932613282,
            y: -0.32,
            z: 0.13618165469335936
          },
          {
            x: 10.272286685102966,
            y: -0.32,
            z: 0.08721482886257935
          },
          {
            x: 10.275781320861816,
            y: -0.32,
            z: 0.0413781911315918
          },
          {
            x: 10.279990800843079,
            y: -0.32,
            z: -0.001102123241851806
          },
          {
            x: 10.285000086,
            y: -0.32,
            z: -0.039999979
          },
          {
            x: 10.279023266,
            y: -0.32,
            z: -0.023814993
          },
          {
            x: 10.273046875,
            y: -0.32,
            z: -7630115e-9
          },
          {
            x: 10.267070484,
            y: -0.32,
            z: 8554764e-9
          },
          {
            x: 10.255117702,
            y: -0.32,
            z: 0.04092452
          },
          {
            x: 10.249140882,
            y: -0.32,
            z: 0.057109399
          },
          {
            x: 10.243164063,
            y: -0.32,
            z: 0.073294277
          },
          {
            x: 10.237187672,
            y: -0.32,
            z: 0.089479156
          },
          {
            x: 10.231211281,
            y: -0.32,
            z: 0.105664034
          },
          {
            x: 10.225234461,
            y: -0.32,
            z: 0.121848912
          },
          {
            x: 10.219257641,
            y: -0.32,
            z: 0.138033791
          },
          {
            x: 10.207304859,
            y: -0.32,
            z: 0.170403547
          },
          {
            x: 10.201328039,
            y: -0.32,
            z: 0.186588426
          },
          {
            x: 10.195351219,
            y: -0.32,
            z: 0.202773304
          },
          {
            x: 10.189374828,
            y: -0.32,
            z: 0.218958182
          },
          {
            x: 10.182538843,
            y: -0.32,
            z: 0.236314971
          },
          {
            x: 10.175702858,
            y: -0.32,
            z: 0.253671761
          },
          {
            x: 10.168866873,
            y: -0.32,
            z: 0.271028442
          },
          {
            x: 10.162030888,
            y: -0.32,
            z: 0.288385231
          },
          {
            x: 10.155194902,
            y: -0.32,
            z: 0.305742021
          },
          {
            x: 10.148358917,
            y: -0.32,
            z: 0.323098702
          },
          {
            x: 10.141522932,
            y: -0.32,
            z: 0.340455492
          },
          {
            x: 10.121014977,
            y: -0.32,
            z: 0.392525859
          },
          {
            x: 10.114178991,
            y: -0.32,
            z: 0.409882648
          },
          {
            x: 10.093671036,
            y: -0.32,
            z: 0.461953015
          },
          {
            x: 10.08683548,
            y: -0.32,
            z: 0.479309697
          },
          {
            x: 10.079999495,
            y: -0.32,
            z: 0.496666486
          },
          {
            x: 10.072070026,
            y: -0.32,
            z: 0.514101381
          },
          {
            x: 10.064140129,
            y: -0.32,
            z: 0.531536384
          },
          {
            x: 10.056210232,
            y: -0.32,
            z: 0.548971279
          },
          {
            x: 10.048280764,
            y: -0.32,
            z: 0.566406174
          },
          {
            x: 10.040351295,
            y: -0.32,
            z: 0.583841069
          },
          {
            x: 10.024491501,
            y: -0.32,
            z: 0.618710859
          },
          {
            x: 10.008632565,
            y: -0.32,
            z: 0.653580649
          },
          {
            x: 10.000702667,
            y: -0.32,
            z: 0.671015544
          },
          {
            x: 9.99277277,
            y: -0.32,
            z: 0.688450439
          },
          {
            x: 9.976913834,
            y: -0.32,
            z: 0.723320229
          },
          {
            x: 9.968983936,
            y: -0.32,
            z: 0.740755124
          },
          {
            x: 9.961054039,
            y: -0.32,
            z: 0.758190019
          },
          {
            x: 9.953124571,
            y: -0.32,
            z: 0.775624914
          },
          {
            x: 9.943866444,
            y: -0.32,
            z: 0.79204411
          },
          {
            x: 9.934608746,
            y: -0.32,
            z: 0.808463306
          },
          {
            x: 9.925351048,
            y: -0.32,
            z: 0.824882717
          },
          {
            x: 9.916093349,
            y: -0.32,
            z: 0.841301913
          },
          {
            x: 9.906835651,
            y: -0.32,
            z: 0.857721109
          },
          {
            x: 9.897577953,
            y: -0.32,
            z: 0.87414052
          },
          {
            x: 9.879062557,
            y: -0.32,
            z: 0.906978912
          },
          {
            x: 9.869804859,
            y: -0.32,
            z: 0.923398323
          },
          {
            x: 9.851289463,
            y: -0.32,
            z: 0.956236715
          },
          {
            x: 9.842031336,
            y: -0.32,
            z: 0.972656126
          },
          {
            x: 9.832773209,
            y: -0.32,
            z: 0.989075322
          },
          {
            x: 9.823515511,
            y: -0.32,
            z: 1.005494518
          },
          {
            x: 9.814257813,
            y: -0.32,
            z: 1.021913929
          },
          {
            x: 9.805000114,
            y: -0.32,
            z: 1.038333125
          },
          {
            x: 9.794179869,
            y: -0.32,
            z: 1.052643032
          },
          {
            x: 9.783359623,
            y: -0.32,
            z: 1.066953154
          },
          {
            x: 9.772538948,
            y: -0.32,
            z: 1.081263061
          },
          {
            x: 9.761718702,
            y: -0.32,
            z: 1.095572968
          },
          {
            x: 9.750898457,
            y: -0.32,
            z: 1.109882874
          },
          {
            x: 9.740077782,
            y: -0.32,
            z: 1.124192781
          },
          {
            x: 9.707617044,
            y: -0.32,
            z: 1.167122502
          },
          {
            x: 9.696796799,
            y: -0.32,
            z: 1.181432409
          },
          {
            x: 9.664336061,
            y: -0.32,
            z: 1.22436213
          },
          {
            x: 9.653515816,
            y: -0.32,
            z: 1.238672037
          },
          {
            x: 9.642695141,
            y: -0.32,
            z: 1.252981944
          },
          {
            x: 9.631874895,
            y: -0.32,
            z: 1.267291851
          },
          {
            x: 9.619257355,
            y: -0.32,
            z: 1.278398557
          },
          {
            x: 9.606640244,
            y: -0.32,
            z: 1.289505262
          },
          {
            x: 9.594023132,
            y: -0.32,
            z: 1.300612183
          },
          {
            x: 9.581406021,
            y: -0.32,
            z: 1.311718888
          },
          {
            x: 9.56878891,
            y: -0.32,
            z: 1.322825594
          },
          {
            x: 9.556171799,
            y: -0.32,
            z: 1.333932514
          },
          {
            x: 9.543554688,
            y: -0.32,
            z: 1.34503922
          },
          {
            x: 9.530937576,
            y: -0.32,
            z: 1.356145926
          },
          {
            x: 9.518320465,
            y: -0.32,
            z: 1.367252631
          },
          {
            x: 9.505703354,
            y: -0.32,
            z: 1.378359337
          },
          {
            x: 9.493086243,
            y: -0.32,
            z: 1.389466257
          },
          {
            x: 9.480468702,
            y: -0.32,
            z: 1.400572963
          },
          {
            x: 9.467851162,
            y: -0.32,
            z: 1.411679668
          },
          {
            x: 9.455234051,
            y: -0.32,
            z: 1.422786589
          },
          {
            x: 9.44261694,
            y: -0.32,
            z: 1.433893294
          },
          {
            x: 9.429999828,
            y: -0.32,
            z: 1.445
          },
          {
            x: 9.414550734,
            y: -0.32,
            z: 1.453020878
          },
          {
            x: 9.399101639,
            y: -0.32,
            z: 1.461041756
          },
          {
            x: 9.383652115,
            y: -0.32,
            z: 1.469062634
          },
          {
            x: 9.352753925,
            y: -0.32,
            z: 1.48510396
          },
          {
            x: 9.337304401,
            y: -0.32,
            z: 1.493124838
          },
          {
            x: 9.321855307,
            y: -0.32,
            z: 1.501145716
          },
          {
            x: 9.306406212,
            y: -0.32,
            z: 1.509166594
          },
          {
            x: 9.290956688,
            y: -0.32,
            z: 1.517187471
          },
          {
            x: 9.260058498,
            y: -0.32,
            z: 1.533229227
          },
          {
            x: 9.244609189,
            y: -0.32,
            z: 1.54124989
          },
          {
            x: 9.22915988,
            y: -0.32,
            z: 1.549270554
          },
          {
            x: 9.213710785,
            y: -0.32,
            z: 1.557291431
          },
          {
            x: 9.198261476,
            y: -0.32,
            z: 1.565312309
          },
          {
            x: 9.182812166,
            y: -0.32,
            z: 1.573333187
          },
          {
            x: 9.164511347,
            y: -0.32,
            z: 1.579166455
          },
          {
            x: 9.146210527,
            y: -0.32,
            z: 1.584999723
          },
          {
            x: 9.127909708,
            y: -0.32,
            z: 1.590833206
          },
          {
            x: 9.109609103,
            y: -0.32,
            z: 1.596666474
          },
          {
            x: 9.091308498,
            y: -0.32,
            z: 1.602499743
          },
          {
            x: 9.073007679,
            y: -0.32,
            z: 1.608333225
          },
          {
            x: 9.05470686,
            y: -0.32,
            z: 1.614166493
          },
          {
            x: 9.03640604,
            y: -0.32,
            z: 1.619999762
          },
          {
            x: 9.018105221,
            y: -0.32,
            z: 1.625833244
          },
          {
            x: 8.999804401,
            y: -0.32,
            z: 1.631666512
          },
          {
            x: 8.981503582,
            y: -0.32,
            z: 1.637499781
          },
          {
            x: 8.963202977,
            y: -0.32,
            z: 1.643333263
          },
          {
            x: 8.944902372,
            y: -0.32,
            z: 1.649166532
          },
          {
            x: 8.926601553,
            y: -0.32,
            z: 1.6549998
          },
          {
            x: 8.908300734,
            y: -0.32,
            z: 1.660833282
          },
          {
            x: 8.889999914,
            y: -0.32,
            z: 1.666666551
          },
          {
            x: 8.870136547,
            y: -0.32,
            z: 1.67039053
          },
          {
            x: 8.850273395,
            y: -0.32,
            z: 1.674114509
          },
          {
            x: 8.830410242,
            y: -0.32,
            z: 1.677838488
          },
          {
            x: 8.790683508,
            y: -0.32,
            z: 1.685286446
          },
          {
            x: 8.770820355,
            y: -0.32,
            z: 1.689010425
          },
          {
            x: 8.750957203,
            y: -0.32,
            z: 1.692734404
          },
          {
            x: 8.711230469,
            y: -0.32,
            z: 1.700182362
          },
          {
            x: 8.691367316,
            y: -0.32,
            z: 1.703906341
          },
          {
            x: 8.671504164,
            y: -0.32,
            z: 1.70763032
          },
          {
            x: 8.611914063,
            y: -0.32,
            z: 1.718802257
          },
          {
            x: 8.592050695,
            y: -0.32,
            z: 1.722526236
          },
          {
            x: 8.572187543,
            y: -0.32,
            z: 1.726250215
          },
          {
            x: 8.55205102,
            y: -0.32,
            z: 1.72794301
          },
          {
            x: 8.531914282,
            y: -0.32,
            z: 1.729635592
          },
          {
            x: 8.511777544,
            y: -0.32,
            z: 1.731328173
          },
          {
            x: 8.491640806,
            y: -0.32,
            z: 1.733020968
          },
          {
            x: 8.471504068,
            y: -0.32,
            z: 1.734713764
          },
          {
            x: 8.451367331,
            y: -0.32,
            z: 1.736406345
          },
          {
            x: 8.431230593,
            y: -0.32,
            z: 1.738098927
          },
          {
            x: 8.411093855,
            y: -0.32,
            z: 1.739791722
          },
          {
            x: 8.390957117,
            y: -0.32,
            z: 1.741484518
          },
          {
            x: 8.350683641,
            y: -0.32,
            z: 1.74486968
          },
          {
            x: 8.330546904,
            y: -0.32,
            z: 1.746562476
          },
          {
            x: 8.310410166,
            y: -0.32,
            z: 1.748255272
          },
          {
            x: 8.27013669,
            y: -0.32,
            z: 1.751640434
          },
          {
            x: 8.249999952,
            y: -0.32,
            z: 1.75333323
          },
          {
            x: 8.230878806,
            y: -0.32,
            z: 1.753072948
          },
          {
            x: 8.21175766,
            y: -0.32,
            z: 1.752812452
          },
          {
            x: 8.192636728,
            y: -0.32,
            z: 1.752551956
          },
          {
            x: 8.154394436,
            y: -0.32,
            z: 1.752030964
          },
          {
            x: 8.135273504,
            y: -0.32,
            z: 1.751770682
          },
          {
            x: 8.116152358,
            y: -0.32,
            z: 1.751510401
          },
          {
            x: 8.097031212,
            y: -0.32,
            z: 1.751249905
          },
          {
            x: 8.077910066,
            y: -0.32,
            z: 1.750989408
          },
          {
            x: 8.058788919,
            y: -0.32,
            z: 1.750729127
          },
          {
            x: 8.039667988,
            y: -0.32,
            z: 1.750468845
          },
          {
            x: 8.001425695,
            y: -0.32,
            z: 1.749947853
          },
          {
            x: 7.982304764,
            y: -0.32,
            z: 1.749687357
          },
          {
            x: 7.963183618,
            y: -0.32,
            z: 1.749426861
          },
          {
            x: 7.944062471,
            y: -0.32,
            z: 1.749166579
          },
          {
            x: 7.927246094,
            y: -0.32,
            z: 1.747031326
          },
          {
            x: 7.910429716,
            y: -0.32,
            z: 1.744895859
          },
          {
            x: 7.893613338,
            y: -0.32,
            z: 1.742760391
          },
          {
            x: 7.876796961,
            y: -0.32,
            z: 1.740624924
          },
          {
            x: 7.859980583,
            y: -0.32,
            z: 1.738489456
          },
          {
            x: 7.843164206,
            y: -0.32,
            z: 1.736353989
          },
          {
            x: 7.826347828,
            y: -0.32,
            z: 1.734218521
          },
          {
            x: 7.809531236,
            y: -0.32,
            z: 1.732083268
          },
          {
            x: 7.792714643,
            y: -0.32,
            z: 1.729948015
          },
          {
            x: 7.775898266,
            y: -0.32,
            z: 1.727812548
          },
          {
            x: 7.759081888,
            y: -0.32,
            z: 1.72567708
          },
          {
            x: 7.742265511,
            y: -0.32,
            z: 1.723541613
          },
          {
            x: 7.725449133,
            y: -0.32,
            z: 1.721406145
          },
          {
            x: 7.708632755,
            y: -0.32,
            z: 1.719270678
          },
          {
            x: 7.691816378,
            y: -0.32,
            z: 1.71713521
          },
          {
            x: 7.675,
            y: -0.32,
            z: 1.714999957
          },
          {
            x: 7.659752607,
            y: -0.32,
            z: 1.710358019
          },
          {
            x: 7.644505215,
            y: -0.32,
            z: 1.705715866
          },
          {
            x: 7.614010429,
            y: -0.32,
            z: 1.69643199
          },
          {
            x: 7.598763037,
            y: -0.32,
            z: 1.691790051
          },
          {
            x: 7.568268251,
            y: -0.32,
            z: 1.682506175
          },
          {
            x: 7.553020859,
            y: -0.32,
            z: 1.677864237
          },
          {
            x: 7.537773466,
            y: -0.32,
            z: 1.673222299
          },
          {
            x: 7.522526073,
            y: -0.32,
            z: 1.66858036
          },
          {
            x: 7.507278681,
            y: -0.32,
            z: 1.663938422
          },
          {
            x: 7.476783895,
            y: -0.32,
            z: 1.654654546
          },
          {
            x: 7.461536503,
            y: -0.32,
            z: 1.650012608
          },
          {
            x: 7.44628911,
            y: -0.32,
            z: 1.645370669
          },
          {
            x: 7.431041718,
            y: -0.32,
            z: 1.640728731
          },
          {
            x: 7.416184962,
            y: -0.32,
            z: 1.633391495
          },
          {
            x: 7.401328206,
            y: -0.32,
            z: 1.626054258
          },
          {
            x: 7.386471343,
            y: -0.32,
            z: 1.618717022
          },
          {
            x: 7.371614587,
            y: -0.32,
            z: 1.611379786
          },
          {
            x: 7.356757832,
            y: -0.32,
            z: 1.604042549
          },
          {
            x: 7.341900969,
            y: -0.32,
            z: 1.596705313
          },
          {
            x: 7.327044213,
            y: -0.32,
            z: 1.589368076
          },
          {
            x: 7.312187457,
            y: -0.32,
            z: 1.582031054
          },
          {
            x: 7.297330701,
            y: -0.32,
            z: 1.574694033
          },
          {
            x: 7.282473946,
            y: -0.32,
            z: 1.567356796
          },
          {
            x: 7.267617083,
            y: -0.32,
            z: 1.56001956
          },
          {
            x: 7.252760327,
            y: -0.32,
            z: 1.552682323
          },
          {
            x: 7.237903571,
            y: -0.32,
            z: 1.545345087
          },
          {
            x: 7.223046708,
            y: -0.32,
            z: 1.538007851
          },
          {
            x: 7.208189952,
            y: -0.32,
            z: 1.530670614
          },
          {
            x: 7.193333197,
            y: -0.32,
            z: 1.523333378
          },
          {
            x: 7.179492033,
            y: -0.32,
            z: 1.514043064
          },
          {
            x: 7.165650868,
            y: -0.32,
            z: 1.50475275
          },
          {
            x: 7.151809812,
            y: -0.32,
            z: 1.495462437
          },
          {
            x: 7.137968647,
            y: -0.32,
            z: 1.486171908
          },
          {
            x: 7.124127483,
            y: -0.32,
            z: 1.47688138
          },
          {
            x: 7.110286427,
            y: -0.32,
            z: 1.467591066
          },
          {
            x: 7.096445262,
            y: -0.32,
            z: 1.458300753
          },
          {
            x: 7.068762934,
            y: -0.32,
            z: 1.439720125
          },
          {
            x: 7.05492177,
            y: -0.32,
            z: 1.430429597
          },
          {
            x: 7.041080713,
            y: -0.32,
            z: 1.421139069
          },
          {
            x: 7.013398385,
            y: -0.32,
            z: 1.402558441
          },
          {
            x: 6.999557328,
            y: -0.32,
            z: 1.393268127
          },
          {
            x: 6.985716164,
            y: -0.32,
            z: 1.383977814
          },
          {
            x: 6.971875,
            y: -0.32,
            z: 1.374687285
          },
          {
            x: 6.959674489,
            y: -0.32,
            z: 1.364186115
          },
          {
            x: 6.947473979,
            y: -0.32,
            z: 1.353684731
          },
          {
            x: 6.935273468,
            y: -0.32,
            z: 1.343183346
          },
          {
            x: 6.923072958,
            y: -0.32,
            z: 1.332681961
          },
          {
            x: 6.910872447,
            y: -0.32,
            z: 1.322180576
          },
          {
            x: 6.898671937,
            y: -0.32,
            z: 1.311679406
          },
          {
            x: 6.886471319,
            y: -0.32,
            z: 1.301178236
          },
          {
            x: 6.874270809,
            y: -0.32,
            z: 1.290676851
          },
          {
            x: 6.862070298,
            y: -0.32,
            z: 1.280175467
          },
          {
            x: 6.84986968,
            y: -0.32,
            z: 1.269674296
          },
          {
            x: 6.83766917,
            y: -0.32,
            z: 1.259173126
          },
          {
            x: 6.825468659,
            y: -0.32,
            z: 1.248671741
          },
          {
            x: 6.813268149,
            y: -0.32,
            z: 1.238170357
          },
          {
            x: 6.801067638,
            y: -0.32,
            z: 1.227668972
          },
          {
            x: 6.788867128,
            y: -0.32,
            z: 1.217167587
          },
          {
            x: 6.776666617,
            y: -0.32,
            z: 1.206666417
          },
          {
            x: 6.766731715,
            y: -0.32,
            z: 1.195696182
          },
          {
            x: 6.746861911,
            y: -0.32,
            z: 1.173756142
          },
          {
            x: 6.736927009,
            y: -0.32,
            z: 1.162786121
          },
          {
            x: 6.726992106,
            y: -0.32,
            z: 1.151816101
          },
          {
            x: 6.717057204,
            y: -0.32,
            z: 1.140846081
          },
          {
            x: 6.707122302,
            y: -0.32,
            z: 1.12987606
          },
          {
            x: 6.687252712,
            y: -0.32,
            z: 1.10793602
          },
          {
            x: 6.67731781,
            y: -0.32,
            z: 1.096966
          },
          {
            x: 6.667382908,
            y: -0.32,
            z: 1.085995979
          },
          {
            x: 6.657448006,
            y: -0.32,
            z: 1.075025959
          },
          {
            x: 6.647513103,
            y: -0.32,
            z: 1.064055939
          },
          {
            x: 6.637578201,
            y: -0.32,
            z: 1.053085918
          },
          {
            x: 6.627643299,
            y: -0.32,
            z: 1.042115898
          },
          {
            x: 6.617708397,
            y: -0.32,
            z: 1.031145663
          },
          {
            x: 6.610664058,
            y: -0.32,
            z: 1.020449228
          },
          {
            x: 6.603619826,
            y: -0.32,
            z: 1.009752579
          },
          {
            x: 6.596575594,
            y: -0.32,
            z: 0.999055929
          },
          {
            x: 6.589531255,
            y: -0.32,
            z: 0.98835928
          },
          {
            x: 6.582487023,
            y: -0.32,
            z: 0.97766263
          },
          {
            x: 6.575442791,
            y: -0.32,
            z: 0.966965981
          },
          {
            x: 6.568398452,
            y: -0.32,
            z: 0.956269331
          },
          {
            x: 6.56135422,
            y: -0.32,
            z: 0.945572681
          },
          {
            x: 6.554309988,
            y: -0.32,
            z: 0.934876032
          },
          {
            x: 6.547265649,
            y: -0.32,
            z: 0.924179382
          },
          {
            x: 6.540221363,
            y: -0.32,
            z: 0.913482733
          },
          {
            x: 6.533177078,
            y: -0.32,
            z: 0.902786298
          },
          {
            x: 6.526132792,
            y: -0.32,
            z: 0.892089863
          },
          {
            x: 6.519088507,
            y: -0.32,
            z: 0.881393213
          },
          {
            x: 6.512044275,
            y: -0.32,
            z: 0.870696564
          },
          {
            x: 6.504999989,
            y: -0.32,
            z: 0.859999914
          },
          {
            x: 6.502190697,
            y: -0.32,
            z: 0.849029894
          },
          {
            x: 6.499381459,
            y: -0.32,
            z: 0.838059874
          },
          {
            x: 6.49657222,
            y: -0.32,
            z: 0.827089853
          },
          {
            x: 6.493762982,
            y: -0.32,
            z: 0.816119833
          },
          {
            x: 6.490953743,
            y: -0.32,
            z: 0.805149813
          },
          {
            x: 6.488144505,
            y: -0.32,
            z: 0.794179792
          },
          {
            x: 6.485335267,
            y: -0.32,
            z: 0.783209772
          },
          {
            x: 6.482526028,
            y: -0.32,
            z: 0.772239537
          },
          {
            x: 6.47971679,
            y: -0.32,
            z: 0.761269517
          },
          {
            x: 6.476907551,
            y: -0.32,
            z: 0.750299497
          },
          {
            x: 6.474098313,
            y: -0.32,
            z: 0.739329476
          },
          {
            x: 6.471289074,
            y: -0.32,
            z: 0.728359349
          },
          {
            x: 6.468479836,
            y: -0.32,
            z: 0.717389221
          },
          {
            x: 6.465670598,
            y: -0.32,
            z: 0.706419201
          },
          {
            x: 6.462861359,
            y: -0.32,
            z: 0.695449181
          },
          {
            x: 6.460052067,
            y: -0.32,
            z: 0.68447916
          },
          {
            x: 6.461246777,
            y: -0.32,
            z: 0.672532601
          },
          {
            x: 6.462441432,
            y: -0.32,
            z: 0.660585935
          },
          {
            x: 6.463636088,
            y: -0.32,
            z: 0.648639269
          },
          {
            x: 6.4660254,
            y: -0.32,
            z: 0.624746151
          },
          {
            x: 6.467220056,
            y: -0.32,
            z: 0.612799485
          },
          {
            x: 6.468414712,
            y: -0.32,
            z: 0.600852818
          },
          {
            x: 6.469609368,
            y: -0.32,
            z: 0.58890626
          },
          {
            x: 6.470804024,
            y: -0.32,
            z: 0.576959701
          },
          {
            x: 6.47199868,
            y: -0.32,
            z: 0.565013034
          },
          {
            x: 6.473193336,
            y: -0.32,
            z: 0.553066368
          },
          {
            x: 6.474387991,
            y: -0.32,
            z: 0.541119809
          },
          {
            x: 6.475582647,
            y: -0.32,
            z: 0.52917325
          },
          {
            x: 6.477971959,
            y: -0.32,
            z: 0.505279918
          },
          {
            x: 6.479166669,
            y: -0.32,
            z: 0.493333359
          },
          {
            x: 6.482626987,
            y: -0.32,
            z: 0.48091795
          },
          {
            x: 6.489547515,
            y: -0.32,
            z: 0.456087346
          },
          {
            x: 6.496468043,
            y: -0.32,
            z: 0.431256528
          },
          {
            x: 6.503388679,
            y: -0.32,
            z: 0.406425924
          },
          {
            x: 6.510309207,
            y: -0.32,
            z: 0.381595106
          },
          {
            x: 6.513769525,
            y: -0.32,
            z: 0.369179804
          },
          {
            x: 6.517229843,
            y: -0.32,
            z: 0.356764503
          },
          {
            x: 6.520690107,
            y: -0.32,
            z: 0.344349093
          },
          {
            x: 6.524150372,
            y: -0.32,
            z: 0.331933684
          },
          {
            x: 6.527610689,
            y: -0.32,
            z: 0.319518275
          },
          {
            x: 6.531071007,
            y: -0.32,
            z: 0.307102866
          },
          {
            x: 6.534531271,
            y: -0.32,
            z: 0.294687564
          },
          {
            x: 6.538518858,
            y: -0.32,
            z: 0.282311316
          },
          {
            x: 6.542506498,
            y: -0.32,
            z: 0.269934959
          },
          {
            x: 6.546494138,
            y: -0.32,
            z: 0.257558603
          },
          {
            x: 6.550481725,
            y: -0.32,
            z: 0.245182354
          },
          {
            x: 6.554469419,
            y: -0.32,
            z: 0.232806106
          },
          {
            x: 6.558457005,
            y: -0.32,
            z: 0.220429749
          },
          {
            x: 6.562444592,
            y: -0.32,
            z: 0.208053393
          },
          {
            x: 6.566432285,
            y: -0.32,
            z: 0.195677145
          },
          {
            x: 6.570419979,
            y: -0.32,
            z: 0.183300896
          },
          {
            x: 6.574407566,
            y: -0.32,
            z: 0.17092454
          },
          {
            x: 6.578395152,
            y: -0.32,
            z: 0.158548183
          },
          {
            x: 6.582382846,
            y: -0.32,
            z: 0.146171935
          },
          {
            x: 6.58637054,
            y: -0.32,
            z: 0.133795686
          },
          {
            x: 6.590358126,
            y: -0.32,
            z: 0.12141933
          },
          {
            x: 6.594345713,
            y: -0.32,
            z: 0.109042974
          },
          {
            x: 6.598333406,
            y: -0.32,
            z: 0.096666725
          },
          {
            x: 6.601110029,
            y: -0.32,
            z: 0.084837217
          },
          {
            x: 6.606663489,
            y: -0.32,
            z: 0.061178417
          },
          {
            x: 6.609440112,
            y: -0.32,
            z: 0.049349017
          },
          {
            x: 6.612216842,
            y: -0.32,
            z: 0.037519617
          },
          {
            x: 6.614993572,
            y: -0.32,
            z: 0.02569011
          },
          {
            x: 6.617770195,
            y: -0.32,
            z: 0.013860602
          },
          {
            x: 6.623323655,
            y: -0.32,
            z: -9798198e-9
          },
          {
            x: 6.626100278,
            y: -0.32,
            z: -0.021627598
          },
          {
            x: 6.628877008,
            y: -0.32,
            z: -0.033456998
          },
          {
            x: 6.631653738,
            y: -0.32,
            z: -0.045286505
          },
          {
            x: 6.634430361,
            y: -0.32,
            z: -0.057116013
          },
          {
            x: 6.639983821,
            y: -0.32,
            z: -0.080774813
          },
          {
            x: 6.642760444,
            y: -0.32,
            z: -0.092604213
          },
          {
            x: 6.642415404,
            y: -0.32,
            z: -0.114153724
          },
          {
            x: 6.642242885,
            y: -0.32,
            z: -0.124928479
          },
          {
            x: 6.642070365,
            y: -0.32,
            z: -0.135703127
          },
          {
            x: 6.641897845,
            y: -0.32,
            z: -0.146477883
          },
          {
            x: 6.641725326,
            y: -0.32,
            z: -0.157252638
          },
          {
            x: 6.641552806,
            y: -0.32,
            z: -0.168027394
          },
          {
            x: 6.641380286,
            y: -0.32,
            z: -0.178802096
          },
          {
            x: 6.641207767,
            y: -0.32,
            z: -0.189576797
          },
          {
            x: 6.640690207,
            y: -0.32,
            z: -0.221901064
          },
          {
            x: 6.640517688,
            y: -0.32,
            z: -0.232675819
          },
          {
            x: 6.640172648,
            y: -0.32,
            z: -0.254225223
          },
          {
            x: 6.640000021,
            y: -0.32,
            z: -0.264999979
          },
          {
            x: 6.6362077,
            y: -0.32,
            z: -0.274544244
          },
          {
            x: 6.632415271,
            y: -0.32,
            z: -0.284088509
          },
          {
            x: 6.628622949,
            y: -0.32,
            z: -0.293632774
          },
          {
            x: 6.624830627,
            y: -0.32,
            z: -0.303177093
          },
          {
            x: 6.621038306,
            y: -0.32,
            z: -0.312721412
          },
          {
            x: 6.617245984,
            y: -0.32,
            z: -0.322265677
          },
          {
            x: 6.613453662,
            y: -0.32,
            z: -0.331809943
          },
          {
            x: 6.609661341,
            y: -0.32,
            z: -0.341354208
          },
          {
            x: 6.605869019,
            y: -0.32,
            z: -0.350898473
          },
          {
            x: 6.602076697,
            y: -0.32,
            z: -0.360442739
          },
          {
            x: 6.598284376,
            y: -0.32,
            z: -0.369987004
          },
          {
            x: 6.590699732,
            y: -0.32,
            z: -0.389075534
          },
          {
            x: 6.586907411,
            y: -0.32,
            z: -0.3986198
          },
          {
            x: 6.583115089,
            y: -0.32,
            z: -0.408164065
          },
          {
            x: 6.579322767,
            y: -0.32,
            z: -0.417708384
          },
          {
            x: 6.573167205,
            y: -0.32,
            z: -0.426393323
          },
          {
            x: 6.567011642,
            y: -0.32,
            z: -0.435078208
          },
          {
            x: 6.56085608,
            y: -0.32,
            z: -0.443763094
          },
          {
            x: 6.55470041,
            y: -0.32,
            z: -0.452447979
          },
          {
            x: 6.548544848,
            y: -0.32,
            z: -0.461132865
          },
          {
            x: 6.542389232,
            y: -0.32,
            z: -0.46981775
          },
          {
            x: 6.536233616,
            y: -0.32,
            z: -0.478502636
          },
          {
            x: 6.530078053,
            y: -0.32,
            z: -0.487187521
          },
          {
            x: 6.523922491,
            y: -0.32,
            z: -0.495872407
          },
          {
            x: 6.517766875,
            y: -0.32,
            z: -0.504557292
          },
          {
            x: 6.511611259,
            y: -0.32,
            z: -0.513242178
          },
          {
            x: 6.505455697,
            y: -0.32,
            z: -0.521927063
          },
          {
            x: 6.499300081,
            y: -0.32,
            z: -0.530611949
          },
          {
            x: 6.493144464,
            y: -0.32,
            z: -0.539296834
          },
          {
            x: 6.486988902,
            y: -0.32,
            z: -0.54798172
          },
          {
            x: 6.480833286,
            y: -0.32,
            z: -0.556666659
          },
          {
            x: 6.473466706,
            y: -0.32,
            z: -0.564804642
          },
          {
            x: 6.458733654,
            y: -0.32,
            z: -0.581080716
          },
          {
            x: 6.451367128,
            y: -0.32,
            z: -0.589218752
          },
          {
            x: 6.444000602,
            y: -0.32,
            z: -0.597356789
          },
          {
            x: 6.42926755,
            y: -0.32,
            z: -0.613632809
          },
          {
            x: 6.414534497,
            y: -0.32,
            z: -0.629908882
          },
          {
            x: 6.399801445,
            y: -0.32,
            z: -0.646184902
          },
          {
            x: 6.392434865,
            y: -0.32,
            z: -0.654322939
          },
          {
            x: 6.385068285,
            y: -0.32,
            z: -0.662460949
          },
          {
            x: 6.377701759,
            y: -0.32,
            z: -0.670598959
          },
          {
            x: 6.370335233,
            y: -0.32,
            z: -0.678736995
          },
          {
            x: 6.362968707,
            y: -0.32,
            z: -0.686875005
          },
          {
            x: 6.355543602,
            y: -0.32,
            z: -0.694778644
          },
          {
            x: 6.348118442,
            y: -0.32,
            z: -0.702682309
          },
          {
            x: 6.340693283,
            y: -0.32,
            z: -0.710585948
          },
          {
            x: 6.325843072,
            y: -0.32,
            z: -0.726393225
          },
          {
            x: 6.318417913,
            y: -0.32,
            z: -0.734296863
          },
          {
            x: 6.310992754,
            y: -0.32,
            z: -0.742200528
          },
          {
            x: 6.303567648,
            y: -0.32,
            z: -0.750104167
          },
          {
            x: 6.296142542,
            y: -0.32,
            z: -0.758007805
          },
          {
            x: 6.288717383,
            y: -0.32,
            z: -0.765911471
          },
          {
            x: 6.281292224,
            y: -0.32,
            z: -0.773815109
          },
          {
            x: 6.273867118,
            y: -0.32,
            z: -0.781718748
          },
          {
            x: 6.266442013,
            y: -0.32,
            z: -0.789622413
          },
          {
            x: 6.259016907,
            y: -0.32,
            z: -0.797526051
          },
          {
            x: 6.251591802,
            y: -0.32,
            z: -0.80542969
          },
          {
            x: 6.244166642,
            y: -0.32,
            z: -0.813333342
          },
          {
            x: 6.237835288,
            y: -0.32,
            z: -0.8213151
          },
          {
            x: 6.23150388,
            y: -0.32,
            z: -0.829296871
          },
          {
            x: 6.225172526,
            y: -0.32,
            z: -0.837278642
          },
          {
            x: 6.218841171,
            y: -0.32,
            z: -0.845260413
          },
          {
            x: 6.212509763,
            y: -0.32,
            z: -0.853242185
          },
          {
            x: 6.206178409,
            y: -0.32,
            z: -0.861223956
          },
          {
            x: 6.199847054,
            y: -0.32,
            z: -0.869205727
          },
          {
            x: 6.187184238,
            y: -0.32,
            z: -0.885169269
          },
          {
            x: 6.180852884,
            y: -0.32,
            z: -0.893151041
          },
          {
            x: 6.17452153,
            y: -0.32,
            z: -0.901132812
          },
          {
            x: 6.161858714,
            y: -0.32,
            z: -0.917096354
          },
          {
            x: 6.161675719141545,
            y: -0.32,
            z: -0.9173270505817582
          }
        ],
        indices: [
          0,
          1,
          599,
          0,
          599,
          598,
          1,
          2,
          600,
          1,
          600,
          599,
          2,
          3,
          601,
          2,
          601,
          600,
          3,
          4,
          602,
          3,
          602,
          601,
          4,
          5,
          603,
          4,
          603,
          602,
          5,
          6,
          604,
          5,
          604,
          603,
          6,
          7,
          605,
          6,
          605,
          604,
          7,
          8,
          606,
          7,
          606,
          605,
          8,
          9,
          607,
          8,
          607,
          606,
          9,
          10,
          608,
          9,
          608,
          607,
          10,
          11,
          609,
          10,
          609,
          608,
          11,
          12,
          610,
          11,
          610,
          609,
          12,
          13,
          611,
          12,
          611,
          610,
          13,
          14,
          612,
          13,
          612,
          611,
          14,
          15,
          613,
          14,
          613,
          612,
          15,
          16,
          614,
          15,
          614,
          613,
          16,
          17,
          615,
          16,
          615,
          614,
          17,
          18,
          616,
          17,
          616,
          615,
          18,
          19,
          617,
          18,
          617,
          616,
          19,
          20,
          618,
          19,
          618,
          617,
          20,
          21,
          619,
          20,
          619,
          618,
          21,
          22,
          620,
          21,
          620,
          619,
          22,
          23,
          621,
          22,
          621,
          620,
          23,
          24,
          622,
          23,
          622,
          621,
          24,
          25,
          623,
          24,
          623,
          622,
          25,
          26,
          624,
          25,
          624,
          623,
          26,
          27,
          625,
          26,
          625,
          624,
          27,
          28,
          626,
          27,
          626,
          625,
          28,
          29,
          627,
          28,
          627,
          626,
          29,
          30,
          628,
          29,
          628,
          627,
          30,
          31,
          629,
          30,
          629,
          628,
          31,
          32,
          630,
          31,
          630,
          629,
          32,
          33,
          631,
          32,
          631,
          630,
          33,
          34,
          632,
          33,
          632,
          631,
          34,
          35,
          633,
          34,
          633,
          632,
          35,
          36,
          634,
          35,
          634,
          633,
          36,
          37,
          635,
          36,
          635,
          634,
          37,
          38,
          636,
          37,
          636,
          635,
          38,
          39,
          637,
          38,
          637,
          636,
          39,
          40,
          638,
          39,
          638,
          637,
          40,
          41,
          639,
          40,
          639,
          638,
          41,
          42,
          640,
          41,
          640,
          639,
          42,
          43,
          641,
          42,
          641,
          640,
          43,
          44,
          642,
          43,
          642,
          641,
          44,
          45,
          643,
          44,
          643,
          642,
          45,
          46,
          644,
          45,
          644,
          643,
          46,
          47,
          645,
          46,
          645,
          644,
          47,
          48,
          646,
          47,
          646,
          645,
          48,
          49,
          647,
          48,
          647,
          646,
          49,
          50,
          648,
          49,
          648,
          647,
          50,
          51,
          649,
          50,
          649,
          648,
          51,
          52,
          650,
          51,
          650,
          649,
          52,
          53,
          651,
          52,
          651,
          650,
          53,
          54,
          652,
          53,
          652,
          651,
          54,
          55,
          653,
          54,
          653,
          652,
          55,
          56,
          654,
          55,
          654,
          653,
          56,
          57,
          655,
          56,
          655,
          654,
          57,
          58,
          656,
          57,
          656,
          655,
          58,
          59,
          657,
          58,
          657,
          656,
          59,
          60,
          658,
          59,
          658,
          657,
          60,
          61,
          659,
          60,
          659,
          658,
          61,
          62,
          660,
          61,
          660,
          659,
          62,
          63,
          661,
          62,
          661,
          660,
          63,
          64,
          662,
          63,
          662,
          661,
          64,
          65,
          663,
          64,
          663,
          662,
          65,
          66,
          664,
          65,
          664,
          663,
          66,
          67,
          665,
          66,
          665,
          664,
          67,
          68,
          666,
          67,
          666,
          665,
          68,
          69,
          667,
          68,
          667,
          666,
          69,
          70,
          668,
          69,
          668,
          667,
          70,
          71,
          669,
          70,
          669,
          668,
          71,
          72,
          670,
          71,
          670,
          669,
          72,
          73,
          671,
          72,
          671,
          670,
          73,
          74,
          672,
          73,
          672,
          671,
          74,
          75,
          673,
          74,
          673,
          672,
          75,
          76,
          674,
          75,
          674,
          673,
          76,
          77,
          675,
          76,
          675,
          674,
          77,
          78,
          676,
          77,
          676,
          675,
          78,
          79,
          677,
          78,
          677,
          676,
          79,
          80,
          678,
          79,
          678,
          677,
          80,
          81,
          679,
          80,
          679,
          678,
          81,
          82,
          680,
          81,
          680,
          679,
          82,
          83,
          681,
          82,
          681,
          680,
          83,
          84,
          682,
          83,
          682,
          681,
          84,
          85,
          683,
          84,
          683,
          682,
          85,
          86,
          684,
          85,
          684,
          683,
          86,
          87,
          685,
          86,
          685,
          684,
          87,
          88,
          686,
          87,
          686,
          685,
          88,
          89,
          687,
          88,
          687,
          686,
          89,
          90,
          688,
          89,
          688,
          687,
          90,
          91,
          689,
          90,
          689,
          688,
          91,
          92,
          690,
          91,
          690,
          689,
          92,
          93,
          691,
          92,
          691,
          690,
          93,
          94,
          692,
          93,
          692,
          691,
          94,
          95,
          693,
          94,
          693,
          692,
          95,
          96,
          694,
          95,
          694,
          693,
          96,
          97,
          695,
          96,
          695,
          694,
          97,
          98,
          696,
          97,
          696,
          695,
          98,
          99,
          697,
          98,
          697,
          696,
          99,
          100,
          698,
          99,
          698,
          697,
          100,
          101,
          699,
          100,
          699,
          698,
          101,
          102,
          700,
          101,
          700,
          699,
          102,
          103,
          701,
          102,
          701,
          700,
          103,
          104,
          702,
          103,
          702,
          701,
          104,
          105,
          703,
          104,
          703,
          702,
          105,
          106,
          704,
          105,
          704,
          703,
          106,
          107,
          705,
          106,
          705,
          704,
          107,
          108,
          706,
          107,
          706,
          705,
          108,
          109,
          707,
          108,
          707,
          706,
          109,
          110,
          708,
          109,
          708,
          707,
          110,
          111,
          709,
          110,
          709,
          708,
          111,
          112,
          710,
          111,
          710,
          709,
          112,
          113,
          711,
          112,
          711,
          710,
          113,
          114,
          712,
          113,
          712,
          711,
          114,
          115,
          713,
          114,
          713,
          712,
          115,
          116,
          714,
          115,
          714,
          713,
          116,
          117,
          715,
          116,
          715,
          714,
          117,
          118,
          716,
          117,
          716,
          715,
          118,
          119,
          717,
          118,
          717,
          716,
          119,
          120,
          718,
          119,
          718,
          717,
          120,
          121,
          719,
          120,
          719,
          718,
          121,
          122,
          720,
          121,
          720,
          719,
          122,
          123,
          721,
          122,
          721,
          720,
          123,
          124,
          722,
          123,
          722,
          721,
          124,
          125,
          723,
          124,
          723,
          722,
          125,
          126,
          724,
          125,
          724,
          723,
          126,
          127,
          725,
          126,
          725,
          724,
          127,
          128,
          726,
          127,
          726,
          725,
          128,
          129,
          727,
          128,
          727,
          726,
          129,
          130,
          728,
          129,
          728,
          727,
          130,
          131,
          729,
          130,
          729,
          728,
          131,
          132,
          730,
          131,
          730,
          729,
          132,
          133,
          731,
          132,
          731,
          730,
          133,
          134,
          732,
          133,
          732,
          731,
          134,
          135,
          733,
          134,
          733,
          732,
          135,
          136,
          734,
          135,
          734,
          733,
          136,
          137,
          735,
          136,
          735,
          734,
          137,
          138,
          736,
          137,
          736,
          735,
          138,
          139,
          737,
          138,
          737,
          736,
          139,
          140,
          738,
          139,
          738,
          737,
          140,
          141,
          739,
          140,
          739,
          738,
          141,
          142,
          740,
          141,
          740,
          739,
          142,
          143,
          741,
          142,
          741,
          740,
          143,
          144,
          742,
          143,
          742,
          741,
          144,
          145,
          743,
          144,
          743,
          742,
          145,
          146,
          744,
          145,
          744,
          743,
          146,
          147,
          745,
          146,
          745,
          744,
          147,
          148,
          746,
          147,
          746,
          745,
          148,
          149,
          747,
          148,
          747,
          746,
          149,
          150,
          748,
          149,
          748,
          747,
          150,
          151,
          749,
          150,
          749,
          748,
          151,
          152,
          750,
          151,
          750,
          749,
          152,
          153,
          751,
          152,
          751,
          750,
          153,
          154,
          752,
          153,
          752,
          751,
          154,
          155,
          753,
          154,
          753,
          752,
          155,
          156,
          754,
          155,
          754,
          753,
          156,
          157,
          755,
          156,
          755,
          754,
          157,
          158,
          756,
          157,
          756,
          755,
          158,
          159,
          757,
          158,
          757,
          756,
          159,
          160,
          758,
          159,
          758,
          757,
          160,
          161,
          759,
          160,
          759,
          758,
          161,
          162,
          760,
          161,
          760,
          759,
          162,
          163,
          761,
          162,
          761,
          760,
          163,
          164,
          762,
          163,
          762,
          761,
          164,
          165,
          763,
          164,
          763,
          762,
          165,
          166,
          764,
          165,
          764,
          763,
          166,
          167,
          765,
          166,
          765,
          764,
          167,
          168,
          766,
          167,
          766,
          765,
          168,
          169,
          767,
          168,
          767,
          766,
          169,
          170,
          768,
          169,
          768,
          767,
          170,
          171,
          769,
          170,
          769,
          768,
          171,
          172,
          770,
          171,
          770,
          769,
          172,
          173,
          771,
          172,
          771,
          770,
          173,
          174,
          772,
          173,
          772,
          771,
          174,
          175,
          773,
          174,
          773,
          772,
          175,
          176,
          774,
          175,
          774,
          773,
          176,
          177,
          775,
          176,
          775,
          774,
          177,
          178,
          776,
          177,
          776,
          775,
          178,
          179,
          777,
          178,
          777,
          776,
          179,
          180,
          778,
          179,
          778,
          777,
          180,
          181,
          779,
          180,
          779,
          778,
          181,
          182,
          780,
          181,
          780,
          779,
          182,
          183,
          781,
          182,
          781,
          780,
          183,
          184,
          782,
          183,
          782,
          781,
          184,
          185,
          783,
          184,
          783,
          782,
          185,
          186,
          784,
          185,
          784,
          783,
          186,
          187,
          785,
          186,
          785,
          784,
          187,
          188,
          786,
          187,
          786,
          785,
          188,
          189,
          787,
          188,
          787,
          786,
          189,
          190,
          788,
          189,
          788,
          787,
          190,
          191,
          789,
          190,
          789,
          788,
          191,
          192,
          790,
          191,
          790,
          789,
          192,
          193,
          791,
          192,
          791,
          790,
          193,
          194,
          792,
          193,
          792,
          791,
          194,
          195,
          793,
          194,
          793,
          792,
          195,
          196,
          794,
          195,
          794,
          793,
          196,
          197,
          795,
          196,
          795,
          794,
          197,
          198,
          796,
          197,
          796,
          795,
          198,
          199,
          797,
          198,
          797,
          796,
          199,
          200,
          798,
          199,
          798,
          797,
          200,
          201,
          799,
          200,
          799,
          798,
          201,
          202,
          800,
          201,
          800,
          799,
          202,
          203,
          801,
          202,
          801,
          800,
          203,
          204,
          802,
          203,
          802,
          801,
          204,
          205,
          803,
          204,
          803,
          802,
          205,
          206,
          804,
          205,
          804,
          803,
          206,
          207,
          805,
          206,
          805,
          804,
          207,
          208,
          806,
          207,
          806,
          805,
          208,
          209,
          807,
          208,
          807,
          806,
          209,
          210,
          808,
          209,
          808,
          807,
          210,
          211,
          809,
          210,
          809,
          808,
          211,
          212,
          810,
          211,
          810,
          809,
          212,
          213,
          811,
          212,
          811,
          810,
          213,
          214,
          812,
          213,
          812,
          811,
          214,
          215,
          813,
          214,
          813,
          812,
          215,
          216,
          814,
          215,
          814,
          813,
          216,
          217,
          815,
          216,
          815,
          814,
          217,
          218,
          816,
          217,
          816,
          815,
          218,
          219,
          817,
          218,
          817,
          816,
          219,
          220,
          818,
          219,
          818,
          817,
          220,
          221,
          819,
          220,
          819,
          818,
          221,
          222,
          820,
          221,
          820,
          819,
          222,
          223,
          821,
          222,
          821,
          820,
          223,
          224,
          822,
          223,
          822,
          821,
          224,
          225,
          823,
          224,
          823,
          822,
          225,
          226,
          824,
          225,
          824,
          823,
          226,
          227,
          825,
          226,
          825,
          824,
          227,
          228,
          826,
          227,
          826,
          825,
          228,
          229,
          827,
          228,
          827,
          826,
          229,
          230,
          828,
          229,
          828,
          827,
          230,
          231,
          829,
          230,
          829,
          828,
          231,
          232,
          830,
          231,
          830,
          829,
          232,
          233,
          831,
          232,
          831,
          830,
          233,
          234,
          832,
          233,
          832,
          831,
          234,
          235,
          833,
          234,
          833,
          832,
          235,
          236,
          834,
          235,
          834,
          833,
          236,
          237,
          835,
          236,
          835,
          834,
          237,
          238,
          836,
          237,
          836,
          835,
          238,
          239,
          837,
          238,
          837,
          836,
          239,
          240,
          838,
          239,
          838,
          837,
          240,
          241,
          839,
          240,
          839,
          838,
          241,
          242,
          840,
          241,
          840,
          839,
          242,
          243,
          841,
          242,
          841,
          840,
          243,
          244,
          842,
          243,
          842,
          841,
          244,
          245,
          843,
          244,
          843,
          842,
          245,
          246,
          844,
          245,
          844,
          843,
          246,
          247,
          845,
          246,
          845,
          844,
          247,
          248,
          846,
          247,
          846,
          845,
          248,
          249,
          847,
          248,
          847,
          846,
          249,
          250,
          848,
          249,
          848,
          847,
          250,
          251,
          849,
          250,
          849,
          848,
          251,
          252,
          850,
          251,
          850,
          849,
          252,
          253,
          851,
          252,
          851,
          850,
          253,
          254,
          852,
          253,
          852,
          851,
          254,
          255,
          853,
          254,
          853,
          852,
          255,
          256,
          854,
          255,
          854,
          853,
          256,
          257,
          855,
          256,
          855,
          854,
          257,
          258,
          856,
          257,
          856,
          855,
          258,
          259,
          857,
          258,
          857,
          856,
          259,
          260,
          858,
          259,
          858,
          857,
          260,
          261,
          859,
          260,
          859,
          858,
          261,
          262,
          860,
          261,
          860,
          859,
          262,
          263,
          861,
          262,
          861,
          860,
          263,
          264,
          862,
          263,
          862,
          861,
          264,
          265,
          863,
          264,
          863,
          862,
          265,
          266,
          864,
          265,
          864,
          863,
          266,
          267,
          865,
          266,
          865,
          864,
          267,
          268,
          866,
          267,
          866,
          865,
          268,
          269,
          867,
          268,
          867,
          866,
          269,
          270,
          868,
          269,
          868,
          867,
          270,
          271,
          869,
          270,
          869,
          868,
          271,
          272,
          870,
          271,
          870,
          869,
          272,
          273,
          871,
          272,
          871,
          870,
          273,
          274,
          872,
          273,
          872,
          871,
          274,
          275,
          873,
          274,
          873,
          872,
          275,
          276,
          874,
          275,
          874,
          873,
          276,
          277,
          875,
          276,
          875,
          874,
          277,
          278,
          876,
          277,
          876,
          875,
          278,
          279,
          877,
          278,
          877,
          876,
          279,
          280,
          878,
          279,
          878,
          877,
          280,
          281,
          879,
          280,
          879,
          878,
          281,
          282,
          880,
          281,
          880,
          879,
          282,
          283,
          881,
          282,
          881,
          880,
          283,
          284,
          882,
          283,
          882,
          881,
          284,
          285,
          883,
          284,
          883,
          882,
          285,
          286,
          884,
          285,
          884,
          883,
          286,
          287,
          885,
          286,
          885,
          884,
          287,
          288,
          886,
          287,
          886,
          885,
          288,
          289,
          887,
          288,
          887,
          886,
          289,
          290,
          888,
          289,
          888,
          887,
          290,
          291,
          889,
          290,
          889,
          888,
          291,
          292,
          890,
          291,
          890,
          889,
          292,
          293,
          891,
          292,
          891,
          890,
          293,
          294,
          892,
          293,
          892,
          891,
          294,
          295,
          893,
          294,
          893,
          892,
          295,
          296,
          894,
          295,
          894,
          893,
          296,
          297,
          895,
          296,
          895,
          894,
          297,
          298,
          896,
          297,
          896,
          895,
          298,
          299,
          897,
          298,
          897,
          896,
          299,
          300,
          898,
          299,
          898,
          897,
          300,
          301,
          899,
          300,
          899,
          898,
          301,
          302,
          900,
          301,
          900,
          899,
          302,
          303,
          901,
          302,
          901,
          900,
          303,
          304,
          902,
          303,
          902,
          901,
          304,
          305,
          903,
          304,
          903,
          902,
          305,
          306,
          904,
          305,
          904,
          903,
          306,
          307,
          905,
          306,
          905,
          904,
          307,
          308,
          906,
          307,
          906,
          905,
          308,
          309,
          907,
          308,
          907,
          906,
          309,
          310,
          908,
          309,
          908,
          907,
          310,
          311,
          909,
          310,
          909,
          908,
          311,
          312,
          910,
          311,
          910,
          909,
          312,
          313,
          911,
          312,
          911,
          910,
          313,
          314,
          912,
          313,
          912,
          911,
          314,
          315,
          913,
          314,
          913,
          912,
          315,
          316,
          914,
          315,
          914,
          913,
          316,
          317,
          915,
          316,
          915,
          914,
          317,
          318,
          916,
          317,
          916,
          915,
          318,
          319,
          917,
          318,
          917,
          916,
          319,
          320,
          918,
          319,
          918,
          917,
          320,
          321,
          919,
          320,
          919,
          918,
          321,
          322,
          920,
          321,
          920,
          919,
          322,
          323,
          921,
          322,
          921,
          920,
          323,
          324,
          922,
          323,
          922,
          921,
          324,
          325,
          923,
          324,
          923,
          922,
          325,
          326,
          924,
          325,
          924,
          923,
          326,
          327,
          925,
          326,
          925,
          924,
          327,
          328,
          926,
          327,
          926,
          925,
          328,
          329,
          927,
          328,
          927,
          926,
          329,
          330,
          928,
          329,
          928,
          927,
          330,
          331,
          929,
          330,
          929,
          928,
          331,
          332,
          930,
          331,
          930,
          929,
          332,
          333,
          931,
          332,
          931,
          930,
          333,
          334,
          932,
          333,
          932,
          931,
          334,
          335,
          933,
          334,
          933,
          932,
          335,
          336,
          934,
          335,
          934,
          933,
          336,
          337,
          935,
          336,
          935,
          934,
          337,
          338,
          936,
          337,
          936,
          935,
          338,
          339,
          937,
          338,
          937,
          936,
          339,
          340,
          938,
          339,
          938,
          937,
          340,
          341,
          939,
          340,
          939,
          938,
          341,
          342,
          940,
          341,
          940,
          939,
          342,
          343,
          941,
          342,
          941,
          940,
          343,
          344,
          942,
          343,
          942,
          941,
          344,
          345,
          943,
          344,
          943,
          942,
          345,
          346,
          944,
          345,
          944,
          943,
          346,
          347,
          945,
          346,
          945,
          944,
          347,
          348,
          946,
          347,
          946,
          945,
          348,
          349,
          947,
          348,
          947,
          946,
          349,
          350,
          948,
          349,
          948,
          947,
          350,
          351,
          949,
          350,
          949,
          948,
          351,
          352,
          950,
          351,
          950,
          949,
          352,
          353,
          951,
          352,
          951,
          950,
          353,
          354,
          952,
          353,
          952,
          951,
          354,
          355,
          953,
          354,
          953,
          952,
          355,
          356,
          954,
          355,
          954,
          953,
          356,
          357,
          955,
          356,
          955,
          954,
          357,
          358,
          956,
          357,
          956,
          955,
          358,
          359,
          957,
          358,
          957,
          956,
          359,
          360,
          958,
          359,
          958,
          957,
          360,
          361,
          959,
          360,
          959,
          958,
          361,
          362,
          960,
          361,
          960,
          959,
          362,
          363,
          961,
          362,
          961,
          960,
          363,
          364,
          962,
          363,
          962,
          961,
          364,
          365,
          963,
          364,
          963,
          962,
          365,
          366,
          964,
          365,
          964,
          963,
          366,
          367,
          965,
          366,
          965,
          964,
          367,
          368,
          966,
          367,
          966,
          965,
          368,
          369,
          967,
          368,
          967,
          966,
          369,
          370,
          968,
          369,
          968,
          967,
          370,
          371,
          969,
          370,
          969,
          968,
          371,
          372,
          970,
          371,
          970,
          969,
          372,
          373,
          971,
          372,
          971,
          970,
          373,
          374,
          972,
          373,
          972,
          971,
          374,
          375,
          973,
          374,
          973,
          972,
          375,
          376,
          974,
          375,
          974,
          973,
          376,
          377,
          975,
          376,
          975,
          974,
          377,
          378,
          976,
          377,
          976,
          975,
          378,
          379,
          977,
          378,
          977,
          976,
          379,
          380,
          978,
          379,
          978,
          977,
          380,
          381,
          979,
          380,
          979,
          978,
          381,
          382,
          980,
          381,
          980,
          979,
          382,
          383,
          981,
          382,
          981,
          980,
          383,
          384,
          982,
          383,
          982,
          981,
          384,
          385,
          983,
          384,
          983,
          982,
          385,
          386,
          984,
          385,
          984,
          983,
          386,
          387,
          985,
          386,
          985,
          984,
          387,
          388,
          986,
          387,
          986,
          985,
          388,
          389,
          987,
          388,
          987,
          986,
          389,
          390,
          988,
          389,
          988,
          987,
          390,
          391,
          989,
          390,
          989,
          988,
          391,
          392,
          990,
          391,
          990,
          989,
          392,
          393,
          991,
          392,
          991,
          990,
          393,
          394,
          992,
          393,
          992,
          991,
          394,
          395,
          993,
          394,
          993,
          992,
          395,
          396,
          994,
          395,
          994,
          993,
          396,
          397,
          995,
          396,
          995,
          994,
          397,
          398,
          996,
          397,
          996,
          995,
          398,
          399,
          997,
          398,
          997,
          996,
          399,
          400,
          998,
          399,
          998,
          997,
          400,
          401,
          999,
          400,
          999,
          998,
          401,
          402,
          1e3,
          401,
          1e3,
          999,
          402,
          403,
          1001,
          402,
          1001,
          1e3,
          403,
          404,
          1002,
          403,
          1002,
          1001,
          404,
          405,
          1003,
          404,
          1003,
          1002,
          405,
          406,
          1004,
          405,
          1004,
          1003,
          406,
          407,
          1005,
          406,
          1005,
          1004,
          407,
          408,
          1006,
          407,
          1006,
          1005,
          408,
          409,
          1007,
          408,
          1007,
          1006,
          409,
          410,
          1008,
          409,
          1008,
          1007,
          410,
          411,
          1009,
          410,
          1009,
          1008,
          411,
          412,
          1010,
          411,
          1010,
          1009,
          412,
          413,
          1011,
          412,
          1011,
          1010,
          413,
          414,
          1012,
          413,
          1012,
          1011,
          414,
          415,
          1013,
          414,
          1013,
          1012,
          415,
          416,
          1014,
          415,
          1014,
          1013,
          416,
          417,
          1015,
          416,
          1015,
          1014,
          417,
          418,
          1016,
          417,
          1016,
          1015,
          418,
          419,
          1017,
          418,
          1017,
          1016,
          419,
          420,
          1018,
          419,
          1018,
          1017,
          420,
          421,
          1019,
          420,
          1019,
          1018,
          421,
          422,
          1020,
          421,
          1020,
          1019,
          422,
          423,
          1021,
          422,
          1021,
          1020,
          423,
          424,
          1022,
          423,
          1022,
          1021,
          424,
          425,
          1023,
          424,
          1023,
          1022,
          425,
          426,
          1024,
          425,
          1024,
          1023,
          426,
          427,
          1025,
          426,
          1025,
          1024,
          427,
          428,
          1026,
          427,
          1026,
          1025,
          428,
          429,
          1027,
          428,
          1027,
          1026,
          429,
          430,
          1028,
          429,
          1028,
          1027,
          430,
          431,
          1029,
          430,
          1029,
          1028,
          431,
          432,
          1030,
          431,
          1030,
          1029,
          432,
          433,
          1031,
          432,
          1031,
          1030,
          433,
          434,
          1032,
          433,
          1032,
          1031,
          434,
          435,
          1033,
          434,
          1033,
          1032,
          435,
          436,
          1034,
          435,
          1034,
          1033,
          436,
          437,
          1035,
          436,
          1035,
          1034,
          437,
          438,
          1036,
          437,
          1036,
          1035,
          438,
          439,
          1037,
          438,
          1037,
          1036,
          439,
          440,
          1038,
          439,
          1038,
          1037,
          440,
          441,
          1039,
          440,
          1039,
          1038,
          441,
          442,
          1040,
          441,
          1040,
          1039,
          442,
          443,
          1041,
          442,
          1041,
          1040,
          443,
          444,
          1042,
          443,
          1042,
          1041,
          444,
          445,
          1043,
          444,
          1043,
          1042,
          445,
          446,
          1044,
          445,
          1044,
          1043,
          446,
          447,
          1045,
          446,
          1045,
          1044,
          447,
          448,
          1046,
          447,
          1046,
          1045,
          448,
          449,
          1047,
          448,
          1047,
          1046,
          449,
          450,
          1048,
          449,
          1048,
          1047,
          450,
          451,
          1049,
          450,
          1049,
          1048,
          451,
          452,
          1050,
          451,
          1050,
          1049,
          452,
          453,
          1051,
          452,
          1051,
          1050,
          453,
          454,
          1052,
          453,
          1052,
          1051,
          454,
          455,
          1053,
          454,
          1053,
          1052,
          455,
          456,
          1054,
          455,
          1054,
          1053,
          456,
          457,
          1055,
          456,
          1055,
          1054,
          457,
          458,
          1056,
          457,
          1056,
          1055,
          458,
          459,
          1057,
          458,
          1057,
          1056,
          459,
          460,
          1058,
          459,
          1058,
          1057,
          460,
          461,
          1059,
          460,
          1059,
          1058,
          461,
          462,
          1060,
          461,
          1060,
          1059,
          462,
          463,
          1061,
          462,
          1061,
          1060,
          463,
          464,
          1062,
          463,
          1062,
          1061,
          464,
          465,
          1063,
          464,
          1063,
          1062,
          465,
          466,
          1064,
          465,
          1064,
          1063,
          466,
          467,
          1065,
          466,
          1065,
          1064,
          467,
          468,
          1066,
          467,
          1066,
          1065,
          468,
          469,
          1067,
          468,
          1067,
          1066,
          469,
          470,
          1068,
          469,
          1068,
          1067,
          470,
          471,
          1069,
          470,
          1069,
          1068,
          471,
          472,
          1070,
          471,
          1070,
          1069,
          472,
          473,
          1071,
          472,
          1071,
          1070,
          473,
          474,
          1072,
          473,
          1072,
          1071,
          474,
          475,
          1073,
          474,
          1073,
          1072,
          475,
          476,
          1074,
          475,
          1074,
          1073,
          476,
          477,
          1075,
          476,
          1075,
          1074,
          477,
          478,
          1076,
          477,
          1076,
          1075,
          478,
          479,
          1077,
          478,
          1077,
          1076,
          479,
          480,
          1078,
          479,
          1078,
          1077,
          480,
          481,
          1079,
          480,
          1079,
          1078,
          481,
          482,
          1080,
          481,
          1080,
          1079,
          482,
          483,
          1081,
          482,
          1081,
          1080,
          483,
          484,
          1082,
          483,
          1082,
          1081,
          484,
          485,
          1083,
          484,
          1083,
          1082,
          485,
          486,
          1084,
          485,
          1084,
          1083,
          486,
          487,
          1085,
          486,
          1085,
          1084,
          487,
          488,
          1086,
          487,
          1086,
          1085,
          488,
          489,
          1087,
          488,
          1087,
          1086,
          489,
          490,
          1088,
          489,
          1088,
          1087,
          490,
          491,
          1089,
          490,
          1089,
          1088,
          491,
          492,
          1090,
          491,
          1090,
          1089,
          492,
          493,
          1091,
          492,
          1091,
          1090,
          493,
          494,
          1092,
          493,
          1092,
          1091,
          494,
          495,
          1093,
          494,
          1093,
          1092,
          495,
          496,
          1094,
          495,
          1094,
          1093,
          496,
          497,
          1095,
          496,
          1095,
          1094,
          497,
          498,
          1096,
          497,
          1096,
          1095,
          498,
          499,
          1097,
          498,
          1097,
          1096,
          499,
          500,
          1098,
          499,
          1098,
          1097,
          500,
          501,
          1099,
          500,
          1099,
          1098,
          501,
          502,
          1100,
          501,
          1100,
          1099,
          502,
          503,
          1101,
          502,
          1101,
          1100,
          503,
          504,
          1102,
          503,
          1102,
          1101,
          504,
          505,
          1103,
          504,
          1103,
          1102,
          505,
          506,
          1104,
          505,
          1104,
          1103,
          506,
          507,
          1105,
          506,
          1105,
          1104,
          507,
          508,
          1106,
          507,
          1106,
          1105,
          508,
          509,
          1107,
          508,
          1107,
          1106,
          509,
          510,
          1108,
          509,
          1108,
          1107,
          510,
          511,
          1109,
          510,
          1109,
          1108,
          511,
          512,
          1110,
          511,
          1110,
          1109,
          512,
          513,
          1111,
          512,
          1111,
          1110,
          513,
          514,
          1112,
          513,
          1112,
          1111,
          514,
          515,
          1113,
          514,
          1113,
          1112,
          515,
          516,
          1114,
          515,
          1114,
          1113,
          516,
          517,
          1115,
          516,
          1115,
          1114,
          517,
          518,
          1116,
          517,
          1116,
          1115,
          518,
          519,
          1117,
          518,
          1117,
          1116,
          519,
          520,
          1118,
          519,
          1118,
          1117,
          520,
          521,
          1119,
          520,
          1119,
          1118,
          521,
          522,
          1120,
          521,
          1120,
          1119,
          522,
          523,
          1121,
          522,
          1121,
          1120,
          523,
          524,
          1122,
          523,
          1122,
          1121,
          524,
          525,
          1123,
          524,
          1123,
          1122,
          525,
          526,
          1124,
          525,
          1124,
          1123,
          526,
          527,
          1125,
          526,
          1125,
          1124,
          527,
          528,
          1126,
          527,
          1126,
          1125,
          528,
          529,
          1127,
          528,
          1127,
          1126,
          529,
          530,
          1128,
          529,
          1128,
          1127,
          530,
          531,
          1129,
          530,
          1129,
          1128,
          531,
          532,
          1130,
          531,
          1130,
          1129,
          532,
          533,
          1131,
          532,
          1131,
          1130,
          533,
          534,
          1132,
          533,
          1132,
          1131,
          534,
          535,
          1133,
          534,
          1133,
          1132,
          535,
          536,
          1134,
          535,
          1134,
          1133,
          536,
          537,
          1135,
          536,
          1135,
          1134,
          537,
          538,
          1136,
          537,
          1136,
          1135,
          538,
          539,
          1137,
          538,
          1137,
          1136,
          539,
          540,
          1138,
          539,
          1138,
          1137,
          540,
          541,
          1139,
          540,
          1139,
          1138,
          541,
          542,
          1140,
          541,
          1140,
          1139,
          542,
          543,
          1141,
          542,
          1141,
          1140,
          543,
          544,
          1142,
          543,
          1142,
          1141,
          544,
          545,
          1143,
          544,
          1143,
          1142,
          545,
          546,
          1144,
          545,
          1144,
          1143,
          546,
          547,
          1145,
          546,
          1145,
          1144,
          547,
          548,
          1146,
          547,
          1146,
          1145,
          548,
          549,
          1147,
          548,
          1147,
          1146,
          549,
          550,
          1148,
          549,
          1148,
          1147,
          550,
          551,
          1149,
          550,
          1149,
          1148,
          551,
          552,
          1150,
          551,
          1150,
          1149,
          552,
          553,
          1151,
          552,
          1151,
          1150,
          553,
          554,
          1152,
          553,
          1152,
          1151,
          554,
          555,
          1153,
          554,
          1153,
          1152,
          555,
          556,
          1154,
          555,
          1154,
          1153,
          556,
          557,
          1155,
          556,
          1155,
          1154,
          557,
          558,
          1156,
          557,
          1156,
          1155,
          558,
          559,
          1157,
          558,
          1157,
          1156,
          559,
          560,
          1158,
          559,
          1158,
          1157,
          560,
          561,
          1159,
          560,
          1159,
          1158,
          561,
          562,
          1160,
          561,
          1160,
          1159,
          562,
          563,
          1161,
          562,
          1161,
          1160,
          563,
          564,
          1162,
          563,
          1162,
          1161,
          564,
          565,
          1163,
          564,
          1163,
          1162,
          565,
          566,
          1164,
          565,
          1164,
          1163,
          566,
          567,
          1165,
          566,
          1165,
          1164,
          567,
          568,
          1166,
          567,
          1166,
          1165,
          568,
          569,
          1167,
          568,
          1167,
          1166,
          569,
          570,
          1168,
          569,
          1168,
          1167,
          570,
          571,
          1169,
          570,
          1169,
          1168,
          571,
          572,
          1170,
          571,
          1170,
          1169,
          572,
          573,
          1171,
          572,
          1171,
          1170,
          573,
          574,
          1172,
          573,
          1172,
          1171,
          574,
          575,
          1173,
          574,
          1173,
          1172,
          575,
          576,
          1174,
          575,
          1174,
          1173,
          576,
          577,
          1175,
          576,
          1175,
          1174,
          577,
          578,
          1176,
          577,
          1176,
          1175,
          578,
          579,
          1177,
          578,
          1177,
          1176,
          579,
          580,
          1178,
          579,
          1178,
          1177,
          580,
          581,
          1179,
          580,
          1179,
          1178,
          581,
          582,
          1180,
          581,
          1180,
          1179,
          582,
          583,
          1181,
          582,
          1181,
          1180,
          583,
          584,
          1182,
          583,
          1182,
          1181,
          584,
          585,
          1183,
          584,
          1183,
          1182,
          585,
          586,
          1184,
          585,
          1184,
          1183,
          586,
          587,
          1185,
          586,
          1185,
          1184,
          587,
          588,
          1186,
          587,
          1186,
          1185,
          588,
          589,
          1187,
          588,
          1187,
          1186,
          589,
          590,
          1188,
          589,
          1188,
          1187,
          590,
          591,
          1189,
          590,
          1189,
          1188,
          591,
          592,
          1190,
          591,
          1190,
          1189,
          592,
          593,
          1191,
          592,
          1191,
          1190,
          593,
          594,
          1192,
          593,
          1192,
          1191,
          594,
          595,
          1193,
          594,
          1193,
          1192,
          595,
          596,
          1194,
          595,
          1194,
          1193,
          596,
          597,
          1195,
          596,
          1195,
          1194,
          597,
          0,
          598,
          597,
          598,
          1195
        ],
        material: {
          color: "#e2d7c9",
          roughness: 0.78,
          metalness: 0
        }
      }
    ],
    sites: [
      {
        id: "cove-apron-approach-1",
        cell: {
          x: 9.65,
          z: 1.25
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-2",
        cell: {
          x: 9.65,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-3",
        cell: {
          x: 9.3,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-4",
        cell: {
          x: 9,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-7",
        cell: {
          x: 7.5,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-8",
        cell: {
          x: 7,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-9",
        cell: {
          x: 6.55,
          z: 1.7
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-10",
        cell: {
          x: 6.55,
          z: 1.2
        },
        floorId: "shared-apron",
        placement: false
      },
      {
        id: "cove-apron-approach-13",
        cell: {
          x: 6.55,
          z: -0.25
        },
        floorId: "shared-apron",
        placement: false
      }
    ],
    ports: []
  },
  siteAdditions: [
    {
      districtId: "native05-inlet-core",
      sites: [
        {
          id: "cove-apron-approach-5",
          cell: {
            x: 8.5,
            z: 1.7
          },
          floorId: "Island / continuous sculpted mature terrain:0",
          placement: false
        },
        {
          id: "cove-apron-approach-6",
          cell: {
            x: 8,
            z: 1.7
          },
          floorId: "Island / continuous sculpted mature terrain:0",
          placement: false
        },
        {
          id: "cove-apron-approach-11",
          cell: {
            x: 6.55,
            z: 0.7
          },
          floorId: "Island / continuous sculpted mature terrain:0",
          placement: false
        },
        {
          id: "cove-apron-approach-12",
          cell: {
            x: 6.55,
            z: 0.25
          },
          floorId: "Island / continuous sculpted mature terrain:0",
          placement: false
        }
      ]
    }
  ],
  edges: [
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "9.5,1"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-1"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-1"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-2"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-2"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-3"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-3"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-4"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-4"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-5"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-5"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-6"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-6"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-7"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-7"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-8"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-8"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-9"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-9"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-10"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-10"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-11"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-11"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-12"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-12"
      },
      to: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-13"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-cove-corner-shared-apron-v1",
        siteId: "cove-apron-approach-13"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "7,-0.25"
      },
      allows: [
        "walk"
      ]
    },
    {
      from: {
        districtId: "native05-inlet-core",
        siteId: "cove-apron-approach-6"
      },
      to: {
        districtId: "native05-inlet-core",
        siteId: "8,1"
      },
      allows: [
        "walk"
      ]
    }
  ],
  routePoints: [
    [
      9.5,
      1
    ],
    [
      9.65,
      1.25
    ],
    [
      9.65,
      1.7
    ],
    [
      9.3,
      1.7
    ],
    [
      9,
      1.7
    ],
    [
      8.5,
      1.7
    ],
    [
      8,
      1.7
    ],
    [
      7.5,
      1.7
    ],
    [
      7,
      1.7
    ],
    [
      6.55,
      1.7
    ],
    [
      6.55,
      1.2
    ],
    [
      6.55,
      0.7
    ],
    [
      6.55,
      0.25
    ],
    [
      6.55,
      -0.25
    ],
    [
      7,
      -0.25
    ]
  ]
};

// src/domain/growingIsland/authoredCoveWorld.ts
var AUTHORED_COVE_VISUAL_CANDIDATE = shared_apron_world_patch_v1_default.candidate;
function freeze3(value) {
  if (value && typeof value === "object" && !Object.isFrozen(value)) {
    for (const child of Object.values(value)) freeze3(child);
    Object.freeze(value);
  }
  return value;
}
function authoredWorldFingerprint(value) {
  const text2 = JSON.stringify(value) ?? "undefined";
  let a = 2166136261, b = 2246822507;
  for (let i = 0; i < text2.length; i++) {
    a = Math.imul(a ^ text2.charCodeAt(i), 16777619);
    b = Math.imul(b ^ text2.charCodeAt(i), 3266489909);
  }
  return (a >>> 0).toString(16).padStart(8, "0") + (b >>> 0).toString(16).padStart(8, "0");
}
var worldRevisions = /* @__PURE__ */ new WeakMap();
var profileRevisions = /* @__PURE__ */ new WeakMap();
function authoredCoveProfileRevision(profile) {
  const known = profileRevisions.get(profile);
  if (known) return known;
  const revision = authoredWorldFingerprint(profile);
  if (profile === AUTHORED_COVE_SOURCE_PROFILE) profileRevisions.set(profile, revision);
  return revision;
}
function authoredWorldGeometryRevision(world) {
  let revision = worldRevisions.get(world);
  if (!revision) {
    revision = authoredWorldFingerprint(world.definition);
    worldRevisions.set(world, revision);
  }
  return revision;
}
function authoredCoveGroundRevision(world, bounds2) {
  const triangles = [];
  for (const floor of world.floors) for (let i = 0; i < floor.indices.length; i += 3) {
    const vertices = floor.indices.slice(i, i + 3).map((index) => floor.vertices[index]);
    const points = vertices.map((vertex) => vertex.point);
    if (Math.max(...points.map((point) => point.x)) < bounds2.min.x || Math.min(...points.map((point) => point.x)) > bounds2.max.x || Math.max(...points.map((point) => point.z)) < bounds2.min.z || Math.min(...points.map((point) => point.z)) > bounds2.max.z) continue;
    triangles.push([floor.id, floor.kind, vertices.map(({ cell, point }) => ({ cell, point }))]);
  }
  return authoredWorldFingerprint(triangles);
}
var AUTHORED_COVE_SOURCE_PROFILE = freeze3({
  revision: "native05-cove-fixed-water-homes-v1",
  sourceId: source_manifest_default.candidate,
  sourceSha256: source_manifest_default.outputs["cove-corner-v3.glb"],
  baseSha256: source_manifest_default.original_hashes["whole-island.glb"],
  groundInputSha256: source_manifest_default.ground_input_sha256,
  transform: {
    pivot: [...source_manifest_default.source_transform.pivot_gltf],
    position: { x: source_manifest_default.source_transform.position[0], y: source_manifest_default.source_transform.position[1], z: source_manifest_default.source_transform.position[2] },
    scale: source_manifest_default.source_transform.uniform_scale,
    yaw: source_manifest_default.source_transform.yaw
  },
  // Actual source floor triangles within this support/entry envelope. The
  // native05 base and its audited hill-water composition have this same value.
  // Include the bowed v4 shoreline and its surrounding clearance, not just
  // the older rectangular apron. A changed floor at its sea-facing tip must
  // invalidate this fixed source too.
  localGround: { min: { x: 5, z: -3.5 }, max: { x: 11, z: 3.5 }, revision: "b854fd9d1de0c4d9" },
  clearCourt: { min: { x: 5, z: -3.5 }, max: { x: 11, z: 3.5 } },
  roles: {
    play: { cell: { x: 8, z: 0 }, stage: 1, style: "plain" },
    homes: [{ cell: { x: 7, z: -1 }, stage: 4, style: "water" }, { cell: { x: 9, z: -1 }, stage: 4, style: "water" }],
    supply: { x: 8, z: -2 }
  },
  patch: structuredClone(shared_apron_world_patch_v1_default)
});
var sameCell = (a, b) => !!a && Math.abs(a.x - b.x) < 1e-8 && Math.abs(a.z - b.z) < 1e-8;
var matchesPlot = (plot, role) => !!plot && sameCell(plot.cell, role.cell) && plot.stage === role.stage && plot.style === role.style;
function deriveAuthoredCovePlan(state, upstream, inputPlaces, profile = AUTHORED_COVE_SOURCE_PROFILE) {
  const upstreamRevision = authoredWorldGeometryRevision(upstream), profileRevision = authoredCoveProfileRevision(profile);
  if (upstream.definition.districts.some((district) => district.id === profile.patch.district.id))
    throw new Error("Authored cove requires the upstream world without its apron");
  const assemblies = [];
  const sourceMatches = upstream.definition.source?.sha256 === profile.baseSha256 && authoredCoveGroundRevision(upstream, profile.localGround) === profile.localGround.revision;
  for (const place of inputPlaces) {
    if (!sourceMatches || place.ruleId !== "P04" || place.variant !== "bay" || !["grown", "lived"].includes(place.stage) || place.missing.length) continue;
    const main = place.mainIds.map((id) => state.plots.find((plot) => plot.id === id));
    const play = main.find((plot) => plot?.kind === "play");
    const homes = main.filter((plot) => plot?.kind === "home");
    if (!play || !matchesPlot(play, profile.roles.play) || main.length !== profile.roles.homes.length + 1 || homes.length !== profile.roles.homes.length || main.some((plot) => !plot || state.unopened.includes(plot.id))) continue;
    if (!profile.roles.homes.every((role) => homes.some((home) => matchesPlot(home, role)))) continue;
    const use = place.useTargets.find((target2) => target2.id === play.id && target2.kind === "play");
    if (!use || !sameCell(use.cell, profile.roles.play.cell)) continue;
    const supply = state.landmarks.find((owner) => owner.kind === "water-bowl" && sameCell(owner.cell, profile.roles.supply) && place.waterRefs.includes(owner.id) && place.memberIds.includes(owner.id));
    if (!supply || ![play, ...homes, supply].every((owner) => owner.cell && upstream.owns(owner.cell) && upstream.anchorAt(owner.cell))) continue;
    const required = new Set([play, ...homes, supply].map((owner) => owner.id));
    const inCourt = (cell) => cell.x >= profile.clearCourt.min.x && cell.x <= profile.clearCourt.max.x && cell.z >= profile.clearCourt.min.z && cell.z <= profile.clearCourt.max.z;
    const occupied = [...state.plots, ...state.keepsakes].filter((owner) => !required.has(owner.id)).flatMap((owner) => owner.cell ? [owner.cell] : []);
    occupied.push(...state.landmarks.filter((owner) => !required.has(owner.id)).flatMap((owner) => occupiedCells({ kind: owner.kind, cell: owner.cell })));
    if (occupied.some(inCourt)) continue;
    assemblies.push({
      placeId: place.id,
      placeRevision: place.revision,
      ownerIds: [...place.memberIds],
      playId: play.id,
      sourceId: profile.sourceId,
      sourceSha256: profile.sourceSha256,
      transform: structuredClone(profile.transform)
    });
  }
  if (assemblies.length > 1) assemblies.length = 0;
  const revision = `authored-cove:${authoredWorldFingerprint([
    upstreamRevision,
    profileRevision,
    assemblies,
    inputPlaces.filter((place) => place.ruleId === "P04"),
    state.plots,
    state.landmarks,
    state.keepsakes,
    state.unopened
  ])}`;
  return freeze3({
    revision,
    upstreamRevision,
    profileRevision,
    sourceId: profile.sourceId,
    sourceSha256: profile.sourceSha256,
    assemblies,
    ...assemblies.length ? { patch: structuredClone(profile.patch) } : {}
  });
}
function composeAuthoredCoveWorld(upstream, plan) {
  if (authoredWorldGeometryRevision(upstream) !== plan.upstreamRevision) throw new Error("Authored cove upstream geometry changed");
  if (!plan.assemblies.length) return upstream;
  if (!plan.patch) throw new Error("Authored cove assembly has no apron");
  const patch = plan.patch;
  if (upstream.definition.districts.some((district) => district.id === patch.district.id)) throw new Error("Authored cove apron already composed");
  if ([...patch.district.sites, ...patch.siteAdditions.flatMap((addition) => addition.sites)].some((site) => site.placement) || patch.edges.some((edge) => edge.allows.length !== 1 || edge.allows[0] !== "walk")) throw new Error("Authored cove patch grants more than walking");
  const districtIds = new Set(upstream.definition.districts.map((district) => district.id));
  if (patch.siteAdditions.some((addition) => !districtIds.has(addition.districtId))) throw new Error("Authored cove site district is absent");
  const districts = upstream.definition.districts.map((district) => ({
    ...district,
    sites: [...district.sites, ...patch.siteAdditions.filter((addition) => addition.districtId === district.id).flatMap((addition) => addition.sites)]
  }));
  const world = compileWorldDefinition({
    ...upstream.definition,
    revision: plan.revision,
    districts: [...districts, patch.district],
    edges: [...upstream.definition.edges, ...patch.edges]
  });
  for (const site of upstream.sites) {
    const before = site.support, after = world.floorAt(site.cell);
    if (!!before !== !!after || before && after && (before.floorId !== after.floorId || Math.hypot(before.point.x - after.point.x, before.point.y - after.point.y, before.point.z - after.point.z) > 1e-8))
      throw new Error("Authored cove patch changes existing site support");
  }
  return world;
}
var placeIdentity = (place) => JSON.stringify([
  place.id,
  place.mainIds,
  place.memberIds,
  place.stage,
  place.variant,
  place.waterRefs,
  place.useTargets.map((target2) => [target2.id, target2.kind, target2.cell])
]);
function reconcileAuthoredCovePlan(plan, inputPlaces, finalPlaces) {
  const valid = plan.assemblies.every((assembly) => {
    const input = inputPlaces.find((place) => place.id === assembly.placeId), final = finalPlaces.find((place) => place.id === assembly.placeId);
    return input && final && placeIdentity(input) === placeIdentity(final);
  });
  if (!valid) return rejectAuthoredCovePlan(plan, "membership-rejected");
  return freeze3({ ...plan, assemblies: plan.assemblies.map((assembly) => ({
    ...assembly,
    placeRevision: finalPlaces.find((place) => place.id === assembly.placeId).revision
  })) });
}
function rejectAuthoredCovePlan(plan, reason) {
  return freeze3({ ...plan, revision: `authored-cove:${authoredWorldFingerprint([plan.revision, reason])}`, assemblies: [], patch: void 0 });
}

// src/domain/natureTown/random.ts
var K = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298];
var rotr = (n, b) => n >>> b | n << 32 - b;
function sha256(text2) {
  const raw = new TextEncoder().encode(text2), length = Math.ceil((raw.length + 9) / 64) * 64;
  const bytes = new Uint8Array(length);
  bytes.set(raw);
  bytes[raw.length] = 128;
  const view = new DataView(bytes.buffer);
  view.setUint32(length - 4, raw.length * 8);
  const h = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
  for (let offset = 0; offset < length; offset += 64) {
    const w = new Uint32Array(64);
    for (let i = 0; i < 64; i++) {
      if (i < 16) w[i] = view.getUint32(offset + i * 4);
      else {
        const a2 = w[i - 15], b2 = w[i - 2];
        w[i] = w[i - 16] + (rotr(a2, 7) ^ rotr(a2, 18) ^ a2 >>> 3) + w[i - 7] + (rotr(b2, 17) ^ rotr(b2, 19) ^ b2 >>> 10);
      }
    }
    let [a, b, c, d, e, f, g, j] = h;
    for (let i = 0; i < 64; i++) {
      const t = j + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + (e & f ^ ~e & g) + K[i] + w[i] | 0;
      const u = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + (a & b ^ a & c ^ b & c) | 0;
      j = g;
      g = f;
      f = e;
      e = d + t | 0;
      d = c;
      c = b;
      b = a;
      a = t + u | 0;
    }
    [a, b, c, d, e, f, g, j].forEach((v, i) => {
      h[i] = h[i] + v | 0;
    });
  }
  return h.map((v) => (v >>> 0).toString(16).padStart(8, "0")).join("");
}

// src/domain/growingIsland/random.ts
function roll(seed, system, id, ordinal) {
  return parseInt(sha256(JSON.stringify(["growing-island-v1", seed, system, id, ordinal])).slice(0, 8), 16) / 4294967296;
}
function pick(items, weights, r) {
  const total = weights.reduce((sum, w) => sum + w, 0);
  let at = r * total;
  for (let i = 0; i < items.length; i++) {
    at -= weights[i];
    if (at < 0) return items[i];
  }
  return items[items.length - 1];
}

// src/domain/growingIsland/flowers.ts
var PLANTED_COLORS = [
  { color: "red", level: 1 },
  { color: "yellow", level: 1 },
  { color: "white", level: 1 },
  { color: "blue", level: 2 }
];
function noteColor(state, color, events) {
  const book = state.flowerBook ?? [];
  if (book.includes(color)) return;
  state.flowerBook = [...book, color];
  events?.push({ type: "new-color", color });
}

// src/domain/growingIsland/nature.ts
function treeAge(state, id) {
  const tree = state.landmarks.find((l) => l.id === id);
  if (!tree || tree.maturedAt === void 0) return "young";
  const age = state.nature.hours - tree.maturedAt;
  return age >= RULES.lordTreeHours ? "lord" : age >= RULES.bigTreeHours ? "big" : "mature";
}

// docs/product/island-place-goals.json
var island_place_goals_default = {
  id: "place-goals-design-v1",
  version: 1,
  date: "2026-10-10",
  status: "RUNTIME_INTEGRATED",
  artBaseline: {
    candidate: "whole-island-native-3d-05",
    glbRevision: "8398eda9ac084a6e",
    decision: "\u5229\u7528\u8005\u300C\u3044\u3044\u611F\u3058\u3002\u3053\u308C\u3092\u3082\u3068\u306B\u2026\u300D\u306B\u57FA\u3065\u304F\u5168\u5CF6\u306E\u7F8E\u8853\u65B9\u5411\u3002\u30B2\u30FC\u30E0\u5B9F\u88C5\u306E\u53D7\u5165\u3068\u306F\u5225\u3002",
    image: "../design/2026-10-10-island-final-3d/whole-island-render.png"
  },
  scope: "\u65E2\u5B58\u306E\u6750\u6599\u30FB\u6642\u8A08\u30FB\u6240\u6709\u304B\u3089\u3001\u4EFB\u610F\u306E\u76EE\u6A19\u3068\u5834\u6240\u306E\u7D44\u307F\u5408\u308F\u305B\u3092\u672C\u4F53\u3078\u7D71\u5408\u3002\u72EC\u7ACB\u89B3\u5BDF\u30FB\u5B9F\u6A5F\u30FB\u5B9F\u6642\u9593\u306E\u81EA\u7136\u6210\u9577\u306F\u5225\u30B2\u30FC\u30C8\u3002",
  common: {
    ownedOnly: true,
    consumeMembers: false,
    learningRewardChange: false,
    goalMandatory: false,
    additionalCurrency: false,
    clockResetOnReconnect: false,
    connection: "orthogonal-or-one-open-cell-straight-gap",
    memberOrder: "stable-id",
    requirements: "runtime v1 minimum conditions; catalog diagrams are explanations, not acquired growth evidence",
    attachmentMaxWalkCells: 2,
    relationMaxWalkCells: 3,
    gardenMinFreeCells: 2
  },
  goals: [
    {
      id: "P01",
      name: "\u6728\u9670\u306E\u5EAD",
      family: "grove",
      scale: "\u5C0F\u3055\u306A\u76EE\u6A19",
      intent: "\u81EA\u5206\u304C\u690D\u3048\u305F\u6728\u306E\u4E0B\u306B\u3001\u307D\u3053\u3082\u3053\u3068\u5EA7\u308C\u308B\u5EAD\u3092\u80B2\u3066\u308B\u3002",
      focus: {
        x: 30,
        y: 46
      },
      clock: "nature",
      image: "../design/2026-10-10-island-final-3d/viewer-grove-phone.png",
      inputs: [
        {
          role: "tree",
          kind: "landmark:sapling",
          count: 2,
          state: "mature"
        },
        {
          role: "seat",
          kind: "landmark:bench",
          count: 1,
          state: "placed"
        }
      ],
      space: "\u6728\u306E\u3064\u306A\u304C\u308A\u3068\u5E2D\u304C\u540C\u3058\u6728\u9670\u306B\u5165\u308A\u3001\u6B69\u3051\u308B\u5165\u53E3\u30682\u30DE\u30B9\u4EE5\u4E0A\u306E\u5EAD\u3092\u6B8B\u3059\u3002",
      variants: [
        {
          id: "lane",
          label: "\u5217\u306B\u3059\u308B",
          result: "\u679D\u304C\u3064\u306A\u304C\u308B\u3001\u7D30\u9577\u3044\u6728\u9670\u306E\u9053",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 1
            },
            {
              role: "tree",
              x: 3,
              z: 1
            },
            {
              role: "seat",
              x: 2,
              z: 2
            }
          ],
          terrain: "any"
        },
        {
          id: "corner",
          label: "\u89D2\u3092\u3064\u304F\u308B",
          result: "\u5EAD\u306E\u7E01\u3092\u5305\u3080\u3001L\u5B57\u306E\u6728\u9670",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 1
            },
            {
              role: "tree",
              x: 2,
              z: 1
            },
            {
              role: "seat",
              x: 2,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "alcove",
          label: "\u6728\u9670\u306E\u304F\u307C\u307F",
          result: "\u3064\u306A\u304C\u308B\u6A39\u51A0\u306E\u7AEF\u306B\u304F\u307C\u307F\u3092\u4F5C\u308A\u3001\u7247\u5074\u306E\u6728\u9670\u3067\u5EA7\u308B\u3002",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 2
            },
            {
              role: "tree",
              x: 3,
              z: 2
            },
            {
              role: "seat",
              x: 1,
              z: 3
            }
          ],
          terrain: "any"
        }
      ],
      stages: [
        {
          id: "seeded",
          label: "\u3057\u3053\u3080",
          condition: "\u6728\u3068\u5E2D\u3092\u7F6E\u304F",
          changes: "\u82D7\u3068\u5E2D\u306E\u4F4D\u7F6E\u306B\u3001\u679D\u304C\u5BC4\u308B\u5411\u304D\u3068\u5EAD\u306E\u4F59\u767D\u3092\u4E88\u544A\u3059\u308B\u3002",
          play: "\u5143\u306E\u5E2D\u3067\u304F\u3064\u308D\u3052\u308B\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u304C\u308B",
          condition: "\u82D7\u306E\u63A5\u7D9A\u3068\u5EAD\u3078\u306E\u5230\u9054\u304C\u6210\u7ACB",
          changes: "\u5730\u9762\u306E\u6839\u3068\u8DB3\u5143\u304C\u9023\u7D9A\u3059\u308B\u3002\u82D7\u306F\u305D\u306E\u307E\u307E\u6B8B\u308B\u3002",
          play: "\u6B21\u306B\u7F6E\u304F\u4F4D\u7F6E\u3092\u5909\u3048\u3066\u3001\u5EAD\u306E\u5F62\u3092\u8A66\u305B\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "2\u672C\u304C\u65E2\u5B58\u306E\u6210\u719F\u6BB5\u968E\u3078\u5230\u9054",
          changes: "\u91CD\u306A\u308B\u6A39\u51A0\u304C\u4E00\u3064\u306E\u6728\u9670\u306B\u306A\u308B\u3002\u8FFD\u52A0\u306E\u5F85\u3061\u6642\u9593\u306F\u8A2D\u3051\u306A\u3044\u3002",
          play: "\u540C\u3058\u5F71\u306E\u4E0B\u3078\u6B69\u304D\u3001\u5E2D\u3078\u5EA7\u308C\u308B\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u5165\u53E3\u30FB\u6728\u9670\u30FB\u5E2D\u3092\u5B9F\u969B\u306E\u884C\u52D5\u306B\u4F7F\u7528",
          changes: "\u307D\u3053\u3082\u3053\u3084\u65E2\u5B58\u4F4F\u4EBA\u304C\u305D\u306E\u6728\u9670\u3068\u5E2D\u3092\u4F7F\u3046\u3002",
          play: "\u3064\u307E\u3093\u3067\u5E2D\u3078\u904B\u3076\u3001\u5EA7\u3063\u3066\u8DB3\u3092\u3086\u3089\u3059\u3002"
        }
      ],
      capability: [
        "derived-place",
        "shared-shade",
        "safe-access"
      ],
      next: [
        "P02",
        "P05"
      ]
    },
    {
      id: "P02",
      name: "\u5927\u6A39\u306E\u4F4F\u307E\u3044",
      family: "grove",
      scale: "\u9577\u304F\u80B2\u3066\u308B\u76EE\u6A19",
      intent: "\u80B2\u3066\u305F\u6728\u3068\u6728\u306E\u5BB6\u304B\u3089\u3001\u4E2D\u3078\u5165\u308C\u308B\u5927\u6A39\u3068\u679D\u306E\u56DE\u5ECA\u3092\u80B2\u3066\u308B\u3002",
      focus: {
        x: 50,
        y: 20
      },
      clock: "nature-and-town",
      image: "../design/2026-10-10-island-final-3d/viewer-grove-phone.png",
      inputs: [
        {
          role: "tree",
          kind: "landmark:sapling",
          count: 4,
          state: "mature; at least 2 big"
        },
        {
          role: "home",
          kind: "plot:home",
          count: 1,
          state: "stage>=2; style=tree"
        },
        {
          role: "seat",
          kind: "landmark:bench",
          count: 1,
          state: "placed"
        }
      ],
      space: "\u6728\u306F\u540C\u3058\u63A5\u7D9A\u9818\u57DF\u3002\u6728\u306E\u5BB6\u306E\u5165\u53E3\u3092\u6B8B\u3057\u3001\u5EAD\u3068\u56DE\u5ECA\u3078\u306E\u9023\u7D9A\u3057\u305F\u7D4C\u8DEF\u3092\u78BA\u4FDD\u3059\u308B\u3002\u666E\u901A\u306E\u5BB6\u306F\u5916\u306E\u5EAD\u3078\u3064\u306A\u3050\u3002",
      variants: [
        {
          id: "lane",
          label: "\u5217\u306B\u3059\u308B",
          result: "\u5E79\u3092\u3064\u306A\u3050\u679D\u306E\u56DE\u5ECA\u3068\u3001\u9053\u6CBF\u3044\u306E\u6728\u306E\u5BB6",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 1
            },
            {
              role: "tree",
              x: 2,
              z: 1
            },
            {
              role: "tree",
              x: 3,
              z: 1
            },
            {
              role: "tree",
              x: 4,
              z: 1
            },
            {
              role: "home",
              x: 3,
              z: 3
            },
            {
              role: "seat",
              x: 4,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "cluster",
          label: "\u584A\u306B\u3059\u308B",
          result: "\u6839\u3068\u5E79\u304C\u5305\u3080\u4F4F\u307E\u3044\u3001\u5468\u56F2\u3092\u56DE\u308C\u308B\u5927\u304D\u306A\u8449\u306E\u5C4B\u6839",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 1
            },
            {
              role: "tree",
              x: 2,
              z: 1
            },
            {
              role: "tree",
              x: 1,
              z: 2
            },
            {
              role: "tree",
              x: 2,
              z: 2
            },
            {
              role: "home",
              x: 4,
              z: 2
            },
            {
              role: "seat",
              x: 3,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "court",
          label: "\u4E2D\u5EAD\u3092\u7A7A\u3051\u308B",
          result: "\u5165\u53E3\u306E\u3042\u308B\u7A7A\u6D1E\u3068\u3001\u5EAD\u3092\u56F2\u3080\u679D\u306E\u56DE\u5ECA",
          demo: [
            {
              role: "tree",
              x: 1,
              z: 1
            },
            {
              role: "tree",
              x: 3,
              z: 1
            },
            {
              role: "tree",
              x: 1,
              z: 3
            },
            {
              role: "tree",
              x: 3,
              z: 3
            },
            {
              role: "home",
              x: 5,
              z: 3
            },
            {
              role: "seat",
              x: 2,
              z: 4
            }
          ],
          terrain: "any"
        }
      ],
      stages: [
        {
          id: "seeded",
          label: "\u3057\u3053\u3080",
          condition: "\u6728\u30FB\u6728\u306E\u5BB6\u30FB\u5E2D\u306E\u4F4D\u7F6E\u3092\u9078\u3076",
          changes: "\u5143\u306E\u5BB6\u3092\u4FDD\u3061\u3001\u6839\u304C\u5305\u3080\u90E8\u5206\u3068\u5165\u53E3\u3001\u4E0A\u3078\u4F38\u3073\u308B\u8449\u306E\u5F62\u3092\u4E88\u544A\u3059\u308B\u3002",
          play: "\u82D7\u3068\u5BB6\u3092\u7F6E\u304D\u76F4\u3057\u3066\u3001\u5165\u308A\u53E3\u306E\u5411\u304D\u3092\u8A66\u305B\u308B\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u304C\u308B",
          condition: "\u6728\u306E\u63A5\u7D9A\u3068\u5BB6\u3078\u306E\u5230\u9054\u304C\u6210\u7ACB",
          changes: "\u6839\u30FB\u5E79\u30FB\u5EAD\u306E\u8DB3\u5143\u304C\u5BC4\u308B\u3002\u5BB6\u3068\u6728\u306EID\u306F\u500B\u5225\u306B\u6B8B\u308B\u3002",
          play: "\u5730\u4E0A\u306E\u5EAD\u3068\u5E2D\u3092\u4F7F\u3048\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "4\u672C\u6210\u719F\u30FB2\u672C\u5927\u6728\u30FB\u6728\u306E\u5BB6\u304C\u3053\u3084\u4EE5\u4E0A",
          changes: "\u9752\u7D2B/\u7FE1\u7FE0\u306E\u8449\u3001\u7425\u73C0\u306E\u5E79\u3001\u958B\u3044\u305F\u7A7A\u6D1E\u3001\u652F\u3048\u306E\u3042\u308B\u56DE\u5ECA\u304C\u80B2\u3064\u3002",
          play: "\u5E79\u306E\u5165\u53E3\u304B\u3089\u5165\u308A\u3001\u679D\u306E\u56DE\u5ECA\u3078\u6B69\u3051\u308B\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u5B9F\u5728\u3059\u308B\u4F4F\u4EBA\u304C\u5230\u9054\u3067\u304D\u308B\u5834\u6240\u3092\u4F7F\u7528",
          changes: "\u5B9F\u4F4F\u4EBA\u304C\u56DE\u5ECA\u306E\u5E2D\u3084\u5165\u53E3\u3092\u4F7F\u3046\u3002\u67B6\u7A7A\u306E\u5165\u5C45\u306F\u8DB3\u3055\u306A\u3044\u3002",
          play: "\u307D\u3053\u3082\u3053\u3092\u56DE\u5ECA\u306E\u5E2D\u3078\u904B\u3076\u3001\u5143\u306E\u5BB6\u306B\u5165\u308B\u3002"
        }
      ],
      capability: [
        "derived-place",
        "shared-shade",
        "safe-access",
        "hollow-and-gallery"
      ],
      next: [
        "P03",
        "P06"
      ]
    },
    {
      id: "P03",
      name: "\u9752\u3044\u6CC9\u306E\u5EAD",
      family: "spring",
      scale: "\u6C34\u3092\u3064\u306A\u3050\u76EE\u6A19",
      intent: "\u81EA\u5206\u306E\u6C34\u3070\u3061\u3068\u307F\u305A\u307F\u3061\u304B\u3089\u3001\u4E00\u7D9A\u304D\u306E\u6CC9\u3068\u6C34\u8FBA\u306E\u5EAD\u3092\u80B2\u3066\u308B\u3002",
      focus: {
        x: 65,
        y: 34
      },
      clock: "existing-water-and-nature",
      image: "../design/2026-10-10-island-final-3d/viewer-village-tablet.png",
      inputs: [
        {
          role: "water",
          kind: "landmark:water-bowl",
          count: 3,
          state: "placed"
        },
        {
          role: "channel",
          kind: "landmark:water-channel",
          count: 2,
          state: "supplied"
        },
        {
          role: "flower",
          kind: "landmark:flower",
          count: 1,
          state: "bloomed"
        },
        {
          role: "seat",
          kind: "landmark:bench",
          count: 1,
          state: "placed"
        }
      ],
      space: "3\u3064\u306E\u6C34\u3070\u3061\u3092\u3001\u5B9F\u969B\u306B\u6C34\u304C\u901A\u308B\u540C\u3058\u9818\u57DF\u3078\u3064\u306A\u3050\u3002\u82B1\u3078\u6C34\u304C\u5C4A\u304D\u3001\u5E2D\u3068\u5165\u53E3\u3078\u6B69\u3051\u308B\u3002\u6BB5\u6CC9\u306F\u5171\u6709\u306E\u5E8A\u9AD8\u3067\u4E0B\u964D\u3059\u308B\u6D41\u308C\u3092\u4F5C\u308C\u308B\u5834\u6240\u306B\u9650\u308B\u3002",
      variants: [
        {
          id: "tiered",
          label: "\u6BB5\u306B\u3064\u306A\u3050",
          result: "\u9271\u77F3\u306E\u6C34\u6E90\u304B\u3089\u6D41\u308C\u308B\u6BB5\u6CC9\u3068\u3001\u6A4B\u3067\u6E21\u308C\u308B\u5EAD",
          demo: [
            {
              role: "water",
              x: 1,
              z: 1
            },
            {
              role: "channel",
              x: 2,
              z: 1
            },
            {
              role: "water",
              x: 3,
              z: 1
            },
            {
              role: "channel",
              x: 4,
              z: 1
            },
            {
              role: "water",
              x: 5,
              z: 1
            },
            {
              role: "flower",
              x: 3,
              z: 3
            },
            {
              role: "seat",
              x: 5,
              z: 3
            }
          ],
          terrain: "slope"
        },
        {
          id: "curve",
          label: "\u66F2\u3052\u308B",
          result: "\u9752\u3044\u6C60\u304C\u66F2\u304C\u3063\u305F\u5CB8\u3067\u3064\u306A\u304C\u308B\u3001\u5E73\u5730\u306E\u6C34\u5EAD",
          demo: [
            {
              role: "water",
              x: 1,
              z: 1
            },
            {
              role: "channel",
              x: 2,
              z: 1
            },
            {
              role: "water",
              x: 3,
              z: 1
            },
            {
              role: "channel",
              x: 3,
              z: 2
            },
            {
              role: "water",
              x: 3,
              z: 3
            },
            {
              role: "flower",
              x: 1,
              z: 3
            },
            {
              role: "seat",
              x: 5,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "shore",
          label: "\u5CB8\u3078\u958B\u304F",
          result: "\u6C34\u306E\u51FA\u53E3\u3068\u6D77\u8FBA\u304C\u898B\u3048\u308B\u3001\u5165\u308A\u6C5F\u306E\u6C34\u5EAD",
          demo: [
            {
              role: "water",
              x: 1,
              z: 2
            },
            {
              role: "channel",
              x: 2,
              z: 2
            },
            {
              role: "water",
              x: 3,
              z: 2
            },
            {
              role: "channel",
              x: 4,
              z: 2
            },
            {
              role: "water",
              x: 5,
              z: 2
            },
            {
              role: "flower",
              x: 3,
              z: 4
            },
            {
              role: "seat",
              x: 5,
              z: 4
            }
          ],
          terrain: "shore"
        }
      ],
      stages: [
        {
          id: "seeded",
          label: "\u3057\u3053\u3080",
          condition: "\u6C34\u3070\u3061\u30FB\u307F\u305A\u307F\u3061\u30FB\u82B1\u30FB\u5E2D\u3092\u7F6E\u304F",
          changes: "\u6C34\u306E\u5165\u53E3\u3068\u51FA\u53E3\u3001\u6CC9\u306B\u306A\u308B\u7BC4\u56F2\u3092\u4E88\u544A\u3059\u308B\u3002",
          play: "\u6C34\u3070\u3061\u306E\u3044\u3064\u3082\u306E\u8FD4\u4E8B\u3092\u697D\u3057\u3081\u308B\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u304C\u308B",
          condition: "\u6C34\u6E90\u304B\u3089\u5B9F\u969B\u306B\u901A\u6C34\u3059\u308B",
          changes: "\u5CB8\u3068\u6C34\u9762\u304C\u9023\u7D9A\u3059\u308B\u3002\u4E7E\u3044\u305F\u307F\u305A\u307F\u3061\u3078\u6C34\u306F\u63CF\u304B\u306A\u3044\u3002",
          play: "\u4E00\u304B\u6240\u306E\u7F6E\u304D\u76F4\u3057\u3067\u3001\u901A\u308B\u6C34\u3092\u898B\u6BD4\u3079\u3089\u308C\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "\u540C\u3058\u901A\u6C34\u9818\u57DF\u30FB\u54B2\u3044\u305F\u82B1\u30FB\u5230\u9054\u3059\u308B\u5E2D\u304C\u6210\u7ACB",
          changes: "\u6DF1\u3044\u9752\u306E\u6C34\u3001\u9271\u77F3\u306E\u6C34\u6E90\u3001\u6C34\u8FBA\u306E\u82B1\u304C\u5EAD\u3092\u3064\u304F\u308B\u3002\u6BB5\u306F\u5E8A\u9AD8\u306E\u3042\u308B\u5834\u6240\u306B\u9650\u308B\u3002",
          play: "\u6A4B\u3084\u5E2D\u304B\u3089\u6CC9\u3092\u773A\u3081\u308B\u3002\u6C34\u304C\u597D\u304D\u306A\u65E2\u5B58\u4F4F\u4EBA\u304C\u5CB8\u3092\u4F7F\u3048\u308B\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u5B9F\u901A\u6C34\u3068\u4F4F\u4EBA\u306E\u6C34\u8FBA\u5229\u7528\u304C\u7D99\u7D9A",
          changes: "\u6C34\u306E\u5C4A\u304F\u82B1\u3068\u5B9F\u4F4F\u4EBA\u306E\u5CB8\u3067\u306E\u884C\u52D5\u304C\u540C\u3058\u5834\u6240\u306B\u898B\u3048\u308B\u3002",
          play: "\u6C34\u306B\u89E6\u308C\u3066\u8FD4\u4E8B\u3092\u697D\u3057\u3080\u3001\u5E2D\u3078\u904B\u3076\u3002"
        }
      ],
      capability: [
        "derived-place",
        "shared-water",
        "safe-access",
        "terrain-height-for-tiered"
      ],
      next: [
        "P04",
        "P05"
      ]
    },
    {
      id: "P04",
      name: "\u5165\u308A\u6C5F\u306E\u96C6\u4F1A\u6240",
      family: "community",
      scale: "\u66AE\u3089\u3057\u3092\u307E\u3068\u3081\u308B\u76EE\u6A19",
      intent: "\u6C34\u8FBA\u306E\u5BB6\u3068\u3042\u305D\u3073\u3070\u304B\u3089\u3001\u8272\u3092\u900F\u304B\u3059\u6BBB\u306B\u5305\u307E\u308C\u305F\u5171\u540C\u306E\u5EAD\u3092\u80B2\u3066\u308B\u3002",
      focus: {
        x: 61,
        y: 77
      },
      clock: "town",
      image: "../design/2026-10-10-island-final-3d/viewer-harbor-tablet.png",
      inputs: [
        {
          role: "home",
          kind: "plot:home",
          count: 2,
          state: "stage>=2"
        },
        {
          role: "play",
          kind: "plot:play",
          count: 1,
          state: "built"
        },
        {
          role: "water",
          kind: "landmark:water-bowl",
          count: 1,
          state: "placed; water reaches play"
        }
      ],
      space: "\u53D6\u5F97\u6E08\u307F\u306E\u6D77\u5CB8\u4ED8\u8FD1\u30022\u8ED2\u3068\u3042\u305D\u3073\u3070\u3092\u56F2\u30802\u30DE\u30B9\u4EE5\u4E0A\u306E\u6B69\u3051\u308B\u5EAD\u3092\u6B8B\u3059\u3002\u4E21\u7384\u95A2\u3001\u3042\u305D\u3073\u3070\u3001\u5CF6\u304B\u3089\u306E\u5165\u53E3\u3092\u5B88\u308B\u3002",
      variants: [
        {
          id: "bay",
          label: "\u5411\u304B\u3044\u5408\u3046",
          result: "\u5BB6\u306E\u9593\u306B\u3001\u8584\u3044\u8C9D\u6BBB\u306E\u5C4B\u6839\u304C\u80B2\u3064\u5EAD",
          demo: [
            {
              role: "home",
              x: 1,
              z: 2
            },
            {
              role: "home",
              x: 5,
              z: 2
            },
            {
              role: "water",
              x: 3,
              z: 2
            },
            {
              role: "play",
              x: 3,
              z: 4
            }
          ],
          terrain: "shore"
        },
        {
          id: "lane",
          label: "\u5CB8\u306B\u4E26\u3079\u308B",
          result: "\u5BB6\u3005\u3092\u7D50\u3076\u3001\u6D77\u306E\u898B\u3048\u308B\u9577\u3044\u5171\u540C\u5C4B\u6839",
          demo: [
            {
              role: "home",
              x: 1,
              z: 2
            },
            {
              role: "home",
              x: 3,
              z: 2
            },
            {
              role: "water",
              x: 5,
              z: 2
            },
            {
              role: "play",
              x: 4,
              z: 3
            }
          ],
          terrain: "shore"
        },
        {
          id: "court",
          label: "\u5EAD\u3092\u56F2\u3080",
          result: "\u7247\u5074\u3092\u958B\u3051\u305F\u6BBB\u3068\u3001\u7384\u95A2\u304C\u898B\u3048\u308B\u4E2D\u5EAD",
          demo: [
            {
              role: "home",
              x: 1,
              z: 1
            },
            {
              role: "home",
              x: 4,
              z: 1
            },
            {
              role: "water",
              x: 5,
              z: 2
            },
            {
              role: "play",
              x: 3,
              z: 3
            }
          ],
          terrain: "shore"
        }
      ],
      stages: [
        {
          id: "seeded",
          label: "\u3057\u3053\u3080",
          condition: "\u5BB6\u30FB\u6C34\u30FB\u3042\u305D\u3073\u3070\u306E\u4F4D\u7F6E\u3092\u9078\u3076",
          changes: "\u500B\u3005\u306E\u5BB6\u3092\u4FDD\u3061\u3001\u96C6\u307E\u308C\u308B\u5E8A\u3068\u5C4B\u6839\u306E\u5E83\u304C\u308A\u3092\u4E88\u544A\u3059\u308B\u3002",
          play: "\u3044\u3064\u3082\u306E\u5BB6\u3068\u3042\u305D\u3073\u3070\u3092\u4F7F\u3048\u308B\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u304C\u308B",
          condition: "\u540C\u3058\u5230\u9054\u3067\u304D\u308B\u5EAD\u306B\u7384\u95A2\u3068\u3042\u305D\u3073\u3070\u304C\u5411\u304F",
          changes: "\u5171\u901A\u306E\u8DB3\u5143\u3068\u66F2\u304C\u3063\u305F\u6881\u304C\u3064\u306A\u304C\u308B\u3002",
          play: "\u5165\u53E3\u3092\u7A7A\u3051\u305F\u5225\u306E\u4E26\u3079\u65B9\u3092\u8A66\u305B\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "2\u8ED2\u3053\u3084\u4EE5\u4E0A\u30FB\u5B8C\u6210\u3042\u305D\u3073\u3070\u30FB\u6C34\u8FBA\u304C\u6210\u7ACB",
          changes: "\u9752/\u7D2B\u3092\u900F\u304B\u3059\u8584\u3044\u6BBB\u306E\u5C4B\u6839\u304C\u5171\u540C\u306E\u5EAD\u3092\u5305\u3080\u3002",
          play: "\u5C4B\u6839\u306E\u4E0B\u3078\u904B\u3093\u3060\u307D\u3053\u3082\u3053\u304C\u3001\u305D\u306E\u3042\u305D\u3073\u3070\u3092\u4F7F\u3046\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u5B9F\u969B\u306E\u4F4F\u4EBA\u3068\u904A\u3073\u5834\u306E\u5229\u7528",
          changes: "\u5B9F\u4F4F\u4EBA\u304C\u5EAD\u3078\u6B69\u3044\u3066\u6765\u308B\u3002\u5BB6\u306E\u5165\u5C45\u67A0\u3084\u3054\u306F\u3093\u3092\u67B6\u7A7A\u306B\u5897\u3084\u3055\u306A\u3044\u3002",
          play: "\u540C\u3058\u3042\u305D\u3073\u3070\u306E\u904A\u3073\u3092\u3001\u5171\u540C\u5C4B\u6839\u306E\u4E0B\u3067\u7E70\u308A\u8FD4\u3059\u3002"
        }
      ],
      capability: [
        "derived-place",
        "shared-water",
        "safe-access",
        "shared-roof"
      ],
      next: [
        "P05",
        "P06"
      ]
    },
    {
      id: "P05",
      name: "\u82B1\u306E\u5C4B\u6839\u306E\u5EAD",
      family: "flowers",
      scale: "\u8272\u3068\u5F62\u3092\u8A66\u3059\u76EE\u6A19",
      intent: "\u690D\u3048\u305F\u82B1\u3068\u5E2D\u304B\u3089\u3001\u5927\u304D\u306A\u82B1\u5F01\u304C\u5305\u3080\u4F11\u61A9\u5834\u6240\u3092\u80B2\u3066\u308B\u3002",
      focus: {
        x: 52,
        y: 57
      },
      clock: "nature",
      image: "../design/2026-10-10-island-final-3d/viewer-garden-tablet.png",
      inputs: [
        {
          role: "flower",
          kind: "landmark:flower",
          count: 4,
          state: "bloomed"
        },
        {
          role: "seat",
          kind: "landmark:bench",
          count: 1,
          state: "placed"
        }
      ],
      space: "\u82B1\u306F\u540C\u3058\u63A5\u7D9A\u9818\u57DF\u3002\u5E2D\u3068\u5165\u53E3\u304C\u5230\u9054\u3067\u304D\u3001\u7A7A\u304D\u5730\u3092\u98F2\u307F\u8FBC\u307E\u306A\u3044\u3002\u57FA\u672C\u306E\u82B1\u8272\u3067\u5B8C\u6210\u3067\u304D\u308B\u3002",
      variants: [
        {
          id: "arch",
          label: "\u5217\u306B\u3059\u308B",
          result: "\u82B1\u5F01\u304C\u3064\u306A\u304C\u308B\u3001\u8272\u306E\u30A2\u30FC\u30C1",
          demo: [
            {
              role: "flower",
              x: 1,
              z: 1
            },
            {
              role: "flower",
              x: 2,
              z: 1
            },
            {
              role: "flower",
              x: 3,
              z: 1
            },
            {
              role: "flower",
              x: 4,
              z: 1
            },
            {
              role: "seat",
              x: 3,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "canopy",
          label: "\u584A\u306B\u3059\u308B",
          result: "\u8907\u6570\u306E\u830E\u304C\u652F\u3048\u308B\u3001\u5927\u304D\u306A\u82B1\u306E\u5C4B\u6839",
          demo: [
            {
              role: "flower",
              x: 1,
              z: 1
            },
            {
              role: "flower",
              x: 2,
              z: 1
            },
            {
              role: "flower",
              x: 1,
              z: 2
            },
            {
              role: "flower",
              x: 2,
              z: 2
            },
            {
              role: "seat",
              x: 3,
              z: 3
            }
          ],
          terrain: "any"
        },
        {
          id: "court",
          label: "\u4E2D\u5EAD\u3092\u7A7A\u3051\u308B",
          result: "\u82B1\u306B\u56F2\u307E\u308C\u3066\u5EA7\u308C\u308B\u3001\u5165\u53E3\u306E\u3042\u308B\u5EAD",
          demo: [
            {
              role: "flower",
              x: 1,
              z: 1
            },
            {
              role: "flower",
              x: 3,
              z: 1
            },
            {
              role: "flower",
              x: 1,
              z: 3
            },
            {
              role: "flower",
              x: 3,
              z: 3
            },
            {
              role: "seat",
              x: 2,
              z: 4
            }
          ],
          terrain: "any"
        }
      ],
      stages: [
        {
          id: "seeded",
          label: "\u3057\u3053\u3080",
          condition: "\u82B1\u3068\u5E2D\u306E\u4F4D\u7F6E\u3001\u597D\u304D\u306A\u8272\u3092\u9078\u3076",
          changes: "\u8272\u306E\u307E\u3068\u307E\u308A\u3068\u82B1\u5F01\u304C\u5BC4\u308B\u5411\u304D\u3092\u4E88\u544A\u3059\u308B\u3002",
          play: "\u540C\u3058\u82B1\u3092\u89E6\u308A\u3001\u8272\u3084\u4F4D\u7F6E\u3092\u9078\u3079\u308B\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u304C\u308B",
          condition: "\u82B1\u3068\u5EAD\u306E\u3064\u306A\u304C\u308A\u304C\u6210\u7ACB",
          changes: "\u8449\u3068\u8DB3\u5143\u304C\u9023\u306A\u308A\u3001\u4E2D\u592E\u306E\u4F59\u767D\u304C\u5EAD\u306B\u306A\u308B\u3002",
          play: "\u5217\u30FB\u584A\u30FB\u4E2D\u5EAD\u3078\u7121\u6599\u3067\u4E26\u3079\u76F4\u305B\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "4\u682A\u304C\u65E2\u5B58\u306E\u958B\u82B1\u6BB5\u968E\u3078\u5230\u9054",
          changes: "\u8272\u306E\u7570\u306A\u308B\u82B1\u5F01\u304C\u652F\u3048\u5408\u3044\u3001\u5E2D\u306E\u4E0A\u3078\u5C4B\u6839\u3092\u3064\u304F\u308B\u3002",
          play: "\u82B1\u306E\u5C4B\u6839\u306E\u4E0B\u306B\u307D\u3053\u3082\u3053\u3092\u5EA7\u3089\u305B\u3089\u308C\u308B\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u54B2\u3044\u305F\u82B1\u3068\u5B9F\u969B\u306E\u5E2D\u306E\u5229\u7528",
          changes: "\u5B9F\u4F4F\u4EBA\u304C\u82B1\u3068\u4F11\u61A9\u5834\u6240\u3092\u4F7F\u3046\u3002",
          play: "\u82B1\u3092\u89E6\u308B\u3001\u5E2D\u3078\u904B\u3076\u3001\u81EA\u7136\u306B\u6DF7\u3056\u3063\u305F\u8272\u3092\u697D\u3057\u3080\u3002"
        }
      ],
      capability: [
        "derived-place",
        "safe-access",
        "joined-petals"
      ],
      next: [
        "P03",
        "P04",
        "P06"
      ]
    },
    {
      id: "P06",
      name: "\u3081\u3050\u308C\u308B\u5CF6",
      family: "island",
      scale: "\u5CF6\u5168\u4F53\u306E\u76EE\u6A19",
      intent: "\u81EA\u5206\u304C\u9078\u3093\u3060\u8907\u6570\u306E\u5834\u6240\u3092\u3064\u306A\u304E\u3001\u666F\u8272\u3068\u66AE\u3089\u3057\u304C\u5909\u308F\u308B\u5CF6\u3078\u80B2\u3066\u308B\u3002",
      focus: {
        x: 50,
        y: 50
      },
      clock: "existing-clocks",
      image: "../design/2026-10-10-island-final-3d/viewer-day-desktop.png",
      inputs: [],
      space: "\u80B2\u3063\u305F\u5834\u6240\u304C3\u3064\u306E\u7570\u306A\u308B\u7CFB\u5217\u306B\u5C5E\u3057\u3001\u4E92\u3044\u306E\u5165\u53E3\u3078\u6B69\u3051\u308B\u3002\u5B9F\u969B\u306E\u5BB6\u306B\u4F4F\u3080\u4EF2\u9593\u3068\u307D\u3053\u3082\u3053\u306E\u66AE\u3089\u3057\u304C\u7D9A\u304F\u3002",
      variants: [],
      stages: [
        {
          id: "seeded",
          label: "\u9078\u3076",
          condition: "\u597D\u304D\u306A\u5834\u6240\u3092\u9078\u3076",
          changes: "\u5168\u5CF63D\u3092\u4E00\u3064\u306E\u5230\u9054\u4F8B\u3068\u3057\u3066\u3001\u80B2\u3066\u305F\u3044\u5834\u6240\u3092\u9078\u3079\u308B\u3002",
          play: "\u76EE\u6A19\u3092\u9078\u3070\u305A\u306B\u81EA\u7531\u306B\u904A\u3093\u3067\u3082\u3088\u3044\u3002"
        },
        {
          id: "connected",
          label: "\u3064\u306A\u3050",
          condition: "\u8907\u6570\u306E\u5834\u6240\u306E\u5165\u53E3\u3078\u6B69\u3051\u308B",
          changes: "\u9053\u30FB\u5CB8\u30FB\u6728\u9670\u306E\u7D99\u304E\u76EE\u304C\u9023\u7D9A\u3059\u308B\u3002",
          play: "\u3069\u3053\u3092\u96A3\u3078\u7F6E\u304F\u304B\u3001\u571F\u5730\u3092\u3069\u3061\u3089\u3078\u5E83\u3052\u308B\u304B\u8A66\u305B\u308B\u3002"
        },
        {
          id: "grown",
          label: "\u80B2\u3064",
          condition: "3\u7CFB\u5217\u4EE5\u4E0A\u306E\u5834\u6240\u304C\u80B2\u3064",
          changes: "\u68EE\u30FB\u6C34\u8FBA\u30FB\u5EAD\u30FB\u96C6\u843D\u304C\u540C\u3058\u5E8A\u306E\u8272\u66FF\u3048\u306B\u306A\u3089\u305A\u3001\u4E00\u3064\u306E\u5CF6\u306E\u666F\u8272\u306B\u306A\u308B\u3002",
          play: "\u666F\u8272\u304C\u5909\u308F\u308B\u7D4C\u8DEF\u3092\u307D\u3053\u3082\u3053\u304C\u6B69\u3051\u308B\u3002"
        },
        {
          id: "lived",
          label: "\u66AE\u3089\u3059",
          condition: "\u5B9F\u5728\u3059\u308B\u4EF2\u9593\u304C1\u4EBA\u4EE5\u4E0A\u4F4F\u307F\u3001\u4F7F\u3048\u308B\u5834\u6240\u304C\u3064\u306A\u304C\u308B",
          changes: "\u4EBA\u53E3\u3001\u5BB6\u3001\u98DF\u4E8B\u3001\u4F11\u61A9\u304C\u5B9F\u72B6\u614B\u306B\u4E00\u81F4\u3059\u308B\u3002",
          play: "\u898B\u305B\u308B\u30FB\u540D\u524D\u3092\u3064\u3051\u308B\u30FB\u5199\u771F\u3092\u6B8B\u3059\u3002\u65B0\u3057\u3044\u5730\u533A\u3065\u304F\u308A\u306F\u7D9A\u3051\u3089\u308C\u308B\u3002"
        }
      ],
      capability: [
        "derived-place",
        "safe-access",
        "place-relations",
        "repeatable-districts"
      ],
      next: []
    }
  ],
  combinations: [
    {
      id: "C01",
      families: [
        "grove",
        "spring"
      ],
      name: "\u6839\u3068\u6CC9\u306E\u5EAD",
      condition: "\u6839\u306E\u5EAD\u3068\u6CC9\u306E\u5165\u53E3\u304C\u8FD1\u304F\u3001\u540C\u3058\u901A\u6C34/\u5230\u9054\u304C\u6210\u7ACB",
      visible: "\u6839\u306E\u8DB3\u5143\u306B\u9752\u3044\u6D41\u308C\u3068\u5CB8\u304C\u9023\u7D9A\u3057\u3001\u6728\u9670\u304B\u3089\u6CC9\u304C\u898B\u3048\u308B\u3002",
      play: "\u5B9F\u969B\u306B\u6C34\u304C\u5C4A\u304F\u690D\u7269\u3068\u3001\u6C34\u8FBA/\u6728\u9670\u306E\u5E2D\u3092\u4F7F\u3046\u3002",
      noStack: "\u6728\u9670\u3068\u6C34\u306F\u5171\u6709\u8A08\u7B97\u30921\u56DE\u3060\u3051\u4F7F\u3046\u3002"
    },
    {
      id: "C02",
      families: [
        "spring",
        "flowers"
      ],
      name: "\u6C34\u8FBA\u306E\u82B1\u306E\u5EAD",
      condition: "\u6CC9\u304B\u3089\u82B1\u306E\u9818\u57DF\u3078\u6C34\u304C\u5C4A\u304D\u3001\u5E2D\u3078\u6B69\u3051\u308B",
      visible: "\u6C34\u306E\u7E01\u306B\u82B1\u5F01\u3068\u4F4E\u3044\u5CB8\u304C\u7D9A\u304F\u3002",
      play: "\u5143\u306E\u6E7F\u308A\u3068\u958B\u82B1\u306E\u898F\u5247\u3067\u82B1\u304C\u80B2\u3061\u3001\u6C34\u8FBA\u306E\u5E2D\u3092\u4F7F\u3048\u308B\u3002",
      noStack: "\u6210\u9577\u500D\u7387\u3001\u4EA4\u914D\u62BD\u9078\u3001\u73CD\u3057\u3044\u8272\u306E\u4FDD\u8A3C\u3092\u8FFD\u52A0\u3057\u306A\u3044\u3002"
    },
    {
      id: "C03",
      families: [
        "grove",
        "community"
      ],
      name: "\u68EE\u306E\u96C6\u843D",
      condition: "\u6728\u306E\u5EAD\u3068\u5BB6\u3005\u304C\u540C\u3058\u5230\u9054\u9818\u57DF\u306B\u3042\u308A\u3001\u7384\u95A2\u3092\u4FDD\u3064",
      visible: "\u679D\u306E\u56DE\u5ECA\u3068\u5171\u540C\u306E\u8DB3\u5143\u304C\u5BB6\u3005\u3078\u7D9A\u304F\u3002",
      play: "\u5B9F\u4F4F\u4EBA\u304C\u5BB6\u304B\u3089\u6728\u9670\u3078\u6B69\u304D\u3001\u4F11\u61A9\u3059\u308B\u3002",
      noStack: "\u5165\u5C45\u67A0\u3001\u3054\u306F\u3093\u3001\u3052\u3093\u304D\u3092\u4E8C\u91CD\u306B\u8DB3\u3055\u306A\u3044\u3002"
    },
    {
      id: "C04",
      families: [
        "flowers",
        "community"
      ],
      name: "\u82B1\u306E\u96C6\u4F1A\u6240",
      condition: "\u5BB6/\u3042\u305D\u3073\u3070\u306E\u5EAD\u3068\u82B1\u306E\u5C4B\u6839\u304C\u8FD1\u304F\u3001\u5165\u53E3\u3078\u6B69\u3051\u308B",
      visible: "\u5171\u540C\u306E\u5EAD\u3078\u82B1\u5F01\u3068\u5C4B\u6839\u306E\u7E01\u304C\u7D9A\u304F\u3002",
      play: "\u65E2\u5B58\u306E\u904A\u3073\u3092\u82B1\u3068\u5171\u540C\u5C4B\u6839\u306B\u5305\u307E\u308C\u305F\u5834\u6240\u3067\u7E70\u308A\u8FD4\u305B\u308B\u3002",
      noStack: "\u796D\u308A\u306E\u56DE\u6570\u3084\u5B66\u7FD2\u5831\u916C\u3092\u5897\u3084\u3055\u306A\u3044\u3002"
    }
  ],
  delivery: [
    {
      id: "D1",
      name: "\u4E00\u3064\u306E\u6728\u9670\u304C\u80B2\u3064",
      goal: "P01",
      done: "\u540C\u30582\u672C\u3067\u96E2\u3059/\u3064\u306A\u3050/\u5206\u3051\u308B\u3092\u5B9F\u88C5\u3057\u3001\u6210\u719F\u3068\u6240\u6709\u3092\u4FDD\u3063\u3066\u5B9F\u969B\u306E\u5E2D\u3092\u4F7F\u3046\u3002"
    },
    {
      id: "D2",
      name: "\u5927\u6A39\u3068\u82B1\u3067\u7F6E\u304D\u65B9\u304C\u5909\u308F\u308B",
      goal: "P02 / P05",
      done: "\u540C\u3058\u6750\u6599\u3067\u5217/\u584A/\u4E2D\u5EAD\u306E\u8F2A\u90ED\u3068\u5165\u53E3\u304C\u5909\u308F\u308A\u3001\u7A7A\u6D1E/\u56DE\u5ECA/\u82B1\u306E\u5C4B\u6839\u3092\u5B9F\u969B\u306B\u4F7F\u3046\u3002"
    },
    {
      id: "D3",
      name: "\u6C34\u3068\u5165\u308A\u6C5F\u304C\u3064\u306A\u304C\u308B",
      goal: "P03 / P04",
      done: "\u901A\u6C34\u30FB\u5E8A\u9AD8\u30FB\u7D4C\u8DEF\u30FB\u63A5\u5730\u3092\u540C\u3058\u8A08\u7B97\u3078\u63C3\u3048\u3001\u6BB5\u6CC9\u3068\u6BBB\u306E\u5C4B\u6839\u3092\u4F7F\u3048\u308B\u72B6\u614B\u306B\u3059\u308B\u3002"
    },
    {
      id: "D4",
      name: "\u5CF6\u5168\u4F53\u3078\u80B2\u3064",
      goal: "P06 / C01\u2013C04",
      done: "\u81EA\u7136\u306A\u53D6\u5F97\u304B\u3089\u8907\u6570\u306E\u5834\u6240\u304C\u80B2\u3061\u3001\u5143\u306E\u5EAD\u3092\u4FDD\u3061\u306A\u304C\u3089\u5730\u533A\u3092\u5E83\u3052\u3001\u518D\u8AAD\u8FBC/\u66F4\u65B0\u5F8C\u3082\u7D9A\u304F\u3002"
    }
  ]
};

// src/domain/growingIsland/placeCatalog.ts
var PLACE_CATALOG = island_place_goals_default;
var placeGoalCatalog = island_place_goals_default.goals.map((goal) => ({
  ...goal,
  id: goal.id,
  family: goal.family
}));
var placeGoalDefinition = (id) => placeGoalCatalog.find((goal) => goal.id === id);
var placeInputCount = (id, kind) => placeGoalDefinition(id).inputs.filter((input) => input.kind === kind).reduce((sum, input) => sum + input.count, 0);

// src/domain/growingIsland/placeTerrain.ts
var stableCoordinate = (value) => Math.round(value * 1e9) / 1e9;
function terrainHeightAt(state, cell, world) {
  if (world) return world.floorAt(cell)?.point.y ?? 0;
  if (!state.land.expanded && !state.land.extra.length && !state.land.capes.length && !state.land.districts?.length) return 0;
  const height = (x2, z2) => {
    const east = Math.max(0, x2 - 5), west = Math.max(0, -x2), south = Math.max(0, z2 - 4);
    const towardBay = Math.max(0, z2 - 3) / 3.4;
    const forest = 1 / (1 + towardBay * towardBay);
    const bank = Math.max(east, west) * 0.34 * forest + south * 0.04;
    return 2.3 * (1 - Math.exp(-bank / 2.3));
  };
  const x = Math.floor(cell.x), z = Math.floor(cell.z), u = cell.x - x, v = cell.z - z;
  const a = height(x, z), b = height(x + 1, z), c = height(x, z + 1), d = height(x + 1, z + 1);
  return stableCoordinate(u + v <= 1 ? a + u * (b - a) + v * (c - a) : d + (1 - u) * (c - d) + (1 - v) * (b - d));
}
var PLACE_GALLERY_WIDTH = 0.42;
function placeGalleryRoute(state, place, anchorCell, world) {
  if (world) return [];
  const open = walkableCells(state);
  const allowed = new Set(place.footprint.filter((cell) => open.has(key2(cell)) && onLand(state, cell)).map(key2));
  const explore = (entrance) => {
    const queue2 = [entrance], previous2 = /* @__PURE__ */ new Map([[key2(entrance), void 0]]);
    for (let i = 0; i < queue2.length; i++) for (const cell of passageNeighbors(queue2[i])) {
      const id = key2(cell);
      if (!allowed.has(id) || previous2.has(id)) continue;
      previous2.set(id, queue2[i]);
      queue2.push(cell);
    }
    return { entrance, queue: queue2, previous: previous2 };
  };
  const choices = place.entrances.filter((cell) => open.has(key2(cell)) && onLand(state, cell)).map(explore).sort((a, b) => b.queue.length - a.queue.length || Math.hypot(a.entrance.x - anchorCell.x, a.entrance.z - anchorCell.z) - Math.hypot(b.entrance.x - anchorCell.x, b.entrance.z - anchorCell.z) || a.entrance.z - b.entrance.z || a.entrance.x - b.entrance.x);
  const chosen = choices[0], base = chosen?.entrance;
  if (!base) return [];
  const ground = terrainHeightAt(state, base) + 0.04;
  const rise = 1.35, radius = 0.275, steps = 28;
  const ascent = [{ ...base, y: ground }];
  ascent.push({ x: base.x + radius, z: base.z, y: ground });
  for (let i = 1; i <= steps; i++) {
    const a = i / steps * Math.PI * 2;
    ascent.push({ x: base.x + Math.cos(a) * radius, z: base.z + Math.sin(a) * radius, y: ground + rise * i / steps });
  }
  const { queue, previous } = chosen;
  const branch = [];
  let cursor = queue[queue.length - 1];
  while (cursor) {
    branch.unshift(cursor);
    cursor = previous.get(key2(cursor));
  }
  const upper = branch.map((cell) => ({ ...cell, y: terrainHeightAt(state, cell) + 0.04 + rise }));
  const clear = (x, z) => allowed.has(key2({ x: Math.round(x), z: Math.round(z) }));
  let loop;
  for (const radius2 of [1.2, 0.95, 0.72, 0.46]) {
    const center = queue.find((cell) => Array.from({ length: 64 }, (_, i) => i * Math.PI * 2 / 64).every((a) => [radius2 - PLACE_GALLERY_WIDTH / 2, radius2, radius2 + PLACE_GALLERY_WIDTH / 2 + 0.018].every((r) => clear(cell.x + Math.cos(a) * r, cell.z + Math.sin(a) * r))));
    if (center) {
      loop = { center, radius: radius2 };
      break;
    }
  }
  const roundWalk = [];
  if (loop) {
    const approach = [];
    let at = loop.center;
    while (at) {
      approach.unshift(at);
      at = previous.get(key2(at));
    }
    roundWalk.push(...approach.map((cell) => ({ ...cell, y: terrainHeightAt(state, cell) + 0.04 + rise })));
    for (let i = 0; i <= 48; i++) {
      const a = i / 48 * Math.PI * 2;
      const point = { x: loop.center.x + Math.cos(a) * loop.radius, z: loop.center.z + Math.sin(a) * loop.radius };
      roundWalk.push({ ...point, y: terrainHeightAt(state, point) + 0.04 + rise });
    }
    roundWalk.push(...approach.slice().reverse().map((cell) => ({ ...cell, y: terrainHeightAt(state, cell) + 0.04 + rise })));
  }
  const stroll = [...roundWalk, ...upper, ...upper.slice(0, -1).reverse()];
  return [...ascent, ...stroll, ascent[ascent.length - 1], ...ascent.slice(0, -1).reverse()].map((point) => ({ x: stableCoordinate(point.x), y: stableCoordinate(point.y), z: stableCoordinate(point.z) }));
}

// src/domain/growingIsland/places.ts
var stable2 = (items) => [...items].sort((a, b) => a.id.localeCompare(b.id));
var count = (id, kind) => placeInputCount(id, kind);
var ATTACH = PLACE_CATALOG.common.attachmentMaxWalkCells;
var FREE = PLACE_CATALOG.common.gardenMinFreeCells;
function placeWalkSearch(open, starts, maxSteps = Infinity, world, target2) {
  const costs = /* @__PURE__ */ new Map(), previous = /* @__PURE__ */ new Map();
  const heap = [];
  let order = 0;
  const less = (a, b) => a.cost < b.cost || a.cost === b.cost && a.order < b.order;
  const push = (cell, cost) => {
    const entry = { cell, cost, order: order++ };
    let at = heap.length;
    heap.push(entry);
    while (at > 0) {
      const parent = Math.floor((at - 1) / 2);
      if (!less(entry, heap[parent])) break;
      heap[at] = heap[parent];
      at = parent;
    }
    heap[at] = entry;
  };
  const pop = () => {
    const result = heap[0], tail = heap.pop();
    if (heap.length) {
      let at = 0;
      while (at * 2 + 1 < heap.length) {
        let child = at * 2 + 1;
        if (child + 1 < heap.length && less(heap[child + 1], heap[child])) child++;
        if (!less(heap[child], tail)) break;
        heap[at] = heap[child];
        at = child;
      }
      heap[at] = tail;
    }
    return result;
  };
  const siteKeys = world ? new Set(world.sites.map((site) => key2(site.cell))) : void 0;
  for (const cell of starts) if (open.has(key2(cell)) && (!siteKeys || siteKeys.has(key2(cell))) && !costs.has(key2(cell))) {
    costs.set(key2(cell), 0);
    previous.set(key2(cell), void 0);
    push(cell, 0);
  }
  const visited = /* @__PURE__ */ new Set();
  while (heap.length) {
    const { cell, cost } = pop(), id = key2(cell);
    if (visited.has(id) || cost !== costs.get(id)) continue;
    visited.add(id);
    if (target2 && id === key2(target2)) break;
    for (const next of passageNeighbors(cell, world)) {
      const nextId = key2(next), nextCost = cost + distance2(cell, next);
      if (!open.has(nextId) || nextCost > maxSteps || nextCost >= (costs.get(nextId) ?? Infinity)) continue;
      previous.set(nextId, cell);
      costs.set(nextId, nextCost);
      push(next, nextCost);
    }
  }
  return { costs, path(to) {
    if (!costs.has(key2(to))) return;
    const path = [];
    let at = to;
    while (at) {
      path.unshift(at);
      at = previous.get(key2(at));
    }
    return path;
  } };
}
var endpointCells = (cell, reached, world) => [cell, ...approachCells(cell, world)].filter((c) => reached.has(key2(c)));
function accessDistanceFrom(search, target2, reached, world) {
  return Math.min(...endpointCells(target2, reached, world).map((cell) => (search.costs.get(key2(cell)) ?? Infinity) + distance2(cell, target2)));
}
function placeConnected(a, b, open, world) {
  const d = distance2(a, b);
  const joins = (from, to) => passageNeighbors(from, world, "join").some((next) => key2(next) === key2(to));
  if (d === 1) return joins(a, b);
  const gap = { x: (a.x + b.x) / 2, z: (a.z + b.z) / 2 };
  return d === 2 && (a.x === b.x || a.z === b.z) && open.has(key2(gap)) && joins(a, gap) && joins(gap, b);
}
function components(items, connects) {
  const remaining = new Map(stable2(items).map((item) => [item.id, item])), out = [];
  while (remaining.size) {
    const start = remaining.values().next().value;
    const group = [start];
    remaining.delete(start.id);
    for (let i = 0; i < group.length; i++) for (const next of [...remaining.values()]) {
      if (!connects(group[i].cell, next.cell)) continue;
      group.push(next);
      remaining.delete(next.id);
    }
    out.push(stable2(group));
  }
  return out;
}
function region(main, open, state, world) {
  const cells = /* @__PURE__ */ new Map();
  for (const item of main) {
    cells.set(key2(item.cell), item.cell);
    const nearby = world ? world.sites.filter((site) => distance2(site.cell, item.cell) <= 1).map((site) => site.cell) : neighbors(item.cell);
    for (const near of nearby) if ((world || onLand(state, near)) && open.has(key2(near))) cells.set(key2(near), near);
  }
  return [...cells.values()].sort((a, b) => a.z - b.z || a.x - b.x);
}
function gardenCells(main, reached, world) {
  const nearby = /* @__PURE__ */ new Map();
  for (const item of main) for (const cell of endpointCells(item.cell, reached, world)) nearby.set(key2(cell), cell);
  return [...nearby.values()];
}
function attachments(groups, items, reached, world) {
  const result = groups.map(() => []);
  const searches = groups.map((group) => placeWalkSearch(reached, gardenCells(group, reached, world), ATTACH, world));
  for (const item of stable2(items)) {
    const choices = groups.map((group, index) => ({
      index,
      id: group[0].id,
      distance: accessDistanceFrom(searches[index], item.cell, reached, world)
    })).filter((choice) => choice.distance <= ATTACH).sort((a, b) => a.distance - b.distance || a.id.localeCompare(b.id));
    if (choices[0]) result[choices[0].index].push(item);
  }
  return result;
}
function enclosedByMain(main, center) {
  if (main.length < 4) return false;
  const quadrants = [false, false, false, false];
  for (const item of main) {
    if (item.cell.x < center.x && item.cell.z < center.z) quadrants[0] = true;
    if (item.cell.x > center.x && item.cell.z < center.z) quadrants[1] = true;
    if (item.cell.x < center.x && item.cell.z > center.z) quadrants[2] = true;
    if (item.cell.x > center.x && item.cell.z > center.z) quadrants[3] = true;
  }
  return quadrants.every(Boolean);
}
function placeShape(main, reached) {
  const occupied = new Set(main.map((item) => key2(item.cell)));
  const minX = Math.min(...main.map((i) => i.cell.x)), maxX = Math.max(...main.map((i) => i.cell.x));
  const minZ = Math.min(...main.map((i) => i.cell.z)), maxZ = Math.max(...main.map((i) => i.cell.z));
  if (main.length >= 4) for (let x = minX + 1; x < maxX; x++) for (let z = minZ + 1; z < maxZ; z++) {
    const center = { x, z };
    if (!reached.has(key2(center))) continue;
    if (enclosedByMain(main, center)) return "court";
  }
  for (const item of main) if ([{ x: 1, z: 0 }, { x: 0, z: 1 }, { x: 1, z: 1 }].every((delta) => occupied.has(key2({ x: item.cell.x + delta.x, z: item.cell.z + delta.z })))) return "cluster";
  if (main.every((item) => item.cell.x === minX) || main.every((item) => item.cell.z === minZ)) return "lane";
  return "freeform";
}
function derivePlace(state, ruleId, family, main, attached, reached, open, variant, connected, missing, world) {
  const members = stable2([...main, ...attached]);
  const anchor = attached.find((item) => state.plots.some((p) => p.id === item.id && (p.kind === "home" || p.kind === "play"))) ?? main[0];
  const footprint = region([...main, ...attached], open, state, world);
  if (variant === "court") {
    const included = new Set(footprint.map(key2));
    for (const id of reached) {
      const [x, z] = id.split(",").map(Number), cell = { x, z };
      if (included.has(id) || !open.has(id) || !(world ? world.floorAt(cell) : onLand(state, cell)) || !enclosedByMain(main, cell)) continue;
      footprint.push(cell);
      included.add(id);
    }
    footprint.sort((a, b) => a.z - b.z || a.x - b.x);
  }
  const entrances = footprint.filter((cell) => reached.has(key2(cell)));
  if ((world ? entrances.filter((cell) => Number.isInteger(cell.x) && Number.isInteger(cell.z)).length : entrances.length) < FREE) missing.push("\u306F\u3044\u308C\u308B \u3059\u304D\u307E\u3092 \u3042\u3051\u3088\u3046");
  const stage = !connected ? "seeded" : missing.length ? "connected" : "grown";
  const useTargets = [];
  for (const member of members) {
    if (!endpointCells(member.cell, reached, world).length) continue;
    if (state.landmarks.some((item) => item.id === member.id && item.kind === "bench")) useTargets.push({ id: member.id, kind: "seat", cell: member.cell });
    if (state.plots.some((item) => item.id === member.id && item.kind === "play" && item.stage > 0 && !state.unopened.includes(item.id)))
      useTargets.push({ id: member.id, kind: "play", cell: member.cell });
  }
  const walkSurface = ruleId === "P02" && stage === "grown" ? placeGalleryRoute(state, { footprint, entrances }, anchor.cell, world) : [];
  if (walkSurface.length) useTargets.push({ id: `${anchor.id}:gallery`, kind: "gallery", cell: walkSurface[0], route: walkSurface });
  if (ruleId === "P03" && entrances.length) useTargets.push({ id: `${anchor.id}:shore`, kind: "shore", cell: entrances[0] });
  const waterRefs = members.filter((item) => state.landmarks.some((l) => l.id === item.id && (l.kind === "water-bowl" || l.kind === "water-channel"))).map((i) => i.id);
  const shadeRefs = members.filter((item) => state.landmarks.some((l) => l.id === item.id && l.kind === "sapling")).map((i) => i.id);
  const revision = JSON.stringify([
    PLACE_CATALOG.version,
    ruleId,
    variant,
    stage,
    members.map((member) => [member.id, member.cell.x, member.cell.z]),
    footprint,
    entrances,
    walkSurface,
    useTargets
  ]);
  return {
    id: `${ruleId}:${anchor.id}`,
    ruleId,
    family,
    anchorId: anchor.id,
    memberIds: members.map((i) => i.id),
    mainIds: main.map((i) => i.id),
    variant,
    stage,
    footprint,
    entrances,
    walkSurface,
    waterRefs,
    shadeRefs,
    useTargets,
    revision,
    missing
  };
}
function derivePlaces(state, world) {
  const open = walkableCells(state, world), reached = reachableFromHome(state, open, world), places = [];
  const landmarks = stable2(state.landmarks.filter((l) => !!l.cell && onLand(state, l.cell, world)));
  const plots = stable2(state.plots.filter((p) => !!p.cell && onLand(state, p.cell, world) && !state.unopened.includes(p.id)));
  const benches = landmarks.filter((l) => l.kind === "bench");
  const trees = landmarks.filter((l) => l.kind === "sapling");
  const groves = components(trees, (a, b) => placeConnected(a, b, open, world));
  const groveSeats = attachments(groves, benches, reached, world);
  const treeHomes = attachments(groves, plots.filter((p) => p.kind === "home" && p.style === "tree"), reached, world);
  groves.forEach((main, index) => {
    const homes2 = treeHomes[index], seats = groveSeats[index], mature = main.filter((t) => t.growth >= TREE_MATURE_HOURS);
    const big = main.filter((t) => ["big", "lord"].includes(treeAge(state, t.id)));
    const enoughBigPlace = main.length >= count("P02", "landmark:sapling") && homes2.length > 0;
    for (const id of enoughBigPlace ? ["P01", "P02"] : ["P01"]) {
      const missing = [];
      if (main.length < count(id, "landmark:sapling")) missing.push("\u6728\u3092 \u3088\u305B\u3066\u307F\u3088\u3046");
      if (mature.length < count(id, "landmark:sapling")) missing.push("\u6728\u304C \u305D\u3060\u3064\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
      if (!seats.length) missing.push("\u6728\u306E\u305D\u3070\u306B \u30D9\u30F3\u30C1\u3092 \u304A\u3053\u3046");
      else if (mature.length >= count(id, "landmark:sapling") && !seats.some((seat) => shadeInfluence(waterLayout(state, world), seat.cell) > 0))
        missing.push("\u6728\u9670\u3078 \u30D9\u30F3\u30C1\u3092 \u3088\u305B\u3088\u3046");
      if (id === "P02") {
        if (big.length < 2) missing.push("\u5927\u6728\u304C \u305D\u3060\u3064\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
        if (!homes2.some((h) => h.stage >= 2)) missing.push("\u6728\u306E\u3044\u3048\u304C \u305D\u3060\u3064\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
      }
      const shape = placeShape(main, reached);
      let variant = shape;
      if (id === "P01") {
        const seat = seats[0];
        const narrow = main.length === 2 && distance2(main[0].cell, main[1].cell) === 1;
        const edge = seat && (seat.cell.x <= Math.min(...main.map((t) => t.cell.x)) || seat.cell.x >= Math.max(...main.map((t) => t.cell.x)));
        variant = narrow ? "corner" : edge ? "alcove" : "lane";
      }
      places.push(derivePlace(
        state,
        id,
        "grove",
        main,
        [...id === "P02" ? homes2 : [], ...seats],
        reached,
        open,
        variant,
        main.length >= count(id, "landmark:sapling") && seats.length > 0,
        missing,
        world
      ));
    }
  });
  const flowers = landmarks.filter((l) => l.kind === "flower");
  const flowerGroups = components(flowers, (a, b) => placeConnected(a, b, open, world));
  const flowerSeats = attachments(flowerGroups, benches, reached, world);
  flowerGroups.forEach((main, index) => {
    if (main.length < 2) return;
    const missing = [], seats = flowerSeats[index];
    if (main.length < count("P05", "landmark:flower")) missing.push("\u82B1\u3092 \u3088\u305B\u3066\u307F\u3088\u3046");
    if (main.filter((f) => f.growth >= BLOOM_HOURS).length < count("P05", "landmark:flower")) missing.push("\u82B1\u304C \u3072\u3089\u304F\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
    if (!seats.length) missing.push("\u82B1\u306E\u305D\u3070\u306B \u30D9\u30F3\u30C1\u3092 \u304A\u3053\u3046");
    const shape = placeShape(main, reached), variant = shape === "lane" ? "arch" : shape === "cluster" ? "canopy" : shape;
    places.push(derivePlace(
      state,
      "P05",
      "flowers",
      main,
      seats,
      reached,
      open,
      variant,
      main.length >= count("P05", "landmark:flower") && seats.length > 0,
      missing,
      world
    ));
  });
  const water = landmarks.filter((l) => l.kind === "water-bowl" || l.kind === "water-channel");
  const channels = connectedWaterChannels(waterLayout(state, world));
  const waterGroups = components(water.filter((l) => l.kind === "water-bowl" || channels.has(key2(l.cell))), (a, b) => passageNeighbors(a, world, "water").some((cell) => key2(cell) === key2(b)));
  const waterSeats = attachments(waterGroups, benches, reached, world);
  const watersideFlowers = attachments(waterGroups, flowers, reached, world);
  const bounds2 = landBounds2(state);
  const nearShore = (cell, radius) => world ? Array.from({ length: 16 }, (_, i) => i * Math.PI / 8).some((angle) => !world.anchorFloorAt({ x: cell.x + Math.cos(angle) * radius, z: cell.z + Math.sin(angle) * radius })) : cell.z >= bounds2.depth - radius || cell.x <= bounds2.minX + radius - 1 || cell.x >= bounds2.maxX - radius + 1;
  waterGroups.forEach((main, index) => {
    const bowls = main.filter((w) => w.kind === "water-bowl");
    if (!bowls.length || main.length < 2) return;
    const supplied = main.filter((w) => w.kind === "water-channel" && channels.has(key2(w.cell)));
    const seats = waterSeats[index], flowersHere = watersideFlowers[index];
    const missing = [];
    if (bowls.length < count("P03", "landmark:water-bowl")) missing.push("\u6C34\u3070\u3061\u3092 \u307F\u305A\u307F\u3061\u3067 \u3064\u306A\u3054\u3046");
    if (supplied.length < count("P03", "landmark:water-channel")) missing.push("\u6C34\u306E\u3068\u304A\u308B \u307F\u305A\u307F\u3061\u3092 \u3064\u306A\u3054\u3046");
    if (!flowersHere.some((f) => f.growth >= BLOOM_HOURS)) missing.push("\u6C34\u306E\u305D\u3070\u3067 \u82B1\u3092 \u305D\u3060\u3066\u3088\u3046");
    if (!seats.length) missing.push("\u5CB8\u306E\u305D\u3070\u306B \u30D9\u30F3\u30C1\u3092 \u304A\u3053\u3046");
    const waterHeight = (cell) => world?.anchorAt(cell)?.y ?? terrainHeightAt(state, cell, world);
    const heights = bowls.map((b) => waterHeight(b.cell));
    const descending = Math.max(...heights) - Math.min(...heights) >= 0.2 && supplied.every((channel) => {
      const adjacent = main.filter((other) => distance2(channel.cell, other.cell) === 1);
      return adjacent.length < 2 || adjacent.some((a) => waterHeight(a.cell) > waterHeight(channel.cell) + 5e-3) && adjacent.some((a) => waterHeight(a.cell) < waterHeight(channel.cell) - 5e-3);
    });
    const onShore = bowls.every((b) => world ? nearShore(b.cell, 2) : b.cell.z >= bounds2.depth - 3 || b.cell.x <= bounds2.minX + 1 || b.cell.x >= bounds2.maxX - 1);
    const variant = descending ? "tiered" : onShore ? "shore" : "curve";
    places.push(derivePlace(
      state,
      "P03",
      "spring",
      main,
      [...flowersHere, ...seats],
      reached,
      open,
      variant,
      bowls.length >= count("P03", "landmark:water-bowl") && supplied.length >= count("P03", "landmark:water-channel") && seats.length > 0 && flowersHere.length > 0,
      missing,
      world
    ));
  });
  const plays = plots.filter((p) => p.kind === "play"), homes = plots.filter((p) => p.kind === "home");
  const playRegions = plays.map((play) => region([play], open, state, world).flatMap((cell) => [cell, ...passageNeighbors(cell, world)]).filter((cell) => reached.has(key2(cell))));
  const assignedHomes = plays.map(() => []);
  const playSearches = playRegions.map((region2) => placeWalkSearch(reached, region2, ATTACH, world));
  for (const home of homes) {
    const closest = plays.map((play, index) => ({
      index,
      id: play.id,
      distance: accessDistanceFrom(playSearches[index], home.cell, reached, world)
    })).filter((c) => c.distance <= ATTACH).sort((a, b) => a.distance - b.distance || a.id.localeCompare(b.id))[0];
    if (closest) assignedHomes[closest.index].push(home);
  }
  plays.forEach((play, index) => {
    const nearby = assignedHomes[index];
    if (!nearby.length) return;
    const supplied = landmarks.filter((l) => l.kind === "water-bowl" && waterInfluence({ items: [{ kind: "water-bowl", cell: l.cell, growth: l.growth }] }, play.cell) > 0);
    const main = stable2([play, ...nearby]);
    const onShore = main.some((item) => nearShore(item.cell, 2));
    const missing = [];
    if (nearby.length < count("P04", "plot:home")) missing.push("\u3042\u305D\u3073\u3070\u306E\u305D\u3070\u306B \u3044\u3048\u3092 \u3088\u305B\u3088\u3046");
    if (nearby.filter((h) => h.stage >= 2).length < count("P04", "plot:home")) missing.push("\u3044\u3048\u304C \u305D\u3060\u3064\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
    if (!play.stage) missing.push("\u3042\u305D\u3073\u3070\u304C \u305D\u3060\u3064\u306E\u3092 \u305F\u306E\u3057\u3082\u3046");
    if (!supplied.length) missing.push("\u3042\u305D\u3073\u3070\u3078 \u6C34\u3092 \u3068\u3069\u3051\u3088\u3046");
    if (!onShore) missing.push("\u6D77\u306E\u305D\u3070\u3078 \u3088\u305B\u3066\u307F\u3088\u3046");
    const homeZ = Math.min(...nearby.map((h) => h.cell.z)), minX = Math.min(...nearby.map((h) => h.cell.x)), maxX = Math.max(...nearby.map((h) => h.cell.x));
    const bowlBetween = supplied.some((b) => b.cell.x > minX && b.cell.x < maxX);
    const variant = play.cell.z - homeZ >= 2 && !bowlBetween ? "court" : bowlBetween ? "bay" : "lane";
    places.push(derivePlace(
      state,
      "P04",
      "community",
      main,
      supplied,
      reached,
      open,
      variant,
      nearby.length >= count("P04", "plot:home") && supplied.length > 0 && onShore,
      missing,
      world
    ));
  });
  const owners = new Map([...landmarks, ...plots].map((item) => [item.id, item]));
  const reassigned = /* @__PURE__ */ new Set();
  for (const bench of benches) {
    const candidates = places.filter((p) => p.memberIds.includes(bench.id) && p.stage !== "seeded");
    const choices = candidates.map((place) => ({
      place,
      group: `${place.family}:${place.mainIds.join(",")}`,
      distance: accessDistanceFrom(placeWalkSearch(reached, gardenCells(place.mainIds.map((id) => owners.get(id)).filter(Boolean), reached, world), ATTACH, world), bench.cell, reached, world)
    })).sort((a, b) => a.distance - b.distance || a.place.anchorId.localeCompare(b.place.anchorId));
    const chosen = choices[0]?.group;
    for (const candidate of choices) if (candidate.group !== chosen) {
      const place = candidate.place;
      reassigned.add(place);
      place.memberIds = place.memberIds.filter((id) => id !== bench.id);
      place.useTargets = place.useTargets.filter((target2) => target2.id !== bench.id);
      if (!place.useTargets.some((target2) => target2.kind === "seat")) {
        place.stage = "connected";
        place.missing.push("\u3053\u306E\u5EAD\u306E \u30D9\u30F3\u30C1\u3092 \u304A\u3053\u3046");
        place.walkSurface = [];
        place.useTargets = place.useTargets.filter((target2) => target2.kind !== "gallery");
      }
      place.revision = JSON.stringify([place.revision, place.memberIds, place.stage]);
    }
  }
  return places.map((place) => {
    if (!reassigned.has(place)) return place;
    const main = place.mainIds.map((id) => owners.get(id)).filter(Boolean);
    const attached = place.memberIds.filter((id) => !place.mainIds.includes(id)).map((id) => owners.get(id)).filter(Boolean);
    const seats = attached.filter((item) => landmarks.some((l) => l.id === item.id && l.kind === "bench"));
    const missing = place.missing.filter((line) => !line.includes("\u30D9\u30F3\u30C1"));
    if (!seats.length) missing.push("\u3053\u306E\u5EAD\u306E \u30D9\u30F3\u30C1\u3092 \u304A\u3053\u3046");
    else if (place.family === "grove" && main.filter((item) => item.growth >= TREE_MATURE_HOURS).length >= count(place.ruleId, "landmark:sapling") && !seats.some((seat) => shadeInfluence(waterLayout(state, world), seat.cell) > 0)) missing.push("\u6728\u9670\u3078 \u30D9\u30F3\u30C1\u3092 \u3088\u305B\u3088\u3046");
    return derivePlace(
      state,
      place.ruleId,
      place.family,
      main,
      attached,
      reached,
      open,
      place.variant,
      place.stage !== "seeded" && seats.length > 0,
      missing,
      world
    );
  }).sort((a, b) => a.id.localeCompare(b.id));
}

// src/domain/growingIsland/authoredShoulderWorld.ts
var AUTHORED_SHOULDER_CANDIDATE = "native05-central-shoulder-sw-v3-source-v1";
var AUTHORED_SHOULDER_COMPONENT_SHA = "c79e2cd7a228b24ff526e6d78913f6a07880e35dec1532d4c278dd7cbf10411e";
var BASE_SHA = "8398eda9ac084a6e80ed22f1a82670c380b017544a177106325aaa7ba7f8f68d";
var GEOMETRY_SHA = "7b4772489932b225d7b31ced5bd53c6835a47e8e63c71eeb43d7b59af1523d3b";
var DISTRICT = "diagnostic-central-shoulder-c-feasibility";
var fail = (message) => {
  throw new Error(`Authored shoulder: ${message}`);
};
var refKey4 = (ref) => JSON.stringify([ref.districtId, ref.siteId]);
var physicalVertex = ({ cell, point }) => ({ cell, point });
var physicalFloor = (floor) => ({ id: floor.id, kind: floor.kind, vertices: floor.vertices.map(physicalVertex), indices: floor.indices });
function fingerprint2(value) {
  const text2 = JSON.stringify(value);
  let a = 2166136261, b = 2246822507;
  for (let i = 0; i < text2.length; i++) {
    a = Math.imul(a ^ text2.charCodeAt(i), 16777619);
    b = Math.imul(b ^ text2.charCodeAt(i), 3266489909);
  }
  return (a >>> 0).toString(16).padStart(8, "0") + (b >>> 0).toString(16).padStart(8, "0");
}
function authoredShoulderGroundRevision(world, bounds2) {
  const triangles = [];
  for (const floor of world.floors) for (let i = 0; i < floor.indices.length; i += 3) {
    const vertices = floor.indices.slice(i, i + 3).map((index) => floor.vertices[index]), points = vertices.map((vertex) => vertex.point);
    if (Math.max(...points.map((p) => p.x)) < bounds2.min.x || Math.min(...points.map((p) => p.x)) > bounds2.max.x || Math.max(...points.map((p) => p.z)) < bounds2.min.z || Math.min(...points.map((p) => p.z)) > bounds2.max.z) continue;
    triangles.push([floor.id, floor.kind, vertices.map(physicalVertex)]);
  }
  return fingerprint2(triangles);
}
function authoredShoulderProfilePhysicalRevision(profile) {
  return fingerprint2({
    candidate: profile.candidate,
    source: profile.source,
    localGround: profile.localGround,
    boundary: profile.boundary,
    sourceDistrictId: profile.sourceDistrictId,
    clipFloorIds: profile.clipFloorIds,
    transferSiteIds: profile.transferSiteIds,
    district: { ...profile.district, floors: profile.district.floors.map(physicalFloor) },
    edges: profile.edges,
    triangleLineage: profile.triangleLineage
  });
}
function authoredShoulderProfileDrawingRevision(profile) {
  return fingerprint2(profile);
}
function area3(poly) {
  return poly.length < 3 ? 0 : Math.abs(poly.reduce((sum, p, i) => {
    const q = poly[(i + 1) % poly.length];
    return sum + p.cell.x * q.cell.z - q.cell.x * p.cell.z;
  }, 0)) / 2;
}
var lerp = (a, b, t) => a + (b - a) * t;
var lerpPoint = (a, b, t) => ({ x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), z: lerp(a.z, b.z, t) });
function half(poly, distance3) {
  const result = [];
  for (let i = 0; i < poly.length; i++) {
    const p = poly[i], q = poly[(i + 1) % poly.length], d = distance3(p.cell), e = distance3(q.cell);
    if (d >= -1e-12) result.push(p);
    if (d >= 0 !== e >= 0) {
      const t = d / (d - e);
      result.push({
        cell: { x: lerp(p.cell.x, q.cell.x, t), z: lerp(p.cell.z, q.cell.z, t) },
        point: lerpPoint(p.point, q.point, t),
        // Keep linear source interpolation through successive clips;
        // normalizing at each cut changes the original shading field.
        ...p.normal && q.normal ? { normal: lerpPoint(p.normal, q.normal, t) } : {}
      });
    }
  }
  return area3(result) > 1e-12 ? result : [];
}
function carve(poly, boundary) {
  let inside = [...poly];
  const outside = [];
  for (let i = 0; i < boundary.length; i++) {
    const p = boundary[i], q = boundary[(i + 1) % boundary.length];
    const distance3 = (c) => (q.x - p.x) * (c.z - p.z) - (q.z - p.z) * (c.x - p.x);
    const remainder = half(inside, (cell) => -distance3(cell));
    if (remainder.length) outside.push(remainder);
    inside = half(inside, distance3);
    if (!inside.length) break;
  }
  return { inside, outside };
}
function clipFloor(floor, boundary) {
  const vertices = [...floor.vertices], indices = [];
  for (let i = 0; i < floor.indices.length; i += 3) {
    const sourceIndices = floor.indices.slice(i, i + 3), result = carve(sourceIndices.map((index) => floor.vertices[index]), boundary);
    if (!result.inside.length) {
      indices.push(...sourceIndices);
      continue;
    }
    for (const poly of result.outside) {
      const offset = vertices.length;
      vertices.push(...poly);
      for (let j = 1; j + 1 < poly.length; j++) {
        if (area3([poly[0], poly[j], poly[j + 1]]) * 2 > 10001e-16) indices.push(offset, offset + j, offset + j + 1);
      }
    }
  }
  return { ...floor, vertices, indices };
}
function checkProfile(profile) {
  if (profile.version !== 1 || profile.candidate !== AUTHORED_SHOULDER_CANDIDATE || profile.source.baseSha256 !== BASE_SHA || profile.source.componentSha256 !== AUTHORED_SHOULDER_COMPONENT_SHA || profile.source.geometryProfileSha256 !== GEOMETRY_SHA) fail("source identity differs");
  if (profile.physicalRevision !== authoredShoulderProfilePhysicalRevision(profile)) fail("physical profile differs");
  const district = profile.district;
  if (district.id !== DISTRICT || district.turn !== 0 || district.logicalOrigin.x !== 0 || district.logicalOrigin.z !== 0 || Object.values(district.worldOrigin).some((value) => value !== 0) || district.floors.length !== 2 || district.floors.some((floor) => floor.kind !== "ground") || district.sites.length !== 19 || district.sites.filter((site) => site.placement).length !== 2 || profile.transferSiteIds.length !== 2 || profile.edges.length !== 36 || profile.edges.filter((edge) => edge.allows.length === 1 && edge.allows[0] === "walk").length !== 35)
    fail("diagnostic extension contract differs");
}
function composeAuthoredShoulderWorld(upstream, profile) {
  checkProfile(profile);
  if (upstream.definition.districts.some((district) => district.id === DISTRICT || district.id.startsWith("native05-cove-")))
    fail("requires immutable terrain without shoulder or cove");
  if (upstream.definition.source?.sha256 !== profile.source.baseSha256 || authoredShoulderGroundRevision(upstream, profile.localGround) !== profile.localGround.revision) fail("upstream physical locality differs");
  const source = upstream.definition.districts.find((district) => district.id === profile.sourceDistrictId) ?? fail("source district frame differs");
  if (source.turn !== 0 || source.logicalOrigin.x !== 0 || source.logicalOrigin.z !== 0 || Object.values(source.worldOrigin).some((value) => value !== 0) || profile.clipFloorIds.some((id) => !source.floors.some((floor) => floor.id === id))) fail("source district frame differs");
  const transfer = new Set(profile.transferSiteIds);
  for (const id of transfer) {
    const old = source.sites.find((site) => site.id === id), next = profile.district.sites.find((site) => site.id === id);
    if (!old || old.placement || !next?.placement || old.cell.x !== next.cell.x || old.cell.z !== next.cell.z) fail("new land must replace the audited walk-only site");
  }
  for (const site of upstream.sites.filter((site2) => site2.placement)) {
    const { x, z } = site.cell;
    const square = [[x - 0.46, z - 0.46], [x + 0.46, z - 0.46], [x + 0.46, z + 0.46], [x - 0.46, z + 0.46]].map(([x2, z2]) => ({ cell: { x: x2, z: z2 }, point: { x: x2, y: 0, z: z2 } }));
    if (area3(carve(square, profile.boundary).inside) > 1e-12) fail("replacement intersects an acquired footprint");
  }
  const definition = structuredClone(upstream.definition);
  definition.districts = definition.districts.map((district) => district.id !== source.id ? district : {
    ...district,
    floors: district.floors.map((floor) => profile.clipFloorIds.includes(floor.id) ? clipFloor(floor, profile.boundary) : floor),
    anchorFloors: district.anchorFloors ?? district.floors,
    sites: district.sites.filter((site) => !transfer.has(site.id)).map((site) => ({
      ...site,
      anchorPoint: site.anchorPoint ?? upstream.anchorAt(site.cell)
    }))
  });
  definition.districts = [...definition.districts, structuredClone(profile.district)];
  const mapRef = (ref) => ref.districtId === source.id && transfer.has(ref.siteId) ? { districtId: DISTRICT, siteId: ref.siteId } : ref;
  const oldEdges = definition.edges.map((edge) => ({ ...edge, from: mapRef(edge.from), to: mapRef(edge.to) }));
  definition.edges = oldEdges.map((edge) => ({ ...edge, allows: edge.allows.filter((passage) => passage !== "walk") })).filter((edge) => edge.allows.length);
  definition.revision = `authored-shoulder:${profile.physicalRevision}`;
  const support = compileWorldDefinition(definition), cells = new Map(support.sites.map((site) => [refKey4(site.ref), site.cell]));
  definition.edges = oldEdges.map((edge) => ({ ...edge, allows: edge.allows.filter((passage) => passage !== "walk" || support.isWalkEdgeSupported(cells.get(refKey4(edge.from)), cells.get(refKey4(edge.to)))) })).filter((edge) => edge.allows.length);
  definition.edges = [...definition.edges, ...structuredClone(profile.edges)];
  definition.revision = `authored-shoulder:${profile.physicalRevision}:${fingerprint2({ ...definition, revision: void 0 })}`;
  const world = compileWorldDefinition(definition);
  for (const site of upstream.sites.filter((site2) => site2.placement)) {
    if (JSON.stringify(world.anchorAt(site.cell)) !== JSON.stringify(site.point)) fail("acquired anchor changed");
    for (const dx of [-0.46, 0, 0.46]) for (const dz of [-0.46, 0, 0.46]) {
      const cell = { x: site.cell.x + dx, z: site.cell.z + dz };
      if (JSON.stringify(world.floorAt(cell)?.point) !== JSON.stringify(upstream.floorAt(cell)?.point)) fail("acquired support changed");
    }
  }
  return world;
}

// src/domain/growingIsland/authoredWorldFrame.ts
var frames2 = /* @__PURE__ */ new WeakMap();
var extensions = /* @__PURE__ */ new WeakMap();
function authoredWorldFrame(state, immutableBase, options, profile = AUTHORED_COVE_SOURCE_PROFILE) {
  if (immutableBase.definition.districts.some((district) => district.id === profile.patch.district.id))
    throw new Error("Authored world frame requires the immutable base, not a cove frame");
  const stateInputs = Object.fromEntries(Object.entries(state).filter(([field]) => field !== "applied" && field !== "placeProgress"));
  const shoulderRevision = options.shoulder ? authoredShoulderProfileDrawingRevision(options.shoulder) : void 0;
  const key6 = JSON.stringify([options.water, options.cove, shoulderRevision, options.cove ? authoredCoveProfileRevision(profile) : void 0, stateInputs]);
  let cache = frames2.get(immutableBase);
  if (!cache) {
    cache = /* @__PURE__ */ new Map();
    frames2.set(immutableBase, cache);
  }
  const cached = cache.get(key6);
  if (cached) return cached;
  cache.clear();
  let land = immutableBase;
  if (options.shoulder && shoulderRevision) {
    const known = extensions.get(immutableBase);
    if (known?.revision === shoulderRevision) land = known.world;
    else {
      land = composeAuthoredShoulderWorld(immutableBase, options.shoulder);
      extensions.set(immutableBase, { revision: shoulderRevision, world: land });
    }
  }
  const water = options.water ? authoredWaterFrame(state, land) : void 0;
  const upstream = water?.world ?? land;
  let world = upstream, covePlan;
  if (options.cove) {
    const inputPlaces = derivePlaces(state, upstream);
    covePlan = deriveAuthoredCovePlan(state, upstream, inputPlaces, profile);
    if (covePlan.assemblies.length) {
      try {
        const composed = composeAuthoredCoveWorld(upstream, covePlan);
        covePlan = reconcileAuthoredCovePlan(covePlan, inputPlaces, derivePlaces(state, composed));
        if (covePlan.assemblies.length) world = composed;
      } catch (error) {
        if (!(error instanceof Error) || !/^(Invalid island world:|Authored cove)/.test(error.message)) throw error;
        covePlan = rejectAuthoredCovePlan(covePlan, error.message);
      }
    }
  }
  const revision = options.cove ? `authored-world:${authoredWorldFingerprint([
    authoredWorldGeometryRevision(immutableBase),
    options.water,
    water?.plan.revision,
    covePlan?.revision,
    ...shoulderRevision ? [shoulderRevision] : []
  ])}` : water?.plan.revision ?? upstream.definition.revision ?? "base";
  const frame = Object.freeze({ world, ...water ? { waterPlan: water.plan } : {}, ...covePlan ? { covePlan } : {}, revision });
  cache.set(key6, frame);
  return frame;
}

// src/domain/growingIsland/guidance.ts
var STARTER_STEPS = ["S1", "S2", "S3", "S4", "S5"];
var ACHIEVEMENTS = ["A1", "A2", "A3", "A4", "A5", "A6"];
var target = (state, id) => state.plots.find((p) => p.id === id) ?? state.landmarks.find((p) => p.id === id) ?? state.keepsakes.find((p) => p.id === id) ?? state.villagers.find((p) => p.id === id);
function evidence(state, source, at, id) {
  const item = id ? target(state, id) : void 0;
  return { source, ...at === void 0 ? {} : { at }, ...id ? { targetId: id } : {}, snapshot: structuredClone({
    flagColor: state.flagColor ?? 0,
    ...item ? { target: item } : {},
    ...source === "legacy" ? { legacy: true } : {}
  }) };
}
function achieve(state, id, proof, silent = false) {
  const g = state.guidance;
  if (g.achievements[id]) return;
  g.achievements[id] = structuredClone(proof);
  if (silent) g.notified.push(id);
}
function noteTownBuilds(state, events) {
  for (const event of events) if (event.type === "built") {
    const p = state.plots.find((plot) => plot.id === event.plotId);
    if (p && !p.starter && p.paid > 0 && p.kind !== "wild" && p.kind !== "wonder" && p.builtAt > p.plantedAt)
      p.townBuilt = true;
  }
}
function noteGuidanceIntent(previous, state, command, source, at) {
  const g = state.guidance;
  if (!g) return;
  const proof = (id) => evidence(state, source, at, id);
  const step = (id, e) => {
    g.starter.steps[id] ??= structuredClone(e);
  };
  if (command.type === "plant" && previous.tutorial === "first-home" && command.kind === "home") {
    const p = state.plots.find((p2) => !previous.plots.some((old) => old.id === p2.id));
    if (p) {
      p.starter = true;
      step("S1", proof(p.id));
    }
  }
  if (command.type === "open" || command.type === "open-all") {
    for (const id of previous.unopened) if (command.type === "open-all" || command.id === id) {
      const p = state.plots.find((p2) => p2.id === id);
      if (!p || !p.cell || p.stage === 0) continue;
      if (p.starter || g.starter.steps.S1?.targetId === id) step("S2", proof(id));
      if (!p.starter && p.townBuilt && p.paid > 0 && p.kind !== "wild" && p.kind !== "wonder") {
        step("S5", proof(id));
        achieve(state, "A2", proof(id));
      }
    }
  }
  if (command.type === "disembark" || command.type === "open-all") {
    for (const id of previous.arrivals) if (command.type === "open-all" || command.id === id) {
      const v = state.villagers.find((v2) => v2.id === id);
      if (!v) continue;
      achieve(state, "A1", proof(id));
      if (v.home === g.starter.steps.S1?.targetId) step("S3", proof(id));
    }
  }
  if (command.type === "paint" || command.type === "flag") {
    const id = command.type === "flag" ? "flag" : command.target;
    const color = command.color;
    const old = id === "flag" ? previous.flagColor ?? 0 : previous.plots.find((p) => p.id === id)?.roof ?? 0;
    if (color !== void 0 && old !== color) achieve(state, "A3", proof(id));
  }
  if (command.type === "move") {
    const old = target(previous, command.id), next = target(state, command.id);
    if (old && next && "cell" in old && "cell" in next && old.cell && next.cell && (old.cell.x !== next.cell.x || old.cell.z !== next.cell.z)) achieve(state, "A4", proof(command.id));
  }
  if (command.type === "expand") {
    const expanded = proof();
    expanded.snapshot.land = structuredClone(state.land);
    achieve(state, "A6", expanded);
  }
  if (command.type === "concert-started") {
    const band = state.landmarks.find((p) => p.id === command.id && p.kind === "bandstand" && p.cell);
    if (!band) throw new Error("\u3072\u308D\u3070\u3092 \u3082\u3046\u3044\u3061\u3069 \u3048\u3089\u3093\u3067\u306D\u3002");
    achieve(state, "A5", proof(band.id));
  }
  if (command.type === "learning-returned" && g.learning) step("S4", g.learning);
  if (STARTER_STEPS.every((id) => g.starter.steps[id])) g.starter.automatic = false;
}

// src/domain/growingIsland/community.ts
function homeCellOf(state, villager) {
  return state.plots.find((p) => p.id === villager.home)?.cell ?? HOME_CELL;
}
function housing(state, reached, world) {
  reached ??= reachableFromHome(state, void 0, world);
  const capacity = state.plots.filter((p) => p.kind === "home" && p.cell && (!world || onLand(state, p.cell, world))).reduce((sum, p) => sum + RULES.homeCapacity[p.stage], 0);
  const housed = state.villagers.filter((v) => v.home !== "pokomoko").length;
  const vacancy = state.plots.filter((p) => p.kind === "home" && p.cell && (!world || onLand(state, p.cell, world)) && isReachable(p.cell, reached, world)).reduce((sum, p) => sum + Math.max(0, RULES.homeCapacity[p.stage] - occupantsOf(state, p.id).length), 0);
  return { capacity, housed, vacancy };
}
function occupantsOf(state, plotId) {
  return state.villagers.filter((v) => v.home === plotId);
}
function foodSupport(state, reached, world) {
  reached ??= reachableFromHome(state, void 0, world);
  let support = RULES.baseFood;
  for (const p of state.plots) {
    if (!p.cell || p.stage === 0 || world && !onLand(state, p.cell, world) || !isReachable(p.cell, reached, world)) continue;
    if (p.kind === "farm") support += waterAt(state, p.cell, world) > 0 ? FOOD_SUPPORT.farm + 1 : FOOD_SUPPORT.farm;
    else if (p.kind === "market") support += FOOD_SUPPORT.market;
  }
  for (const l of state.landmarks) {
    if (!l.cell || world && !onLand(state, l.cell, world) || !isReachable(l.cell, reached, world)) continue;
    if (l.kind === "planter") support += 1;
    else if (l.kind === "bakery") support += 3;
  }
  return support;
}
function playCells(state, world) {
  return [
    ...state.plots.filter((p) => p.cell && (!world || onLand(state, p.cell, world)) && p.stage > 0 && PLAY_SUPPORT[p.kind]).map((p) => p.cell),
    ...state.landmarks.filter((l) => l.cell && (!world || onLand(state, l.cell, world)) && PLAY_SUPPORT[l.kind]).map((l) => l.cell),
    ...state.keepsakes.filter((k) => k.cell && (!world || onLand(state, k.cell, world))).map((k) => k.cell)
  ];
}
function playPlotCells(state, world) {
  return state.plots.filter((p) => p.cell && (!world || onLand(state, p.cell, world)) && p.stage > 0 && (p.kind === "play" || p.kind === "festival")).map((p) => p.cell);
}
function likeCells(state, like, world) {
  const reached = connectedWaterChannels(waterLayout(state, world));
  switch (like) {
    case "flower":
      return [
        ...state.landmarks.filter((l) => l.kind === "flower" && l.cell && (!world || onLand(state, l.cell, world)) && growthStage({ kind: "flower", growth: l.growth }) === 2).map((l) => l.cell),
        ...state.plots.filter((p) => p.kind === "wild" && p.cell && (!world || onLand(state, p.cell, world)) && p.stage > 0 && p.growth >= 6 && p.style !== "tree").map((p) => p.cell)
      ];
    case "water":
      return state.landmarks.filter((l) => l.cell && (!world || onLand(state, l.cell, world)) && (l.kind === "water-bowl" || l.kind === "fountain" || l.kind === "water-channel" && reached.has(key2(l.cell)))).map((l) => l.cell);
    case "tree":
      return state.landmarks.filter((l) => l.kind === "sapling" && l.cell && (!world || onLand(state, l.cell, world)) && l.growth >= TREE_MATURE_HOURS).map((l) => l.cell);
    case "light":
      return state.landmarks.filter((l) => l.cell && (!world || onLand(state, l.cell, world)) && (l.kind === "lantern" || l.kind === "lighthouse")).map((l) => l.cell);
    case "farm":
      return state.plots.filter((p) => p.cell && (!world || onLand(state, p.cell, world)) && p.stage > 0 && (p.kind === "farm" || p.kind === "market")).map((p) => p.cell);
    case "play":
      return playCells(state, world);
    default:
      return [];
  }
}
var within = (cells, home, radius) => cells.some((c) => distance2(c, home) <= radius);
function comfort(state, villager, fed, reached, world) {
  reached ??= reachableFromHome(state, void 0, world);
  fed ??= foodSupport(state, void 0, world) >= state.villagers.length;
  if (world && villager.home !== "pokomoko" && !state.plots.some((p) => p.id === villager.home && p.kind === "home" && p.cell && p.stage > 0 && onLand(state, p.cell, world))) return 0;
  const home = homeCellOf(state, villager), likes = likesOf(villager);
  if (!isReachable(home, reached, world)) return 0;
  const accessible = (cells) => cells.filter((cell) => isReachable(cell, reached, world));
  const quiet = !within(accessible(playPlotCells(state, world)), home, RULES.quietRadius);
  const liked = likes.some((like) => like === "food" ? fed : like === "quiet" ? quiet : within(accessible(likeCells(state, like, world)), home, RULES.likeRadius));
  const played = likes.includes("quiet") ? quiet : within(accessible(playCells(state, world)), home, RULES.likeRadius);
  return (liked ? 1 : 0) + (fed ? 1 : 0) + (played ? 1 : 0);
}
function genki(state, reached, world) {
  reached ??= reachableFromHome(state, void 0, world);
  const fed = foodSupport(state, reached, world) >= state.villagers.length;
  return state.villagers.reduce((sum, v) => sum + comfort(state, v, fed, reached, world), 0);
}
function levelFor(points) {
  let level = 1;
  RULES.genkiLevels.forEach((threshold, index) => {
    if (points >= threshold) level = index + 1;
  });
  return level;
}
var islandLevel = (state) => levelFor(state.genki.best);
function unlockedKeys(state) {
  const level = islandLevel(state), villagers = state.villagers.length;
  return UNLOCKS.filter((u) => (u.level ?? 1) <= level && (u.villagers ?? 0) <= villagers).map((u) => u.key);
}
function refreshUnlocks(state) {
  const fresh = unlockedKeys(state).filter((k) => !state.unlocked.includes(k));
  state.unlocked.push(...fresh);
  return fresh;
}

// src/domain/growingIsland/room.ts
var WORD_GROUPS = [
  { id: "food", name: "\u305F\u3079\u3082\u306E", color: "#e2574c", categories: ["\u98DF\u3079\u7269", "\u98DF\u4E8B", "\u98F2\u307F\u7269", "\u6599\u7406", "\u679C\u7269", "\u91CE\u83DC"] },
  { id: "nature", name: "\u3069\u3046\u3076\u3064\u30FB\u3057\u305C\u3093", color: "#5fae5a", categories: ["\u52D5\u7269", "\u81EA\u7136", "\u74B0\u5883", "\u74B0\u5883\u554F\u984C", "\u5929\u6C17", "\u690D\u7269", "\u5B63\u7BC0", "\u751F\u304D\u7269"] },
  { id: "people", name: "\u3072\u3068", color: "#ef8fb1", categories: ["\u4EBA", "\u5BB6\u65CF", "\u8077\u696D", "\u8EAB\u4F53", "\u611F\u60C5", "\u5065\u5EB7"] },
  { id: "town", name: "\u307E\u3061", color: "#4f9bd9", categories: ["\u5EFA\u7269", "\u5834\u6240", "\u4EA4\u901A", "\u5B66\u6821", "\u5730\u7406", "\u793E\u4F1A", "\u793E\u4F1A\u554F\u984C", "\u7D4C\u6E08", "\u884C\u4E8B", "\u751F\u6D3B", "\u5834\u9762"] },
  { id: "things", name: "\u3082\u306E\u30FB\u304B\u305A", color: "#f2c14b", categories: ["\u9053\u5177", "\u7269", "\u8272", "\u6570\u5B57", "\u6708", "\u6642\u9593", "\u6642\u9593\u30FB\u5909\u5316", "\u66DC\u65E5", "\u5F62"] },
  { id: "move", name: "\u3046\u3054\u304D", color: "#f08a3c", categories: ["\u52D5\u8A5E"] },
  { id: "look", name: "\u3088\u3046\u3059", color: "#9a74d6", categories: ["\u5F62\u5BB9\u8A5E", "\u526F\u8A5E"] },
  { id: "other", name: "\u305D\u306E\u307B\u304B", color: "#3fb3a7", categories: [] }
];
var WALL_PATTERNS = [
  { id: "dots", name: "\u307F\u305A\u305F\u307E", mathLevel: 0 },
  { id: "blocks", name: "\u3044\u308D\u306E \u30D6\u30ED\u30C3\u30AF", mathLevel: 8 },
  { id: "rings", name: "\u3068\u3051\u3044\u306E \u308F", mathLevel: 13 },
  { id: "stars", name: "\u307B\u3057", mathLevel: 19 },
  { id: "pie", name: "\u30B1\u30FC\u30AD", mathLevel: 21 },
  // English levels open shapes made of the words themselves.
  { id: "letters", name: "\u30A2\u30EB\u30D5\u30A1\u30D9\u30C3\u30C8", vocabLevel: 3 },
  { id: "hearts", name: "\u30CF\u30FC\u30C8", vocabLevel: 6 }
];
var RUG_COLORS = ["#4d9b9b", "#e2574c", "#f2c14b", "#4f9bd9", "#9a74d6", "#ef8fb1"];
var DEFAULT_DECOR = { pattern: "dots", rug: 0 };
function patternOpen(pattern, mathLevel, vocabLevel = 0) {
  const entry = WALL_PATTERNS.find((p) => p.id === pattern);
  if (!entry) return false;
  return entry.vocabLevel !== void 0 ? entry.vocabLevel <= vocabLevel : (entry.mathLevel ?? Infinity) <= mathLevel;
}

// src/domain/growingIsland/placeTypes.ts
var PLACE_GOAL_IDS = ["P01", "P02", "P03", "P04", "P05", "P06"];

// src/domain/growingIsland/placeGoals.ts
function newPlaceProgress() {
  return { version: 1, milestones: {}, uses: {}, shown: {}, useHistory: [] };
}
var goalId = (id) => PLACE_GOAL_IDS.includes(id);
var object = (value) => Boolean(value && typeof value === "object" && !Array.isArray(value));
var text = (value) => typeof value === "string" && value.length > 0;
var keysOnly = (value, keys) => Object.keys(value).every((key6) => keys.includes(key6));
var receiptKey = (use) => JSON.stringify([use.ruleId, use.revision, use.actorId, use.targetId]);
function validatePlaceProgress(progress) {
  const evidence2 = (value, id) => object(value) && goalId(value.ruleId) && (id === void 0 || value.ruleId === id) && Number.isFinite(value.at) && Number(value.at) >= 0 && text(value.anchorId) && text(value.variant) && text(value.revision) && Array.isArray(value.memberIds) && value.memberIds.length > 0 && value.memberIds.every(text) && new Set(value.memberIds).size === value.memberIds.length;
  const use = (value, id) => evidence2(value, id) && text(value.actorId) && text(value.targetId) && value.ruleId !== "P06";
  if (!object(progress) || progress.version !== 1 || !keysOnly(progress, ["version", "selected", "milestones", "uses", "shown", "useHistory"]) || progress.selected !== void 0 && !goalId(progress.selected) || !object(progress.milestones) || !object(progress.uses) || !object(progress.shown) || Object.entries(progress.milestones).some(([id, value]) => !goalId(id) || !evidence2(value, id)) || Object.entries(progress.shown).some(([id, value]) => !goalId(id) || !text(value)) || Object.entries(progress.uses).some(([id, value]) => !goalId(id) || id === "P06" || !object(value) || !keysOnly(value, ["pokomoko", "villager"]) || Object.entries(value).some(([actor, fact]) => !use(fact, id) || (actor === "pokomoko" ? fact.actorId !== "pokomoko" : fact.actorId === "pokomoko"))) || progress.useHistory !== void 0 && (!Array.isArray(progress.useHistory) || progress.useHistory.some((value) => !use(value)) || new Set(progress.useHistory.map(receiptKey)).size !== progress.useHistory.length))
    throw new Error("\u3053\u306E\u5CF6\u306E\u80B2\u3064\u3070\u3057\u3087\u306F\u65B0\u3057\u3044\u7248\u3067\u958B\u3044\u3066\u304F\u3060\u3055\u3044\u3002");
}
function snapshot(place, at) {
  return { at, ruleId: place.ruleId, anchorId: place.anchorId, memberIds: [...place.memberIds], variant: place.variant, revision: place.revision };
}
function presentActor(state, id, world) {
  if (id === "pokomoko") return !world || world.owns(HOME_CELL);
  const actor = state.villagers.find((actor2) => actor2.id === id && !actor2.away && !state.arrivals.includes(actor2.id));
  if (!actor) return false;
  if (actor.home === "pokomoko") return !world || world.owns(HOME_CELL);
  const home = state.plots.find((plot) => plot.id === actor.home && plot.kind === "home" && plot.stage > 0 && plot.cell && !state.unopened.includes(plot.id));
  return Boolean(home?.cell && (!world || onLand(state, home.cell, world)) && isReachable(home.cell, reachableFromHome(state, void 0, world), world));
}
function matchesCurrentUse(state, place, fact, world) {
  return Boolean(fact && fact.ruleId === place.ruleId && fact.revision === place.revision && fact.anchorId === place.anchorId && fact.memberIds.length === place.memberIds.length && fact.memberIds.every((id) => place.memberIds.includes(id)) && place.useTargets.some((target2) => target2.id === fact.targetId) && presentActor(state, fact.actorId, world));
}
function hasCurrentUse(state, place, actor, world) {
  const matches = (fact) => (actor === void 0 || (fact.actorId === "pokomoko" ? "pokomoko" : "villager") === actor) && matchesCurrentUse(state, place, fact, world);
  return Boolean(state.placeProgress?.useHistory?.some(matches) || Object.values(state.placeProgress?.uses[place.ruleId] ?? {}).some(matches));
}
var grown = (place) => place.stage === "grown" || place.stage === "lived";
function currentIsland(state, places, world) {
  const reachable = reachableFromHome(state, void 0, world);
  const mature = places.filter((place) => grown(place) && place.entrances.some((cell) => reachable.has(key2(cell))));
  const families = new Set(mature.map((place) => place.family));
  const pokomoko = mature.some((place) => hasCurrentUse(state, place, "pokomoko", world));
  const villager = mature.some((place) => hasCurrentUse(state, place, "villager", world));
  return { mature, families, pokomoko, villager };
}
function placeRevisionForGoal(state, id, world) {
  const places = derivePlaces(state, world);
  if (id !== "P06") return places.filter((place) => place.ruleId === id && grown(place)).sort((a, b) => a.id.localeCompare(b.id))[0]?.revision;
  const { mature, families } = currentIsland(state, places, world);
  return families.size >= 3 ? JSON.stringify(mature.map((place) => place.revision).sort()) : void 0;
}
function syncPlaceMilestones(state, now, world) {
  const progress = state.placeProgress ??= newPlaceProgress();
  validatePlaceProgress(progress);
  const places = derivePlaces(state, world);
  for (const place of places.filter(grown).sort((a, b) => a.id.localeCompare(b.id)))
    progress.milestones[place.ruleId] ??= snapshot(place, now);
  const island = currentIsland(state, places, world);
  if (island.families.size >= 3 && island.pokomoko && island.villager && !progress.milestones.P06) {
    progress.milestones.P06 = {
      at: now,
      ruleId: "P06",
      anchorId: state.seed,
      memberIds: [...new Set(island.mature.flatMap((place) => place.memberIds))].sort(),
      variant: "island",
      revision: JSON.stringify(island.mature.map((place) => place.revision).sort())
    };
  }
}
function recordPlaceUse(state, receipt, at, world) {
  if (!Number.isFinite(at) || at < 0) throw new Error("\u3070\u3057\u3087\u306E \u3044\u307E\u3092 \u3082\u3046\u3044\u3061\u3069 \u305F\u3057\u304B\u3081\u3066\u306D\u3002");
  const place = derivePlaces(state, world).find((place2) => place2.id === receipt.placeId && place2.ruleId === receipt.ruleId && grown(place2) && place2.revision === receipt.revision && place2.entrances.length > 0);
  if (!place || !presentActor(state, receipt.actorId, world)) throw new Error("\u3070\u3057\u3087\u306E \u3044\u307E\u3092 \u3082\u3046\u3044\u3061\u3069 \u305F\u3057\u304B\u3081\u3066\u306D\u3002");
  const target2 = place.useTargets.find((target3) => target3.id === receipt.targetId);
  const reached = reachableFromHome(state, void 0, world);
  if (!target2 || !isReachable(target2.route?.[0] ?? target2.cell, reached, world)) throw new Error("\u3053\u3053\u307E\u3067 \u3042\u308B\u3051\u308B \u3070\u3057\u3087\u3092 \u3042\u3051\u3066\u307F\u3088\u3046\u3002");
  const progress = state.placeProgress ??= newPlaceProgress();
  validatePlaceProgress(progress);
  const fact = { ...snapshot(place, at), actorId: receipt.actorId, targetId: receipt.targetId };
  const history = progress.useHistory ??= Object.values(progress.uses).flatMap((actors) => Object.values(actors)).filter((fact2) => Boolean(fact2));
  const original = history.find((use) => receiptKey(use) === receiptKey(fact));
  if (!original) history.push(fact);
  const latest = progress.uses[place.ruleId] ??= {};
  latest[receipt.actorId === "pokomoko" ? "pokomoko" : "villager"] = original ?? fact;
  syncPlaceMilestones(state, at, world);
}
function recordPlaceShown(state, receipt, world) {
  if (!goalId(receipt.ruleId) || !text(receipt.revision)) throw new Error("\u3070\u3057\u3087\u306E \u3044\u307E\u3092 \u3082\u3046\u3044\u3061\u3069 \u305F\u3057\u304B\u3081\u3066\u306D\u3002");
  const current = receipt.ruleId === "P06" ? placeRevisionForGoal(state, "P06", world) : derivePlaces(state, world).find((place) => place.ruleId === receipt.ruleId && grown(place) && place.revision === receipt.revision)?.revision;
  if (current !== receipt.revision) throw new Error("\u3070\u3057\u3087\u306E \u3044\u307E\u3092 \u3082\u3046\u3044\u3061\u3069 \u305F\u3057\u304B\u3081\u3066\u306D\u3002");
  const progress = state.placeProgress ??= newPlaceProgress();
  validatePlaceProgress(progress);
  progress.shown[receipt.ruleId] = receipt.revision;
}

// src/domain/growingIsland/names.ts
var NAME_CANDIDATES = {
  rabbit: ["\u307F\u307F", "\u3057\u3089\u305F\u307E", "\u3082\u306A\u304B", "\u3075\u308F\u308A", "\u3046\u3055\u3053", "\u3074\u3087\u3093\u305F"],
  otter: ["\u3061\u3083\u3077", "\u306A\u307F\u306E", "\u3059\u3044\u3059\u3044", "\u307D\u3061\u3083", "\u304B\u3044\u308A", "\u308B\u308B"],
  fox: ["\u3053\u3093\u305F", "\u304D\u306A\u3053", "\u3082\u307F\u3058", "\u3086\u305A", "\u307D\u3093", "\u3042\u3093\u305A"],
  duck: ["\u3077\u304F\u308A", "\u3071\u308B", "\u304B\u3082\u307F", "\u307A\u305F\u3053", "\u3061\u3083\u3063\u3077", "\u3050\u3045"],
  squirrel: ["\u304F\u308B\u307F", "\u3069\u3093\u3050\u308A", "\u307E\u308D\u3093", "\u304F\u308A\u3053", "\u3061\u3063\u3077", "\u307D\u3063\u3051"],
  hedgehog: ["\u3068\u3052\u307E\u308B", "\u3053\u308D\u3093", "\u307E\u308B\u308B", "\u3044\u304C\u3063\u3061", "\u3061\u304F\u3061\u304F", "\u306F\u308A\u3043"],
  bird: ["\u3074\u3074", "\u3061\u3085\u3093\u305F", "\u308B\u308A", "\u3074\u3044\u3053", "\u3053\u3068\u306D", "\u305D\u3088"],
  penguin: ["\u307A\u3093\u305F", "\u3053\u304A\u308A", "\u307A\u307A", "\u3057\u305A\u304F"],
  owl: ["\u307B\u3046\u307B\u3046", "\u3082\u308A\u304A", "\u3064\u304D\u307F", "\u3075\u304F\u3059\u3051"],
  frog: ["\u3051\u308D\u308A", "\u3042\u307E\u304C\u3048", "\u3074\u3087\u3053", "\u307F\u3069\u308A"],
  girl: [KID.girl.name],
  boy: [KID.boy.name]
};
function arrivalName(state, visitor) {
  if (isKid(visitor.species)) return KID[visitor.species].name;
  const list = NAME_CANDIDATES[visitor.species];
  const start = Math.floor(roll(state.seed, "name", visitor.species, visitor.ordinal) * list.length);
  const used = new Set(state.villagers.map((v) => v.name));
  for (let i = 0; i < list.length; i++) {
    const name = list[(start + i) % list.length];
    if (!used.has(name)) return name;
  }
  return list[start];
}

// src/domain/growingIsland/pier.ts
var TRAITS = ["lively", "mellow", "shy", "hungry"];
function rareChance(state, world) {
  return RULES.rareBase + RULES.rareBonus * Math.min(1, richness(state, world) / RULES.rareRichness);
}
function rollVisitor(state, ordinal, only, world) {
  const present = /* @__PURE__ */ new Set([...state.villagers.map((v) => v.species), state.pier.visitor.species, state.pier.next.species]);
  const missing = KIDS.filter((kid) => !present.has(kid));
  if (!only && missing.length && (ordinal === 1 || ordinal === 2)) {
    const first = roll(state.seed, "kid-order", "island", 0) < 0.5 ? "girl" : "boy";
    const kid = missing.includes(first) ? first : missing[0];
    return { ordinal, species: kid, variant: { ...KID[kid].variant }, trait: KID[kid].trait };
  }
  const character = islandCharacter(state, world), favored = character === "mixed" ? [] : FAVORED[character];
  const pool = (only ?? AVAILABLE_SPECIES).filter((s) => !isKid(s) || ordinal > 0 && missing.includes(s));
  const weight = (s) => {
    const rare = RARE[s];
    if (rare) return rare.weight * (rare.home === character ? 3 : 1);
    return isKid(s) || favored.includes(s) ? RULES.favoredWeight : 1;
  };
  const species = pick(pool, pool.map(weight), roll(state.seed, "pier-species", "boat", ordinal));
  if (isKid(species)) return { ordinal, species, variant: { ...KID[species].variant }, trait: KID[species].trait };
  return {
    ordinal,
    species,
    variant: {
      color: Math.floor(roll(state.seed, "pier-color", "boat", ordinal) * 6),
      accessory: Math.floor(roll(state.seed, "pier-accessory", "boat", ordinal) * 4),
      sparkle: roll(state.seed, "pier-sparkle", "boat", ordinal) < rareChance(state, world)
    },
    trait: TRAITS[Math.floor(roll(state.seed, "pier-trait", "boat", ordinal) * TRAITS.length)]
  };
}
function boatInterval(villagers) {
  return RULES.boatBaseHours + RULES.boatHoursPerVillager * villagers;
}
var docked = (state, hour = state.town.clock) => hour >= state.pier.dockAt;
function advancePier(state, hour, world) {
  const arriving = state.pier.visitor;
  const rolled = state.pier.rolled + 1;
  state.pier = {
    visitor: state.pier.next,
    next: rollVisitor(state, rolled, void 0, world),
    rolled,
    dockAt: hour + boatInterval(state.villagers.length + 1)
  };
  return arriving;
}

// src/domain/growingIsland/town.ts
var isDawn = (hour) => hour % 24 === RULES.dawnHour;
function levelUp(state, before, after) {
  const events = [];
  for (let level = before + 1; level <= after; level++) {
    events.push({ type: "level", level });
    if (WONDER_LEVELS.includes(level)) {
      state.wonderSeeds = (state.wonderSeeds ?? 0) + 1;
      events.push({ type: "wonder-seed" });
    }
  }
  return events;
}
function build(state, hour, events, world) {
  const due = state.plots.filter((p) => p.cell && (!world || onLand(state, p.cell, world)) && p.stage === 0 && p.plantedAt + RULES.buildHours <= hour);
  if (!due.length) return;
  const reached = reachableFromHome(state, void 0, world), all = features(state, world);
  for (const plot of due) {
    if (!isReachable(plot.cell, reached, world)) continue;
    plot.stage = 1;
    plot.builtAt = hour;
    plot.stagedAt = hour;
    plot.style = styleAt(state, plot.cell, all, world);
    events.push({ type: "built", plotId: plot.id });
    if (!state.unopened.includes(plot.id)) state.unopened.push(plot.id);
  }
}
function growHomes(state, hour, events, world) {
  const reached = reachableFromHome(state, void 0, world), level = islandLevel(state), fed = foodSupport(state, reached, world) >= state.villagers.length;
  for (const plot of state.plots) {
    if (plot.kind !== "home" || !plot.cell || world && !onLand(state, plot.cell, world) || !isReachable(plot.cell, reached, world) || plot.stage < 1 || plot.stage > 3) continue;
    const rule = RULES.homeGrowth[plot.stage], people = occupantsOf(state, plot.id);
    if (!people.length || hour - (plot.stagedAt ?? plot.builtAt ?? hour) < rule.hours || level < rule.level) continue;
    const average = people.reduce((sum, v) => sum + comfort(state, v, fed, reached, world), 0) / people.length;
    if (average < rule.comfort) continue;
    plot.stage = plot.stage + 1;
    plot.stagedAt = hour;
    events.push({ type: "grew", plotId: plot.id, stage: plot.stage });
    if (!state.unopened.includes(plot.id)) state.unopened.push(plot.id);
  }
}
function refreshCommunity(state, events, world) {
  const before = levelFor(state.genki.best);
  state.genki.current = genki(state, void 0, world);
  state.genki.best = Math.max(state.genki.best, state.genki.current);
  const after = levelFor(state.genki.best);
  events.push(...levelUp(state, before, after));
  const character = islandCharacter(state, world);
  if (character !== state.character) {
    state.character = character;
    events.push({ type: "character", character });
  }
  const keys = refreshUnlocks(state);
  if (keys.length) events.push({ type: "unlocked", keys });
}
function chooseHome(state, villager, world) {
  const reached = reachableFromHome(state, void 0, world);
  const homes = state.plots.filter((p) => p.kind === "home" && p.cell && (!world || onLand(state, p.cell, world)) && isReachable(p.cell, reached, world) && p.stage > 0 && occupantsOf(state, p.id).length < RULES.homeCapacity[p.stage]);
  let best, bestScore = -1;
  for (const home of homes.sort((a, b) => a.builtAt - b.builtAt || a.id.localeCompare(b.id))) {
    const score = comfort(state, { ...villager, home: home.id }, void 0, reached, world);
    if (score > bestScore) {
      best = home;
      bestScore = score;
    }
  }
  return best;
}
function welcome(state, hour, home, world) {
  if (world) {
    const owned = state.plots.find((plot) => plot.id === home.id && plot.kind === "home" && plot.stage > 0 && plot.cell && world.owns(plot.cell));
    if (!owned?.cell || occupantsOf(state, owned.id).length >= RULES.homeCapacity[owned.stage] || !isReachable(owned.cell, reachableFromHome(state, void 0, world), world)) throw new Error("\u306A\u304B\u307E\u306E \u3044\u3048\u307E\u3067 \u3042\u308B\u3051\u308B \u3070\u3057\u3087\u3092 \u3042\u3051\u3066\u307F\u3088\u3046\u3002");
  }
  const visitor = advancePier(state, hour, world);
  const villager = {
    id: `v${state.nextId++}`,
    species: visitor.species,
    variant: visitor.variant,
    trait: visitor.trait,
    home: home.id,
    arrivedAt: hour,
    name: arrivalName(state, visitor)
  };
  state.villagers.push(villager);
  state.arrivals.push(villager.id);
  return villager;
}
function moveIn(state, hour, events, world) {
  if (!docked(state, hour)) return;
  const people = state.villagers.length;
  if (housing(state, void 0, world).vacancy < 1) return "full";
  if (foodSupport(state, void 0, world) <= people) return "food";
  const home = chooseHome(state, { ...state.pier.visitor, id: "candidate", home: "", arrivedAt: hour }, world);
  if (!home) return "full";
  events.push({ type: "arrived", villagerId: welcome(state, hour, home, world).id });
}
function hasTownWork(state, world) {
  if (!docked(state)) return true;
  const reached = reachableFromHome(state, void 0, world), people = state.villagers.length;
  if (state.plots.some((p) => p.cell && (!world || onLand(state, p.cell, world)) && p.stage === 0 && isReachable(p.cell, reached, world))) return true;
  if (housing(state, reached, world).vacancy > 0 && foodSupport(state, reached, world) > people) return true;
  if (genki(state, reached, world) !== state.genki.current) return true;
  const fed = foodSupport(state, reached, world) >= people, level = islandLevel(state);
  return state.plots.some((p) => {
    if (p.kind !== "home" || !p.cell || world && !onLand(state, p.cell, world) || !isReachable(p.cell, reached, world) || p.stage < 1 || p.stage > 3) return false;
    const rule = RULES.homeGrowth[p.stage], occupants = occupantsOf(state, p.id);
    return level >= rule.level && occupants.length > 0 && occupants.reduce((sum, v) => sum + comfort(state, v, fed, reached, world), 0) / occupants.length >= rule.comfort;
  });
}
function openTown(state, world) {
  const events = [], from = state.town.clock;
  while (state.town.bank > 0 && hasTownWork(state, world)) {
    state.town.clock += 1;
    state.town.bank -= 1;
    const hour = state.town.clock;
    build(state, hour, events, world);
    if (!isDawn(hour)) continue;
    growHomes(state, hour, events, world);
    refreshCommunity(state, events, world);
    moveIn(state, hour, events, world);
  }
  const reached = reachableFromHome(state, void 0, world);
  for (const plot of state.plots) if (plot.cell && plot.stage === 0 && !isReachable(plot.cell, reached, world))
    events.push({ type: "blocked", reason: "unreachable", plotId: plot.id });
  if (docked(state) && !events.some((e) => e.type === "arrived")) {
    if (housing(state, reached, world).vacancy < 1) events.push({ type: "blocked", reason: "full" });
    else if (foodSupport(state, reached, world) <= state.villagers.length) events.push({ type: "blocked", reason: "food" });
  }
  if (!docked(state) && state.town.clock > from) events.push({ type: "boat", hoursLeft: state.pier.dockAt - state.town.clock });
  if (!events.length && state.town.clock > from) events.push({ type: "quiet" });
  return events;
}

// src/domain/growingIsland/authoredPlacementSupport.ts
var indexes2 = /* @__PURE__ */ new WeakMap();
var key5 = (cell) => `${cell.x},${cell.z}`;
var EPSILON2 = 1e-7;
var PHYSICAL_MATCH_BAND = 1e-5 / Math.SQRT2 * 0.9999;
var area4 = (polygon) => polygon.reduce((sum, p, i) => {
  const q = polygon[(i + 1) % polygon.length];
  return sum + p.x * q.z - q.x * p.z;
}, 0);
var hasArea = (polygon) => polygon.length >= 3 && Math.abs(area4(polygon)) > 1e-12;
function clip(polygon, distance3) {
  const result = [];
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i], b = polygon[(i + 1) % polygon.length], da = distance3(a), db = distance3(b);
    if (da >= 0) result.push(a);
    if (da >= 0 !== db >= 0) {
      const t = da / (da - db);
      result.push({ x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t });
    }
  }
  return result;
}
function coordinateAt(triangle, at, coordinate) {
  const [a, b, c] = triangle.cells, determinant = (b.z - c.z) * (a.x - c.x) + (c.x - b.x) * (a.z - c.z);
  const u = ((b.z - c.z) * (at.x - c.x) + (c.x - b.x) * (at.z - c.z)) / determinant;
  const v = ((c.z - a.z) * (at.x - c.x) + (a.x - c.x) * (at.z - c.z)) / determinant;
  return triangle.points[0][coordinate] * u + triangle.points[1][coordinate] * v + triangle.points[2][coordinate] * (1 - u - v);
}
var heightAt = (triangle, at) => coordinateAt(triangle, at, "y");
function matchingCover(polygon, floor, water) {
  let result = [...polygon];
  for (const coordinate of ["x", "z"]) {
    const delta = (at) => coordinateAt(floor, at, coordinate) - coordinateAt(water, at, coordinate);
    result = clip(result, (at) => PHYSICAL_MATCH_BAND - delta(at));
    result = clip(result, (at) => PHYSICAL_MATCH_BAND + delta(at));
  }
  return result;
}
function subtract2(polygon, cover) {
  const result = [], orientation = Math.sign(area4(cover));
  let inside = [...polygon];
  for (let i = 0; i < cover.length && hasArea(inside); i++) {
    const a = cover[i], b = cover[(i + 1) % cover.length];
    const side = (p) => orientation * ((b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x));
    const outside = clip(inside, (p) => -side(p));
    if (hasArea(outside)) result.push(outside);
    inside = clip(inside, side);
  }
  return result;
}
function intersect2(polygon, boundary) {
  let result = [...polygon];
  const orientation = Math.sign(area4(boundary));
  for (let i = 0; i < boundary.length && hasArea(result); i++) {
    const a = boundary[i], b = boundary[(i + 1) % boundary.length];
    result = clip(result, (p) => orientation * ((b.x - a.x) * (p.z - a.z) - (b.z - a.z) * (p.x - a.x)));
  }
  return result;
}
function supportIndex(world) {
  const existing = indexes2.get(world);
  if (existing) return existing;
  const index = { buckets: /* @__PURE__ */ new Map(), answers: /* @__PURE__ */ new Map() };
  for (const floor of world.floors) for (let i = 0; i < floor.indices.length; i += 3) {
    const vertices = floor.indices.slice(i, i + 3).map((id) => floor.vertices[id]);
    const cells = vertices.map((v) => v.cell), points = vertices.map((v) => v.point);
    const triangle = {
      cells,
      points,
      water: floor.kind === "water",
      minX: Math.min(...cells.map((p) => p.x)),
      maxX: Math.max(...cells.map((p) => p.x)),
      minZ: Math.min(...cells.map((p) => p.z)),
      maxZ: Math.max(...cells.map((p) => p.z))
    };
    for (let z = Math.floor(triangle.minZ); z <= Math.floor(triangle.maxZ); z++) for (let x = Math.floor(triangle.minX); x <= Math.floor(triangle.maxX); x++) {
      const id = key5({ x, z }), bucket = index.buckets.get(id) ?? [];
      bucket.push(triangle);
      index.buckets.set(id, bucket);
    }
  }
  indexes2.set(world, index);
  return index;
}
function hasAuthoredPlacementSupport(world, cell) {
  const center = world.floorAt(cell);
  if (!center) return false;
  const radius = AUTHORED_OWNER_HALF_EXTENT;
  for (const x of [-radius, 0, radius]) for (const z of [-radius, 0, radius]) {
    const support = world.floorAt({ x: cell.x + x, z: cell.z + z });
    if (!support || Math.abs(support.point.y - center.point.y) > 0.28) return false;
  }
  if (!world.floors.some((floor) => floor.kind === "water")) return true;
  const index = supportIndex(world), id = key5(cell), cached = index.answers.get(id);
  if (cached !== void 0) return cached;
  const bounds2 = { minX: cell.x - radius, maxX: cell.x + radius, minZ: cell.z - radius, maxZ: cell.z + radius };
  const candidates = /* @__PURE__ */ new Set();
  for (let z = Math.floor(bounds2.minZ); z <= Math.floor(bounds2.maxZ); z++) for (let x = Math.floor(bounds2.minX); x <= Math.floor(bounds2.maxX); x++)
    for (const triangle of index.buckets.get(key5({ x, z })) ?? [])
      if (triangle.maxX >= bounds2.minX && triangle.minX <= bounds2.maxX && triangle.maxZ >= bounds2.minZ && triangle.minZ <= bounds2.maxZ) candidates.add(triangle);
  const dry = [...candidates].filter((triangle) => !triangle.water);
  let supported = true;
  for (const water of candidates) {
    if (!water.water) continue;
    let polygon = clip(water.cells, (p) => p.x - bounds2.minX);
    polygon = clip(polygon, (p) => bounds2.maxX - p.x);
    polygon = clip(polygon, (p) => p.z - bounds2.minZ);
    polygon = clip(polygon, (p) => bounds2.maxZ - p.z);
    if (!hasArea(polygon)) continue;
    const overlapping = dry.filter((floor) => floor.maxX >= water.minX && floor.minX <= water.maxX && floor.maxZ >= water.minZ && floor.minZ <= water.maxZ);
    if (overlapping.some((floor) => {
      const high = clip(floor.cells, (p) => heightAt(floor, p) - center.point.y - 0.28 - EPSILON2);
      return hasArea(high) && hasArea(intersect2(high, polygon));
    })) {
      supported = false;
      break;
    }
    if (overlapping.some((floor) => {
      const above = intersect2(clip(floor.cells, (p) => heightAt(floor, p) + EPSILON2 - heightAt(water, p)), polygon);
      if (!hasArea(above)) return false;
      const matching = matchingCover(above, floor, water);
      let mismatched = hasArea(matching) ? subtract2(above, matching) : [above];
      if (!mismatched.length) return false;
      for (const other of overlapping) {
        if (other === floor) continue;
        const higher = clip(other.cells, (p) => heightAt(other, p) - heightAt(floor, p) - EPSILON2);
        if (hasArea(higher)) mismatched = mismatched.flatMap((piece) => subtract2(piece, higher));
        if (!mismatched.length) return false;
      }
      return true;
    })) {
      supported = false;
      break;
    }
    let uncovered = [polygon];
    for (const floor of overlapping) {
      let cover = clip(floor.cells, (p) => heightAt(floor, p) + EPSILON2 - heightAt(water, p));
      cover = clip(cover, (p) => heightAt(floor, p) - center.point.y + 0.28 + EPSILON2);
      cover = clip(cover, (p) => center.point.y + 0.28 + EPSILON2 - heightAt(floor, p));
      cover = matchingCover(cover, floor, water);
      if (!hasArea(cover)) continue;
      uncovered = uncovered.flatMap((piece) => subtract2(piece, cover));
      if (!uncovered.length) break;
    }
    if (uncovered.length) {
      supported = false;
      break;
    }
  }
  if (index.answers.size >= 16384) index.answers.clear();
  index.answers.set(id, supported);
  return supported;
}

// src/domain/growingIsland/commands.ts
function fail2(message) {
  throw new Error(message);
}
function claim(state, cell, except, world) {
  if (!onLand(state, cell, world) || world && !hasAuthoredPlacementSupport(world, cell)) fail2("\u3053\u3053\u306B\u306F \u304A\u3051\u306A\u3044\u3088\u3002");
  const found = occupant(state, cell, except);
  if (!found) return;
  if (found.type === "plot" && found.spread) {
    state.plots = state.plots.filter((p) => p.id !== found.id);
    return;
  }
  fail2("\u3053\u3053\u306B\u306F \u3082\u3046 \u3082\u306E\u304C \u3042\u308B\u3088\u3002");
}
function pay(state, price) {
  if (state.drops < price) fail2("\u3057\u305A\u304F\u304C \u3082\u3046\u3059\u3053\u3057 \u3044\u308B\u3088\u3002");
  state.drops -= price;
}
function landStep(state) {
  return (state.land.expanded ? 1 : 0) + state.land.extra.length + state.land.capes.length + (state.land.districts?.length ?? 0);
}
function landQuote(state) {
  const step = landStep(state) + 1;
  if (step === 1) return { step, sides: ["west", "east"], price: LAND_PRICE[0] };
  if (step === 2) return { step, sides: [state.land.expanded === "west" ? "east" : "west"], price: LAND_PRICE[1] };
  if (step === 3) return { step, sides: ["south"], price: LAND_PRICE[2] };
  if (step <= 5 && islandLevel(state) >= CAPE_LEVEL[step - 4]) {
    return { step, sides: ["east", "west"].filter((side) => !state.land.capes.includes(side)), price: LAND_PRICE[step - 1] };
  }
  if (step >= 6) return { step, sides: ["east", "west", "south"], price: LAND_PRICE[4] + DISTRICT_PRICE_STEP * (step - 5) };
}
function expand(state, side) {
  const quote = landQuote(state);
  if (!quote || !quote.sides.includes(side)) fail2("\u3072\u308D\u3052\u308B \u3070\u3057\u3087\u3092 \u3082\u3046\u3044\u3061\u3069 \u3048\u3089\u3093\u3067\u306D\u3002");
  pay(state, quote.price);
  if (quote.step === 1) state.land.expanded = side;
  else if (quote.step <= 3) state.land.extra.push(side);
  else if (quote.step <= 5) state.land.capes.push(side);
  else (state.land.districts ??= []).push(side);
  syncSoil(state);
  if (state.bridge) {
    const x = bridgeSite(state);
    if (x === void 0) fail2("\u306F\u3057\u306E \u3070\u3057\u3087\u304C \u306A\u3044\u3088\u3002\u306F\u3057\u3092 \u3057\u307E\u3063\u3066\u304B\u3089 \u3072\u308D\u3052\u3066\u306D\u3002");
    state.bridge.x = x;
  }
}
function find(state, id) {
  return state.plots.find((p) => p.id === id) ?? state.landmarks.find((l) => l.id === id) ?? state.keepsakes.find((k) => k.id === id) ?? fail2("\u307F\u3064\u304B\u3089\u306A\u3044\u3088\u3002");
}
function apply(state, command, world) {
  if (world && ["expand", "bridge-build", "bridge-remove"].includes(command.type))
    fail2("\u3053\u306E\u5236\u4F5C\u4E2D\u306E\u5CF6\u3067\u306F \u571F\u5730\u3068\u306F\u3057\u306E\u7DE8\u96C6\u3092 \u307E\u3060\u4F7F\u3048\u306A\u3044\u3088\u3002");
  const events = [];
  switch (command.type) {
    case "choose-place-goal": {
      if (command.id !== void 0 && !PLACE_GOAL_IDS.includes(command.id)) fail2("\u3082\u3046\u3044\u3061\u3069 \u3048\u3089\u3093\u3067\u306D\u3002");
      (state.placeProgress ??= newPlaceProgress()).selected = command.id;
      break;
    }
    case "place-used":
    case "place-shown":
      break;
    case "choose-goal": {
      if (!state.guidance || command.id !== void 0 && !ACHIEVEMENTS.includes(command.id)) fail2("\u3082\u3046\u3044\u3061\u3069 \u3048\u3089\u3093\u3067\u306D\u3002");
      state.guidance.selected = command.id;
      state.guidance.starter.automatic = false;
      break;
    }
    case "choose-starter-play": {
      if (!state.guidance || !state.guidance.starter.steps.S3 || state.guidance.starter.steps.S4 || command.id !== "A3" && command.id !== "A4") fail2("\u3082\u3046\u3044\u3061\u3069 \u3048\u3089\u3093\u3067\u306D\u3002");
      state.guidance.selected = command.id;
      break;
    }
    case "starter-guide":
      if (state.guidance) state.guidance.starter.automatic = command.automatic;
      break;
    case "ack-revisit-flower": {
      if (state.guidance?.firstFlower?.id === command.id) state.guidance.firstFlower.seen = true;
      break;
    }
    case "ack-achievements": {
      if (state.guidance) {
        for (const id of command.ids) if (state.guidance.achievements[id] && !state.guidance.notified.includes(id)) state.guidance.notified.push(id);
      }
      break;
    }
    case "concert-started":
    case "learning-returned":
      break;
    case "plant": {
      if (command.kind === "wonder") {
        if (!state.wonderSeeds) fail2("\u3075\u3057\u304E\u306E \u305F\u306D\u304C \u307E\u3060 \u306A\u3044\u3088\u3002");
      } else if (!state.unlocked.includes(`seed:${command.kind}`)) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
      const tutorial = state.tutorial === "first-home" && command.kind === "home";
      if (command.kind === "home" && !canReachHomePlacement(state, command.cell, void 0, world)) fail2("\u3053\u3053\u307E\u3067 \u3044\u3051\u306A\u3044\u307F\u305F\u3044\u3002\u307E\u308F\u308A\u3092 \u3042\u3051\u3066\u307F\u3088\u3046");
      claim(state, command.cell, void 0, world);
      const price = tutorial ? 0 : SEED_PRICE[command.kind];
      pay(state, price);
      const plot = {
        id: `p${state.nextId++}`,
        kind: command.kind,
        cell: { ...command.cell },
        plantedAt: state.town.clock,
        stage: 0,
        growth: 0,
        origin: "seed",
        paid: price
      };
      state.plots.push(plot);
      if (command.kind === "wonder") state.wonderSeeds = state.wonderSeeds - 1;
      if (tutorial) {
        Object.assign(plot, { stage: 1, builtAt: state.town.clock, stagedAt: state.town.clock, style: styleAt(state, plot.cell, void 0, world) });
        state.unopened.push(plot.id);
        events.push({ type: "built", plotId: plot.id });
        events.push({ type: "arrived", villagerId: welcome(state, state.town.clock, plot, world).id });
        state.tutorial = "done";
        const keys = refreshUnlocks(state);
        if (keys.length) events.push({ type: "unlocked", keys });
      }
      break;
    }
    case "place": {
      if (!state.unlocked.includes(`landmark:${command.kind}`)) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
      const price = LANDMARK_PRICE[command.kind] ?? fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
      let color = command.color;
      if (color !== void 0) {
        const planted = PLANTED_COLORS.find((entry) => entry.color === color);
        if (command.kind !== "flower" || !planted || islandLevel(state) < planted.level) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
      } else if (command.kind === "flower") color = "red";
      claim(state, command.cell, void 0, world);
      pay(state, price);
      const id = `l${state.nextId++}`;
      state.landmarks.push({ id, kind: command.kind, cell: { ...command.cell }, growth: 0, ...color ? { color } : {} });
      if (command.kind === "flower" && state.guidance && !state.guidance.firstFlower)
        state.guidance.firstFlower = { id, seen: false };
      if (color) noteColor(state, color);
      break;
    }
    case "move": {
      const target2 = find(state, command.id);
      if (!target2.cell) fail2("\u3057\u307E\u3063\u3066\u3042\u308B \u3082\u306E\u306F\u300C\u304A\u304F\u300D\u304B\u3089 \u3048\u3089\u3093\u3067\u306D\u3002");
      if (state.plots.some((p) => p.id === command.id && p.kind === "home") && !canReachHomePlacement(state, command.cell, command.id, world))
        fail2("\u3053\u3053\u307E\u3067 \u3044\u3051\u306A\u3044\u307F\u305F\u3044\u3002\u307E\u308F\u308A\u3092 \u3042\u3051\u3066\u307F\u3088\u3046");
      claim(state, command.cell, command.id, world);
      target2.cell = { ...command.cell };
      break;
    }
    case "store": {
      const plot = state.plots.find((p) => p.id === command.id);
      if (plot?.stage === 0) {
        state.plots = state.plots.filter((p) => p.id !== plot.id);
        state.drops += plot.paid;
        if (plot.kind === "wonder") state.wonderSeeds = (state.wonderSeeds ?? 0) + 1;
        break;
      }
      if (plot?.kind === "home" && occupantsOf(state, plot.id).length) fail2("\u3060\u308C\u304B\u304C \u3059\u3093\u3067\u3044\u308B\u3088\u3002");
      find(state, command.id).cell = void 0;
      break;
    }
    case "unstore": {
      const target2 = find(state, command.id);
      if (target2.cell) fail2("\u3082\u3046 \u304A\u3044\u3066\u3042\u308B\u3088\u3002");
      if (state.plots.some((p) => p.id === command.id && p.kind === "home") && !canReachHomePlacement(state, command.cell, command.id, world))
        fail2("\u3053\u3053\u307E\u3067 \u3044\u3051\u306A\u3044\u307F\u305F\u3044\u3002\u307E\u308F\u308A\u3092 \u3042\u3051\u3066\u307F\u3088\u3046");
      claim(state, command.cell, void 0, world);
      target2.cell = { ...command.cell };
      break;
    }
    case "pluck": {
      const plot = state.plots.find((p) => p.id === command.id && p.kind === "wild" && p.stage > 0) ?? fail2("\u3064\u3081\u306A\u3044\u3088\u3002");
      state.plots = state.plots.filter((p) => p.id !== plot.id);
      break;
    }
    case "expand":
      expand(state, command.side);
      break;
    case "bridge-build": {
      if (state.bridge) fail2("\u306F\u3057\u306F \u3082\u3046 \u3042\u308B\u3088\u3002");
      if (!state.villagers.some((v) => !v.away && !state.arrivals.includes(v.id))) fail2("\u306A\u304B\u307E\u304C \u304D\u3066\u304B\u3089 \u3064\u304F\u308D\u3046\u3002");
      if (!canBuildBridge(state, command.x)) fail2("\u306F\u3057\u3092 \u304B\u3051\u308B \u3070\u3057\u3087\u3092 \u3042\u3051\u3066\u306D\u3002");
      state.bridge = { x: command.x };
      break;
    }
    case "bridge-remove": {
      if (!state.bridge) fail2("\u306F\u3057\u306F \u307E\u3060 \u306A\u3044\u3088\u3002");
      delete state.bridge;
      break;
    }
    case "name": {
      const name = command.name.trim();
      if (!name || [...name].length > 12) fail2("\u306A\u307E\u3048\u306F 1\u301C12\u3082\u3058\u3067 \u3064\u3051\u3066\u306D\u3002");
      if (command.target === "island") state.islandName = name;
      else {
        const villager = state.villagers.find((v) => v.id === command.target) ?? fail2("\u307F\u3064\u304B\u3089\u306A\u3044\u3088\u3002");
        if (isKid(villager.species)) fail2("\u3048\u307E\u3068 \u3048\u3044\u305F\u306E \u306A\u307E\u3048\u306F \u305D\u306E\u307E\u307E\u3060\u3088\u3002");
        villager.name = name;
      }
      break;
    }
    case "paint": {
      if (!Number.isInteger(command.color) || command.color < 0 || command.color > 9) fail2("\u3044\u308D\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
      if (command.target === "flag") state.flagColor = command.color;
      else (state.plots.find((p) => p.id === command.target && p.kind === "home") ?? fail2("\u307F\u3064\u304B\u3089\u306A\u3044\u3088\u3002")).roof = command.color;
      break;
    }
    case "open":
      state.unopened = state.unopened.filter((id) => id !== command.id);
      break;
    case "open-all":
      state.unopened = [];
      state.arrivals = [];
      break;
    case "disembark":
      state.arrivals = state.arrivals.filter((id) => id !== command.id);
      break;
    case "away":
      (state.villagers.find((v) => v.id === command.id) ?? fail2("\u307F\u3064\u304B\u3089\u306A\u3044\u3088\u3002")).away = command.away || void 0;
      break;
    case "dress": {
      const villager = state.villagers.find((v) => v.id === command.id) ?? fail2("\u307F\u3064\u304B\u3089\u306A\u3044\u3088\u3002");
      const level = islandLevel(state), outfit = { ...villager.outfit };
      if (command.color !== void 0) {
        if (level < STYLE_LEVEL.clothes) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
        if (!Number.isInteger(command.color) || command.color < 0 || command.color > 5) fail2("\u3044\u308D\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        outfit.color = command.color;
      }
      if (command.hat !== void 0) {
        if (level < STYLE_LEVEL.hats) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
        if (!Number.isInteger(command.hat) || command.hat < 0 || command.hat > HATS) fail2("\u307C\u3046\u3057\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        outfit.hat = command.hat || void 0;
      }
      villager.outfit = outfit.color === void 0 && outfit.hat === void 0 ? void 0 : outfit;
      break;
    }
    case "decorate": {
      const room = { ...DEFAULT_DECOR, ...state.room };
      if (command.pattern !== void 0) {
        if (!patternOpen(command.pattern, state.mastery?.math ?? 0, state.mastery?.vocab ?? 0)) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
        room.pattern = command.pattern;
      }
      if (command.rug !== void 0) {
        if (!Number.isInteger(command.rug) || command.rug < 0 || command.rug >= RUG_COLORS.length) fail2("\u3044\u308D\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        room.rug = command.rug;
      }
      if (command.hidden !== void 0) {
        const ids = new Set(WORD_GROUPS.map((g) => g.id));
        if (command.hidden.some((id) => !ids.has(id))) fail2("\u3044\u308D\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        room.hidden = [...new Set(command.hidden)];
        if (!room.hidden.length) delete room.hidden;
      }
      state.room = room;
      break;
    }
    case "emblem": {
      if (!/^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(command.image) || command.image.length > 24e3) fail2("\u3082\u3046\u3044\u3061\u3069 \u306A\u305E\u3063\u3066\u306D\u3002");
      if (!/^[0-9A-Za-z]$/.test(command.glyph)) fail2("\u3082\u3046\u3044\u3061\u3069 \u306A\u305E\u3063\u3066\u306D\u3002");
      state.emblem = { image: command.image, glyph: command.glyph };
      break;
    }
    case "ack-moment": {
      if (state.surprise?.pending?.day === command.day) delete state.surprise.pending;
      break;
    }
    case "flag": {
      if (command.color !== void 0) {
        if (!Number.isInteger(command.color) || command.color < 0 || command.color > 7) fail2("\u3044\u308D\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        state.flagColor = command.color;
      }
      if (command.pattern !== void 0) {
        if (islandLevel(state) < STYLE_LEVEL.flagPattern) fail2("\u307E\u3060 \u3048\u3089\u3079\u306A\u3044\u3088\u3002");
        if (!Number.isInteger(command.pattern) || command.pattern < 0 || command.pattern >= FLAG_PATTERNS) fail2("\u3082\u3088\u3046\u3092 \u3048\u3089\u3073\u306A\u304A\u3057\u3066\u306D\u3002");
        state.flagPattern = command.pattern;
      }
      break;
    }
  }
  if (state.bridge && !reachableFromHome(state).has(key2(bridgeAnchor(state))))
    fail2("\u306F\u3057\u307E\u3067 \u3044\u3051\u306A\u304F\u306A\u308B\u3088\u3002\u307E\u308F\u308A\u3092 \u3042\u3051\u3066\u306D\u3002");
  return events;
}
function applyIntent(previous, intent, at, world) {
  if (previous.applied.includes(intent.id)) return { state: previous, events: [] };
  const state = structuredClone(previous);
  const events = apply(state, intent.command, world);
  if (["plant", "place", "move", "store", "unstore", "pluck", "expand"].includes(intent.command.type) && state.town.bank > 0)
    events.push(...openTown(state, world));
  noteTownBuilds(state, events);
  noteGuidanceIntent(previous, state, intent.command, intent.id, at);
  const now = at ?? state.nature.realAt;
  if (intent.command.type === "place-used") recordPlaceUse(state, intent.command, now, world);
  if (intent.command.type === "place-shown") recordPlaceShown(state, intent.command, world);
  syncPlaceMilestones(state, now, world);
  state.applied = [...state.applied, intent.id].slice(-RULES.appliedMemory);
  return { state, events };
}
function canPlace(state, cell, except, world) {
  if (!onLand(state, cell, world) || world && !hasAuthoredPlacementSupport(world, cell)) return false;
  if (isVacant(state, cell, except, world)) return true;
  const found = occupant(state, cell, except);
  return found?.type === "plot" && found.spread;
}
function canReachHomePlacement(state, cell, id, world) {
  if (!canPlace(state, cell, id, world)) return false;
  const preview = structuredClone(state);
  const home = preview.plots.find((p) => p.id === id);
  if (home) home.cell = cell;
  else preview.plots.push({ id: "placement-preview", kind: "home", cell, stage: 0, plantedAt: 0, growth: 0, origin: "seed", paid: 0 });
  return isReachable(cell, reachableFromHome(preview, void 0, world), world);
}
export {
  applyIntent,
  approachCells,
  authoredWorldFrame,
  canPlace,
  compileWorldDefinition,
  derivePlaces,
  hasAuthoredPlacementSupport,
  key2 as key,
  landCells2 as landCells,
  reachableFromHome,
  treeAge,
  walkableCells,
  withNative05WaterCarvingScope
};
